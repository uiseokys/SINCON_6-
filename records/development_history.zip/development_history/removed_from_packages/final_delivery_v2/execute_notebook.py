"""Execute every code cell using only the Python standard library plus notebook deps.

This is a socket-free cell runner, not a Jupyter kernel. No cells are skipped.
Example: python -B execute_notebook.py . --hedges
"""
from __future__ import annotations
import argparse
from contextlib import redirect_stdout, redirect_stderr
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import platform
try:
    import resource
except ImportError:
    resource = None
import sys
from time import perf_counter
import traceback


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def execute(package, hedges=False, root_override=False):
    package = package.resolve()
    notebook_path = package / "SINCON_final_step2_layers.ipynb"
    notebook = json.loads(notebook_path.read_text(encoding="utf-8"))
    executed = copy.deepcopy(notebook)
    namespace = {"__name__": "__main__"}
    os.chdir(package)
    sys.dont_write_bytecode = True
    input_paths = [p for d in ["cache", "reference", "data", "input"] for p in (package / d).rglob("*") if p.is_file()]
    input_paths += [package / name for name in ["final_layers.py", "event_hedges.py", "delivery_runtime.py", "delivery_manifest.json"]]
    before = {str(p.relative_to(package)): sha(p) for p in input_paths}
    # Prove the relocated execution cannot read the original project or use a network.
    read_roots = [package, Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve()]
    def audit(event, args):
        if event.startswith("socket.") and event in {"socket.connect", "socket.bind", "socket.getaddrinfo"}:
            raise PermissionError("노트북 검증은 네트워크와 소켓을 사용하지 않습니다")
        if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).resolve()
            mode = args[1]
            flags = args[2] if len(args) > 2 else 0
            writing = (isinstance(mode, str) and any(x in mode for x in "wax+")) or (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT))
            if writing and not path.is_relative_to(package):
                raise PermissionError("패키지 밖 쓰기 차단")
            if not writing and path != Path("/dev/null") and not any(path.is_relative_to(r) for r in read_roots):
                raise PermissionError("원본 폴더를 포함한 패키지 밖 데이터 읽기 차단: " + path.name)
    sys.addaudithook(audit)
    starts = perf_counter()
    records = []
    succeeded = True
    count = 0
    def clean(text):
        for real, alias in [(str(package), "<PACKAGE>"), (str(Path(sys.prefix).resolve()), "<VENV>"),
                            (str(Path(sys.base_prefix).resolve()), "<PYTHON>")]:
            text = text.replace(real, alias)
        return text
    for index, cell in enumerate(executed["cells"]):
        if cell["cell_type"] != "code":
            continue
        count += 1
        source = "".join(cell["source"])
        output = io.StringIO()
        cell_start = perf_counter()
        cell["execution_count"] = count
        try:
            with redirect_stdout(output), redirect_stderr(output):
                exec(compile(source, f"SINCON_final_step2_layers.ipynb:cell_{index}", "exec"), namespace)
                if "settings" in cell["metadata"].get("tags", []):
                    if hedges:
                        namespace["ENABLE_HEDGES"] = True
                    if root_override:
                        namespace["ROOT"] = str(package)
        except Exception:
            succeeded = False
            output.write(traceback.format_exc())
        cell["outputs"] = [{"output_type": "stream", "name": "stdout", "text": clean(output.getvalue()).splitlines(keepends=True)}]
        records.append(dict(cell=index, execution_count=count, tags=cell["metadata"].get("tags", []),
                            seconds=perf_counter() - cell_start, success=succeeded))
        if not succeeded:
            break
    elapsed = perf_counter() - starts
    after = {str(p.relative_to(package)): sha(p) for p in input_paths}
    unchanged = before == after
    suffix = "hedges" if hedges else "main"
    target = package / "verification" / ("executed_" + suffix)
    target.mkdir(parents=True, exist_ok=False)
    (target / "notebook.executed.ipynb").write_text(json.dumps(executed, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report = dict(success=succeeded and unchanged, all_code_cells_executed=count == sum(c["cell_type"] == "code" for c in notebook["cells"]),
                  execution_backend="standard-library sequential compile/exec; no Jupyter kernel",
                  notebook_sha256=sha(notebook_path), settings_override={"ENABLE_HEDGES": hedges, "ROOT_explicit": root_override},
                  code_cells_executed=count, elapsed_seconds=elapsed,
                  peak_rss_bytes=(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if platform.system() == "Darwin" else 1024)) if resource else None,
                  platform=dict(system=platform.system(), release=platform.release(), machine=platform.machine(), cpu_count=os.cpu_count()),
                  input_hashes_before=before, inputs_unchanged=unchanged,
                  data_reads_restricted_to_relocated_package=True, network_and_socket_blocked=True, cells=records)
    if "result" in namespace:
        report["notebook_result"] = namespace["result"]
    (target / "execution.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    log = "\n".join("".join(c["outputs"][0]["text"]) for c in executed["cells"] if c["cell_type"] == "code" and c.get("outputs"))
    (target / "execution.log").write_text(log, encoding="utf-8")
    print(json.dumps({k: report[k] for k in ["success", "all_code_cells_executed", "code_cells_executed", "elapsed_seconds", "peak_rss_bytes", "inputs_unchanged"]}, indent=2))
    if not succeeded:
        print(clean(output.getvalue()))
    if not report["success"]:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path)
    parser.add_argument("--hedges", action="store_true")
    parser.add_argument("--explicit-root", action="store_true")
    args = parser.parse_args()
    execute(args.package, args.hedges, args.explicit_root)
