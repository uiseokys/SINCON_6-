"""Exercise all six public switches on the real relocated data, without training."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np


def main(package, output):
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("delivery_runtime", package / "delivery_runtime.py")
    rt = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rt)
    module = rt.load_module(package / "final_layers.py", "accepted_final_layers")
    data, _ = rt.find_data(package)
    clean = rt.read_csv(package / "reference/submission_clean_refined.csv")
    grid = rt.read_csv(data / "test.csv")
    cases = [("none", set()), ("all", set(module.LAYER_NAMES))]
    cases += [("only_" + name, {name}) for name in module.LAYER_NAMES]
    cases += [("without_" + name, set(module.LAYER_NAMES) - {name}) for name in module.LAYER_NAMES]
    rows = []
    for name, enabled in cases:
        frame, deltas, report = module.build_submission(data, package / "cache", package / "reference/submission_clean_refined.csv", enabled)
        rt.validate_submission(frame, grid)
        for disabled in set(module.LAYER_NAMES) - enabled:
            if not deltas[disabled].eq(0).all():
                raise AssertionError("꺼진 층에 변화가 있습니다")
        changed = int((frame.boardings.to_numpy() != clean.boardings.to_numpy()).sum())
        expected = {"none": 0, "only_timecapsule": 3, "only_plave_existing": 4,
                    "only_friday": 2016, "only_plave22": 2, "only_lunar3122": 36}
        if name in expected and changed != expected[name]:
            raise AssertionError("층별 대상 행 수가 다릅니다: " + name)
        comparison = rt.compare(frame, package / "reference/submission_night_v4_main.csv", grid)
        if name == "all" and comparison["max_abs_log1p_difference"] > 1e-10:
            raise AssertionError("주후보 재현 차이")
        rows.append(dict(case=name, changed_rows_from_clean=changed, valid=True,
                         max_abs_log1p_difference_from_main=comparison["max_abs_log1p_difference"]))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(dict(cases=rows, all_passed=True), stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(f"{len(rows)}개 스위치 조합 모두 통과")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    main(args.package.resolve(), args.output.resolve())
