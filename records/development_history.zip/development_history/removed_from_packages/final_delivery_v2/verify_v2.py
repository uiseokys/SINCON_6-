"""Check input tolerance, frozen hashes, changed IDs, and bounded discovery offline.

Usage: python -B verify_v2.py RELOCATED_PACKAGE CLAUDE_CSV OUTPUT_JSON
The relocated package must contain official CSVs. All scratch files stay below it.
"""
from pathlib import Path
import argparse,ast,hashlib,importlib.util,json,shutil,sys
import numpy as np


def run(package,claude_csv,output):
    sys.dont_write_bytecode=True
    spec=importlib.util.spec_from_file_location('v2_runtime',package/'delivery_runtime.py')
    rt=importlib.util.module_from_spec(spec);spec.loader.exec_module(rt)
    grid=rt.read_csv(package/'data/test.csv')
    reference=package/'reference/submission_clean_refined.csv'
    clean=rt.read_csv(reference)
    scratch=package/'.validation/boundary_checks';scratch.mkdir(parents=True,exist_ok=False)
    checks=[]
    def record(name,check):
        check();checks.append(dict(name=name,passed=True))
    def rejects(name,check,expected=ValueError):
        try:check()
        except expected:checks.append(dict(name=name,passed=True));return
        raise AssertionError('Expected rejection: '+name)
    exact=rt.verify_baseline(reference,reference,grid,rt.sha256(reference))
    assert exact['acceptance']=='sha256_exact'
    checks.append(dict(name='exact SHA accepted',passed=True))
    real=rt.verify_baseline(claude_csv,reference,grid,rt.sha256(reference))
    assert real['acceptance']=='numeric_equivalence' and real['input_sha256']!=real['reference_sha256']
    checks.append(dict(name='actual Claude Python 3.11 CSV accepted',passed=True))
    def write(name,frame):
        p=scratch/(name+'.csv');frame.to_csv(p,index=False);return p
    mutations={
        'wrong_row_count':clean.iloc[:-1],
        'wrong_id_order':clean.iloc[::-1].reset_index(drop=True),
        'duplicate_id':clean.assign(example_id=clean.example_id.where(clean.index!=1,clean.example_id.iloc[0])),
        'negative':clean.assign(boardings=clean.boardings.where(clean.index!=0,-1.)),
        'infinite':clean.assign(boardings=clean.boardings.where(clean.index!=0,np.inf)),
        'nan':clean.assign(boardings=clean.boardings.where(clean.index!=0,np.nan)),
        'wrong_columns':clean.rename(columns={'boardings':'prediction'}),
        'above_1e_9':clean.assign(boardings=clean.boardings.where(clean.index!=0,np.expm1(np.log1p(clean.boardings.iloc[0])+2e-9))),
    }
    for name,frame in mutations.items():
        path=write(name,frame)
        rejects(name,lambda p=path:rt.verify_baseline(p,reference,grid,rt.sha256(reference)))
    near=clean.copy();near.loc[0,'boardings']=np.expm1(np.log1p(near.loc[0,'boardings'])+5e-10)
    near_path=write('within_tolerance_synthetic_only',near)
    accepted=rt.verify_baseline(near_path,reference,grid,rt.sha256(reference))
    assert 1e-10<accepted['max_abs_log1p_difference']<=1e-9
    checks.append(dict(name='subthreshold synthetic input accepted',passed=True))
    context=rt.prepare(package,str(near_path))
    assert context['baseline']==near_path
    layers=context['layers_module']
    none,_,_=layers.build_submission(package/'data',package/'cache',near_path,set())
    assert abs(np.log1p(none.boardings.iloc[0])-np.log1p(clean.boardings.iloc[0]))>1e-10
    checks.append(dict(name='calculation uses supplied input, no reference substitution',passed=True))
    main,deltas,report=layers.build_submission(package/'data',package/'cache',near_path)
    rejects('final main still enforces 1e-10',lambda:rt.finish(context,main,deltas,report))
    rejects('direct layer API rejects above tolerance',lambda:layers.build_submission(package/'data',package/'cache',scratch/'above_1e_9.csv',set()))
    # Check corrupted byte rejection; always restore the scratch package after each case.
    for name in ['cache/calendar.csv','reference/submission_clean_refined.csv','official_inputs.json']:
        target=package/name;before=target.read_bytes()
        try:
            target.write_bytes(before+b'\n')
            rejects('strict hash '+name,lambda:rt.verify_inputs(package))
        finally:target.write_bytes(before)
    official=package/'data/test.csv';before=official.read_bytes()
    try:
        official.write_bytes(before+b'\n')
        rejects('strict official CSV hash',lambda:rt.find_data(package),FileNotFoundError)
    finally:official.write_bytes(before)
    # Test both implementations against the same fake trees; drive and symlinks are pruned.
    tree=scratch/'search';tree.mkdir()
    wanted={}
    for depth in range(6):
        directory=tree
        for i in range(depth):directory=directory/('d'+str(i))
        directory.mkdir(parents=True,exist_ok=True)
        for filename in ['train.csv','delivery_manifest.json']:(directory/filename).touch()
        wanted[depth]=directory
    drive=tree/'drive';drive.mkdir();(drive/'train.csv').touch();(drive/'delivery_manifest.json').touch()
    (tree/'alias').symlink_to(wanted[5],target_is_directory=True)
    found=rt.bounded_matches(tree,'train.csv',3,('drive',))
    assert {p.parent for p in found}=={wanted[i] for i in range(4)}
    found=rt.bounded_matches(tree,'train.csv',4,('drive',))
    assert {p.parent for p in found}=={wanted[i] for i in range(5)}
    notebook=json.loads((package/'SINCON_final_step2_layers.ipynb').read_text())
    parsed=ast.parse(''.join(notebook['cells'][2]['source']))
    function=next(node for node in parsed.body if isinstance(node,ast.FunctionDef) and node.name=='bounded_packages')
    namespace={'os':__import__('os'),'Path':Path}
    exec(compile(ast.Module(body=[function],type_ignores=[]),'<notebook-discovery>','exec'),namespace)
    for depth in [3,4]:
        assert set(namespace['bounded_packages'](tree,depth,('drive',)))=={wanted[i].resolve() for i in range(depth+1)}
    checks.append(dict(name='both discovery functions obey depth 3/4, skip drive, skip symlinks',passed=True))
    expected=rt.read_csv(package/'evidence/hedges_15_current_review.csv')
    main=rt.read_csv(package/'reference/submission_night_v4_main.csv')
    candidate,assumptions=rt.apply_hedges(main,rt.read_csv(package/'data/test.csv',parse_dates=['date']),package)
    changed=candidate.boardings.ne(main.boardings)
    assert changed.sum()==15 and set(candidate.loc[changed,'example_id'])==set(expected.example_id)
    assert candidate.loc[candidate.example_id.isin(['J093670','J094948']),'boardings'].equals(main.loc[main.example_id.isin(['J093670','J094948']),'boardings'])
    assert assumptions.round11_judgment.value_counts().to_dict()=={'근거 부족':13,'지지':2}
    checks.append(dict(name='exact 15 changed IDs, PLAVE22 unchanged, 2 support/13 insufficient',passed=True))
    result=dict(all_passed=True,checks=checks,claude_input_verification=real,
                synthetic_inputs='boundary tests only; never candidate tuning',
                environment=dict(python=sys.version.split()[0],numpy=np.__version__,pandas=rt.pd.__version__))
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(f'{len(checks)} input/discovery/hedge checks passed')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package',type=Path);parser.add_argument('claude_csv',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();run(args.package.resolve(),args.claude_csv.resolve(),args.output.resolve())
