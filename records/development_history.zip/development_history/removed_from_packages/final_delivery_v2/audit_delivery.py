"""Static Linux portability and distribution checks; this does not run Linux."""
import ast
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
EXCLUDED = {".validation", "outputs", "__pycache__"}


def distribution_files(root=ROOT):
    return sorted(p for p in root.rglob("*") if p.is_file()
                  and not set(p.relative_to(root).parts).intersection(EXCLUDED)
                  and p.name not in {"SINCON_final_delivery.zip", "SINCON_final_delivery_v2.zip", "DISTRIBUTION.json", "FILE_LIST.tsv"}
                  and p.suffix != ".pyc")


def audit():
    problems = []
    files = distribution_files()
    names = [str(p.relative_to(ROOT)) for p in files]
    if len(set(x.casefold() for x in names)) != len(names):
        problems.append("대소문자 구분 없는 이름 충돌")
    absolute_prefix = "/" + "Users" + "/"
    checked_text = 0
    preserved_csv_crlf = []
    code_imports = set()
    for path in files:
        if path.name in {"train.csv", "test.csv", "metaData.csv"}:
            problems.append("공식 CSV가 배포 대상에 포함됨: " + str(path.relative_to(ROOT)))
        if path.suffix in {".py", ".md", ".txt", ".csv", ".tsv", ".json", ".ipynb"}:
            raw = path.read_bytes()
            checked_text += 1
            try:
                content = raw.decode("utf-8")
            except UnicodeDecodeError:
                problems.append("UTF-8 아님: " + path.name)
                continue
            if b"\r" in raw:
                if path.suffix == ".csv" and b"\r" not in raw.replace(b"\r\n", b""):
                    preserved_csv_crlf.append(str(path.relative_to(ROOT)))
                else:
                    problems.append("지원하지 않는 줄바꿈: " + str(path.relative_to(ROOT)))
            if absolute_prefix in content:
                problems.append("개인 절대 경로: " + str(path.relative_to(ROOT)))
        if path.suffix == ".py":
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=path.name)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    code_imports.update(x.name.split(".")[0] for x in node.names)
                if isinstance(node, ast.ImportFrom) and node.module:
                    code_imports.add(node.module.split(".")[0])
    external = code_imports - set(sys.stdlib_module_names) - {p.stem for p in files if p.suffix == ".py"}
    if external - {"numpy", "pandas"}:
        problems.append("추가 외부 의존성: " + repr(external))
    notebook = json.loads((ROOT / "SINCON_final_step2_layers.ipynb").read_text(encoding="utf-8"))
    ids = [cell.get("id") for cell in notebook["cells"]]
    if None in ids or len(set(ids)) != len(ids):
        problems.append("노트북 cell ID 누락 또는 중복")
    for index, cell in enumerate(notebook["cells"]):
        if cell["cell_type"] == "code":
            ast.parse("".join(cell["source"]), filename=f"notebook:{index}")
    settings = "".join(notebook["cells"][1]["source"])
    if "ENABLE_HEDGES = False" not in settings:
        problems.append("절충 기본 꺼짐 설정 없음")
    input_manifest = json.loads((ROOT / "delivery_manifest.json").read_text(encoding="utf-8"))
    for name, expected in input_manifest["files"].items():
        target = ROOT / name
        if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest() != expected:
            problems.append("동결 파일 누락·변경: " + name)
    for p in (ROOT / "verification").glob("py*/*/executed_*/execution.json"):
        report = json.loads(p.read_text(encoding="utf-8"))
        if report["notebook_sha256"] != hashlib.sha256((ROOT / "SINCON_final_step2_layers.ipynb").read_bytes()).hexdigest():
            problems.append("실행 증거와 노트북 해시가 다름")
    native_extensions = [str(p.relative_to(ROOT)) for p in files if p.suffix in {".so", ".dylib", ".dll", ".pyd"}]
    if native_extensions:
        problems.append("배포본 안에 OS 전용 확장 모듈이 있음: " + repr(native_extensions))
    result = dict(passed=not problems, problems=problems, utf8_lf_text_files_checked=checked_text,
                  casefold_paths_unique=True, third_party_imports=sorted(external),
                  notebook_code_cells=sum(c["cell_type"] == "code" for c in notebook["cells"]),
                  official_csv_excluded=True, native_extensions_in_delivery=bool(native_extensions),
                  preserved_csv_crlf=preserved_csv_crlf,
                  linux_execution="미실행; 정적 점검만", kaggle_execution="미실행", colab_execution="미실행",
                  notes=["POSIX/Windows 경로는 pathlib 사용. Kaggle·Colab 경로는 환경별 탐색.",
                         "실행기는 resource가 없는 OS에서 RSS를 생략. 노트북은 resource에 의존하지 않음.",
                         "원본 CSV 두 개의 CRLF는 해시 보존을 위해 유지. pandas와 csv의 CSV 파서가 처리하며 코드 셀/모듈은 LF.",
                         "numpy/pandas의 Linux wheel 신규 설치 및 Linux 연산은 이번에 실행하지 않음."])
    target = ROOT / "verification/static_audit.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if problems:
        raise SystemExit(1)


if __name__ == "__main__":
    audit()
