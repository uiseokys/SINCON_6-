"""Create a deterministic ZIP and file manifest. Excludes raw competition CSV."""
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZipInfo

from audit_delivery import distribution_files

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build():
    summary = ROOT / "PACKAGE_CONTENTS.md"
    if not summary.exists():
        summary.write_text("", encoding="utf-8")
    for _ in range(5):
        files = distribution_files(ROOT)
        contents = ("# 배포 파일의 크기\n\n"
                    f"FILE_LIST.tsv 자체를 제외한 배포 파일 {len(files):,}개, "
                    f"{sum(p.stat().st_size for p in files):,}바이트, "
                    f"{sum(p.stat().st_size for p in files)/2**20:.3f}MiB입니다.\n\n"
                    "FILE_LIST.tsv에는 상대 경로·바이트 수·SHA-256을 기록했습니다. "
                    "자기 파일의 해시는 자기 참조를 피하기 위해 목록에서 제외합니다. "
                    "ZIP에는 FILE_LIST.tsv도 포함합니다. ZIP의 정확한 크기와 SHA는 "
                    "ZIP 바깥 DISTRIBUTION.json에 있습니다.\n\n"
                    "공식 train.csv·test.csv·metaData.csv, input/의 사용자 CSV, "
                    "임시 검증 폴더 .validation/, 실행 후 outputs/, ZIP 자체와 "
                    "외부 sidecar DISTRIBUTION.json은 배포 입력 목록에서 제외합니다. "
                    "이번 배포본의 data/와 input/에는 안내 문서만 있습니다.\n")
        if summary.read_text(encoding="utf-8") == contents:
            break
        summary.write_text(contents, encoding="utf-8")
    files = distribution_files(ROOT)
    for path in files:
        if path.name in {"train.csv", "test.csv", "metaData.csv"} or ("input" in path.relative_to(ROOT).parts and path.suffix == ".csv"):
            raise ValueError("공식 또는 사용자 원본 CSV를 ZIP에 넣을 수 없습니다")
    listing = ROOT / "FILE_LIST.tsv"
    with listing.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow(["relative_path", "bytes", "sha256"])
        for path in files:
            writer.writerow([str(path.relative_to(ROOT)), path.stat().st_size, sha(path)])
    archive = ROOT / "SINCON_final_delivery_v2.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(files + [listing]):
            name = "final_delivery_v2/" + str(path.relative_to(ROOT))
            info = ZipInfo(name, date_time=(2026, 11, 13, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    info = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
                archive_members=len(files) + 1, files_listed=len(files), file_list_sha256=sha(listing),
                official_csv_included=False, temporary_validation_included=False,
                root_directory="final_delivery_v2", self_referential_exclusions=["FILE_LIST.tsv", "DISTRIBUTION.json", archive.name])
    (ROOT / "DISTRIBUTION.json").write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(info, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
