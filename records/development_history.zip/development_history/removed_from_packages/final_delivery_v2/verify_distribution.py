"""Read every archived byte and verify its length/hash against FILE_LIST.tsv."""
import csv
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent


def main():
    distribution = json.loads((ROOT / "DISTRIBUTION.json").read_text(encoding="utf-8"))
    archive = ROOT / distribution["archive"]
    if hashlib.sha256(archive.read_bytes()).hexdigest() != distribution["sha256"]:
        raise AssertionError("ZIP SHA-256 불일치")
    final_execution = distribution.get("final_archive_execution")
    if final_execution and (not final_execution["all_passed"]
                            or final_execution["tested_archive_sha256"] != distribution["sha256"]):
        raise AssertionError("최종 ZIP 실행 기록의 해시 또는 통과 상태 불일치")
    with ZipFile(archive) as z:
        prefix = distribution["root_directory"] + "/"
        listing = z.read(prefix + "FILE_LIST.tsv").decode("utf-8")
        rows = list(csv.DictReader(io.StringIO(listing), delimiter="\t"))
        expected_names = {prefix + row["relative_path"] for row in rows} | {prefix + "FILE_LIST.tsv"}
        if set(z.namelist()) != expected_names or len(z.namelist()) != len(expected_names):
            raise AssertionError("ZIP 파일 목록 또는 중복 불일치")
        for row in rows:
            name = row["relative_path"]
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise AssertionError("안전하지 않은 상대 경로")
            if Path(name).name in {"train.csv", "test.csv", "metaData.csv"}:
                raise AssertionError("공식 CSV가 ZIP에 있음")
            content = z.read(prefix + name)
            if len(content) != int(row["bytes"]) or hashlib.sha256(content).hexdigest() != row["sha256"]:
                raise AssertionError("ZIP 내용 해시 불일치: " + name)
            if (ROOT / name).read_bytes() != content:
                raise AssertionError("현재 배포 폴더와 ZIP 불일치: " + name)
        manifest = json.loads(z.read(prefix + "delivery_manifest.json"))
        if not set(manifest["files"]).issubset({r["relative_path"] for r in rows}):
            raise AssertionError("실행에 필요한 파일이 ZIP에 없음")
    print(f"ZIP {len(rows)+1}개 항목의 실제 바이트·크기·SHA-256 모두 통과. 공식 CSV 없음.")


if __name__ == "__main__":
    main()
