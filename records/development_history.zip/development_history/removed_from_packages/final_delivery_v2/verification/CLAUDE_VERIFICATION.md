# Claude가 확인한 표준 kernel 실행

### 표준 Jupyter kernel 실행, Claude 검증

- v1 ZIP을 빈 폴더에 풀고 jupyter nbconvert --execute로 절충 꺼짐·켜짐을 실행했습니다. Python 3.14.6, numpy 2.5.4, pandas 3.0.6에서 주후보·당시 17행 후보 모두 기준 대비 바뀐 행 0입니다. v2 15행 후보 실행으로 확대해 쓰지 않습니다.
- 1단계 final_package/SINCON_final.ipynb를 새 Python 3.11.17 환경의 표준 kernel에서 설치 셀부터 6개 코드 셀 전부 실행했습니다. numpy 2.3.5, pandas 3.1.1, xgboost 3.1.2, torch 2.9.1, assemble 4단계 약 45초입니다. 기준 대비 최대 log1p 차이 8.88e-16, 0이 아닌 log 차이 106행, 1e-12 초과 0행으로 수치 일치·바이트 불일치입니다.
- 위 1단계 출력 SHA는 eea4b781f8bafaab76c5cd86b1dec826904d9406c4be23823e486ccc00aeee5b, 기준은 519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199입니다. Codex는 이 실제 CSV의 읽기 전용 원본을 v2 임시 폴더에 복사해 1단계→2단계 연결을 시험합니다. 수치 차이 행 수는 파서와 log 계산 환경에 따라 달라질 수 있어 각 실행 JSON에 따로 기록합니다.

위 실행 사실은 작업 지시로 전달받은 Claude 검증입니다. Codex의 직접 실행 결과와 구분합니다. 원시 모델 전체 재학습이나 Kaggle·Colab·Linux 실기 기록은 아닙니다.
