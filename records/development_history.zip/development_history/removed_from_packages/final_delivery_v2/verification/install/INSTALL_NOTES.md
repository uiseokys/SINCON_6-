# 오프라인 설치

기존 읽기 전용 uv 추출 wheel 캐시를 코드 변경 없이 wheel로 다시 묶었다. 새 Python 3.11·3.12 가상환경을 system site packages 없이 만들고 pip --no-index --no-cache-dir --find-links로 설치했다. 네트워크 설치는 시도하지 않았다. 실제 wheel 해시와 설치 목록을 이 폴더에 기록했다. wheel·가상환경·공식 CSV 복사본은 .validation/ 안에만 있고 ZIP에서 제외한다.
