# 1단계 결과를 쓰는 위치

final_package/SINCON_final.ipynb의 assemble 모드 결과 submission_clean_refined.csv를 여기에 놓으세요. 없으면 reference/의 동봉 기준을 씁니다. 기준 SHA가 같거나, 157,194행·공식 ID 순서·고유성·유한·비음수이고 동봉 기준과 최대 log1p 차이가 1e-9 이하이면 허용합니다. 수치 동등성으로 허용하면 두 SHA·차이·다른 행 수를 출력하고 verification.json에 기록합니다. 제공한 CSV로 계산하며 기준으로 대체하지 않습니다. 1e-9를 넘는 재학습 결과는 별도 검토가 필요합니다. 최종 주후보·15행 후보의 재현 허용오차 1e-10은 그대로입니다. 캐시·공식 CSV·동봉 기준 해시는 엄격히 검사합니다.
