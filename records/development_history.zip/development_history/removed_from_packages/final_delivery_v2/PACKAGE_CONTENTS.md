# 배포 파일의 크기

FILE_LIST.tsv 자체를 제외한 배포 파일 133개, 60,352,375바이트, 57.557MiB입니다.

FILE_LIST.tsv에는 상대 경로·바이트 수·SHA-256을 기록했습니다. 자기 파일의 해시는 자기 참조를 피하기 위해 목록에서 제외합니다. ZIP에는 FILE_LIST.tsv도 포함합니다. ZIP의 정확한 크기와 SHA는 ZIP 바깥 DISTRIBUTION.json에 있습니다.

공식 train.csv·test.csv·metaData.csv, input/의 사용자 CSV, 임시 검증 폴더 .validation/, 실행 후 outputs/, ZIP 자체와 외부 sidecar DISTRIBUTION.json은 배포 입력 목록에서 제외합니다. 이번 배포본의 data/와 input/에는 안내 문서만 있습니다.
