# 보고서 이력

ROUND11_RESULT.txt의 중첩 표와 현재 15행 검토가 v2의 검증 설명 기준이다. ROUND2·3·5·7·FINAL_REPORT 등 앞선 스냅샷의 검증 수치·17행 표는 당시 이력이다. 소급 OOF는 조건부 재계산이며 현재 독립 검증 표로 인용하지 않는다. 감사9번 오류의 현재 교정은 ../../DOCUMENT_CORRECTIONS.md를 따른다. 원 보고서의 절대 경로는 <PROJECT>·<TEAM>으로 치환했다.
