"""Copy accepted inputs and build the reviewable notebook. Never writes to sources."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def copy_assets(project, team):
    sources = {
        "final_layers.py": project / "night7/final_layers.py",
        "event_hedges.py": team / "event_hedges.py",
        "reference/submission_clean_refined.csv": project / "final_package/reference/submission_clean_refined.csv",
        "reference/submission_night_v4_main.csv": team / "submission_night_v4_main.csv",
        "reference/submission_night_v4_events_hedged.csv": team / "submission_night_v4_events_hedged.csv",
        "evidence/hedges_17_judgments_round7_original.csv": project / "night7/event_validation_v2/hedges_17_judgments.csv",
        "evidence/CC_ATTRIBUTION.csv": project / "night6/resourced/CC_ATTRIBUTION.csv",
        "evidence/sports_field_comparison.csv": project / "night6/resourced/comparisons/sports_field_comparison.csv",
        "evidence/sports_unresolved_and_differences.csv": project / "night6/resourced/comparisons/sports_unresolved_and_differences.csv",
    }
    for path in sorted((project / "night7/cache").iterdir()):
        if path.is_file():
            sources["cache/" + path.name] = path
    for name, source in sources.items():
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if digest(source) != digest(target):
                raise FileExistsError("동결 입력 변경: " + name)
        else:
            shutil.copyfile(source, target)
    records = [{"source": str(p.relative_to(project)) if p.is_relative_to(project) else "team/" + p.name,
                "destination": name, "bytes": p.stat().st_size, "sha256": digest(p)}
               for name, p in sources.items()]
    write_json(ROOT / "provenance.json", records)
    # Keep source text available without embedding private workstation paths.
    reports = ["night/ROUND2_RESULT.md", "night3/ROUND3_RESULT.md", "night5/ROUND5_RESULT.md",
               "night7/ROUND7_RESULT.md", "night_sources/SOURCES_AUDIT.md", "night6/SOURCES_FINAL.md",
               "RULES_NOTICE_PUBLIC_SCORE.md", "SINCON_PUBLIC_SCORE_AUDIT.md"]
    snapshots = ROOT / "evidence/reports"
    snapshots.mkdir(parents=True, exist_ok=True)
    for name in reports + ["FINAL_REPORT.md"]:
        source = team / name if name == "FINAL_REPORT.md" else project / name
        content = source.read_text(encoding="utf-8")
        content = re.sub("/" + "Users" + r"/[^\s`\"'<>)]*", "[원본 로컬 경로 생략]", content)
        (snapshots / (Path(name).stem + ".txt")).write_text(
            "원문 참고용 스냅샷. 개인 절대 경로만 가렸습니다. 상대 링크는 원 작업 폴더 기준입니다.\n\n" + content,
            encoding="utf-8")
    original = (project / "night6/SOURCES_FINAL.md").read_text(encoding="utf-8")
    section = original.split("## 노트북용 출처 표\n", 1)[1].split("## 야구 차이와 실제 피처", 1)[0]
    section = section.replace("resourced/CC_ATTRIBUTION.csv", "evidence/CC_ATTRIBUTION.csv")
    section = section.replace("resourced/comparisons/sports_field_comparison.csv", "evidence/sports_field_comparison.csv")
    (ROOT / "SOURCES.md").write_text(
        "# 외부 자료의 출처와 남은 확인\n\n"
        "night6의 노트북용 표를 옮겼습니다. 이번 작업에서 웹을 다시 조회하지 않았습니다. "
        "허용 확인은 표에 적힌 자료·필드 범위에 한정됩니다. "
        "대체 자료의 확보·일치 대조가 원 수집 경로 전체의 교체를 뜻하지는 않습니다.\n\n" + section,
        encoding="utf-8")


def make_manifest():
    paths = [ROOT / "final_layers.py", ROOT / "event_hedges.py", ROOT / "delivery_runtime.py",
             ROOT / "official_inputs.json", ROOT / "evidence/hedges_17_judgments_round7_original.csv"]
    paths += sorted((ROOT / "cache").glob("*")) + sorted((ROOT / "reference").glob("*.csv"))
    write_json(ROOT / "delivery_manifest.json", {
        "format": 1, "clean_sha256": digest(ROOT / "reference/submission_clean_refined.csv"),
        "files": {str(p.relative_to(ROOT)): digest(p) for p in paths if p.is_file()},
        "official_csv_included": False,
    })


def make_notebook():
    cells = []
    def markdown(text):
        cells.append(dict(cell_type="markdown", metadata={}, source=text.splitlines(keepends=True)))
    def code(text, tag):
        cells.append(dict(cell_type="code", metadata={"tags": [tag]}, execution_count=None, outputs=[], source=text.splitlines(keepends=True)))

    markdown("""# SINCON 2026 핫식스 · 2단계 최종 보정

1단계 `SINCON_final.ipynb`가 만든 `submission_clean_refined.csv`에 승인된 6개 층을 순서대로 적용합니다. 기본 출력은 **주후보**입니다. `ENABLE_HEDGES=False`를 유지하면 검증되지 않은 절충안은 만들지 않습니다.

필요한 것은 이 패키지와 공식 `train.csv`, `test.csv`, `metaData.csv`입니다. 공식 CSV는 재배포하지 않습니다. `data/`에 직접 넣거나 Kaggle의 공식 Dataset을 연결하세요. `input/submission_clean_refined.csv`가 있으면 그 1단계 결과를 우선 읽고, 없으면 동봉 기준을 씁니다. 승인된 기준의 SHA-256만 허용하므로 재학습으로 달라진 파일을 조용히 대체하지 않습니다.

실행 의존성은 numpy와 pandas뿐입니다. 설치가 필요하면 노트북 밖에서 `python -m pip install -r requirements.txt`를 실행하세요. 이 노트북에는 다운로드·Kaggle 업로드·Public 점수 조회 코드가 없습니다. 승차 정답은 2026-06-30까지 공식 train만 사용합니다. 7월 이후 행사·날씨·달력 사실과 지하철 승하차 실측은 다른 자료입니다.

상위 모델 재학습의 완료 여부는 1단계 패키지의 최신 STATUS에서 확인해야 합니다. 이 노트북의 성공은 2단계 재현을 의미하며, 전체 모델 재학습이나 대회 미래 정확도를 입증하지 않습니다. 실행법은 README, 출처 조건은 SOURCES, 이번 실제 실행 범위는 STATUS를 참고하세요.
""")
    code('''# 경로를 수동 지정할 때 바꾸는 변수는 ROOT 하나입니다. 빈 값은 자동 탐색입니다.
ROOT = ""
BASELINE_CSV = ""  # 선택: 패키지 기준 상대 경로. 기본은 input/ 우선, 없으면 reference/.
ENABLED = dict(timecapsule=True, plave_existing=True, station025=True, friday=True, plave22=True, lunar3122=True)
ENABLE_HEDGES = False  # 검증되지 않은 추정 17행. 별도 후보가 필요할 때만 True.
''', "settings")
    code('''import sys
sys.dont_write_bytecode = True
from pathlib import Path
import importlib.util
import json
from time import perf_counter

started = perf_counter()
if ROOT:
    package = Path(ROOT).expanduser().resolve()
else:
    candidates = []
    for base in (Path.cwd(), Path.cwd() / "final_delivery", Path("/kaggle/input"), Path("/content")):
        if (base / "delivery_manifest.json").is_file():
            candidates.append(base.resolve())
        elif base in (Path("/kaggle/input"), Path("/content")) and base.is_dir():
            candidates.extend(p.parent.resolve() for p in sorted(base.rglob("delivery_manifest.json")))
    candidates = list(dict.fromkeys(candidates))
    if len(candidates) != 1:
        raise ValueError("패키지 폴더를 ROOT 한 줄에 지정하세요. 발견된 패키지 수: " + str(len(candidates)))
    package = candidates[0]
if not (package / "delivery_manifest.json").is_file():
    raise FileNotFoundError("ROOT는 delivery_manifest.json이 있는 폴더여야 합니다")
spec = importlib.util.spec_from_file_location("sincon_delivery_runtime", package / "delivery_runtime.py")
rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
context = rt.prepare(package, BASELINE_CSV)
print("패키지:", package)
print("공식 CSV:", context["data"])
print("1단계 입력:", context["baseline"].name)
print(json.dumps(context["environment"], ensure_ascii=False, indent=2))
''', "prepare")
    markdown("""## 승인된 순서와 스위치

각 층은 `ENABLED`의 해당 `True`를 `False`로 한 줄 수정해 끌 수 있습니다. 끈 결과는 승인된 주후보와 다른 실험 파일로 저장합니다. 다음 셀은 원 `night7/final_layers.py`의 바이트 동일 복사본을 불러 계산합니다. 원 모듈은 캐시 해시, 정답 날짜, OOF 시간 순서와 공식 정답 일치를 확인합니다. 층을 끄면 역별 오차도 남아 있는 앞선 행사층에 맞춰 다시 적합합니다.

| 순서 | 스위치 | 대상 | 작동 |
|---|---|---|---|
| 1 | timecapsule | 7/11 송도달빛축제공원 21~23시 3행 | 과거 같은 공연 초과분 75%의 하한 |
| 2 | plave_existing | 9/12~13 문학 21~22시 4행 | 과거 공연 합계 쪽으로 log 차이 35%, 상한 0.50 |
| 3 | station025 | 전체 역 | 앞선 OOF 최근 60일 평균 오차를 중심화해 0.25배 차감 |
| 4 | friday | 7/17·10/9 2,016행 | 금요일 공휴일의 역별 상대 차이, 시간별 중심화, log ±0.05 |
| 5 | plave22 | 9/12~13 문학 22시 2행 | 평소 + 과거 22시 비율 × 지정 예매 수 |
| 6 | lunar3122 | 9/24~25 부평삼거리 36행 | 평소 일요일 대비 과거 명절 전날·당일 전이 |

모든 연산은 이 순서입니다. `plave22`는 앞선 22시 예측을 대체합니다. 전 단계의 변화가 그대로 합산된다고 해석하면 안 됩니다. 아래 검증 수치는 보관 보고서에서 측정된 것이며 이 노트북에서 과거 검증을 새로 실행한 수치가 아닙니다.
""")
    code('''main, deltas, layer_report = context["layers_module"].build_submission(
    context["data"], package / "cache", context["baseline"],
    enabled={name for name, enabled in ENABLED.items() if enabled},
)
print(rt.layer_table(deltas, layer_report).to_string(index=False))
''', "build_layers")
    explanations = [
        ("timecapsule", """## 1. 누락된 타임캡슐 공연 3행

7/11 공연이 기존 행사 목록에 빠져 있었습니다. 2025-06-14 같은 공연의 21~23시 실제 272/489/88에서 평소 80/78/55를 뺍니다. 올해 평소 102/77/58에 초과분의 0.75를 더한 246/385.25/82.75를 하한으로 씁니다. 이 값은 역별 보정 전 값입니다.

| 보관 검증 | 측정 RMSLE | 한계 |
|---|---|---|
| 펜타포트·맥주축제 36행, summer | 1.697556589 → 1.414320016 | 같은 12일을 다른 origin에서 반복 검증 |
| 같은 36행, 2025-07-31 origin | 1.726618182 → 1.399029261 | 고유 변경 키 24개, 같은 시리즈 기증 공연 1건 |

0.75는 기존 아시아드 규칙을 유지했습니다. 새 행사 정답이나 Public 점수로 맞추지 않았습니다. 사실 개최 확인과 자료 이용 허락은 별개이며 타임캡슐의 일부 출처 확인은 남아 있습니다. 근거는 ROUND2입니다.
"""),
        ("plave_existing", """## 2. 기존 PLAVE 4행

과거 문학 대형 공연의 21·22시 합계를 시리즈마다 중앙값으로 집계하고 시리즈 간 중앙값을 구합니다. 현재 하루 두 시간 예측 합계와의 log 차이 0.35배를 두 행에 더하되 0~0.50으로 제한합니다. 계수는 기존 방법 그대로입니다.

| 보관 검증 | 측정 결과 | 한계 |
|---|---|---|
| YE·MUSE·진·박효신, 14행 | RMSLE 2.079960524 → 1.657658006, 13/14행 개선 | 4개 공연 계열의 작은 부분집합 |

매 과거 origin에서 기증 공연 전체가 이미 끝난 경우만 사용했습니다. 22시를 나중에 다시 바꾸더라도 이 층은 역별 오차 적합에도 영향을 줍니다. 근거는 ROUND2입니다.
"""),
        ("station025", """## 3. 역별 최근 오차 60일·0.25배

최종 적합에는 2026-05-02~06-30의 앞선 origin 예측 오차만 씁니다. 가장 늦은 origin은 2026-04-30입니다. 역별 평균 오차에서 역간 평균을 빼고 그 0.25배를 차감합니다. 표본 360행 이상인 역만 보정하며 전체 수준 상수는 더하지 않습니다.

| 보관 검증 | 측정 결과 | 한계 |
|---|---|---|
| 행사층 이후 8개 origin | 7/8개선, Δ −0.004343960~−0.000249749 | origin 구간이 서로 겹침 |
| B, 2025-12-31 | Δ +0.001572662로 악화 | 미래 모든 계절 개선을 보장하지 않음 |

OOF 라벨은 공식 train에서 다시 연결해 캐시와 비교합니다. 겹치는 과거 예측을 그대로 포함하는 승인된 프로토콜을 유지합니다. 근거는 ROUND2입니다.
"""),
        ("friday", """## 4. 금요일 공휴일 2,016행

과거 금요일 3일 연휴의 log 실측과 주변 ±42일 평소 금요일 중앙값 차이를 구합니다. 목표일 예측의 같은 대비 차이를 빼고, 시간별 역간 평균을 0으로 맞춘 뒤 0.20배 적용합니다. 최종 절대 log 변화는 0.05 이하입니다. log 0.05는 count의 정확히 5%가 아니라 약 5.13% 증가에 해당합니다. 행사 제외 15역과 보호 역·날짜는 유지합니다.

| 보관 검증 | 노출 행 RMSLE | 한계 |
|---|---|---|
| summer / 2025-07-31, 2025-08-15 | .218975464→.216520455 / .183296996→.179771367 | 같은 날짜를 반복 예측 |
| A / 2026-03-31 / 04-30, 2026-05-01 | .156458892→.155691769 / .149289198→.148297489 / .149551214→.148457444 | 독립 날짜는 2개 |

발동한 5개 구간에서 개선했습니다. 다른 공휴일 전체로 확대하지 않았습니다. 목표 7/17과 10/9는 각각 1,008행입니다. 근거는 ROUND3입니다.
"""),
        ("plave22", """## 5. PLAVE 22시 2행만 대체

과거 공연별 `(22시 실제−평소)/관객 대용치`를 계열별 중앙값으로 모읍니다. 계열 비율 Q25와 Q50의 기하평균 0.1732267021을 씁니다. 최종은 토요일 평소 21.5 + 비율×23,120, 일요일 평소 15 + 비율×19,494입니다. 21·23시는 유지합니다.

| 보관 검증, 22시 5행 | 보관 OOF / 기존식 재구성 / 제안 | 한계 |
|---|---|---|
| 계열 제외 | 2.572896 / 2.083644 / 0.605504 | 관객 수를 알고 있다는 조건 |
| 시간 순서 | 2.572896 / 2.083644 / 0.589066 | 현재 round2 전체의 정확한 OOF가 아님 |

6행 전체 시간 배분은 시간 순서 검증에서 실패해 쓰지 않았습니다. 예매 수량과 과거 관객 대용치의 정의가 다르고 예매 수량 원출처는 팀원 확인이 남았습니다. 버스 비중은 계수 계산에 쓰지 않았습니다. 과거 계열 수가 적고 MUSE에는 여전히 과대예측합니다. 근거는 ROUND5입니다.
"""),
        ("lunar3122", """## 6. 부평삼거리 추석 전날·당일 36행

인천가족공원 접근역의 명절 성묘 수요를 옮깁니다. 주변 ±35일 평소 일요일의 목표 예측 log 중앙값에 과거 명절 같은 상대일의 실제 log 차이 평균을 더합니다. 과거 기증일과 그 일요일 실측은 모두 origin 이하로 제한합니다. 9월 24·25일의 18시간씩만 대체합니다.

| 보관 검증 | 측정 결과 | 한계 |
|---|---|---|
| 발동 6개 origin의 전체 RMSLE | 모두 개선, Δ −0.000552~−0.000133 | 독립 수령 명절은 2회, 고유 변경 72행 |
| C / B 전체 | .159530→.159398 / .165979→.165775 | ROUND5 22시를 OOF 전체에 붙인 점수는 아님 |
| origin 이후 실측 log에 1000을 더한 시간 순서 검사 | 12개 명절 일자 예측 변화 0 | 이번 실행이 아닌 ROUND7 독립 검사 |

원 코드의 미래 일요일 혼입을 제거한 검증 결과입니다. 최종 origin에서는 값이 변하지 않았습니다. 과거 명절 당일은 수·월·화요일이어서 목표 금요일을 직접 검증하지 못했습니다. 06~07·18~23시를 묶으면 C와 B가 악화했고 다음날 보정도 제외했습니다. 새 창·계수를 탐색하지 않았습니다. 근거는 ROUND7입니다.
"""),
    ]
    for name, explanation in explanations:
        markdown(explanation)
        code(f'rt.show_layer("{name}", deltas, layer_report)\n', "layer_" + name)
    markdown("""## 선택 셀 · 검증되지 않은 추정 17행

기본은 꺼져 있습니다. `ENABLE_HEDGES=True`로 바꾸면 주후보 외에 별도 파일 하나를 더 만듭니다. 주후보는 그대로 저장합니다. 아래 가정의 W와 시간 배분은 독립 시간 순서 검증을 통과하지 못했습니다. Public 점수로 수치를 선택하지 않습니다.

| 현재 별도 후보의 가정 | FULL 계산 | log1p 혼합 W |
|---|---|---|
| PLAVE 9/12·13 21/22/23시 | 토 평소63/21/5, 일24/15/4 + 예매23,120/19,494 ×0.30 ×10%/85%/5% | 0.7 |
| Sustainable 8/29·30 20/21/22/23시 | 토 평소150/63/21/5, 일37/24/15/4 + 가정12,000명 ×0.30 ×10%/20%/45%/25% | 0.5 |
| 랜더스10/17 20/21/22시 | 전년 같은 행사 초과분을 규모·종료차로 옮긴 진단 2,199/4,102/860명을 FULL로 지정 | 0.5 |

계산은 `exp((1−W)×log1p(현재)+W×log1p(FULL))−1`입니다. 관객 12,000명, 퇴장 비중, 혼합 W는 검증되지 않은 추정입니다. 0.30이 과거 야구 비율 범위 안에 있다는 사실이 개별 공연의 비중과 W를 검증하지는 않습니다.

**검토 버전 차이:** 7번 당시 PLAVE 비중은 3%/85%/12%, 랜더스 FULL은 3,255/3,513/366이었습니다. 현재 제공된 `event_hedges.py`는 각각 10%/85%/5%와 2,199/4,102/860을 씁니다. 아래 7번 표는 수정하지 않은 원 판정입니다. 현재 값에 대한 새 검증 통과 판정으로 읽으면 안 됩니다. 이 노트북은 사용자가 지정한 현재 별도 CSV를 재현합니다.

7번 결론은 17행 모두 주후보 추가 보류입니다. PLAVE의 종료 시각만으로 안정적인 비중을 얻지 못했고 0.255의 FULL 22시 계수는 채택 계수보다 약 47% 큽니다. Sustainable의 12,000명·비중·W는 동종 과거 사례가 부족합니다. 랜더스 20시의 과도한 앞당김은 '과함', 나머지는 '근거 부족' 판정입니다. 같은 시리즈 한 회차를 옮긴 현재 랜더스 진단도 독립 검증된 최종값은 아닙니다.
""")
    with (ROOT / "evidence/hedges_17_judgments_round7_original.csv").open(encoding="utf-8", newline="") as stream:
        old = list(csv.DictReader(stream))
    table = ["| ID | 행사 | 날짜 | 시 | 당시 주후보 | 당시 절충 | 당시 FULL | 당시 비중 | W | 7번 원 판정 |", "|---|---|---|---|---|---|---|---|---|---|"]
    for row in old:
        table.append("| " + " | ".join(row[k] for k in ["example_id", "event", "date", "hour", "current", "hedged", "full", "share", "weight", "judgment"]) + " |")
    markdown("\n".join(table) + "\n\n원 CSV에는 ratio_judgment, shape_judgment, mix_judgment와 대안 문구까지 그대로 보관했습니다. 선택 셀을 켜면 현재 17행의 모든 계산 가정과 당시 판정을 나란히 출력하고 CSV로 저장합니다.\n")
    code('''if ENABLE_HEDGES:
    optional_candidate, assumptions = rt.apply_hedges(main, context["grid"], package)
    print(assumptions.to_string(index=False))
else:
    print("선택 셀 꺼짐. 17행 절충안은 검증되지 않은 추정입니다.")
''', "optional_hedges")
    markdown("""## 저장 후 형식과 기준 차이 확인

157,194행, 공식 example_id 순서와 중복, 유한·비음수, CSV 저장 후 값 보존을 검사합니다. `SHA-256`은 파일 바이트 식별자입니다. 부동소수점 직렬화가 다르면 수치가 거의 같아도 해시는 다를 수 있어 최대 log1p 차이를 함께 출력합니다. 기준 후보 대비 차이는 미래 정답 오차가 아닙니다.

매 실행은 새 시각 이름 폴더에 저장하므로 기존 파일을 덮어쓰지 않습니다. Kaggle은 `/kaggle/working`, Colab은 `/content`, 로컬은 패키지의 `outputs/`를 사용합니다. 출력에는 후보 CSV, 층별 전 행 변화, JSON 검증 결과가 있습니다.
""")
    code('''result = rt.finish(context, main, deltas, layer_report, enable_hedges=ENABLE_HEDGES)
print("전체 코드 셀 계산 경과 초:", round(perf_counter() - started, 3))
''', "verify_save")
    markdown("""## 출처와 재현 범위

외부 자료 이용 조건은 SOURCES.md의 night6 노트북용 표를 유지합니다. 날씨·NEIS·달력·비철도 생활이동·공개 버스/역 자료·TabICL의 허락 확인 범위, 스포츠 대체 출처 대조, 주거·취소·축제 미확인을 구분해야 합니다. 예매 수량 원출처와 신규 보정 공지의 이용 허락도 남았습니다. 따라서 전체 제출 적합 판정을 완료했다고 쓰지 않습니다.

2단계에는 난수와 GPU가 없습니다. 실행한 Python·numpy·pandas·OS는 JSON에 남습니다. 상위 LightGBM·MLP·XGBoost·TabICL의 시드와 하드웨어 차이는 README에 따로 정리했습니다. Kaggle·Colab 실제 실행은 로컬 경로 검사와 구분하며, 미실행 항목은 STATUS에 표시했습니다.
""")
    for index, cell in enumerate(cells):
        cell["id"] = f"sincon-step2-{index:02d}"
    write_json(ROOT / "SINCON_final_step2_layers.ipynb", dict(
        cells=cells, metadata={"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                               "language_info": {"name": "python", "version": "3.11"}}, nbformat=4, nbformat_minor=5))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path)
    parser.add_argument("--team", type=Path)
    args = parser.parse_args()
    if args.project is not None and args.team is not None:
        copy_assets(args.project.resolve(), args.team.resolve())
    make_manifest()
    make_notebook()
    print("동결 입력 매니페스트와 노트북을 만들었습니다.")
