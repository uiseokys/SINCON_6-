"""Rebuild notebook and current validation tables from the bundled evidence only."""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parent

def rows(name):
 with (ROOT/name).open(encoding='utf-8') as f:return list(csv.DictReader(f))
def table(headers,data):
 return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(str(v).replace('|','/') for v in row)+' |' for row in data])
def f(value):return f'{float(value):.9f}'
station=rows('evidence/round11/station_validation_nested.csv')
friday=rows('evidence/round11/friday_exposed_nested.csv')
lunar=rows('evidence/round11/lunar_validation_nested.csv')
hedges=rows('evidence/hedges_15_current_review.csv')
station_table=table(['origin','구분','중첩 기준 RMSLE','중첩 적용 RMSLE','Δ'],[[r['origin'],r['label'],f(r['reference']),f(r['candidate']),f(r['delta'])] for r in station])
friday_table=table(['origin','노출 날짜','행','중첩 기준 RMSLE','중첩 적용 RMSLE','Δ'],[[r['origin'],r['date'],r['rows'],f(r['reference']),f(r['candidate']),f(r['delta'])] for r in friday])
lunar_table=table(['origin','구분','변경 행','중첩 기준 RMSLE','중첩 적용 RMSLE','Δ'],[[r['origin'],r['label'],r['changed_rows'],f(r['reference']),f(r['candidate']),f(r['delta'])] for r in lunar if int(r['changed_rows'])])
hedges_table=table(['ID','행사','날짜','시','주후보','15행 후보 값','FULL','W','11번 판정'],[[r['example_id'],r['event'],r['date'],r['hour'],f'{float(r["current_main"]):.6f}',f'{float(r["current_hedged"]):.6f}',f'{float(r["FULL"]):.6f}',f'{float(r["W"]):.1f}',r['judgment']] for r in hedges])
correction='보관 원시 예측에서 기준일마다 그 시점까지의 정답만으로 층 채택을 다시 정한 순방향 OOF를 만들었다. 최근 60일·0.25배 역별 층은 유효 8개 기준일 중 7개 개선했고 B는 악화했다. 금요일 층은 발동 5개 기준일에서, 부평삼거리 층은 발동 6개 기준일에서 개선했다. 기준일별 평가기간이 겹치며 금요일은 두 날짜, 명절은 두 회차다. 기존 OOF는 최종 채택 구성을 소급한 조건부 재계산으로 구분한다. 최종 역별 보정은 두 적합법의 최대 log 차이가 0.000067407이어서 기존값을 유지했다.'
input_policy='1단계 CSV는 기준 SHA가 같거나, 157,194행·고유 example_id·공식 순서·유한·비음수이고 동봉 기준과 최대 log1p 차이가 1e-9 이하일 때 허용합니다. 수치 동등성으로 허용하면 차이·다른 행 수·입력과 기준 SHA를 출력하고 verification.json에 기록합니다. 계산에는 제공된 CSV를 그대로 씁니다. 차이가 1e-9를 넘으면 중단하며 재학습 결과는 별도 검토가 필요합니다. 캐시·공식 CSV·동봉 기준의 해시는 엄격히 검사합니다. 6개 층을 켠 주후보와 선택 15행 후보는 각각 기준 대비 최대 log1p 차이 1e-10 이하여야 합니다.'
order=table(['순서','스위치','대상','작동'],[
[1,'timecapsule','7/11 송도달빛축제공원 21~23시 3행','같은 시리즈 과거 초과분 75% 하한'],
[2,'plave_existing','9/12~13 문학 21~22시 4행','과거 공연 합계로 log 차이 35%, cap .50'],
[3,'station025','전체 역','최근 60일 역별 평균 오차를 중심화해 .25배 차감'],
[4,'friday','7/17·10/9 2,016행','역간 상대 차이, 시간별 중심화, log ±.05'],
[5,'plave22','9/12~13 문학 22시 2행','평소+과거 22시 비율×지정 예매'],
[6,'lunar3122','9/24~25 부평삼거리 36행','평소 일요일 대비 전날·당일 전이']])
history='17행 버전은 이력입니다. PLAVE 22시 두 행을 다시 올리며 11번 판정은 그 두 행이 과함, 나머지가 지지 2·근거 부족 13입니다. 7번 옛 표는 PLAVE 3%/85%/12%, 랜더스 FULL 3,255/3,513/366을 사용한 당시 검토여서 현재 판정으로 인용하지 않습니다. 17행 기준 CSV·현재 17행 검토는 evidence/history/, 7번 원 판정은 evidence/hedges_17_judgments_round7_original.csv에 보존했습니다.'
assumptions='''PLAVE는 21시 10%·23시 5%만 계산하고 22시는 주후보를 유지합니다. Sustainable은 가정 관객 12,000명, 20/21/22/23시 10%/20%/45%/25%, W=.5입니다. 랜더스 FULL은 기존 2,199/4,102/860, W=.5입니다. PLAVE W=.7을 포함해 계수는 새로 정하지 않았습니다. 혼합식은 `(1+현재)^(1−W) × (1+FULL)^W − 1`입니다. 평소 표는 반올림한 기존 정수입니다.

11번 판정은 지지 2행·근거 부족 13행입니다. 지지는 랜더스 21·22시의 상향 방향과 과거 규모만을 뜻하며 W의 독립 검증이 아닙니다. 시험기간 정답에 대한 성능은 미평가입니다. 박효신은 시작 시각과 실제 시간 비중만 참고했고 공연 길이는 미확인입니다. 2026-03-28~06-30 야구 36경기는 관중 기록이 있는 전 경기이며 매진은 그중 11경기입니다.'''
validation='''## 검증 표를 읽는 기준

'''+correction+'''

중첩 표는 11번의 보관 원시 예측에서 재조립한 검증입니다. 이번 전달 작업에서 모델이나 OOF를 다시 학습한 결과가 아닙니다. 감사 F1의 세 층 채택 판단을 cutoff 이전 정답으로 다시 정했지만 원시 모델의 전 생애·그 밖의 사후 선택까지 해소한 독립 홀드아웃은 아닙니다. 최종 잔차 적합은 승인된 최종 구성의 기존 cross-fit 캐시를 유지합니다.

### 역별 최근 60일·0.25배, 중첩 OOF

'''+station_table+'''

최초 summer는 이전 OOF가 없어 보정하지 않습니다. 평가기간은 겹칩니다.

### 금요일 층, 중첩 OOF의 실제 변경 1,008행

'''+friday_table+'''

발동 5개 origin이 고유 2025-08-15·2026-05-01 두 날짜를 반복 평가했습니다. 전체 기간 점수는 evidence/round11/friday_validation_nested.csv에 있습니다.

### 부평삼거리 층, 중첩 OOF 전체 기간

'''+lunar_table+'''

발동 6개 origin은 고유 명절 2025 추석·2026 설 두 회차이며, 216 OOF행은 고유 72개 키의 반복입니다. station025·friday 뒤의 점수이고 PLAVE22 최종 override를 OOF 전체에 적용한 점수는 아닙니다.

### 기존 수치는 조건부 재계산

최종 채택 구성을 소급한 조건부 재계산에서 역별 개선폭은 −.004343960~−.000249749, B는 +.001572662였습니다. 금요일 A 노출행은 .156458892→.155691769, 부평삼거리 C/B 전체는 .159530321→.159397712 / .165979241→.165774892였습니다. 위의 순방향 중첩 표와 구분합니다. 정확한 기존·중첩 CSV를 evidence/round11/에 함께 보관했습니다.

1단계 모델층 A/B/C의 중첩 RMSLE는 .150257683/.164782599/.161453202입니다. 기존 .149904003/.164576151/.161174942는 최종 채택 구성을 소급한 조건부 재계산이며 마지막 행사층 전체의 누적 점수도 아닙니다.
'''
(ROOT/'VALIDATION.md').write_text('# 층별 검증 근거\n\n'+validation,encoding='utf-8')

cells=[]
def md(text,id):cells.append(dict(cell_type='markdown',id=id,metadata={},source=text.strip().splitlines(keepends=True)))
def code(text,id,tags=None):cells.append(dict(cell_type='code',id=id,metadata={'tags':tags or []},source=text.strip().splitlines(keepends=True),execution_count=None,outputs=[]))
md('''# SINCON 2026 핫식스 · 최종 전달 2단계 v2

1단계 `final_package/SINCON_final.ipynb`의 `RUN_MODE="assemble"` 출력 `submission_clean_refined.csv`를 input/에 놓습니다. 없으면 동봉 기준을 사용합니다. 이 노트북은 승인된 6개 층으로 주후보를 만들고, 선택 셀을 켜면 별도로 15행 후보를 만듭니다.

'''+input_policy+'''

공식 train.csv·test.csv·metaData.csv는 data/에 직접 준비합니다. 새 다운로드·Kaggle 업로드·Public 점수 조회 코드는 없습니다. 정답은 2026-06-30까지 공식 train뿐이며 7월 이후 지하철 실측을 찾거나 쓰지 않습니다. 설치는 노트북 밖에서 requirements.txt로 합니다. 전체 재학습의 상태는 1단계 STATUS를 확인하세요.''','intro')
code('''# ROOT는 delivery_manifest.json이 있는 패키지 폴더입니다. 빈 값이면 제한 탐색합니다.
ROOT = ""
BASELINE_CSV = ""  # 패키지 기준 상대 경로 또는 절대 경로. 기본 input/ 우선, 없으면 reference/.
ENABLED = dict(timecapsule=True, plave_existing=True, station025=True, friday=True, plave22=True, lunar3122=True)
ENABLE_HEDGES = False  # 별도 15행 후보. True여도 주후보는 함께 저장합니다.''','settings',['settings'])
code('''import os
import sys
sys.dont_write_bytecode = True
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
from pathlib import Path
import importlib.util
import json
from time import perf_counter

started = perf_counter()
def bounded_packages(root, max_depth, skip_names=()):
    found = []
    if root.is_dir():
        for directory, children, files in os.walk(root, followlinks=False):
            current = Path(directory)
            depth = len(current.relative_to(root).parts)
            children[:] = sorted(name for name in children if name not in skip_names
                                 and depth < max_depth and not (current / name).is_symlink())
            if "delivery_manifest.json" in files:
                found.append(current.resolve())
    return found

if ROOT:
    package = Path(ROOT).expanduser().resolve()
else:
    candidates = [base.resolve() for base in (Path.cwd(), Path.cwd() / "final_delivery_v2")
                  if (base / "delivery_manifest.json").is_file()]
    candidates += bounded_packages(Path("/kaggle/input"), 4)
    candidates += bounded_packages(Path("/content"), 3, ("drive",))
    candidates = list(dict.fromkeys(candidates))
    if len(candidates) != 1:
        raise ValueError("ROOT에 패키지 폴더를 지정하세요. /content 깊이3·drive 제외, /kaggle/input 깊이4 탐색. 발견 수: " + str(len(candidates)))
    package = candidates[0]
if not (package / "delivery_manifest.json").is_file():
    raise FileNotFoundError("ROOT는 delivery_manifest.json이 있는 패키지 폴더여야 합니다")
spec = importlib.util.spec_from_file_location("sincon_delivery_runtime", package / "delivery_runtime.py")
rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
context = rt.prepare(package, BASELINE_CSV)
print("패키지:", package)
print("공식 CSV:", context["data"])
print("1단계 입력:", context["baseline"].name)
print(json.dumps(context["environment"], ensure_ascii=False, indent=2))''','prepare')
md('''## 승인된 순서와 스위치

'''+order+'''

ENABLED의 한 줄로 층을 끌 수 있습니다. 꺼진 조합은 EXPERIMENT_layers_disabled.csv이며 주후보로 표시하지 않습니다. 앞선 행사층 스위치에 따라 역별 오차도 다시 적합합니다. 수치 계산·계수는 v1 그대로이고 final_layers.py에서는 1단계 입력 검사와 입력 해시 기록만 바꿨습니다.

'''+correction,'layer-order')
code('''main, deltas, layer_report = context["layers_module"].build_submission(
    context["data"], package / "cache", context["baseline"],
    enabled={name for name, enabled in ENABLED.items() if enabled},
)
print(rt.layer_table(deltas, layer_report).to_string(index=False))''','build-main')
md('''## 1. 누락 타임캡슐 3행

7/11 누락 공연에 2025-06-14 같은 시리즈의 초과분 75% 하한을 적용합니다. 21~23시 실제 272/489/88, 평소 80/78/55, 목표 평소 102/77/58로 역별 보정 전 하한 246/385.25/82.75입니다.

보관 ROUND2의 summer 36행 RMSLE 1.697556589→1.414320016, 7/31 origin의 같은 36행 1.726618182→1.399029261입니다. 같은 12일의 반복 검증이며 같은 시리즈 기증은 1건입니다. 새 독립 홀드아웃은 아닙니다.''','timecapsule-doc')
code('rt.show_layer("timecapsule", deltas, layer_report)','timecapsule-show')
md('''## 2. 기존 PLAVE 4행

완결된 공연의 21·22시 합계를 계열별 중앙값과 계열 간 중앙값으로 모읍니다. 현재 합계와 log 차이 .35배를 두 행에 적용하고 0~.50으로 제한합니다. 보관 ROUND2의 4계열 14행 RMSLE 2.079960524→1.657658006, 13행 개선입니다. 작은 부분집합이며 나중 22시 대체와 단순 합산할 수 없습니다. 과거 예측 비교가 가능한 공연 날짜는 고유 7일이며 2025-03-20·21은 OOF가 없습니다.''','plave-existing-doc')
code('rt.show_layer("plave_existing", deltas, layer_report)','plave-existing-show')
md('''## 3. 역별 최근 오차 60일·0.25배

최종 적합은 2026-05-02~06-30, 최신 origin 2026-04-30입니다. 230,040개 예측 잔차에 고유 실측 키 76,680개가 반복 포함됩니다. 역별 평균 오차를 중심화해 .25배 차감하고 360행 이상인 역만 적용합니다. 공식 train으로 OOF 정답을 다시 연결합니다.

'''+station_table+'''

중첩 OOF 유효 8개 기준일 중 7개 개선·B 악화입니다. summer는 이전 OOF가 없어 보정하지 않습니다. 기존값은 최종 채택 구성을 소급한 조건부 재계산으로 VALIDATION.md에 분리했습니다. 두 적합법의 최대 log 보정 차이는 .000067407이며 승인된 기존 최종값을 유지합니다.''','station-doc')
code('rt.show_layer("station025", deltas, layer_report)','station-show')
md('''## 4. 금요일 공휴일 2,016행

주변 ±42일 평소 금요일 대비 과거 금요일 3일 연휴의 차이를 구합니다. 시간별 역간 평균을 0으로 맞춰 .20배 적용하고 log ±.05로 제한합니다. log .05는 1+승차 비율 약 +5.13%입니다. 행사 제외 15역과 보호 키를 유지합니다.

'''+friday_table+'''

표는 중첩 OOF의 실제 변경 1,008행입니다. 5개 기준일 모두 개선했지만 고유 날짜는 2개입니다. 최종 목표 7/17·10/9는 각 1,008행입니다. 전체 기간 표와 기존 조건부 재계산은 VALIDATION.md에 있습니다.''','friday-doc')
code('rt.show_layer("friday", deltas, layer_report)','friday-show')
md('''## 5. PLAVE 22시 2행

과거 계열별 `(22시 실제−평소)/관객 대용치`의 Q25·Q50 기하평균 .173226702067872를 씁니다. 토 평소 21.5+비율×23,120, 일 평소 15+비율×19,494입니다. 선택 후보에서도 두 행은 유지합니다.

보관 ROUND5의 22시 5행에서 OOF/기존식 재구성/시간 순서 제안 RMSLE는 2.572896/2.083644/.589066입니다. 관객을 안다는 조건의 작은 부분집합이며 현재 전체 후보의 정확한 OOF가 아닙니다. 6행 시간 배분은 시간순 검증에서 실패해 제외했습니다. 버스 비중은 계수 계산에 쓰지 않았고 예매 원출처·이용 조건은 미확인입니다.''','plave22-doc')
code('rt.show_layer("plave22", deltas, layer_report)','plave22-show')
md('''## 6. 부평삼거리 전날·당일 36행

주변 ±35일 평소 일요일 목표 예측 log 중앙값에 과거 명절 같은 상대일의 실제 log 차이 평균을 더합니다. 기증일과 그 주변 일요일 실측은 cutoff 이하로 자릅니다. 최종 9/24·25의 18시간씩만 대체합니다.

'''+lunar_table+'''

중첩 OOF 발동 6개 모두 개선했습니다. 고유 수령 명절은 2회이고 216 OOF행은 고유 키 72개의 반복입니다. station025·friday 뒤이며 PLAVE22를 OOF 전체에 붙인 점수는 아닙니다. 옛 미래 일요일 혼입을 제거해도 최종값은 같았습니다. 당일 금요일의 직접 과거 검증은 없고 시간 묶음은 C/B에서 악화해 제외했습니다.''','lunar-doc')
code('rt.show_layer("lunar3122", deltas, layer_report)','lunar-show')
md('''## 선택 셀 · 별도 15행 후보

ENABLE_HEDGES=True이면 submission_night_v5_events_hedged15.csv를 추가로 만듭니다. 주후보와 지정된 15행만 달라야 합니다. 비교 기준 SHA-256은 9b01382c398fa49c141c78da278e678e7930a75373a8dd1dafa1c2d076c74b6c입니다.

'''+assumptions,'optional-doc')
md(hedges_table+'''

값은 표시용 소수 6자리입니다. 계산은 반올림하지 않으며 전체 정밀도와 근거·한계는 evidence/hedges_15_current_review.csv에 있습니다.''','optional-table')
code('''if ENABLE_HEDGES:
    optional_candidate, assumptions = rt.apply_hedges(main, context["grid"], package)
    print(assumptions.to_string(index=False))
else:
    print("선택 셀 꺼짐. 별도 15행 후보는 W·시간 비중의 독립 검증이 없는 추정입니다.")''','optional-show')
md('''## 저장 후 검증

형식, ID 순서·고유성, 유한·비음수, 저장 후 값 보존을 검사합니다. 6개 층 주후보와 선택 후보는 각 동봉 기준 대비 최대 log1p 차이 1e-10 이하를 강제합니다. 15행의 정확한 변경 ID도 검사합니다. 입력을 수치 동등성으로 받아들인 내역은 verification.json의 baseline_verification에 남습니다.

매 실행은 새 시각 폴더입니다. Kaggle /kaggle/working, Colab /content, 로컬 outputs/를 사용합니다. SHA는 바이트 식별자이며 미래 정확도가 아닙니다.''','output-doc')
code('''result = rt.finish(context, main, deltas, layer_report, enable_hedges=ENABLE_HEDGES)
print("전체 코드 셀 계산 경과 초:", round(perf_counter() - started, 3))''','finish')
md('''## 이력·넣지 않은 것·확인 범위

'''+history+'''

12번의 모델층 증폭 규칙 세 가지는 모두 통과하지 못해 후보에 넣지 않았습니다.

출처 조건은 SOURCES.md, 감사9번 문서 교정은 DOCUMENT_CORRECTIONS.md, 실제 실행은 STATUS.md와 verification/을 확인하세요. Claude는 v1 ZIP의 표준 Jupyter kernel에서 주후보·17행 후보를 바뀐 행 0으로 확인했고, 1단계 Python 3.11 실환경의 표준 kernel에서는 수치 일치·바이트 불일치를 확인했습니다. 이는 Claude 검증이며 이번 Codex 셀 실행기 검사와 구분합니다. Kaggle·Colab·Linux 실기는 미실행입니다. 전체 모델 재학습·권리 확인 완료를 뜻하지 않습니다.''','scope')
notebook=dict(cells=cells,metadata=dict(kernelspec=dict(display_name='Python 3',language='python',name='python3'),language_info=dict(name='python',version='3.11')),nbformat=4,nbformat_minor=5)
(ROOT/'SINCON_final_step2_layers.ipynb').write_text(json.dumps(notebook,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

claude='''### 표준 Jupyter kernel 실행, Claude 검증

- v1 ZIP을 빈 폴더에 풀고 jupyter nbconvert --execute로 절충 꺼짐·켜짐을 실행했습니다. Python 3.14.6, numpy 2.5.4, pandas 3.0.6에서 주후보·당시 17행 후보 모두 기준 대비 바뀐 행 0입니다. v2 15행 후보 실행으로 확대해 쓰지 않습니다.
- 1단계 final_package/SINCON_final.ipynb를 새 Python 3.11.17 환경의 표준 kernel에서 설치 셀부터 6개 코드 셀 전부 실행했습니다. numpy 2.3.5, pandas 3.1.1, xgboost 3.1.2, torch 2.9.1, assemble 4단계 약 45초입니다. 기준 대비 최대 log1p 차이 8.88e-16, 0이 아닌 log 차이 106행, 1e-12 초과 0행으로 수치 일치·바이트 불일치입니다.
- 위 1단계 출력 SHA는 eea4b781f8bafaab76c5cd86b1dec826904d9406c4be23823e486ccc00aeee5b, 기준은 519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199입니다. Codex는 이 실제 CSV의 읽기 전용 원본을 v2 임시 폴더에 복사해 1단계→2단계 연결을 시험합니다. 수치 차이 행 수는 파서와 log 계산 환경에 따라 달라질 수 있어 각 실행 JSON에 따로 기록합니다.

위 실행 사실은 작업 지시로 전달받은 Claude 검증입니다. Codex의 직접 실행 결과와 구분합니다. 원시 모델 전체 재학습이나 Kaggle·Colab·Linux 실기 기록은 아닙니다.
'''
(ROOT/'verification/CLAUDE_VERIFICATION.md').write_text('# Claude가 확인한 표준 kernel 실행\n\n'+claude)
run_summary=ROOT/'verification/RUN_SUMMARY.md'
executed=run_summary.read_text() if run_summary.exists() else 'Codex v2 재검증 진행 중입니다. 결과 확정 후 이 표를 갱신합니다.\n'
README='''# SINCON 2026 핫식스 · 최종 전달 2단계 v2

## 아침에 실행하는 순서

### Kaggle

1. 준비된 1단계 final_package/SINCON_final.ipynb를 RUN_MODE="assemble"로 모두 실행합니다.
2. 그 출력 submission_clean_refined.csv를 추출한 final_delivery_v2/input/에 복사합니다. 공식 대회 CSV도 연결합니다.
3. SINCON_final_step2_layers.ipynb를 열고 ROOT를 패키지 폴더로 지정해 모두 실행합니다.
4. 필요하면 ENABLE_HEDGES=True로 별도 15행 후보를 만듭니다. /kaggle/working의 verification.json을 확인합니다. 이 작업은 업로드하지 않았습니다.

### Colab

1. 준비된 final_package/SINCON_final.ipynb를 RUN_MODE="assemble"로 모두 실행합니다.
2. 그 출력 CSV를 /content 아래에 푼 final_delivery_v2/input/에, 공식 세 CSV를 data/에 놓습니다.
3. 이 2단계 노트북에서 ROOT를 그 패키지 폴더로 지정해 모두 실행합니다. /content 탐색은 깊이 3이고 drive를 건너뜁니다.
4. 주후보 또는 ENABLE_HEDGES=True의 15행 후보와 /content의 verification.json을 확인합니다.

### 로컬

1. final_package/SINCON_final.ipynb를 RUN_MODE="assemble"로 모두 실행합니다.
2. 출력 CSV를 final_delivery_v2/input/에, 공식 train.csv·test.csv·metaData.csv를 data/에 복사합니다.
3. Python 3.11 또는 3.12 환경에서 python -m pip install -r requirements.txt를 실행합니다.
4. 이 노트북을 모두 실행하거나 python -B execute_notebook.py . 를 실행합니다. 별도 후보는 --hedges입니다.
5. outputs/의 새 시각 폴더와 verification.json을 확인합니다. 기존 실행 증거가 있으면 새 복사본에서 CLI 실행기를 씁니다.

위 Kaggle·Colab 안내는 실행 절차이며 실기 성공 기록은 아닙니다. 1단계 패키지는 이 ZIP에 포함하지 않았습니다.

## 입력과 출력

'''+input_policy+'''

기본 입력은 input/submission_clean_refined.csv, 없으면 reference/submission_clean_refined.csv입니다. BASELINE_CSV로 경로를 지정할 수도 있습니다. 출력은 주후보 submission_night_v4_main.csv이며 ENABLE_HEDGES=True이면 submission_night_v5_events_hedged15.csv도 만듭니다. 주후보는 승인된 6개 층을 유지합니다. 비교용 15행 기준 SHA는 9b01382c398fa49c141c78da278e678e7930a75373a8dd1dafa1c2d076c74b6c입니다. 시험기간 정답 검증이나 새 후보 보정은 하지 않습니다.

ROOT는 delivery_manifest.json이 있는 폴더입니다. 자동 탐색은 현재 폴더·그 아래 final_delivery_v2, /content 깊이 3 이내·drive 제외, /kaggle/input 깊이 4 이내입니다. 심볼릭 링크 폴더를 따라가지 않습니다. 못 찾거나 후보가 여럿이면 ROOT를 직접 지정합니다. 공식 데이터 자동 탐색에도 같은 깊이 제한을 적용합니다. 드라이브 안 패키지는 ROOT를 지정하고 공식 CSV를 그 data/에 둡니다.

직접 실행 의존성은 numpy·pandas와 그 필수 의존성입니다. 2단계는 모델 학습·GPU·난수·새 네트워크 입력을 쓰지 않습니다. 표준 라이브러리 실행기는 코드 셀 11개를 순서대로 실행하며 Jupyter kernel과 구분합니다. 노트북은 Jupyter에서도 열 수 있습니다. 스레드 환경 변수는 1로 제한합니다.

## 최종 예측이 만들어지는 순서

1단계는 LightGBM·임베딩 MLP와 생활이동·그래프·시간대·버스·경기·수요 혼합 모델을 조건별·로컬 스택으로 결합합니다. 행사·날씨·역별·심야 보정, 취소·장소 변경, 역 시간 프로필, TabICL, 동춘 휴업일, 음력 연휴 상대 수준, 검단 아침, 예측 시차 가중치, 18시간 벡터 XGBoost, 최종 행사층을 거쳐 clean CSV를 만듭니다. 일부 부분 재학습 성공을 전체 train부터 재학습 완료로 쓰지 않습니다. 최신 상태는 1단계 STATUS를 따릅니다.

2단계는 다음 순서를 유지합니다. 행 수는 각 층의 적용 순간이며 합산하지 않습니다. PLAVE22와 부평삼거리 층은 앞선 값을 대체합니다.

'''+order+'''

'''+validation+'''
## 선택 후보 15행

'''+assumptions+'''

'''+hedges_table+'''

표는 표시용 반올림입니다. 전체 값과 근거·한계는 evidence/hedges_15_current_review.csv에 있습니다. 실행 시 현재 값·FULL·W·11번 판정이 출력되고 hedges_15_current_assumptions.csv로 저장됩니다. PLAVE 22시 J093670·J094948은 주후보 값을 그대로 둡니다.

## 이력

'''+history+'''

## 넣지 않은 것

12번 모델층 증폭 규칙 세 가지는 모두 통과하지 못해 후보에 넣지 않았습니다. 17행 버전·폐기된 구조 하한·새 계수·Public 기반 조정은 현재 후보에 추가하지 않았습니다.

## 규칙과 출처의 남은 한계

이번 작업은 Public 점수로 값·스위치를 정하지 않았고 2026년 7월 이후 지하철 승하차 실측을 찾거나 쓰지 않았습니다. 새 웹 조회·다운로드·Kaggle 업로드도 하지 않았습니다. 승차 정답은 공식 train 2025-01-01~2026-06-30의 688,176행뿐입니다. test는 예측 키입니다. 캐시의 과거 라벨을 공식 train에 재연결해 검사합니다.

과거 경로의 Public 유래 전체 log +.021742424607211323, 후속 +.0090238206986512966, 역 패턴 배율 .62와 탐색 제출은 현재 입력에서 제외했습니다. 공연 조사 순서에 Public 차이를 참고한 과거 경위도 삭제하지 않습니다. 이력은 evidence/reports/RULES_NOTICE_PUBLIC_SCORE.txt와 SINCON_PUBLIC_SCORE_AUDIT.txt에 있습니다.

상위 경로의 7~10월 날씨·행사·비철도 생활이동 등 외생 정보는 6월에 미리 안 실시간 예측이라는 뜻이 아닙니다. 생활이동의 소비 교통수단은 버스·도보·차량이지만 공급자 내부의 간접 철도실측 보정은 독립 확인하지 못했습니다. PLAVE 버스 자료를 계산 입력이나 계수 산정에는 쓰지 않았으나 사람이 22시 집중을 참고한 이력은 남습니다.

외부 자료의 조건·45개 위키 출처·저작자표시는 SOURCES.md, LICENSE_NOTICES.md와 evidence/CC_ATTRIBUTION.csv를 보존했습니다. 일정 사실과 이용 허락은 다릅니다. 원수집 KBO 제한, 주거35단지·일부 행사·축제 확인 미완료, PLAVE 예매 원출처·이용 조건은 해결되지 않았습니다. CC 위키 대조를 입력 전체 교체·권리 해결로 설명하지 않습니다. 야구 +3명 3건만 바꾼 전용 트리 부분 실험은 변화 0행이고, 충돌 포함 4건은 630행·최대 log .1419061688·최대 572.4153명 차이입니다. 다수 원시 모델은 고정했습니다. 상세 문서 교정은 DOCUMENT_CORRECTIONS.md에 있습니다.

이 ZIP은 공개 재배포 허락이나 전체 제출 적합 판정의 완료가 아닙니다. 공식 원본 세 CSV는 동봉하지 않습니다. OOF 캐시는 공식 train 파생 라벨을 포함합니다.

## 실행해서 확인한 범위

'''+executed+'\n'+claude+'''
## 파일과 재실행

캐시·동봉 기준 CSV·실행 코드·문서를 함께 보관합니다. 파일별 바이트·SHA는 FILE_LIST.tsv, 크기는 PACKAGE_CONTENTS.md, ZIP 바이트·SHA는 ZIP 바깥 DISTRIBUTION.json입니다. build_distribution.py가 재생성하고 verify_distribution.py가 실제 ZIP 전체 바이트를 검산합니다. verify_layer_switches.py는 14개 조합을, verify_v2.py는 입력 허용·거부와 탐색 경계를 검사합니다.

verification/은 v2 직접 실행 증거이고 verified_outputs/는 실제 생성된 주후보·15행 후보·검증 JSON입니다. .validation/은 공식 CSV 복사본·wheel·가상환경·실행용 임시 패키지를 보관하는 로컬 검증 폴더이며 ZIP에서 제외합니다. data/와 input/에는 배포 안내만 있습니다. 이 폴더 전체를 직접 업로드하지 말고 공식 CSV가 제외된 배포 ZIP의 파일 목록을 확인하세요.

현재 상태와 못 한 것은 STATUS.md, v1 대비 변경은 CHANGES_FROM_V1.md에 있습니다. Kaggle·Colab·Linux 실기·전체 모델 재학습은 이번 Codex 작업에서 실행하지 않았습니다.
'''
(ROOT/'README.md').write_text(README,encoding='utf-8')
print('Refreshed notebook: 11 code cells; nested validation and current 15-row tables')
if __name__=='__main__':pass
