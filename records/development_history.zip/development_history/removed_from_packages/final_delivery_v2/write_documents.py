"""Generate documentation from measured delivery verification and preserved reports."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def render():
    results = []
    for p in sorted((ROOT / "verification").glob("py*/executed_*/execution.json")):
        d = json.loads(p.read_text(encoding="utf-8"))
        results.append((p, d))
    if len(results) != 4 or not all(d["success"] and d["all_code_cells_executed"] for _, d in results):
        raise ValueError("최종 4개 실행의 측정 결과가 필요합니다")
    runs = ["| Python | numpy / pandas | 절충 | 전체 코드 셀 | 실행 초 | 최대 RSS MiB | 주후보 최대 log1p 차이 | 별도 후보 최대 log1p 차이 |",
            "|---|---|---|---|---|---|---|---|"]
    for _, d in results:
        n = d["notebook_result"]
        e, out = n["environment"], n["outputs"]
        optional = out.get("hedged")
        hedge_diff = f'{optional["comparison"]["max_abs_log1p_difference"]:.16g}' if optional else "미생성"
        runs.append(f'| {e["python"]} | {e["numpy"]} / {e["pandas"]} | {bool(optional)} | {d["code_cells_executed"]}/11 | {d["elapsed_seconds"]:.3f} | {d["peak_rss_bytes"]/2**20:.1f} | {out["main"]["comparison"]["max_abs_log1p_difference"]:.16g} | {hedge_diff} |')
    run_table = "\n".join(runs)
    sizes = ["| 필요한 파일 | 바이트 | MiB | 역할 |", "|---|---|---|---|"]
    items = [("cache/final_stage_oof.csv.gz", "상위 모델의 검증 예측과 train 유래 log 라벨"),
             ("reference/submission_clean_refined.csv", "1단계 동봉 기준"),
             ("reference/submission_night_v4_main.csv", "주후보 비교 전용"),
             ("reference/submission_night_v4_events_hedged.csv", "별도 후보 비교 전용")]
    for name, role in items:
        size = (ROOT / name).stat().st_size
        sizes.append(f"| {name} | {size:,} | {size/2**20:.3f} | {role} |")
    cache_other = sum(p.stat().st_size for p in (ROOT / "cache").iterdir() if p.name != "final_stage_oof.csv.gz")
    sizes.append(f"| 나머지 cache/ 7개 | {cache_other:,} | {cache_other/2**20:.3f} | 달력·행사·보호키·해시 |")
    specs = json.loads((ROOT / "official_inputs.json").read_text(encoding="utf-8"))
    for name, item in specs.items():
        size = item["bytes"]
        sizes.append(f"| data/{name}, 사용자가 별도 준비 | {size:,} | {size/2**20:.3f} | ZIP에 미포함 |")
    size_table = "\n".join(sizes)
    source_table = (ROOT / "SOURCES.md").read_text(encoding="utf-8").split("\n\n", 2)[2]
    readme = """# SINCON 2026 핫식스 · 최종 전달 2단계

`SINCON_final_step2_layers.ipynb`를 모두 실행하면 승인된 주후보 `submission_night_v4_main.csv`를 만듭니다. 기본 설정은 6개 층을 모두 켜고 검증되지 않은 절충 17행은 끕니다. 이 패키지는 Kaggle에 업로드하지 않았습니다.

## 1단계에서 2단계로 실행하기

전체 흐름은 `공식 train → 1단계 SINCON_final.ipynb → submission_clean_refined.csv → 이 2단계 노트북 → 주후보`입니다. 선택 스위치를 켜면 주후보와 별도로 `submission_night_v4_events_hedged.csv`도 만듭니다.

1단계 노트북과 모델 학습 파일은 다른 작업의 `final_package/`에 있습니다. 이 배포 ZIP에는 포함하지 않았습니다. 1단계의 `RUN_MODE="assemble"` 결과를 `input/submission_clean_refined.csv`에 놓으세요. 이 파일이 없으면 `reference/`의 동봉 기준을 씁니다. 승인 기준 SHA-256은 `519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199`입니다.

2단계는 이 해시가 다른 입력에서 중단합니다. 숫자가 같고 CSV 직렬화만 달라도 중단할 수 있습니다. 1단계 `full` 재학습으로 달라진 예측에는 기존 OOF 캐시를 그대로 붙여도 되는지 새 검토가 필요합니다. 2단계의 캐시 재현 성공을 전체 모델 재학습 성공으로 쓰지 마세요.

### Kaggle Notebook에서 실행하기

1. `SINCON_final_delivery.zip`을 풉니다. 그 안의 `final_delivery/`가 한 개의 Dataset 폴더 구조입니다. 공식 대회 CSV는 포함되어 있지 않습니다.
2. 팀이 자료 이용 조건을 확인한 뒤 이 폴더를 비공개 Dataset으로 직접 연결하고, 공식 대회 Dataset도 별도로 연결합니다. 이 작업에서는 업로드하지 않았습니다.
3. `SINCON_final_step2_layers.ipynb`를 열고 모두 실행합니다. `/kaggle/input` 아래에서 패키지와 공식 CSV 폴더를 자동으로 찾습니다. 후보가 여럿이면 설정 셀의 `ROOT`에 사용할 패키지 폴더만 지정합니다.
4. `/kaggle/working/sincon_step2_<시각>/`의 후보와 `verification.json`을 확인합니다. 이 설명은 실행 절차이며 Kaggle 실기 성공 기록은 아닙니다.

### Google Colab에서 실행하기

1. ZIP을 `/content` 아래에 풉니다. 노트북을 Colab에서 엽니다.
2. 대회에서 받은 공식 `train.csv`, `test.csv`, `metaData.csv`를 추출한 `final_delivery/data/`에 직접 넣습니다.
3. 모두 실행합니다. `/content`에서 패키지를 자동으로 찾습니다. 필요하면 `ROOT` 하나에 추출한 폴더를 지정합니다.
4. `/content/sincon_step2_<시각>/`의 결과를 내려받습니다. Colab 실기는 미실행입니다.

### 로컬에서 실행하기

Python 3.11 또는 3.12를 사용하세요. 공식 세 CSV를 `data/`에 놓고 아래를 실행합니다. 새 가상환경에 설치하는 직접 의존성은 numpy와 pandas뿐이며, dateutil·시간대 패키지는 pandas의 의존성입니다.

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -B execute_notebook.py .
```

이 명령은 노트북 코드 셀 11개를 표준 Python으로 순서대로 실행하고, 실행된 노트북·로그·JSON을 남깁니다. Jupyter 서버와 kernel은 필요 없습니다. Jupyter나 VS Code에서 직접 열어 모두 실행할 수도 있습니다. 이번 측정은 표준 라이브러리 셀 실행기로 했고, Jupyter 화면·kernel 실기는 확인하지 않았습니다. 패키지 밖에서 노트북을 열었다면 `ROOT`에 패키지 폴더를 지정하세요.

직접 실행한 CLI 검증에서 선택 셀을 켜려면 `python -B execute_notebook.py . --hedges`를 사용합니다. 노트북에서는 `ENABLE_HEDGES=True` 한 줄을 바꿉니다. 실행 로그는 그 설정 변경을 기록합니다. 같은 `verification/executed_main/` 또는 `executed_hedges/`가 이미 있으면 셀 실행기는 덮어쓰지 않고 중단하므로 새 복사본에서 실행하세요. 노트북 자체의 후보 결과는 매번 새 시각 폴더에 저장합니다.

## 필요한 파일과 용량

FILE_SIZES

실행 코드와 설명 문서, 8개 캐시, 기준 CSV 3개를 함께 보존해야 합니다. 전체 배포 파일별 바이트 수와 SHA-256은 [FILE_LIST.tsv](FILE_LIST.tsv), 전체 크기는 [PACKAGE_CONTENTS.md](PACKAGE_CONTENTS.md)에 있습니다. 공식 CSV의 해시는 [official_inputs.json](official_inputs.json)에 기록했습니다. `data/`와 `input/`에는 위치 안내만 넣었습니다.

캐시는 새 학습을 대체하는 보관 검증 예측이며 공식 train에서 파생된 log 라벨을 포함합니다. 공식 원본 CSV의 재배포와 구분하되, 공개 배포용 독립 데이터로 오해하지 마세요. `reference/`의 주후보·절충 CSV는 검산용이며 모델 정답이 아닙니다. `verified_outputs/`에는 이번에 실제 노트북에서 생성한 두 결과를 보관했습니다.

## 최종 예측이 만들어지는 순서

1단계는 보정 전 개별 모델 예측에서 출발합니다. LightGBM과 임베딩 MLP, 생활이동·그래프·가법 시간대·버스·경기·수요 혼합 모델을 조건별 스택과 로컬 스택으로 결합합니다. 주거·축제 효과도 이 상위 경로에 들어 있습니다. 초기 행사·날씨·역별·심야 보정을 계산한 뒤 공연 취소·장소 변경과 행사층을 재생성합니다. 이어 역 시간 프로필, TabICL 일별 수준, 동춘 휴업일, 음력 연휴 상대 수준, 검단 아침, 예측 시차별 TabICL 가중치, 18시간 벡터 XGBoost를 적용합니다. 마지막으로 드림파크·과학대제전 시간대·능허대·둘레길 보정을 적용해 clean CSV를 만듭니다.

아래는 보관된 보고서가 실제로 측정한 A/B/C RMSLE입니다. A의 origin은 2026-02-28, B는 2025-12-31, C는 2025-10-31입니다. 이 작업에서 상위 모델 검증을 다시 실행하지 않았습니다. 표의 단계들은 검증 범위가 다르며 최종 행사층 전체를 같은 과거 사건에 모의 적용한 단일 누적 점수표가 아닙니다.

| 1단계의 측정 범위 | A | B | C | 근거·한계 |
|---|---|---|---|---|
| 원 로컬 보고의 team 비교군 | .166115767 | .178403976 | .170259852 | 이전 보고의 비교값. 현재 clean 누적 점수가 아님 |
| 조건별 스택 | .157906459 | .169849042 | .163470895 | 조건별 보고, 이 과업에서 재학습하지 않음 |
| 로컬 스택 | .152395126 | .165980432 | .163163737 | 로컬 보고, 후속 행사층 전 |
| clean 모델층 결합의 비교군 | .150806837 | .165727453 | .162339372 | Public 상수를 제거한 새 OOF |
| clean 모델층 결합 후 | .149904003 | .164576151 | .161174942 | 모델층 지표, 마지막 행사층 전체의 점수 아님 |
| 마지막 행사 보정 | 미산출 | 미산출 | 미산출 | 최종 59행 변경을 보관 보고에서 확인. 전체 효과로 위 점수를 재사용하지 않음 |

숫자의 원본 JSON 네 개는 `evidence/sincon_*results.json`에 보관했습니다. 1단계 실행 방법과 전체 학습 의존성은 별도 1단계 패키지의 README와 STATUS를 확인하세요. 일부 모델만 재학습한 부분 실행과 모든 모델을 train부터 재학습한 실행은 다릅니다.

2단계에서는 아래 순서를 고정합니다. 행 수는 각 층의 적용 순간을 기준으로 하므로 합산하면 안 됩니다.

| 순서 | 무엇을·왜 하는가 | 보관 검증에서 측정한 결과 | 남은 한계 |
|---|---|---|---|
| 1 타임캡슐 3행 | 누락 공연에 같은 시리즈 과거 초과분의 75% 하한 | summer 36행 1.697556589→1.414320016, 7/31 36행 1.726618182→1.399029261 | 동일 12일을 반복 검증. 같은 시리즈 기증 1건 |
| 2 PLAVE 기존 4행 | 문학 공연 합계 쪽으로 log 차이 .35배, cap .50 | 14행 2.079960524→1.657658006, 13행 개선 | 4계열의 작은 표본 |
| 3 역별 60일·.25배 | 앞선 OOF의 역별 평균 오차를 중심화해 차감 | 8개 origin 중 7개 개선. 행사 경로 Δ −.004343960~−.000249749 | B는 +.001572662 악화. origin 구간 중복 |
| 4 금요일 2,016행 | 7/17·10/9 역간 상대 차이, log cap .05 | 노출 5개 구간 모두 개선. A 노출행 .156458892→.155691769 | 독립 날짜 2개. log .05는 count +5.13% 수준 |
| 5 PLAVE 22시 2행 | 평소+관객 비율 Q25·Q50 기하평균×지정 예매 | 22시 5행 시간 순서 .589066, 보관 OOF 2.572896·기존식 재구성 2.083644 | 관객을 안다는 조건. 현재 후보 전체의 정확한 OOF 아님 |
| 6 부평삼거리 36행 | 추석 전날·당일 성묘 수요를 평소 일요일 대비 전이 | 발동 6개 origin 모두 개선. C .159530→.159398, B .165979→.165775 | 독립 수령 명절 2회. 22시층을 OOF 전체에 붙인 점수 아님 |

현재 코드가 실제로 바꾼 행과 log 변화는 노트북 실행 표 및 `layer_deltas.csv.gz`에 나옵니다. 층별 상세 검증과 실패 사례는 노트북과 `evidence/reports/ROUND*_RESULT.txt`에 있습니다. 이 보고서는 과거 작업의 스냅샷이며 일부 링크는 원 작업 폴더를 가리킵니다.

### 별도 후보의 17행

절충은 검증되지 않은 추정입니다. PLAVE는 예매×.30을 21/22/23시에 10%/85%/5% 배분하고 W=.7로 섞습니다. Sustainable은 하루 12,000명을 가정해 20/21/22/23시 10%/20%/45%/25%, W=.5를 씁니다. 랜더스는 같은 시리즈를 옮긴 진단 FULL 2,199/4,102/860을 W=.5로 섞습니다. 식은 `exp((1−W)log1p(현재)+W log1p(FULL))−1`입니다.

7번은 17행을 주후보에 추가하지 않았습니다. 원 검토의 랜더스 20시는 '과함', 나머지 16행은 '근거 부족'입니다. 원 검토 시점은 PLAVE 비중 3%/85%/12%, 랜더스 FULL 3,255/3,513/366이었으므로 현재 수식에 대한 새 통과 판정으로 쓸 수 없습니다. 원 판정 CSV는 [그대로 보관](evidence/hedges_17_judgments_round7_original.csv)했고, 선택 셀은 현재 모든 가정과 원 판정을 나란히 출력합니다. 현재 수식을 새로 튜닝하지 않고 지정된 별도 CSV와의 재현만 확인했습니다.

## 규칙 4절 · Public 사용 이력과 제거

과거 경로에는 Public 점수 변화에서 얻은 전체 log 수준 +0.021742424607211323, 후속 수준 +0.0090238206986512966, 역 패턴 배율 .62가 있었습니다. 초기 역별 배율 약1.021을 역산한 기록도 있습니다. 그 계산·출력과 probe, Public 기반 혼합 파일은 현재 입력 경로에서 제외했습니다. 공연 취소·장소 변경의 조사 순서에 Public 차이를 참고한 과거 경위도 남깁니다.

현재 1단계는 보정 전 개별 모델과 새 OOF에서 깨끗하게 조립한 SHA가 고정된 CSV를 쓰며, 2단계는 그 SHA와 캐시를 검사합니다. Public 점수·리더보드·탐색 제출을 예측 함수에 전달하지 않습니다. 이번 작업은 어떤 크기·가중치·스위치도 Public 점수로 정하지 않았고 Kaggle 업로드도 하지 않았습니다. 과거 감사의 자세한 이력은 `evidence/reports/RULES_NOTICE_PUBLIC_SCORE.txt`와 `SINCON_PUBLIC_SCORE_AUDIT.txt`에 있습니다.

## 규칙 4절 · 7월 이후 지하철 실측

이번 작업은 2026년 7월 이후 지하철 승하차 실측을 검색·조회·사용하지 않았습니다. 승차 정답은 공식 train의 2025-01-01~2026-06-30 688,176행뿐입니다. 캐시의 과거 정답도 공식 train에 다시 연결해 확인합니다. test는 예측 대상 키만 담고 있습니다.

상위 경로는 7~10월 날씨·행사·경기·비철도 생활이동·버스 등 외생 정보를 사용합니다. 이를 6월에 미리 알고 한 실시간 수요예측이라고 주장하지 않습니다. 생활이동의 소비 교통수단은 버스·도보·차량으로 제한했지만, 공급자 내부에서 간접 철도 실측 보정이 있었는지까지 독립 확인한 것은 아닙니다. 이 원점검 한계는 운영진 문의 대상으로 남습니다. PLAVE 보조 버스 자료는 이번 실행 입력에 없으며 계수 산정에도 넣지 않았습니다.

## 규칙 3절 · 외부 자료의 이용 조건

| 구분 | 확인 범위 | 아직 필요한 것 |
|---|---|---|
| 허용 확인 | 법정 달력·자체 대리변수·NEIS·Open-Meteo·공개 포털 역/버스·비철도 생활이동·TabICL | 출처표시와 해당 조건 유지. 생활이동 간접 보정은 별도 미확인 |
| 대체 출처로 확인 | 부천39경기117값 전부 일치. 야구 실제 시각·날짜·상태160경기 대조. 수기 행사9건 전량 확인 | 최초 수집 경로가 대체된 것으로 소급해 적지 않음 |
| 일부 확인·미확인 | 야구 관중 충돌1경기·예정시각, 주거35단지 값, 수기26건 중12일부·5미확보, 축제293역일 전량확인0 | 허용 출처만으로 전경로 재생성 미완료. 원수집 KBO 제한 유지 |
| 2단계 추가 입력 미확인 | PLAVE 예매 수량의 원출처, 일부 공연·기사·명절 접근 공지의 이용 조건 | 일정 사실 확인과 이용 허락을 분리해 운영진·팀원에게 확인 |

아래는 night6의 '노트북용 출처 표'입니다. 조회일은 원 작업의 2026-11-13이며 이번 과업에서 웹을 재조회하지 않았습니다. 원 수집 KBO 약관의 제한은 CC 대체 대조만으로 해소됐다고 쓰지 않습니다. 야구3건 +3명 부분 재학습이 0행 변화였다는 결과도 전체 모델의 출처 교체 완료를 뜻하지 않습니다. 주거 승인일 규칙 변경 역시 허용 원본 값의 재확보 실험이 아닙니다. 전체 제출 적합 판정은 여전히 보류입니다.

SOURCE_TABLE

## 규칙 7절 · 이번에 실행해서 확인한 범위

패키지만 빈 한글·공백 경로에 복사한 뒤 공식 세 CSV를 그 안의 `data/`에 따로 복사했습니다. 새 가상환경을 두 개 만들고 모든 코드 셀을 실행했습니다. 검증 중 네트워크·소켓 사용과 원본 프로젝트의 데이터 읽기를 차단했고, 입력 해시가 바뀌지 않았습니다. Python 3.11과 3.12에서 절충 꺼짐·켜짐을 각각 실행했습니다.

RUN_TABLE

실행 시간은 패키지 설치를 제외한 셀 실행 벽시계 시간입니다. 동시 작업과 OS 파일 캐시의 영향을 받으므로 속도 비교 수치로 쓰지 않습니다. RSS는 macOS의 해당 실행 프로세스 최대 사용량이며 필요한 메모리의 보장값이 아닙니다. 두 버전의 설치된 외부 패키지는 numpy·pandas와 그 필수 의존성뿐입니다. PyPI DNS 연결이 실패해 읽기 전용 uv 캐시의 wheel 내용으로 오프라인 설치했습니다. 캐시를 다시 압축한 경위와 설치 목록은 `verification/install/`에 보관했습니다. 원격 서버에서의 신규 다운로드 성공은 미확인입니다.

저장된 두 CSV는 모두 157,194행, 공식 ID 순서·고유성, 유한·비음수, CSV round-trip 검사에 통과했습니다. 각 후보의 기준 대비 최대 log1p 차이는 8.881784197001252e-16, 1e-10 초과 차이는 0행입니다. 별도 후보는 주후보와 정확히 지정된 17행만 다릅니다. 출력 SHA는 주후보 `b1b8a74dfece0eeded0c88e66033668eb70552f89544f4bb8a764cfe99d40d76`, 별도 후보 `20dcb3af817781e22abd5f8ba227626070e8213bd559854eb3834b315ca649d5`입니다. 비교용 원본 CSV와는 직렬화·극소 부동소수점 차이로 바이트 해시가 다릅니다.

배포 ZIP을 빈 폴더에 실제로 풀고 공식 CSV만 따로 넣어 Python 3.12에서 절충 켜짐 전체 11셀을 추가 실행했습니다. 두 후보의 최대 log1p 차이는 위와 같습니다. 증거는 `verification/archive_smoke/`입니다. 이 실행 후 원본 노트북과 동결 입력은 바꾸지 않았고 최종 ZIP에는 설명·검증 기록을 추가했습니다. 임시 가상환경·wheel·공식 CSV 복사본은 검증 후 정리했으며, 배포 폴더에도 공식 원본 CSV가 남아 있지 않습니다.

14개 층 스위치 조합도 실제 계산으로 검사했습니다. 모두 끔, 모두 켬, 각 층만 켬, 각 층만 끔입니다. `verification/layer_switches_py311.json`이 증거입니다. Linux 경로 대소문자·UTF-8·줄바꿈·개인 절대 경로·추가 의존성을 정적으로 검사했습니다. 코드와 노트북은 LF이며, 원본 calendar.csv와 CC_ATTRIBUTION.csv의 CRLF는 CSV 파서가 읽으므로 해시 보존을 위해 유지했습니다. 정적 검사 결과는 Linux 실행 성공을 뜻하지 않습니다.

## 시드·버전·하드웨어

2단계는 난수·모델 학습·GPU·OpenMP를 사용하지 않습니다. 사용한 Python·numpy·pandas는 위 실측 표와 requirements에 적었습니다. macOS ARM64 CPU에서 확인했습니다. 다른 CPU나 수학 라이브러리에서는 극소 부동소수점 차이가 날 수 있어 SHA와 최대 log 차이를 함께 확인합니다.

| 1단계 구성 | 보관된 시드·설정 |
|---|---|
| 팀 LightGBM | 0·1·2 |
| 최종/A·B·C MLP | 0~29, 30 epoch, 폭512. 월말 rolling은 시드0, 폭384 |
| 그래프·혼합 신경망 | 0·1 |
| 버스 / 행사 응답 | 버스0, 행사 LightGBM·MLP 0·1·2 |
| 시간별 / 벡터 XGBoost | 0 / 19 |
| TabICL | 2026, CPU, 앙상블2, tabicl-regressor-v2-20260212.ckpt |

이 표는 1단계 재현 문서에서 옮겼으며 이번 과업에서 재학습한 설정이 아닙니다. 1단계 요구 패키지 스냅샷은 `evidence/step1_requirements_snapshot.txt`에 있습니다. PyTorch 버전·CPU/GPU·스레드에 따라 MLP 재학습 값은 달라질 수 있습니다. 전체 학습의 최신 성공 여부와 버전은 병행 작업 중인 1단계 STATUS를 따릅니다.

## 아직 남은 일

- 운영진에게 KBO 원수집 경로와 대체 사실의 사용, 주거·행사·축제 미확인, 생활이동 간접 철도 보정의 해석을 문의해야 합니다. 이번 과업에서는 문의를 발송하지 않았습니다.
- PLAVE 지정 예매 수량의 예매처·집계 방식과 이용 조건을 팀원에게 확인해야 합니다.
- Kaggle·Colab에서 실제로 모두 실행해야 합니다. Linux와 Windows 실기, 표준 Jupyter kernel 실행도 미실행입니다.
- 병행 중인 1단계의 train부터 전체 재학습 검증 결과를 연결해야 합니다. 2단계 캐시 재현만으로 규칙 7절 전체를 충족했다고 주장하지 않습니다.
- 8번 산출물에 대한 Claude의 최종 검토가 남았습니다. 후보 제출과 최종 2개 선택은 사용자가 직접 진행합니다.

실행한 것과 못한 것의 최종 목록은 [STATUS.md](STATUS.md)에 있습니다. 이번 판단 기록은 [decisions_delivery.tsv](decisions_delivery.tsv)이며 기존 공용 기록은 수정하지 않았습니다.
"""
    readme = readme.replace("FILE_SIZES", size_table).replace("SOURCE_TABLE", source_table.strip()).replace("RUN_TABLE", run_table)
    (ROOT / "README.md").write_text(readme, encoding="utf-8")
    status = """# 8번 작업 상태

2026-11-13 KST. 주후보의 6개 층과 기본 꺼짐 절충 17행을 동결한 재현 패키지입니다. Claude 최종 검토는 아직 받지 않았습니다.

## 실제 실행 완료

- 새 Python 3.11·3.12 가상환경, 빈 한글·공백 경로에 패키지 복사, 공식 CSV 별도 복사.
- 코드 셀 11개 전부 실행. 두 버전 각각 절충 꺼짐·켜짐 검사, 입력 불변·네트워크 차단·원본 프로젝트 데이터 접근 차단.
- 주후보·별도 후보 모두 원본 기준 대비 최대 log1p 차이 8.881784197001252e-16. 1e-10 초과 0행. 별도 후보는 지정된 17행만 변경.
- 두 CSV의 157,194행, example_id 공식 순서·중복 없음, 유한·비음수와 저장 후 round-trip 통과.
- 14개 층 스위치 조합 통과. 원 night7/final_layers.py와 cache를 바이트 그대로 복사.
- ZIP을 빈 폴더에 추출한 뒤 공식 CSV만 별도 추가한 Python 3.12 실행에서도 전체11셀·두 후보 재현 통과. verification/archive_smoke에 증거 보존.
- Linux 관련 경로 대소문자·개인 절대 경로·UTF-8·LF를 정적으로 검사. 상세 결과는 verification/static_audit.json.

RUN_TABLE

증거는 `verification/py311/`, `verification/py312/`의 실행된 노트북·JSON·로그입니다. 로그의 개인 절대 경로만 `<PACKAGE>` 등으로 가렸습니다. 노트북 원본의 설정은 절충 꺼짐이며 선택 실행의 설정 덮어쓰기는 JSON에 기록했습니다. 실제 생성한 CSV와 현재 17행 가정표는 `verified_outputs/`에 보관했습니다.

## 미실행

- Kaggle·Google Colab·Linux·Windows 실기 및 표준 Jupyter kernel. 이번 전체 셀 실행은 Python 표준 라이브러리의 순차 compile/exec 방식입니다.
- 이 과업에서 1단계 상위 모델 전체를 train부터 재학습하는 작업. 다른 Codex의 final_package 검증이 담당합니다.
- PyPI에서 새 패키지 다운로드. DNS 실패 후 기존 읽기 전용 wheel 캐시를 새 환경에 오프라인 설치했습니다.
- 미래 지하철 정답 점수, 새 Public 평가, Kaggle 업로드, 운영진 문의 발송.

## 남은 위험

1. 규칙 3절 전체 제출 적합 판정 보류. KBO 원수집 제한·관중 충돌·예정시각, 주거35단지, 일부 행사·축제 및 추가 공연 출처가 미해결입니다. PLAVE 예매 수량 원출처도 미확인입니다.
2. 생활이동의 공급자 내부 간접 철도 보정은 독립 확인하지 못했습니다. 7월 이후 지하철 실측은 이번 과업에서 검색·조회·사용하지 않았습니다.
3. 절충17행은 검증되지 않은 추정입니다. 현재 수식은 7번 검토 당시와 PLAVE·랜더스에서 다르며 원 판정을 새 통과 근거로 쓰지 않았습니다.
4. 보정의 과거 표본이 적고 origin이 겹칩니다. 역별 층은 B에서 악화했고, 부평삼거리의 비주간 시간 묶음도 C/B에서 악화했습니다. 별도 최종 홀드아웃 검증은 없습니다.
5. 승인 baseline SHA를 엄격히 요구합니다. 재학습 출력이나 직렬화가 달라지면 새 검토 없이 진행하지 않고 중단합니다.
6. ZIP은 실행 구조를 묶은 배포본입니다. 외부 자료의 공개 재배포 허락 완료를 뜻하지 않습니다. 공식 원본 세 CSV는 ZIP에 없습니다.

현재 경로에서 Public 유래 보정은 제외했습니다. 과거 사용 이력과 제거 경위는 README에 기록했습니다. 모든 기존 작업물과 final_package는 읽기만 했으며 새 산출물·판단 기록은 final_delivery에만 썼습니다.

본 작업에서 새로 만든 임시 가상환경·wheel·공식 CSV 복사본은 증거를 보존한 뒤 정리했습니다. 최종 폴더와 ZIP의 data/·input/에는 안내 문서만 남겼습니다. 최종 파일 목록·용량·SHA는 FILE_LIST.tsv와 ZIP 바깥 DISTRIBUTION.json에 있습니다.
""".replace("RUN_TABLE", run_table)
    (ROOT / "STATUS.md").write_text(status, encoding="utf-8")
    print("README와 STATUS를 실제 4회 측정값으로 작성했습니다.")


if __name__ == "__main__":
    render()
