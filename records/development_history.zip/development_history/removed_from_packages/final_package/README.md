# SINCON 2026 핫식스 최종 패키지

`SINCON_final.ipynb`를 실행하면 기본 결과 `submission_clean_refined.csv`를 만듭니다. 기본 추가 보정은 모두 꺼져 있습니다. Kaggle 업로드 기능은 없습니다.

Kaggle에는 배포 ZIP을 푼 내용 전체를 비공개 Dataset으로 연결하세요. Colab에서는 `/content`에 풉니다. 로컬에서는 노트북의 `LOCAL_ROOT` 한 줄만 지정합니다. 공식 CSV와 외부 입력·모델별 예측·TabICL 체크포인트가 들어 있으므로 기존 팀 폴더는 필요 없습니다. 설치에는 네트워크가 필요합니다.

노트북의 첫 셀은 Python3.11 또는3.12에 맞는 버전을 설치합니다. `RUN_MODE="assemble"`은 보관 모델 출력을 읽고 모든 최종 보정을 다시 계산합니다. `RUN_MODE="full"`은 기본으로 모든 사용 모델을 공식 train부터 다시 학습합니다. 각 단계의 스위치·설정·예상 시간과 실제 실행 범위의 차이는 노트북과 `STATUS.md`에 적었습니다. native를 다시 학습하면 행사 응답도 함께 학습해야 합니다.

| 위치 | 내용 |
|---|---|
| `SINCON_final.ipynb` | 한국어 설명, 설치, 자동 경로, 학습 모드·보정 목록, 조립·검사 |
| `pipeline.py`, `full_train.py`, `full_stage.py` | 입력 해시·형식 검사, 단계별 실행, 재학습 출력 연결 |
| `payload/team/data/` | 공식 train·test·metaData |
| `payload/team/` | Public 보정 main을 제거한 팀 모델 코드와 보정 전 개별 모델 예측 |
| `payload/work/` | 검증·행사 코드, 동결 외부 자료, 보정 전 local·conditional 출력, 과거 예측 ZIP |
| `payload/work/sincon_clean_refined_cache.zip` | clean OOF, TabICL 원시 최종·과거 예측, 벡터 과거 원시 예측 |
| `payload/models/` | 해시가 고정된 TabICL 회귀 체크포인트 |
| `reference/submission_clean_refined.csv` | 마지막 비교 전용 기준 CSV. 예측 생성에는 사용하지 않음 |
| `submission_clean_refined.csv` | 격리 CPU 실행에서 만든 CSV |
| `EXTERNAL_DATA.md`, `docs/`, `licenses/` | 외부 자료·조회일·이용 조건, 검증 수치, Public 감사, 라이선스 고지 |
| `verification/` | 실제 조립 결과·실행 시간·환경·로그, 정적 감사, full 측정 결과 |
| `payload_manifest.json` | 노트북 입력 1개당 SHA-256 |
| `FILE_LIST.tsv` | 배포 파일별 상대 경로·바이트 수·SHA-256 전체 목록 |

격리 CPU 실행은 6개 코드 셀을 모두 수행했습니다. 최신 축소 배포본 실행은 약73초(최초 실행 약77초)였고 기준과 최대 `log1p` 차이는0, CSV SHA-256은 `519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199`였습니다. 현재 샌드박스가 로컬 소켓을 막으므로 표준 Jupyter TCP·IPC kernel 시작은 실패했습니다. `jupyter nbconvert --execute`의 별도 subprocess IPython 백엔드로 새 가상환경에서 같은 셀을 순서대로 실행했습니다. Linux·Kaggle·Colab의 표준 kernel 실기는 별도 미실행입니다. 최신 실행 증거는 `verification/assemble/` 및 `STATUS.md`를 확인하세요. Linux wheel·경로·OpenMP 점검은 `verification/LINUX_COMPATIBILITY.md`에 구분했습니다.

CLI 조립은 다음과 같습니다. 노트북이 최종 제출의 주 진입점이며 이 명령은 검토용입니다.

```bash
python -m pip install -r requirements.txt
SINCON_DEVICE=cpu python -c 'from pipeline import Run; r=Run(".", mode="assemble", device="cpu"); r.assemble(); r.verify()'
python audit_package.py
```

표준 Jupyter 실행이 허용되는 환경에서는 노트북을 열어 모두 실행하거나 다음을 사용하세요.

```bash
jupyter nbconvert --to notebook --execute SINCON_final.ipynb --ExecutePreprocessor.timeout=86400 --output SINCON_final.executed.ipynb
```

이 샌드박스의 소켓 없는 검증은 새 Python3.12 가상환경에 `requirements.txt`와 IPython을 설치하고 다음을 사용합니다. 이 백엔드는 노트북의 코드를 바꾸지 않습니다.

```bash
python verify_socketless.py /path/to/isolated/final_package --python /path/to/new/venv/bin/python
```

실행 결과는 매번 새 `outputs/sincon_<mode>_<UTC>/`에 씁니다. 입력은 덮어쓰지 않습니다. 로컬 개발용 `.build/`와 `outputs/`는 배포 ZIP 및 파일 목록에서 제외합니다. 원래 프로젝트의 `sources/`나 팀 폴더는 수정하지 않았습니다.

`FILE_LIST.tsv`는 ZIP에 담은 시점의 파일별 바이트와 해시를 기록합니다. 로컬의 백그라운드 상태 JSON은 이후 갱신될 수 있습니다. 실제 읽기 기록과 full 학습 명시 입력만 남겼으며 미사용 KOPIS·도보거리·톨게이트 실험 자료와 과거 제출 CSV는 배포 입력에서 제외했습니다.

KBO·K리그·일부 주거·행사 자료는 이용 조건이 미확인입니다. 원래 자료를 보존하는 재현 패키지이며, 이용 허락을 보증하는 패키지는 아닙니다. 공개 배포 전에 Claude가 대회 규칙 3절과 원출처의 재배포 조건을 판단해야 합니다. Public 점수로 보정값을 정하거나7월 이후 지하철 승하차 실측을 사용한 단계는 없습니다. 감사 배경은 `docs/SINCON_PUBLIC_SCORE_AUDIT.md`에 남겼습니다.

<!-- PACKAGE_SIZE_START -->
동결 payload: 173개, 272,032,418바이트, 259.4MiB.

배포 파일: 목록 자체를 제외하고 289개, 약 268.2MiB.

배포 ZIP: 약 222.7MiB.

정확한 ZIP 바이트 수와 해시는 원본 작업 폴더의 `DISTRIBUTION.json`에 있습니다. 이 sidecar는 ZIP 바깥에 둡니다. ZIP 내부 전체 파일 목록은 `FILE_LIST.tsv`입니다.
<!-- PACKAGE_SIZE_END -->

<!-- PACKAGE_FILES_START -->
<details>
<summary>배포 ZIP 전체 파일 목록</summary>

```text
EXTERNAL_DATA.md
FILE_LIST.tsv
PLAN.md
README.md
SINCON_final.ipynb
STATUS.md
audit_package.py
background_full.py
build_distribution.py
build_payload.py
docs/RULES_NOTICE_PUBLIC_SCORE.md
docs/SINCON_EXTERNAL_SOURCES.md
docs/SINCON_PUBLIC_SCORE_AUDIT.md
docs/SINCON_REPRODUCE_CLEAN.md
docs/sincon_clean_model_layers_results.json
docs/sincon_clean_refined_results.json
docs/sincon_clean_replay_verification.json
docs/sincon_conditional_candidate_results.json
docs/sincon_local_candidate_results.json
docs/sincon_source_reweight_april_origin_results.json
docs/sincon_source_reweight_replay_results.json
execute_cells.py
full_stage.py
full_train.py
licenses/TabICL-BSD-3-Clause.txt
make_notebook.py
payload/models/tabicl-regressor-v2-20260212.ckpt
payload/team/baseline.py
payload/team/calendar_features.csv
payload/team/data/metaData.csv
payload/team/data/test.csv
payload/team/data/train.csv
payload/team/ensemble.py
payload/team/ensemble_parts.csv
payload/team/experiments/model_zoo.py
payload/team/experiments/valid_predictions_zoo.csv.gz
payload/team/external/crowd_munhak.csv
payload/team/external/events_daily.csv
payload/team/external/munhak_games.csv
payload/team/external/school_calendar.csv
payload/team/external/weather_hourly.csv
payload/team/external_features.py
payload/team/improved.py
payload/team/make_calendar.py
payload/team/nn_model.py
payload/team/valid_predictions_ABC.csv.gz
payload/work/external.zip
payload/work/external_inputs/CALENDAR_SOURCES.md
payload/work/external_inputs/DATA_AUDIT.md
payload/work/external_inputs/calendar_features.csv
payload/work/external_inputs/external/events.csv
payload/work/external_inputs/external/events_daily.csv
payload/work/external_inputs/external/munhak_games.csv
payload/work/external_inputs/external/weather_hourly.csv
payload/work/external_inputs/external/weather_zone_map.csv
payload/work/mobility_monthly/202501.csv.gz
payload/work/mobility_monthly/202502.csv.gz
payload/work/mobility_monthly/202503.csv.gz
payload/work/mobility_monthly/202504.csv.gz
payload/work/mobility_monthly/202505.csv.gz
payload/work/mobility_monthly/202506.csv.gz
payload/work/mobility_monthly/202507.csv.gz
payload/work/mobility_monthly/202508.csv.gz
payload/work/mobility_monthly/202509.csv.gz
payload/work/mobility_monthly/202510.csv.gz
payload/work/mobility_monthly/202511.csv.gz
payload/work/mobility_monthly/202512.csv.gz
payload/work/mobility_monthly/202601.csv.gz
payload/work/mobility_monthly/202602.csv.gz
payload/work/mobility_monthly/202603.csv.gz
payload/work/mobility_monthly/202604.csv.gz
payload/work/mobility_monthly/202605.csv.gz
payload/work/mobility_monthly/202606.csv.gz
payload/work/mobility_monthly/202607.csv.gz
payload/work/mobility_monthly/202608.csv.gz
payload/work/mobility_monthly/202609.csv.gz
payload/work/mobility_monthly/202610.csv.gz
payload/work/sincon_3107_mature_hour_profile.py
payload/work/sincon_additive_model.py
payload/work/sincon_annual_analog.py
payload/work/sincon_apply_final_calibration.py
payload/work/sincon_archived_intraday_anomalies.py
payload/work/sincon_asiad_concert_spillover.py
payload/work/sincon_asiad_science_festival.py
payload/work/sincon_asiad_science_festival_results.json
payload/work/sincon_bucheon_football_data.csv
payload/work/sincon_bus_model.py
payload/work/sincon_bus_stop_data.py
payload/work/sincon_calendar_kernel.py
payload/work/sincon_calibrated_ensemble.py
payload/work/sincon_clean_15126_replay.py
payload/work/sincon_clean_event_replay.py
payload/work/sincon_clean_model_layers.py
payload/work/sincon_clean_native_forecasts.py
payload/work/sincon_clean_refined_cache.zip
payload/work/sincon_clean_tabicl_forecast.py
payload/work/sincon_complementary_blend.py
payload/work/sincon_complementary_replay.py
payload/work/sincon_conditional_candidate.py
payload/work/sincon_corridor_bus_growth.py
payload/work/sincon_daily_network.py
payload/work/sincon_district_mobility.py
payload/work/sincon_dongchun_retail.py
payload/work/sincon_dreampark_festival_audit.py
payload/work/sincon_event_effects.py
payload/work/sincon_external_covariates.py
payload/work/sincon_festival_experiment.py
payload/work/sincon_festival_fact_check.py
payload/work/sincon_festival_station_days.csv
payload/work/sincon_flow_mixture.py
payload/work/sincon_football_experiment.py
payload/work/sincon_forecast.py
payload/work/sincon_fuel_shock.py
payload/work/sincon_game_exit.py
payload/work/sincon_geomdan_morning_anchor.py
payload/work/sincon_geomdan_opening_control.py
payload/work/sincon_graph_network.py
payload/work/sincon_hierarchical_experiments.py
payload/work/sincon_holiday_transfer.py
payload/work/sincon_housing_approvals.csv
payload/work/sincon_housing_growth.py
payload/work/sincon_housing_occupancy.py
payload/work/sincon_intraday_ensemble.py
payload/work/sincon_joint_candidate.py
payload/work/sincon_kbo_cancellation_time.py
payload/work/sincon_kbo_game_data.csv
payload/work/sincon_late_composition_kernel.py
payload/work/sincon_late_low_count_calibration.py
payload/work/sincon_lightgbm_experiments.py
payload/work/sincon_local_blend_experiment.py
payload/work/sincon_local_candidate.py
payload/work/sincon_local_repro.zip
payload/work/sincon_local_validation.csv.gz
payload/work/sincon_lunar_network_level.py
payload/work/sincon_matched_year.py
payload/work/sincon_mobility_data.py
payload/work/sincon_mobility_experiment.py
payload/work/sincon_munhak_cancellation_candidate.py
payload/work/sincon_munhak_cancellation_lgb.py
payload/work/sincon_munhak_cancellation_responses.zip
payload/work/sincon_munhak_cancelled_nn.py
payload/work/sincon_munhak_ordinary.py
payload/work/sincon_munhak_spectator.py
payload/work/sincon_network_level_audit.py
payload/work/sincon_neunghudae_festival_audit.py
payload/work/sincon_ordinary_shape_calibration.py
payload/work/sincon_overlay_candidate.py
payload/work/sincon_public14774_event_followup.py
payload/work/sincon_public14774_event_update.py
payload/work/sincon_regime_anchors.py
payload/work/sincon_replay_clean_refined.py
payload/work/sincon_rolling_conditional_cache.zip
payload/work/sincon_rolling_forecasts.py
payload/work/sincon_songdo_beach_evening_audit.py
payload/work/sincon_songdo_beach_location_candidate.py
payload/work/sincon_songdo_beach_location_lgb.py
payload/work/sincon_songdo_beach_location_responses.zip
payload/work/sincon_songdo_schedule.py
payload/work/sincon_source_reweight.py
payload/work/sincon_source_reweight_portable.zip
payload/work/sincon_spectator_month_split.py
payload/work/sincon_sports_stack.py
payload/work/sincon_stacked_experiment.py
payload/work/sincon_stadium_concert_analogs.py
payload/work/sincon_station_addresses.csv
payload/work/sincon_station_bus_traffic.csv
payload/work/sincon_station_centers.csv
payload/work/sincon_station_profile_candidate.py
payload/work/sincon_station_state.py
payload/work/sincon_summer_replay.py
payload/work/sincon_summer_replay_validation.csv.gz
payload/work/sincon_tabicl_daily_deviation.py
payload/work/sincon_tabicl_day_weight.py
payload/work/sincon_tabicl_experiment.py
payload/work/sincon_tabicl_final_delta.py
payload/work/sincon_tabicl_submission.py
payload/work/sincon_target_season_validation.zip
payload/work/sincon_team_bias_proxy.py
payload/work/sincon_team_game_exit.py
payload/work/sincon_toll_directional_local.py
payload/work/sincon_trail_festival_audit.py
payload/work/sincon_tree_covariates.py
payload/work/sincon_vector_boost.py
payload/work/sincon_vector_boost_validation.csv.gz
payload/work/sincon_vector_shape_final.py
payload/work/sincon_vector_shape_final_raw.csv.gz
payload/work/sincon_vector_shape_weights.py
payload/work/sincon_weather_sensitivity.py
payload/work/sincon_weekday_contrast.py
payload/work/sincon_weekly_variability.py
payload/work/sincon_wonmi_namdong_audit.py
payload/work/sincon_xgb_conditioned.py
payload/work/sincon_xgb_extra_validation.zip
payload/work/sincon_xgb_forecasts.zip
payload/work/sincon_xgb_weather_candidate.py
payload/work/sincon_zoo_transfer.py
payload/work/sincon_zoo_transfer_season.py
payload/work/submission_conditional_stack.csv
payload/work/submission_local_stack.csv
payload_manifest.json
pipeline.py
reference/submission_clean_refined.csv
requirements.txt
run_full_check.py
socketless_nbconvert_config.py
submission_clean_refined.csv
summarize_native.py
summarize_rolling.py
summarize_verification.py
test_contract.py
test_full_cached.py
verification/LINUX_COMPATIBILITY.md
verification/MEASURED_RUNS.md
verification/assemble/01_early.log
verification/assemble/02_events_before_model.log
verification/assemble/03_model_layers.log
verification/assemble/04_events_after_model.log
verification/assemble/corrections.json
verification/assemble/early.json
verification/assemble/environment_install.log
verification/assemble/event_keys.csv
verification/assemble/events_after_model.json
verification/assemble/events_before_model.json
verification/assemble/execution_certificate.json
verification/assemble/model.json
verification/assemble/notebook_execution.log
verification/assemble/release_summary.json
verification/assemble/run.json
verification/assemble/standard_jupyter_blocked.log
verification/assemble/verification.json
verification/background_controller_handoff.json
verification/background_full_original_versions_status.json
verification/conditional_event_ablation.json
verification/contract_test.log
verification/full/compat_xgb312_stack_and_layers/early.json
verification/full/compat_xgb312_stack_and_layers/events_after_model.json
verification/full/compat_xgb312_stack_and_layers/events_before_model.json
verification/full/compat_xgb312_stack_and_layers/model.json
verification/full/compat_xgb312_stack_and_layers/run.json
verification/full/compat_xgb312_stack_and_layers/verification.json
verification/full/compat_xgb312_tabicl_vector/early.json
verification/full/compat_xgb312_tabicl_vector/events_after_model.json
verification/full/compat_xgb312_tabicl_vector/events_before_model.json
verification/full/compat_xgb312_tabicl_vector/model.json
verification/full/compat_xgb312_tabicl_vector/run.json
verification/full/compat_xgb312_tabicl_vector/verification.json
verification/full/default_py312_tabicl_vector/early.json
verification/full/default_py312_tabicl_vector/events_after_model.json
verification/full/default_py312_tabicl_vector/events_before_model.json
verification/full/default_py312_tabicl_vector/model.json
verification/full/default_py312_tabicl_vector/run.json
verification/full/default_py312_tabicl_vector/verification.json
verification/full/hourly_xgb_original_versions/run.json
verification/full/hourly_xgb_original_versions/training.log
verification/full/native_progress.json
verification/full/native_progress.log
verification/full/rolling_and_clean_oof/corrections.json
verification/full/rolling_and_clean_oof/early.json
verification/full/rolling_and_clean_oof/early_retrained.json
verification/full/rolling_and_clean_oof/events_after_model.json
verification/full/rolling_and_clean_oof/events_before_model.json
verification/full/rolling_and_clean_oof/model.json
verification/full/rolling_and_clean_oof/reassembly.log
verification/full/rolling_and_clean_oof/run.json
verification/full/rolling_and_clean_oof/verification.json
verification/full/rolling_completed/run.json
verification/full/rolling_completed/strict_summer.json
verification/full/rolling_completed/training.log
verification/full/rolling_progress.json
verification/full/sincon_full_20261112T152311_765902Z.json
verification/full/sincon_full_20261112T152836_093232Z.json
verification/full/sincon_full_20261112T155343_861580Z.json
verification/full/sincon_full_20261112T161800_819489Z.json
verification/original_sources_unchanged.json
verification/payload_read_trace.json
verification/portability_audit.json
verification/portability_audit.log
verification/python311_syntax.json
verification/regression/cached_full_green.json
verification/regression/cached_full_red.json
verification/regression/full_cached_green.log
verification/regression/full_cached_red.log
verification/regression/pruned_cached_full_run.json
verification/regression/pruned_cached_full_verification.json
verification/requirements_cpu_py312.txt
verification/review.md
verification/vector_version_control.json
verify_distribution.py
verify_isolated.py
verify_socketless.py
```

</details>
<!-- PACKAGE_FILES_END -->
