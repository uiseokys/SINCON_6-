"""Collect the existing validated inputs without modifying their originals.

Run from the project root: python final_package/build_payload.py --team TEAM_DIR
Only files under this script's directory are written.
"""
import argparse
import ast
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trim_module(text, keep):
    tree = ast.parse(text)
    nodes = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            nodes.append(node)
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in keep:
            nodes.append(node)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(t, ast.Name) and t.id in keep for t in targets):
                nodes.append(node)
    return ast.unparse(ast.Module(body=nodes, type_ignores=[])) + '\n'


def portable(text):
    # MPS is deliberately absent in the delivered code.
    text = text.replace('("mps" if torch.backends.mps.is_available() else "cpu")', '"cpu"')
    text = text.replace("('mps' if torch.backends.mps.is_available() else 'cpu')", "'cpu'")
    text = text.replace('"cuda" if torch.cuda.is_available() else "cpu"',
                        '("cuda" if __import__("os").environ.get("SINCON_DEVICE", "auto") != "cpu" and torch.cuda.is_available() else "cpu")')
    text = text.replace("'cuda' if torch.cuda.is_available() else 'cpu'",
                        "('cuda' if __import__('os').environ.get('SINCON_DEVICE', 'auto') != 'cpu' and torch.cuda.is_available() else 'cpu')")
    # Historical CLI examples are comments/docstrings, not live input paths.
    text = re.sub(r'/Users/[^\s\"\'<>`]+', 'PORTABLE_SOURCE_PATH', text)
    text = text.replace('Path("/private/tmp/sincon_level_neutral_exact_replay.pkl")',
                        '(Path(__file__).resolve().parent / "sincon_level_neutral_exact_replay.pkl")')
    text = text.replace('Path.home() / "sincon-2026/sincon-baseline"',
                        '(Path(__file__).resolve().parent.parent / "team")')
    return text


def build(team):
    payload = ROOT / 'payload'
    work, target = payload / 'work', payload / 'team'
    for p in (work, target / 'data', target / 'external', target / 'experiments', payload / 'models', ROOT / 'reference', ROOT / 'docs'):
        p.mkdir(parents=True, exist_ok=True)
    entries = ['sincon_replay_clean_refined', 'sincon_clean_15126_replay', 'sincon_clean_event_replay',
               'sincon_clean_model_layers', 'sincon_clean_native_forecasts', 'sincon_local_candidate',
               'sincon_rolling_forecasts', 'sincon_summer_replay', 'sincon_zoo_transfer_season',
               'sincon_munhak_cancellation_lgb', 'sincon_songdo_beach_location_lgb', 'sincon_munhak_cancelled_nn',
               'sincon_clean_tabicl_forecast', 'sincon_archived_intraday_anomalies', 'sincon_vector_boost']
    sources = {p.stem: p for p in SOURCE.glob('*.py')}
    pending, found = list(entries), set()
    while pending:
        name = pending.pop()
        if name in found or name not in sources:
            continue
        found.add(name)
        tree = ast.parse(sources[name].read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                pending.append(node.module.split('.')[0])
            elif isinstance(node, ast.Import):
                pending.extend(alias.name.split('.')[0] for alias in node.names)
    originals = {}
    for name in sorted(found):
        p = sources[name]
        txt = p.read_text()
        if name == 'sincon_joint_candidate':
            txt = trim_module(txt, {'rmsle_logs', 'assemble', 'setup'})
        if name == 'sincon_complementary_blend':
            node = next(n for n in ast.parse(txt).body if isinstance(n, ast.FunctionDef) and n.name == 'historical_station_shift')
            lines = txt.splitlines()
            lines[node.lineno - 1:node.end_lineno] = [
                'def historical_station_shift(*args, **kwargs):',
                '    raise RuntimeError("Obsolete Public-scaled historical calibration is blocked")']
            txt = '\n'.join(lines) + '\n'
        # Unused old calibration entry points are never a runnable path.
        if name == 'sincon_apply_final_calibration':
            (work / p.name).write_text('"""Obsolete Public-derived calibration is blocked in this package."""\n'
                                       'PUBLIC_STATION_WEIGHT = None\nPUBLIC_LOG_LEVEL = None\n'
                                       'def calibrate(*args, **kwargs):\n'
                                       '    raise RuntimeError("Public-derived calibration is unavailable")\n')
            continue
        if name == 'sincon_clean_model_layers':
            txt = txt.replace('if digest(args.vector) != VECTOR_SHA256:',
                              'if digest(args.vector) != VECTOR_SHA256 and not args.allow_retrained_vector:')
            txt = txt.replace('"raw_forecast_sha256": VECTOR_SHA256', '"raw_forecast_sha256": digest(args.vector)')
            txt = txt.replace('args = parser.parse_args()',
                              'parser.add_argument("--allow-retrained-vector", action="store_true")\n    args = parser.parse_args()')
        (work / p.name).write_text(portable(txt))
        originals[f'work/{p.name}'] = digest(p)
    selected = {'submission_local_stack.csv', 'submission_conditional_stack.csv', 'sincon_local_validation.csv.gz',
                'sincon_kbo_game_data.csv', 'sincon_station_addresses.csv', 'sincon_station_bus_traffic.csv',
                'sincon_bucheon_football_data.csv', 'sincon_festival_station_days.csv',
                'sincon_housing_approvals.csv', 'sincon_station_centers.csv',
                'sincon_vector_shape_final_raw.csv.gz', 'sincon_vector_boost_validation.csv.gz',
                'sincon_clean_refined_cache.zip', 'sincon_xgb_forecasts.zip', 'sincon_xgb_extra_validation.zip',
                'sincon_target_season_validation.zip', 'sincon_munhak_cancellation_responses.zip',
                'sincon_songdo_beach_location_responses.zip', 'sincon_summer_replay_validation.csv.gz',
                'sincon_zoo_transfer_april_predictions.csv.gz', 'sincon_zoo_transfer_season_predictions.csv.gz'}
    required_inputs = selected.copy()
    required_compressed = selected.copy()
    # Resolve literal data dependencies, including helper functions' file names.
    for name in found:
        tree = ast.parse(sources[name].read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                p = SOURCE / node.value
                if len(node.value) < 200 and '\n' not in node.value and p.is_file() and p.suffix in {'.csv', '.gz', '.json', '.zip'}:
                    selected.add(node.value)
    # Never collect submissions other than the two uncalibrated precursors.
    selected = {n for n in selected if not n.startswith('submission_') or n in {'submission_local_stack.csv', 'submission_conditional_stack.csv'}}
    selected = {n for n in selected if not n.endswith(('.gz', '.zip')) or n in required_compressed}
    trace = ROOT / 'verification/payload_read_trace.json'
    if trace.exists():
        opened = set(json.loads(trace.read_text())['paths'])
        selected = {n for n in selected if n in required_inputs or 'work/' + n in opened}
    selected.discard('submission.csv')
    retained = selected | {'sincon_local_repro.zip', 'sincon_source_reweight_portable.zip', 'external.zip', 'sincon_rolling_conditional_cache.zip'}
    for p in work.iterdir():
        if p.is_file() and p.suffix != '.py' and p.name not in retained:
            p.unlink()  # only obsolete files previously generated inside this payload
    for name in sorted(selected):
        p = SOURCE / name
        if p.is_file() and name not in {'sincon_local_repro.zip', 'sincon_source_reweight_portable.zip'}:
            shutil.copyfile(p, work / name)
            originals[f'work/{name}'] = digest(p)
    # These legacy archives originally mixed clean inputs and obsolete submissions.
    # Retain just the external data and raw historical forecasts used by this path.
    with ZipFile(SOURCE / 'sincon_local_repro.zip') as z, ZipFile(work / 'sincon_local_repro.zip', 'w', ZIP_DEFLATED) as out:
        for n in z.namelist():
            if n.startswith('external_inputs/'):
                data = z.read(n)
                out.writestr(n, data)
                q = work / n
                q.parent.mkdir(parents=True, exist_ok=True)
                q.write_bytes(data)
            elif n.startswith('mobility_monthly/'):
                q = work / n
                q.parent.mkdir(parents=True, exist_ok=True)
                q.write_bytes(z.read(n))
    with ZipFile(SOURCE / 'sincon_source_reweight_portable.zip') as z, ZipFile(work / 'sincon_source_reweight_portable.zip', 'w', ZIP_DEFLATED) as out:
        for n in z.namelist():
            if n.startswith('cache/origin_'):
                out.writestr(n, z.read(n))
    # The lightweight portable archive omits conditional_stack. Vector retraining
    # needs the original conditional precursor even when rolling is disabled.
    with ZipFile(work / 'sincon_rolling_conditional_cache.zip', 'w', ZIP_DEFLATED) as out:
        for p in sorted(Path('/private/tmp/sincon-rolling-forecasts').glob('origin_*.csv.gz')):
            with gzip.open(p, 'rt') as stream:
                rows = csv.DictReader(stream)
                buffer = io.StringIO()
                writer = csv.DictWriter(buffer, fieldnames=['date', 'station_id', 'hour', 'origin', 'conditional_stack'], lineterminator='\n')
                writer.writeheader()
                for row in rows:
                    writer.writerow({k: row[k] for k in writer.fieldnames})
                out.writestr(p.name, gzip.compress(buffer.getvalue().encode(), mtime=0))
    with ZipFile(work / 'external.zip', 'w', ZIP_DEFLATED) as z:
        for p in sorted((work / 'external_inputs').rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(work / 'external_inputs'))
    for name in ('train.csv', 'test.csv', 'metaData.csv'):
        shutil.copyfile(team / 'data' / name, target / 'data' / name)
    for name in ('baseline.py', 'ensemble.py', 'external_features.py', 'improved.py', 'make_calendar.py', 'nn_model.py'):
        txt = (team / name).read_text()
        if name == 'ensemble.py':
            txt = trim_module(txt, {'HERE', 'FEATURES', 'LGB_SEEDS', 'NN_SEEDS', 'NN_KW', 'predict_both', 'rmse'})
            # Load the already-required PyTorch runtime before the tree library.
            # All entry points then use the same runtime initialization order.
            tree = ast.parse(txt)
            neural = next(n for n in tree.body if isinstance(n, ast.ImportFrom) and n.module == 'nn_model')
            tree.body.remove(neural)
            position = sum(isinstance(n, ast.ImportFrom) and n.module == '__future__' for n in tree.body)
            tree.body.insert(position, neural)
            txt = ast.unparse(tree) + '\n'
        if name == 'nn_model.py':
            txt = txt.replace('for seed in seeds:\n        torch.manual_seed(seed)',
                              'for seed in seeds:\n        print(f"MLP seed={seed}, epochs={epochs}, width={width}, device={DEVICE}", flush=True)\n        torch.manual_seed(seed)')
        (target / name).write_text(portable(txt))
    for p in (team / 'external').glob('*.csv'):
        shutil.copyfile(p, target / 'external' / p.name)
    for name in ('ensemble_parts.csv', 'valid_predictions_ABC.csv.gz', 'calendar_features.csv'):
        shutil.copyfile(team / name, target / name)
    for name in ('model_zoo.py', 'valid_predictions_zoo.csv.gz'):
        p = team / 'experiments' / name
        if p.suffix == '.py':
            (target / 'experiments' / name).write_text(portable(p.read_text()))
        else:
            shutil.copyfile(p, target / 'experiments' / name)
    checkpoint = Path('/private/tmp/sincon-tabicl-regressor-v2.ckpt')
    shutil.copyfile(checkpoint, payload / 'models' / 'tabicl-regressor-v2-20260212.ckpt')
    shutil.copyfile(team / 'submission_clean_refined.csv', ROOT / 'reference' / 'submission_clean_refined.csv')
    for name in ('SINCON_EXTERNAL_SOURCES.md', 'SINCON_PUBLIC_SCORE_AUDIT.md', 'RULES_NOTICE_PUBLIC_SCORE.md', 'SINCON_REPRODUCE_CLEAN.md'):
        (ROOT / 'docs' / name).write_text(portable((SOURCE / name).read_text()))
    for name in ('sincon_clean_model_layers_results.json', 'sincon_clean_refined_results.json', 'sincon_clean_replay_verification.json',
                 'sincon_local_candidate_results.json', 'sincon_conditional_candidate_results.json',
                 'sincon_source_reweight_replay_results.json', 'sincon_source_reweight_april_origin_results.json'):
        if (SOURCE / name).exists():
            (ROOT / 'docs' / name).write_text(portable((SOURCE / name).read_text()))
    files = {str(p.relative_to(payload)): digest(p) for p in sorted(payload.rglob('*')) if p.is_file()}
    (ROOT / 'payload_manifest.json').write_text(json.dumps({'sha256': files, 'original_sha256_before_portability_edits': originals}, indent=2) + '\n')
    print(json.dumps({'modules': len(found), 'files': len(files), 'payload_bytes': sum(p.stat().st_size for p in payload.rglob('*') if p.is_file())}))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--team', type=Path, required=True)
    build(ap.parse_args().team)
