# Linux 배포 사전 점검

2026-11-13 KST에 공식 PyPI의 고정 버전 배포 파일을 조회했다. 표는 다운로드 가능한 wheel 메타데이터를 확인한 기록이며 Linux 설치·실행 성공 기록은 아니다. Linux·Kaggle·Colab 실제 실행은 미실행이다.

| 패키지 | 확인한 배포 형태 | 근거 |
|---|---|---|
| numpy2.5.4 | CPython3.12 manylinux glibc2.27/2.28 x86_64 | [PyPI](https://pypi.org/project/numpy/2.5.4/#files) |
| pandas3.1.1 | CPython3.11·3.12 manylinux glibc2.24/2.28 x86_64 | [PyPI](https://pypi.org/project/pandas/3.1.1/#files) |
| scipy1.17.1 | CPython3.11·3.12 manylinux glibc2.27/2.28 x86_64 | [PyPI](https://pypi.org/project/scipy/1.17.1/#files) |
| torch2.9.1 | CPython3.11·3.12 manylinux glibc2.28 x86_64 | [PyPI](https://pypi.org/project/torch/2.9.1/#files) |
| LightGBM4.6.0 | Python3 manylinux glibc2.28 x86_64 | [PyPI](https://pypi.org/project/lightgbm/4.6.0/#files) |
| XGBoost3.4.1 | Python>=3.12, manylinux glibc2.28 x86_64 | [PyPI](https://pypi.org/project/xgboost/3.4.1/#files) |
| TabICL2.2.0 | Python3 none-any wheel | [PyPI](https://pypi.org/project/tabicl/2.2.0/#files) |

Python3.11은 numpy2.3.5·XGBoost3.1.2로 나눠 고정한다. 이 환경의 전체 실제 실행은 하지 않았다. Python3.12를 전체 재학습의 우선 환경으로 정했다.

정적 검사는 파일명 대소문자 충돌 없음, payload 해시 일치, 실제 사용자 절대 경로·MPS 호출 없음, 폰트 파일 의존성 없음, 금지 파일 없음과 정답 날짜 범위를 확인했다. 사용하지 않는 동춘 모듈 CLI의 /private/tmp·홈 팀 폴더 기본값도 패키지 상대 경로로 바꿨다. macOS용 libomp 설치 명령·Homebrew 경로를 실행 코드에 넣지 않았다. 로컬에서 발견한 OpenMP 로드 순서 오류는 필요한 Torch를 먼저 import하도록 수정하고, 실제 별도 프로세스 및 학습으로 확인했다.

고정 버전이 이미 로드된 구버전 메모리를 바꾸지는 못하므로 첫 셀은 버전 불일치가 있으면 런타임 재시작을 요구한다. 일반 Linux pip의 Torch wheel과 CUDA 의존성 다운로드는 클 수 있으며, 설치 다운로드 시간은77초 조립 측정에 포함하지 않는다. CUDA 장치가 없거나 SINCON_DEVICE=cpu이면 신경망은 CPU로 실행한다. TabICL은 원래 재현 설정대로 CPU를 사용한다.
