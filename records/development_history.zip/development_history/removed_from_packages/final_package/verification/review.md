# 독립 코드 검토

검토자 gpt-6-astra, 2026-11-13 KST. 검토 시점에는 full 실행이 진행 중이었다.

정적 검토에서 기본 full의 새 출력이 실제 최종 입력에 이어지는 것을 확인했다. native→팀 모델별 출력, stacks→local·conditional, rolling→과거 예측, hourly_xgb→최종·과거 XGB, clean_oof→새 검증 캐시, event_responses→행사 응답 ZIP, tabicl·vector→후속 보정 입력의 연결이다. 기본 full을 확실히 깨뜨리는 결함이나 금지 보정의 실제 유입은 찾지 못했다. 이는 실제 전체 실행 성공을 뜻하지 않는다.

검토자가 지적한 혼합 실행의 제약을 반영했다. native를 다시 학습하고 event_responses를 끄면 행사 응답이 원본 예측 일치 검사와 충돌할 수 있다. 노트북에서 두 항목을 함께 켜도록 시작 전에 검사하며 조립 함수에도 같은 제약을 둔다.

미확인 사항: 모든 모델의 full 완료, Linux·Python3.11·Kaggle·Colab 실제 실행, 일부 외부 자료의 이용 조건. 실제 실행 로그와 정적 검토는 별도 증거다. 검토 이후 실행에서 발견한 누락 버스 입력 파일과 Jupyter 소켓 제한은 구현자가 수정·기록했다.

## 축소 배포본 추가 정적 검토

2026-11-13 KST, 독립 검토 에이전트(gpt-6-astra). 새 학습이나 파일 수정 없이 관련 코드와 ZIP 구조를 읽었다.

- rolling 종료·clean OOF 진입·최종 조립에서2025년 기준일4개를 earlier/에 동기화하는 연결을 확인했다. 2026년3·4월은 보조 검증으로 분리한다.
- strict summer30시드, 새 A/B/C·최종 conditional, rolling이 clean OOF와 vector에 연결되고, 새 행사·TabICL·vector 출력이 최종 조립으로 전달됨을 확인했다.
- 축소 payload173개와 관련 ZIP의 기준일·컬럼, 노트북17셀·코드6셀의 구문을 확인했다. 추가 치명적 결함은 발견하지 못했다.
- 정적 검토이며 전체 full 완료나 Linux 실기 성공을 입증하지 않는다.
