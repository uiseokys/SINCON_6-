"""Inventory and zip the delivery files, excluding local venvs and training workspaces."""
import csv
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
EXCLUDE = {'.build', 'outputs', '__pycache__', 'SINCON_final_package.zip', 'DISTRIBUTION.json', 'FILE_LIST.tsv',
           'background_full_status.json', 'background_full_failure.json'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink()
                  and not any(x in EXCLUDE or x.startswith('.') for x in p.relative_to(ROOT).parts))


def build():
    archive = ROOT / 'SINCON_final_package.zip'
    for _ in range(2):
        listed = files()
        payload = [p for p in listed if p.is_relative_to(ROOT / 'payload')]
        sizes = {'payload_files': len(payload), 'payload_bytes': sum(p.stat().st_size for p in payload),
                 'delivery_files_excluding_inventory': len(listed), 'delivery_bytes_excluding_inventory': sum(p.stat().st_size for p in listed)}
        zip_mib = archive.stat().st_size / 2**20 if archive.exists() else None
        lines = [f"동결 payload: {sizes['payload_files']}개, {sizes['payload_bytes']:,}바이트, {sizes['payload_bytes']/2**20:.1f}MiB.",
                 f"배포 파일: 목록 자체를 제외하고 {sizes['delivery_files_excluding_inventory']}개, 약 {sizes['delivery_bytes_excluding_inventory']/2**20:.1f}MiB.",
                 f"배포 ZIP: 약 {zip_mib:.1f}MiB." if zip_mib is not None else '배포 ZIP: 생성 중.',
                 '정확한 ZIP 바이트 수와 해시는 원본 작업 폴더의 `DISTRIBUTION.json`에 있습니다. 이 sidecar는 ZIP 바깥에 둡니다. ZIP 내부 전체 파일 목록은 `FILE_LIST.tsv`입니다.']
        readme = ROOT / 'README.md'
        text = readme.read_text()
        text = re.sub(r'<!-- PACKAGE_SIZE_START -->.*?<!-- PACKAGE_SIZE_END -->',
                      '<!-- PACKAGE_SIZE_START -->\n' + '\n\n'.join(lines) + '\n<!-- PACKAGE_SIZE_END -->', text, flags=re.S)
        file_names = sorted([str(p.relative_to(ROOT)) for p in listed] + ['FILE_LIST.tsv'])
        listing = ('<!-- PACKAGE_FILES_START -->\n<details>\n<summary>배포 ZIP 전체 파일 목록</summary>\n\n```text\n'
                   + '\n'.join(file_names) + '\n```\n\n</details>\n<!-- PACKAGE_FILES_END -->')
        if '<!-- PACKAGE_FILES_START -->' in text:
            text = re.sub(r'<!-- PACKAGE_FILES_START -->.*?<!-- PACKAGE_FILES_END -->', listing, text, flags=re.S)
        else:
            text += '\n' + listing + '\n'
        readme.write_text(text)
        listed = files()
        snapshot = {p: p.read_bytes() for p in listed}
        with (ROOT / 'FILE_LIST.tsv').open('w') as stream:
            writer = csv.writer(stream, delimiter='\t', lineterminator='\n')
            writer.writerow(['path', 'bytes', 'sha256'])
            for p in listed:
                data = snapshot[p]
                writer.writerow([str(p.relative_to(ROOT)), len(data), hashlib.sha256(data).hexdigest()])
        with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=3) as z:
            for p in [*listed, ROOT / 'FILE_LIST.tsv']:
                data = snapshot.get(p) if p in snapshot else p.read_bytes()
                z.writestr(str(Path('final_package') / p.relative_to(ROOT)), data)
    result = {**sizes, 'zip_bytes': archive.stat().st_size, 'zip_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
    (ROOT / 'DISTRIBUTION.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    build()
