"""Run the user-visible delivery checks; no model-quality assertions."""
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent


class DeliveryContract(unittest.TestCase):
    def test_notebook_contains_both_modes(self):
        self.assertTrue((ROOT / 'SINCON_final.ipynb').is_file(), 'Final notebook has not been built')
        notebook = json.loads((ROOT / 'SINCON_final.ipynb').read_text())
        code = '\n'.join(''.join(c['source']) for c in notebook['cells'] if c['cell_type'] == 'code')
        self.assertIn('RUN_MODE', code)
        self.assertIn('assemble', code)
        self.assertIn('full', code)

    def test_payload_contains_only_portable_code(self):
        self.assertTrue((ROOT / 'payload').is_dir(), 'Portable payload has not been built')
        for p in (ROOT / 'payload').rglob('*.py'):
            self.assertNotIn('/Users/', p.read_text(), str(p))


if __name__ == '__main__':
    unittest.main()
