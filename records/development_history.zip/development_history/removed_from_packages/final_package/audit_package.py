"""Rerunnable portability, hash, forbidden-input and official-label audit."""
import argparse
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
FORBIDDEN = {'station_backtest_bias.csv', 'score_blend.py', 'station_probe_calibration.py',
             'submission_0p14774_lgb_blend.csv', 'submission_ens30_level_station.csv'}


def label_check(data, name):
    encoding = 'utf-8'
    try:
        columns = pd.read_csv(io.BytesIO(data), nrows=0).columns
    except UnicodeDecodeError:
        encoding = 'cp949'
        columns = pd.read_csv(io.BytesIO(data), nrows=0, encoding=encoding).columns
    except Exception as exc:
        raise ValueError(f'표 형식 확인 실패: {name}; header={data[:12]!r}') from exc
    target = [c for c in ('boardings', 'y_log', 'observed') if c in columns]
    if not target or 'date' not in columns:
        return None
    rows = pd.read_csv(io.BytesIO(data), usecols=['date', *target], encoding=encoding)
    valid = rows[target].notna().any(axis=1)
    dates = rows.loc[valid, 'date'].astype(str)
    if (dates > '2026-06-30').any():
        raise ValueError('학습 기준일 뒤 정답으로 보이는 열: ' + name)
    return {'file': name, 'label_columns': target, 'label_rows': int(valid.sum()), 'last_label_date': dates.max() if len(dates) else None}


def run():
    payload = ROOT / 'payload'
    manifest = json.loads((ROOT / 'payload_manifest.json').read_text())['sha256']
    for n, sha in manifest.items():
        assert hashlib.sha256((payload / n).read_bytes()).hexdigest() == sha, n
    scripts, labels = [], []
    for p in sorted(payload.rglob('*')):
        if not p.is_file():
            continue
        assert p.name not in FORBIDDEN and 'probes' not in p.parts, p
        if p.suffix == '.py':
            text = p.read_text()
            ast.parse(text, filename=str(p))
            assert '/Users/' not in text, p
            assert 'torch.backends.mps' not in text, p
            scripts.append(str(p.relative_to(ROOT)))
        if p.name.endswith(('.csv', '.csv.gz')):
            data = p.read_bytes()
            if p.name.endswith('.gz'):
                data = gzip.decompress(data)
            check = label_check(data, str(p.relative_to(ROOT)))
            if check:
                labels.append(check)
        elif p.suffix == '.zip':
            with ZipFile(p) as archive:
                for name in archive.namelist():
                    assert Path(name).name not in FORBIDDEN, f'{p}!{name}'
                    if name.endswith(('.csv', '.csv.gz')):
                        data = archive.read(name)
                        if name.endswith('.gz'):
                            data = gzip.decompress(data)
                        check = label_check(data, f'{p.relative_to(ROOT)}!{name}')
                        if check:
                            labels.append(check)
    # Detect path case collisions independently of macOS's filesystem behavior.
    files = list(manifest)
    assert len({n.casefold() for n in files}) == len(files)
    mobility = [pd.read_csv(p, usecols=['date', 'mode']) for p in sorted((payload / 'work/mobility_monthly').glob('*.csv.gz'))]
    mobility = pd.concat(mobility, ignore_index=True)
    modes = sorted(mobility['mode'].unique().tolist())
    assert set(modes) == {'car', 'local_bus', 'regional_bus', 'walking'}, modes
    report = {'manifest_files': len(files), 'python_scripts_parsed': len(scripts), 'no_user_absolute_code_paths': True,
              'no_mps_calls': True, 'no_case_collisions': True, 'no_forbidden_input_files': True,
              'official_label_cutoff': '2026-06-30', 'checked_label_tables': labels,
              'mobility_non_subway_audit': {'rows': len(mobility), 'modes': modes, 'first_date': mobility.date.min(), 'last_date': mobility.date.max()},
              'linux_cloud_runtime': 'not executed; static checks only'}
    output = ROOT / 'verification'
    output.mkdir(exist_ok=True)
    (output / 'portability_audit.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'checked_label_tables'}, indent=2))


if __name__ == '__main__':
    run()
