"""nbconvert execution backend for environments that forbid Jupyter socket binds.

All notebook code runs in a single subprocess using the specified new venv.
This is an explicit alternative backend, not a claim that the TCP kernel worked.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

import nbformat
from nbconvert.preprocessors import ExecutePreprocessor


class IsolatedCPUExecute(ExecutePreprocessor):
    def preprocess(self, nb, resources):
        directory = Path(resources['metadata']['path']).resolve()
        script = directory / 'execute_cells.py'
        source = directory / 'SINCON_final.ipynb'
        destination = directory / 'SINCON_final.executed.ipynb'
        environment = os.environ.copy()
        environment.pop('PYTHONPATH', None)
        subprocess.run([os.environ['SINCON_KERNEL_PYTHON'], str(script), str(source), str(destination)],
                       cwd=directory, env=environment, check=True)
        return nbformat.read(destination, as_version=4), resources


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('package', type=lambda s: Path(s).resolve())
    p.add_argument('--python', type=lambda s: Path(s).absolute(), required=True)
    args = p.parse_args()
    env = {'SINCON_KERNEL_PYTHON': str(args.python), 'SINCON_DEVICE': 'cpu', 'CUDA_VISIBLE_DEVICES': '',
           'SINCON_RUN_MODE': 'assemble', 'SINCON_PIP_NO_INDEX': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'IPYTHONDIR': str(args.package / 'verification/ipython')}
    os.environ.update(env)
    os.environ['PYTHONPATH'] = str(args.package)
    os.environ.pop('SINCON_LOCAL_ROOT', None)
    os.environ.pop('SINCON_OUTPUT_DIR', None)
    subprocess.run([sys.executable, '-m', 'jupyter', 'nbconvert', '--to', 'notebook', '--execute',
        '--config', str(args.package / 'socketless_nbconvert_config.py'), 'SINCON_final.ipynb',
        '--output', 'SINCON_final.executed.ipynb'], cwd=args.package, env=os.environ.copy(), check=True)
    print('jupyter nbconvert --execute completed with isolated subprocess execution.', flush=True)
