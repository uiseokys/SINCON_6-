"""Measure only atomically completed rolling files, including partial-stage coverage."""
import argparse
import json
from pathlib import Path
import shutil
from zipfile import ZipFile

import numpy as np
import pandas as pd

from summarize_verification import difference

ROOT = Path(__file__).resolve().parent
KEY = ['date', 'station_id', 'hour']


def run(directory):
    truth = pd.read_csv(ROOT / 'payload/team/data/train.csv').set_index(KEY).boardings
    truth = np.log1p(truth)
    log = directory / 'logs/full_rolling.log'
    timings = {}
    if log.exists():
        for line in log.read_text(errors='replace').splitlines():
            if line.startswith('{'):
                try:
                    row = json.loads(line)
                    if 'origin' in row and 'seconds' in row:
                        timings[row['origin']] = row['seconds']
                except json.JSONDecodeError:
                    pass
    cases = {}
    for archive in ['sincon_source_reweight_portable.zip', 'sincon_target_season_validation.zip']:
        with ZipFile(ROOT / 'payload/work' / archive) as z:
            for member in z.namelist():
                name = Path(member).name
                p = directory / 'runtime/rolling' / name
                if not name.startswith('origin_') or not p.exists():
                    continue
                old = pd.read_csv(z.open(member), compression='gzip')
                new = pd.read_csv(p)
                cutoff = name[7:17]
                if cutoff not in timings:
                    continue
                metric = difference(old, new, KEY, ['local_stack'])
                actual = truth.reindex(pd.MultiIndex.from_frame(new[KEY])).to_numpy()
                assert np.isfinite(actual).all() and np.allclose(actual, new.y_log, atol=1e-8, rtol=0)
                old_values = old.set_index(KEY).local_stack.reindex(pd.MultiIndex.from_frame(new[KEY])).to_numpy()
                metric.update(seconds=timings[cutoff], old_raw_rmsle=float(np.sqrt(np.mean((actual-old_values.clip(min=0))**2))),
                              new_raw_rmsle=float(np.sqrt(np.mean((actual-new.local_stack.to_numpy().clip(min=0))**2))))
                cases[cutoff] = metric
    records = json.loads((directory / 'run.json').read_text())['records']
    complete = any(r['stage'] == 'full_rolling' and r['status'] == 'complete' for r in records)
    report = {'scope': 'raw local_stack before downstream clean corrections; these scores are not final model-layer scores',
              'whole_rolling_stage_complete': complete, 'completed_rolling_origins': len(cases), 'cases': cases}
    if complete:
        completed = next(r for r in reversed(records) if r['stage'] == 'full_rolling' and r['status'] == 'complete')
        report['whole_stage_seconds'] = completed['seconds']
        result = json.loads((directory / 'strict_summer.json').read_text())
        old = pd.read_csv(ROOT / 'payload/work/sincon_summer_replay_validation.csv.gz')
        new = pd.read_csv(directory / 'runtime/work/sincon_summer_replay_validation.csv.gz')
        actual = truth.reindex(pd.MultiIndex.from_frame(new[KEY])).to_numpy()
        assert len(new) == 157_194 and np.isfinite(actual).all()
        assert np.allclose(actual, new.y_log, atol=1e-8, rtol=0)
        old_values = old.set_index(KEY).local_stack.reindex(pd.MultiIndex.from_frame(new[KEY])).to_numpy()
        metric = difference(old, new, KEY, ['team', 'joint', 'conditional_stack', 'local_stack'])
        metric.update(mlp_seeds=result['mlp_seeds'], seconds=result['seconds'],
                      old_raw_rmsle=float(np.sqrt(np.mean((actual-old_values.clip(min=0))**2))),
                      new_raw_rmsle=float(np.sqrt(np.mean((actual-new.local_stack.to_numpy().clip(min=0))**2))))
        report['strict_summer'] = metric
        evidence = ROOT / 'verification/full/rolling_completed'
        evidence.mkdir(exist_ok=True)
        for name in ('strict_summer.json', 'run.json'):
            shutil.copyfile(directory / name, evidence / name)
        shutil.copyfile(log, evidence / 'training.log')
    out = ROOT / 'verification/full/rolling_progress.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'whole_stage_complete': complete, 'completed_origins': len(cases),
                      'scores': {k: [v['old_raw_rmsle'], v['new_raw_rmsle']] for k,v in cases.items()},
                      'strict_summer': report.get('strict_summer')}, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('directory', type=lambda s: Path(s).resolve())
    run(p.parse_args().directory)
