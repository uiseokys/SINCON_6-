# Use only for the local sandbox's no-socket verification. Kaggle/Colab do not need it.
c = get_config()  # noqa: F821, supplied by jupyter's config loader
c.Exporter.default_preprocessors = ['verify_socketless.IsolatedCPUExecute']
