"""Run selected full stages and keep all logs; a subset is explicitly a mixed run."""
import argparse
from pathlib import Path
import os

from pipeline import DEFAULT_STAGES, Run

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stages', default=','.join(DEFAULT_STAGES))
    p.add_argument('--threads', type=int, default=4)
    p.add_argument('--no-assemble', action='store_true')
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    requested = set(args.stages.split(','))
    if requested - DEFAULT_STAGES.keys():
        p.error('Unknown stage')
    run = Run(root, mode='full', device=os.environ.get('SINCON_DEVICE', 'cpu'), threads=args.threads)
    print('RUN_DIRECTORY=' + str(run.output), flush=True)
    run.train({n: n in requested for n in DEFAULT_STAGES})
    if not args.no_assemble:
        run.assemble()
        run.verify()
