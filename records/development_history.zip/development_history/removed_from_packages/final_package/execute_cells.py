"""Execute every notebook code cell in one fresh-venv IPython process.

This backend uses pipes and files, because this sandbox forbids local sockets.
It preserves cell order, state, stdout, rich outputs and exceptions. It is used
by verify_socketless.py's nbconvert preprocessor, not by the submission notebook.
"""
import argparse
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import io
import json
import os
from pathlib import Path
import sys
from time import perf_counter

from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output


def execute(source, destination):
    notebook = json.loads(source.read_text())
    shell = InteractiveShell.instance()
    records = []
    count = 0
    for i, cell in enumerate(notebook['cells']):
        if cell['cell_type'] != 'code':
            continue
        count += 1
        text = cell['source'] if isinstance(cell['source'], str) else ''.join(cell['source'])
        print(f'Executing code cell {i}, execution {count}', flush=True)
        start = perf_counter()
        with capture_output(stdout=True, stderr=True, display=True) as captured:
            result = shell.run_cell(text, store_history=False)
        cell['execution_count'] = count
        cell['outputs'] = []
        for name in ('stdout', 'stderr'):
            value = getattr(captured, name)
            if value:
                cell['outputs'].append({'output_type': 'stream', 'name': name, 'text': value})
        for item in captured.outputs:
            cell['outputs'].append({'output_type': 'display_data', 'data': item.data, 'metadata': item.metadata})
        error = result.error_before_exec or result.error_in_exec
        records.append({'cell_index': i, 'execution_count': count, 'seconds': perf_counter() - start, 'success': error is None})
        destination.write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + '\n')
        if captured.stdout:
            print(captured.stdout[-4500:], flush=True)
        if error:
            print(captured.stderr, file=sys.stderr)
            raise RuntimeError(f'Cell {i} failed') from error
    certificate = {'backend': 'nbconvert custom subprocess IPython preprocessor; no local sockets',
                   'standard_tcp_ipc_kernel': 'blocked by sandbox', 'python_executable': sys.executable,
                   'python': sys.version, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                   'all_code_cells_executed': len(records) == sum(c['cell_type'] == 'code' for c in notebook['cells']),
                   'records': records, 'device': os.environ.get('SINCON_DEVICE'), 'cwd': str(Path.cwd())}
    (destination.parent / 'execution_certificate.json').write_text(json.dumps(certificate, indent=2) + '\n')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    p.add_argument('destination', type=Path)
    args = p.parse_args()
    execute(args.source, args.destination)
