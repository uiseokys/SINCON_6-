"""Verify archived bytes against FILE_LIST.tsv and the payload manifest."""
import csv
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent


def verify():
    archive = ROOT / 'SINCON_final_package.zip'
    prefix = 'final_package/'
    with ZipFile(archive) as z:
        assert z.testzip() is None, 'ZIP CRC failure'
        names = z.namelist()
        assert len(names) == len(set(names)), 'Duplicate archive member'
        assert all(n.startswith(prefix) and '..' not in Path(n).parts for n in names)
        assert not any(s in Path(n).parts for n in names for s in ('.build', 'outputs', '__pycache__', 'probes'))
        notebook_names = [n for n in names if n.endswith('.ipynb')]
        assert notebook_names == [prefix + 'SINCON_final.ipynb'], notebook_names
        inventory = list(csv.DictReader(io.StringIO(z.read(prefix + 'FILE_LIST.tsv').decode()), delimiter='\t'))
        assert {prefix + row['path'] for row in inventory} == set(names) - {prefix + 'FILE_LIST.tsv'}
        for row in inventory:
            data = z.read(prefix + row['path'])
            assert len(data) == int(row['bytes']), row['path']
            assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
        manifest = json.loads(z.read(prefix + 'payload_manifest.json'))['sha256']
        for name, digest in manifest.items():
            assert hashlib.sha256(z.read(prefix + 'payload/' + name)).hexdigest() == digest, name
        source_hash = hashlib.sha256(z.read(prefix + 'SINCON_final.ipynb')).hexdigest()
        certificate = json.loads(z.read(prefix + 'verification/assemble/execution_certificate.json'))
        assert certificate['source_sha256'] == source_hash
        assert certificate['all_code_cells_executed'] and all(c['success'] for c in certificate['records'])
        release = json.loads(z.read(prefix + 'verification/assemble/release_summary.json'))
        assert release['payload_manifest_sha256'] == hashlib.sha256(z.read(prefix + 'payload_manifest.json')).hexdigest()
        csv_bytes = z.read(prefix + 'submission_clean_refined.csv')
        assert csv_bytes == z.read(prefix + 'reference/submission_clean_refined.csv')
        assert hashlib.sha256(csv_bytes).hexdigest() == release['csv_sha256']
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    sidecar = json.loads((ROOT / 'DISTRIBUTION.json').read_text())
    assert sidecar['zip_sha256'] == digest and sidecar['zip_bytes'] == archive.stat().st_size
    return {'archive_files': len(names), 'payload_files': len(manifest), 'inventory_hashes_match': True,
            'notebook_and_payload_match_executed_release': True, 'csv_bytes_match_reference': True,
            'zip_bytes': archive.stat().st_size, 'zip_sha256': digest}


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
