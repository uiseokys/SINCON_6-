"""Compare a completed 30-seed ABC artifact, even while final fitting is still running."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from summarize_verification import difference

ROOT = Path(__file__).resolve().parent
KEY = ['date', 'station_id', 'hour']
COUNTS = {'A': 155916, 'B': 153360, 'C': 153360}


def summarize(directory):
    fresh = directory / 'native_retrained/valid_predictions_ABC.csv.gz'
    new = pd.read_csv(fresh)
    old = pd.read_csv(ROOT / 'payload/team/valid_predictions_ABC.csv.gz')
    assert new.groupby('fold').size().to_dict() == COUNTS
    truth = pd.read_csv(ROOT / 'payload/team/data/train.csv').set_index(KEY).boardings
    actual = np.log1p(truth.reindex(pd.MultiIndex.from_frame(new[KEY])).to_numpy())
    assert np.isfinite(actual).all() and np.allclose(actual, new.y_log, atol=5.1e-7, rtol=0)
    cases = {}
    for label in COUNTS:
        a, b = old.loc[old.fold.eq(label)], new.loc[new.fold.eq(label)]
        result = difference(a, b, KEY, ['lgb_log', 'nn_log', 'ens_log'])
        indexed = a.set_index(KEY).reindex(pd.MultiIndex.from_frame(b[KEY]))
        result['raw_rmsle'] = {column: {
            'old': float(np.sqrt(np.mean((b.y_log.to_numpy() - indexed[column].to_numpy().clip(min=0))**2))),
            'new': float(np.sqrt(np.mean((b.y_log.to_numpy() - b[column].to_numpy().clip(min=0))**2)))}
            for column in ['lgb_log', 'nn_log', 'ens_log']}
        cases[label] = result
    records = json.loads((directory / 'run.json').read_text())['records']
    report = {'scope': 'native uncalibrated LightGBM3 seeds and MLP30 seeds, three official past folds',
              'full_native_stage_complete': any(r['stage'] == 'full_native' and r['status'] == 'complete' for r in records),
              'final_prediction_artifact_exists': (directory / 'native_retrained/ensemble_parts.csv').exists(), 'cases': cases}
    out = ROOT / 'verification/full/native_abc.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'native_stage_complete': report['full_native_stage_complete'],
                      'raw_scores': {k: v['raw_rmsle'] for k,v in cases.items()}}, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('directory', type=lambda s: Path(s).resolve())
    summarize(p.parse_args().directory)
