"""Full mode with all training disabled must preserve the assemble input scope."""
from pathlib import Path
from pipeline import DEFAULT_STAGES, Run

if __name__ == '__main__':
    r = Run(Path(__file__).resolve().parent, mode='full', device='cpu', threads=3)
    print('REGRESSION_RUN=' + str(r.output), flush=True)
    r.train({name: False for name in DEFAULT_STAGES})
    r.assemble()
    result = r.verify()
    assert result['max_abs_log1p_difference'] <= 1e-10, result
