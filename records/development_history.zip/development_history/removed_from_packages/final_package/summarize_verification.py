"""Measure executed artifacts against frozen model outputs, without using Public scores."""
import argparse
import io
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
KEY = ['date', 'station_id', 'hour']


def difference(old, new, keys, columns):
    old, new = old.set_index(keys, verify_integrity=True), new.set_index(keys, verify_integrity=True)
    if not old.index.sort_values().equals(new.index.sort_values()):
        raise ValueError('Comparison keys differ')
    new = new.reindex(old.index)
    result = {'rows': len(old), 'units': 'raw log1p forecast or raw log difference, as column name states'}
    for col in columns:
        a, b = old[col].to_numpy(float), new[col].to_numpy(float)
        assert np.isfinite(a).all() and np.isfinite(b).all()
        d = b - a
        result[col] = {'max_abs_difference': float(np.abs(d).max()), 'mean_abs_difference': float(np.abs(d).mean()),
                       'rms_difference': float(np.sqrt(np.mean(d**2)))}
    return result


def summarize(run):
    work = run / 'runtime/work'
    report = {'run_directory': str(run.relative_to(ROOT)) if run.is_relative_to(ROOT) else run.name,
              'stage_records': json.loads((run / 'run.json').read_text())['records'], 'comparisons': {}}
    baseline = ROOT / 'payload/work'
    for name in ('submission_local_stack.csv', 'submission_conditional_stack.csv'):
        if (work / name).exists() and any(r['stage'] == 'full_stacks' and r['status'] == 'complete' for r in report['stage_records']):
            old, new = (pd.read_csv(p, float_precision='round_trip') for p in (baseline / name, work / name))
            for frame in (old, new): frame['log_prediction'] = np.log1p(frame.boardings)
            report['comparisons'][name] = difference(old, new, ['example_id'], ['log_prediction'])
    with ZipFile(baseline / 'sincon_clean_refined_cache.zip') as z:
        tabicl_complete = any(r['stage'] == 'full_tabicl' and r['status'] == 'complete' for r in report['stage_records'])
        tabicl_log = run / 'logs/full_tabicl.log'
        final_finished = tabicl_log.exists() and '\nA ' in tabicl_log.read_text(errors='replace')
        for name, keys in [('sincon_clean_tabicl_final.csv', ['date', 'station_id']),
                           ('sincon_clean_tabicl_oof.csv', ['date', 'station_id', 'label', 'origin'])]:
            p = run / 'cache' / name
            if p.exists() and (tabicl_complete or (name.endswith('_final.csv') and final_finished)):
                report['comparisons'][name] = difference(pd.read_csv(z.open(name)), pd.read_csv(p), keys, ['tabicl'])
                report['comparisons'][name]['whole_tabicl_stage_complete'] = tabicl_complete
    p = run / 'runtime/hourly_xgb/origin_2026-06-30.csv.gz'
    if p.exists() and any(r['stage'] == 'full_hourly_xgb' and r['status'] == 'complete' for r in report['stage_records']):
        with ZipFile(baseline / 'sincon_xgb_forecasts.zip') as z:
            report['comparisons']['hourly_xgb_final'] = difference(pd.read_csv(z.open(p.name), compression='gzip'), pd.read_csv(p), KEY, ['xgb'])
    p = work / 'sincon_vector_shape_final_raw.csv.gz'
    if p.exists() and any(r['stage'] == 'full_vector' and r['status'] == 'complete' for r in report['stage_records']):
        report['comparisons']['vector_final'] = difference(pd.read_csv(baseline / p.name), pd.read_csv(p), KEY, ['raw_delta'])
    p = run / 'native_retrained/ensemble_parts.csv'
    if p.exists():
        report['comparisons']['native_final'] = difference(pd.read_csv(ROOT / 'payload/team/ensemble_parts.csv'), pd.read_csv(p), ['example_id'], ['log_lgb', 'log_nn'])
    if any(r['stage'] == 'full_event_responses' and r['status'] == 'complete' for r in report['stage_records']):
        for name, prefix in [('sincon_munhak_cancellation_responses.zip', 'sincon_munhak_cancelled_nn_seed'),
                             ('sincon_songdo_beach_location_responses.zip', 'sincon_songdo_beach_nn_seed')]:
            old_parts, new_parts = [], []
            with ZipFile(baseline / name) as old_zip, ZipFile(work / name) as new_zip:
                for seed in range(3):
                    member = f'{prefix}{seed}.csv'
                    old_parts.append(pd.read_csv(old_zip.open(member)).assign(seed=seed))
                    new_parts.append(pd.read_csv(new_zip.open(member)).assign(seed=seed))
            report['comparisons'][prefix] = difference(pd.concat(old_parts), pd.concat(new_parts), ['example_id', 'seed'],
                                                       ['original_nn', 'station_delta', 'combined_delta'])
            report['comparisons'][prefix]['scope'] = 'same three seeds; original and new environment differences are not isolated to hardware alone'
            columns = ['original_nn', 'station_delta', 'combined_delta']
            old_mean = pd.concat(old_parts).groupby('example_id')[columns].mean().reset_index()
            new_mean = pd.concat(new_parts).groupby('example_id')[columns].mean().reset_index()
            report['comparisons'][prefix + '_mean_of_three'] = difference(old_mean, new_mean, ['example_id'], columns)
    output = ROOT / 'verification/full'
    output.mkdir(parents=True, exist_ok=True)
    path = output / (run.name + '.json')
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'report': str(path.relative_to(ROOT)), 'comparisons': report['comparisons']}, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('run', type=lambda s: Path(s).resolve())
    args = p.parse_args()
    summarize(args.run)
    if (args.run / 'native_retrained/valid_predictions_ABC.csv.gz').exists():
        from summarize_native import summarize as summarize_native
        summarize_native(args.run)
    if (args.run / 'strict_summer.json').exists():
        from summarize_rolling import run as summarize_rolling
        summarize_rolling(args.run)
