"""Continue the already-running native training into a strict full verification.

This supervisor writes only in final_package. It never changes the default CSV,
the frozen payload, any parameter using Public scores, or an external service.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def stamp():
    return datetime.now(timezone.utc).isoformat()


def run(args):
    output = args.run
    state_path = ROOT / f'verification/background_full_{args.supervisor_id}_status.json'
    state = {'run_directory': str(output.relative_to(ROOT)), 'supervisor_pid': os.getpid(),
             'started_utc': stamp(), 'state': 'waiting_for_native', 'standard_cloud_execution': False,
             'supervisor_id': args.supervisor_id, 'python_executable': sys.executable}

    def save(**updates):
        state.update(updates, updated_utc=stamp())
        temporary = state_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False) + '\n')
        temporary.replace(state_path)

    save()
    while datetime.now(timezone.utc) < args.deadline:
        try:
            records = json.loads((output / 'run.json').read_text())['records']
        except (FileNotFoundError, json.JSONDecodeError):
            time.sleep(20)
            continue
        if any(r['stage'] == 'full_native' and r['status'] == 'failed' for r in records):
            save(state='native_failed', evidence='run.json')
            return
        native_done = any(r['stage'] == 'full_native' and r['status'] == 'complete' for r in records)
        parent_done = any(r['stage'] == 'training_coverage' for r in records)
        if native_done and parent_done:
            break
        log = output / 'logs/full_native.log'
        if log.exists():
            progress = [line for line in log.read_text(errors='replace').splitlines() if line.startswith('MLP seed=')]
            save(native_started_seed_fits=len(progress), native_most_recent_seed=progress[-1] if progress else None)
        time.sleep(20)
    else:
        save(state='native_not_finished_by_deadline', evidence='logs/full_native.log')
        return
    # The original driver has finished writing its ledger before this writer starts.
    marker = output / f'background_continuation.{args.supervisor_id}.started'
    with marker.open('x') as stream:
        stream.write(stamp() + '\n')
    time.sleep(2)
    from pipeline import DEFAULT_STAGES, Run
    r = Run.__new__(Run)
    r.package, r.mode, r.output = ROOT, 'full', output
    r.payload, r.work, r.team = output / 'runtime', output / 'runtime/work', output / 'runtime/team'
    r.logs, r.cache, r.threads = output / 'logs', output / 'cache', args.threads
    r.earlier, r.xgb = r.payload / 'rolling', r.payload / 'hourly_xgb/origin_2026-06-30.csv.gz'
    r.records = json.loads((output / 'run.json').read_text())['records']
    r.full_stages = DEFAULT_STAGES.copy()
    r.retrained_vector = False
    r.env = {**os.environ, 'SINCON_DEVICE': 'cpu', 'CUDA_VISIBLE_DEVICES': '', 'PYTHONDONTWRITEBYTECODE': '1',
             'PYTHONNOUSERSITE': '1', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': str(args.threads),
             'TMPDIR': str(output / 'tmp')}
    r.env.pop('PYTHONPATH', None)
    # Preserve the just-trained model predictions. Refresh only portable code.
    for p in (ROOT / 'payload/work').glob('*.py'):
        shutil.copyfile(p, r.work / p.name)
    for p in (ROOT / 'payload/team').glob('*.py'):
        shutil.copyfile(p, r.team / p.name)
    shutil.copyfile(ROOT / 'payload/work/sincon_rolling_conditional_cache.zip', r.work / 'sincon_rolling_conditional_cache.zip')
    r.validate_official()
    r.record('background_continuation', 'native_complete_continue_remaining', 0., {'strict_full_requested': True})
    for stage in DEFAULT_STAGES:
        if stage == 'native':
            continue
        save(state='training_' + stage)
        r.execute('full_' + stage, ROOT / 'full_stage.py', stage, r.payload, r.cache, r.output, '--threads', r.threads)
        if stage == 'vector':
            r.retrained_vector = True
    r.record('training_coverage', 'all_stages_complete', 0., {'stages': r.full_stages, 'strict_full': True})
    save(state='assembling_retrained_predictions')
    r.assemble()
    verification = r.verify()
    subprocess.run([sys.executable, str(ROOT / 'summarize_verification.py'), str(output)], check=True)
    evidence = ROOT / 'verification/full/strict_full_verification.json'
    shutil.copyfile(output / 'verification.json', evidence)
    save(state='strict_full_complete', verification=verification, evidence=str(evidence.relative_to(ROOT)))
    # Keep the submission requested by the user unchanged. The new run is a separate result.
    status = ROOT / 'STATUS.md'
    with status.open('a') as stream:
        stream.write('\n## 백그라운드 strict full 완료, ' + stamp() + '\n\n')
        stream.write('위 중간 상태를 대체하는 실제 완료 기록이다. native·스택·rolling·시간별XGB·clean OOF·행사 응답·TabICL·벡터를 모두 수행하고 최종 형식 검사를 통과했다. ')
        stream.write(f"기준과 최대 log1p 차이는 {verification['max_abs_log1p_difference']:.12g}이다. ")
        stream.write('기본 조립 CSV와 동결 입력은 바꾸지 않았다. 새 결과는 `' + str(output.relative_to(ROOT)) + '/submission_clean_refined.csv`이다. ')
        stream.write(f'증거는 `verification/background_full_{args.supervisor_id}_status.json` 및 `verification/full/strict_full_verification.json`이다. Linux·Kaggle·Colab·Python3.11·GPU 실기와 미확인 자료 이용 조건은 여전히 미확인이다.\n')
    subprocess.run([sys.executable, str(ROOT / 'build_distribution.py')], check=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('run', type=lambda s: Path(s).resolve())
    ap.add_argument('--deadline', type=lambda s: datetime.fromisoformat(s.replace('Z', '+00:00')), required=True)
    ap.add_argument('--threads', type=int, default=4)
    ap.add_argument('--supervisor-id', required=True)
    ns = ap.parse_args()
    try:
        run(ns)
    except Exception as exc:
        p = ROOT / f'verification/background_full_{ns.supervisor_id}_failure.json'
        p.write_text(json.dumps({'updated_utc': stamp(), 'error': repr(exc)}, indent=2) + '\n')
        state = ROOT / f'verification/background_full_{ns.supervisor_id}_status.json'
        if state.exists():
            data = json.loads(state.read_text())
            data.update(state='failed', updated_utc=stamp(), failure_file=str(p.relative_to(ROOT)))
            state.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
        raise
