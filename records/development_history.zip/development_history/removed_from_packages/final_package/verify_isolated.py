"""Copy only the delivery package into an empty directory, then execute its notebook.

Use --prepare to copy files and create an isolated kernelspec. The venv must already
contain requirements.txt and ipykernel. nbconvert runs in the controlling environment,
but every notebook cell runs in the supplied fresh venv's Python kernel.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def prepare(destination, python):
    destination.mkdir(parents=True, exist_ok=True)
    package = destination / 'final_package'
    if package.exists():
        raise FileExistsError('검증 폴더는 비어 있어야 합니다.')
    package.mkdir()
    for p in ROOT.iterdir():
        if p.name.startswith('.') or p.name in {'outputs', 'verification', '__pycache__'} or p.suffix == '.zip':
            continue
        q = package / p.name
        if p.is_dir():
            shutil.copytree(p, q)
        else:
            shutil.copyfile(p, q)
    kernel = destination / 'jupyter/kernels/sincon-clean'
    kernel.mkdir(parents=True)
    (kernel / 'kernel.json').write_text(json.dumps({'argv': [str(python.absolute()), '-m', 'ipykernel_launcher', '-f', '{connection_file}'],
        'display_name': 'SINCON isolated CPU', 'language': 'python', 'env': {'SINCON_DEVICE': 'cpu', 'CUDA_VISIBLE_DEVICES': '',
        'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': ''}}, indent=2))
    return package


def execute(destination):
    package = destination / 'final_package'
    env = {**os.environ, 'JUPYTER_PATH': str(destination / 'jupyter'), 'SINCON_DEVICE': 'cpu', 'CUDA_VISIBLE_DEVICES': '',
           'SINCON_RUN_MODE': 'assemble', 'SINCON_PIP_NO_INDEX': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'IPYTHONDIR': str(destination / 'ipython'), 'JUPYTER_CONFIG_DIR': str(destination / 'jupyter_config'),
           'JUPYTER_RUNTIME_DIR': str(destination / 'jupyter_runtime'), 'MPLCONFIGDIR': str(destination / 'matplotlib')}
    env.pop('PYTHONPATH', None)
    env.pop('SINCON_LOCAL_ROOT', None)
    env.pop('SINCON_OUTPUT_DIR', None)
    subprocess.run([sys.executable, '-m', 'jupyter', 'nbconvert', '--to', 'notebook', '--execute', 'SINCON_final.ipynb',
        '--ExecutePreprocessor.kernel_name=sincon-clean', '--ExecutePreprocessor.timeout=1800',
        '--KernelManager.transport=ipc', '--KernelManager.ip=sincon-ipc',
        '--output', 'SINCON_final.executed.ipynb'], cwd=package, env=env, check=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('destination', type=lambda s: Path(s).resolve())
    ap.add_argument('--python', type=lambda s: Path(s), required=True)
    ap.add_argument('--prepare-only', action='store_true')
    ns = ap.parse_args()
    prepare(ns.destination, ns.python)
    if not ns.prepare_only:
        execute(ns.destination)
