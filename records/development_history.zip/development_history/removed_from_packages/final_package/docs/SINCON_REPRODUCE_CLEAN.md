# SINCON 정리본 재현

`submission_clean_refined.csv`는 2026-06-30까지의 공식 승차 자료로 검증한 보정만 적용한다. Public 점수로 정한 전체 수준과 역 패턴 배율은 원본 스택 단계부터 제외했다. 공식 예측 대상의 157,194개 ID를 순서대로 사용한다. 대회 점수는 미측정이다. KBO·K리그 등 일부 기존 외부 자료는 이용 조건 확인이 남아 있다. [출처 및 이용 조건](SINCON_EXTERNAL_SOURCES.md) · [Public 점수 사용 감사](SINCON_PUBLIC_SCORE_AUDIT.md)

## 공식 CSV와 보관 모델 출력으로 재현

공식 `train.csv`, `test.csv`, `metaData.csv`는 팀 폴더의 `data/`에 둔다. `sample_submission.csv`는 필요 없다. 팀의 `ensemble_parts.csv`와 `valid_predictions_ABC.csv.gz`는 보정 전 모델별 출력과 검증 자료다. 작업 폴더의 `sincon_clean_refined_cache.zip`은 이른 기준일의 검증 예측, TabICL의 원시 일별 예측, 벡터 XGBoost의 시간대 차이를 보관한다. 보관된 검증 예측의 정답은 실행 중 공식 `train.csv`에서 다시 가져온다.

```bash
repo="PORTABLE_SOURCE_PATH"
team="PORTABLE_SOURCE_PATH"
output="$(mktemp -d)"
OPENBLAS_NUM_THREADS=1 python "$repo/sincon_replay_clean_refined.py" \
  "$team" "$repo/sincon_clean_refined_cache.zip" "$output"
```

이 명령은 원본 로컬 스택, 키별 XGBoost 예측, 고정 자료를 읽는다. 초기 행사·날씨·계양/귤현·심야 보정, 공연 취소·장소 및 추가 행사, 후속 모델, 마지막 축제의 순으로 다시 적용한다. `early.json`, `events_before_model.json`, `model.json`, `events_after_model.json`에서 각 단계 입력 해시와 변경 행을 확인한다. `event_keys.csv`에 행사 키가 들어 있다.

정리본 SHA-256은 `519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199`이다. 별도 작업 디렉터리의 두 CLI 실행은 바이트가 일치했다. 한 번은 Public 유래 후보와 역별 보정 파일을 열면 실패하도록 차단한 상태에서 실행했다. 단계별 별도 실행과의 최대 승차 예측 차이는 `2.51e-12` 미만이었다. 다른 환경에서는 `log1p` 공간의 절대 오차 허용치 `1e-10`으로 정리본과 비교한다. [재현 확인](sincon_clean_replay_verification.json) · [단계별 보정 검증](sincon_clean_model_layers_results.json) · [최종 행사 결과](sincon_clean_refined_results.json)

## 공식 train.csv부터 학습 순서

1. [로컬 모델 노트북](sincon_reproduce_local.ipynb)과 [조건별 결합 노트북](sincon_reproduce_stack.ipynb)에 원본 CSV 폴더를 지정한다. 전자는 `sincon_local_repro.zip`, 후자는 `sincon_conditional_repro.zip`을 사용한다. 두 노트북에서 `REBUILD_TEAM=False`를 유지한다. 이 경로는 팀의 보정 전 신경망을 불러오고 LightGBM, 그래프, 가법 시간대 모형, 버스·경기 모형, 수요 혼합, 축제·주거 보정을 공식 과거 자료에서 재학습한다. `submission_local_stack.csv`, `submission_conditional_stack.csv`, `sincon_local_replay_validation.csv.gz`를 얻는다.
2. 팀의 기본 LightGBM·MLP까지 재학습하려면 복사한 팀 코드와 동결된 `external/`로 `python "$repo/sincon_clean_native_forecasts.py" "$team" "$fresh_team" --threads 6`을 실행한다. 생성한 `ensemble_parts.csv`와 `valid_predictions_ABC.csv.gz`를 새로 푼 두 노트북의 복사본 팀 폴더에 각각 넣고 1단계를 실행한다. 원래 노트북의 선택적 `sincon_rebuild_team.py`는 옛 수준 보정을 출력하므로 이 경로에서 실행하지 않는다. GPU·CPU와 PyTorch 버전에 따라 새 MLP 수치가 조금 달라질 수 있다.
3. 과거 기준일 예측을 다시 학습하려면 `sincon_rolling_forecasts.py`에 로컬 노트북의 모델 인수 10개와 새 출력 폴더를 넘긴다. 2025-06-30, 07-31, 08-31, 09-30은 기본 설정이다. 2026년 3·4월 기준일에는 `--window 2026-03-31:2026-06-30 --window 2026-04-30:2026-06-30`을 사용한다. 엄격한 2025년 여름 비교는 같은 모델 인수를 `sincon_summer_replay.py`에 넘기고 `--seeds 30`으로 실행한다. 2026년 보조 두 개는 `sincon_target_season_validation.zip`에 보관했다.
4. 시간별 XGBoost는 `python "$repo/sincon_zoo_transfer_season.py" "$team" "$xgb" --origin 2026-06-30 --end 2026-10-31 --competition-test`로 재학습한다. 같은 명령에서 기준일과 종료일을 과거 검증에 맞추고 `--competition-test`를 빼면 과거 예측을 만든다. A/B/C 예측은 팀 `experiments/valid_predictions_zoo.csv.gz`의 보정 전 XGBoost 열을 사용한다. 나머지 예측은 `sincon_xgb_forecasts.zip` 및 `sincon_xgb_extra_validation.zip`에서 확인할 수 있다.
5. `sincon_clean_15126_replay.py`에 팀 폴더, 2025년 과거 예측 폴더, 최종 XGBoost, 새 CSV, 보고서 경로를 넘긴다. 재학습한 경우 `--local-stack`, `--conditional-stack`, `--local-historical-abc`로 1단계 출력을 지정한다. 과거 행별 예측도 새로 만들려면 `--validate --validation-archive` 및 `--recent`, `--extra-xgb`, `--june-xgb`, `--april-xgb`를 지정한다. 아홉 구간의 `combined` 열이 후속 모형과 행사 검증에 쓰이는 보정 전 기준이다. 이 열을 `baseline`으로 이름을 바꾸고 `date,station_id,hour,label,origin,baseline` 순으로 CSV에 저장한다.
6. 공연 취소와 송도해변축제 장소 변경의 원본 모델 반응은 `sincon_munhak_cancellation_lgb.py`, `sincon_songdo_beach_location_lgb.py`, `sincon_munhak_cancelled_nn.py`로 재학습한다. 송도 LightGBM 스크립트에는 2025-07-31 예측과 5단계의 CSV를 준다. 신경망은 시드 0·1·2를 각각 실행한다. 송도 시나리오에는 `--songdo-beach`를 넣는다. 재현 경로는 두 `*_responses.zip`에 보관한 보정 전 모델 응답을 사용하며, 96개 행의 수정량을 이 응답에서 재계산한다.
7. `sincon_clean_tabicl_forecast.py`에 팀 폴더, 로컬 노트북이 만든 `external.zip`, 정확한 TabICL 체크포인트, 출력 경로를 전달한다. 최종에는 `--folds final`을 지정한다. 과거에는 `--folds A B C summer 2025-07-31 2025-08-31 2025-09-30 2026-03-31 2026-04-30`을 지정한다. 벡터 XGBoost는 `sincon_archived_intraday_anomalies.vector_inputs`와 `vector_signal`에 각 기준일의 조건별 결합 예측을 넘긴다. 최종 열은 `date,station_id,hour,fold,raw_delta`다. A/B/C는 `sincon_vector_boost.py`의 검증 출력에서 `shape-reference`를 사용한다. 보관된 벡터 입력은 재현 중 해시와 키가 확인된다.
8. `sincon_clean_event_replay.py --stage before_model`로 행사 보정을 만들고 `--protected`로 보호 키를 남긴다. `sincon_clean_model_layers.py`에 그 예측과 보호 키, 5단계의 OOF, 7단계의 TabICL·벡터 입력을 준다. `sincon_clean_event_replay.py --stage after_model`로 검암, 선학, 과학대제전 시간대와 둘레길 축제 보정을 적용한다. 정확 재현 명령이 이 세 단계를 순서대로 실행한다. 1·4단계의 새 모델을 활용하려면 명령에 `--local-stack`, `--conditional-stack`, `--local-historical-abc`, `--xgb`를 지정한다.

로컬에서는 공식 CSV와 보관 신경망을 사용한 원본 스택 재학습, 최종 XGBoost 재학습, TabICL 10개 기준일 원시 예측 생성, 정리본 조립을 실행했다. 팀 MLP 30개 시드 전체를 새 런타임에서 재학습하는 경로와 Kaggle·Colab에서의 전체 재실행은 확인 전이다. 정확 재현에는 검증된 보관 예측을 사용한다.

## 시드와 환경

| 구성 | 시드와 고정 설정 |
|---|---|
| 팀 LightGBM 및 생활이동 LightGBM | 0·1·2, 1,500회, 학습률 0.05, 63 leaves, 최소 리프 100, 로그 승차 MSE |
| 팀 임베딩 MLP | 최종과 A/B/C는 0~29, 30 epoch, 폭 512, dropout 0.15. 2025년 월말 롤링 예측은 시드 0, 30 epoch, 폭 384 |
| 그래프와 혼합 신경망 | 시드 0·1. 그래프 120 epoch, 비음수 혼합 125 epoch 및 6개 성분 |
| 버스 LightGBM과 행사 대응 | 버스 시드 0. 취소·장소 LightGBM 시드 0·1·2, MLP 대응도 0·1·2 |
| 시간별 XGBoost | 시드 0, 2,000회, 학습률 0.05, 깊이 8 |
| 벡터 XGBoost | 시드 19, 650회, 학습률 0.06, 깊이 6, 18출력 트리 |
| TabICL | 시드 2026, CPU, 앙상블 멤버 2. [사용 체크포인트](https://huggingface.co/jingang/TabICL/blob/main/tabicl-regressor-v2-20260212.ckpt) |

| 확인한 실행 | 패키지 버전 |
|---|---|
| 원본 로컬·조건별 스택 매니페스트 | numpy 2.3.5, pandas 2.2.3, scipy 1.17.1, torch 2.9.1, lightgbm 4.6.0 |
| 이번 TabICL 및 정리본 조립 실행 | Python 3.12.15, macOS ARM64, numpy 2.5.4, pandas 3.1.1, scipy 1.17.1, torch 2.15.0, lightgbm 4.6.0, xgboost 3.4.1, scikit-learn 1.9.1, tabicl 2.2.0, catboost 1.2.10, huggingface-hub 2.4.0, einops 0.8.2, psutil 7.2.2 |

검증 로그에 포함된 모델별 데이터 기준일은 최종 2026-06-30, A 2026-02-28, B 2025-12-31, C 2025-10-31, 엄격 여름 2025-06-30이다. 정답 조회는 해당 검증 및 학습 기간의 공식 `train.csv`로 제한한다.
