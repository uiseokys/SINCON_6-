# 실행 상태

2026-11-13 01:52 KST 기준. 아래 진행 상태는 스냅샷이며 실제 완료 증거와 구분한다.

## (a) 실행해서 확인한 것

- 배포 입력173개만 복사한 빈 폴더와 새 Python3.12 CPU 가상환경에서 노트북 코드6셀 전체 실행. 약73초(설치 다운로드 제외), 157,194행·공식 ID 순서·열·유한한 비음수 검사 통과. 기준 CSV와 최대 log1p 차이 **0**, 바이트 일치. SHA-256 `519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199`. 증거: `verification/assemble/release_summary.json`.
- 표준 Jupyter TCP·IPC kernel은 샌드박스 소켓 bind 제한으로 실패했다. 실제 `jupyter nbconvert --execute`에 별도 subprocess IPython 백엔드를 연결해 전체 셀을 실행했다. 표준 kernel 성공으로 표시하지 않는다.
- 실제 설정으로 스택 A/B/C·최종, 시간별XGB10구간, clean OOF, 행사 LGB·MLP응답, TabICL10구간, 벡터10구간 완료. 단계별 실제 시간과 범위는 `verification/MEASURED_RUNS.md`. 단계별 캐시가 섞인 실행이므로 전체 full 완료와 구분한다.
- 원본 XGB3.4.1의 시간별·벡터 최종 원시 예측은 보관값과 차이0. TabICL·벡터만 재학습한 최종 조립은 최대 log1p 차이6.8664551e-7.
- 모든 학습을 끈 full 회귀는 과거 기준일 범위 수정 뒤 차이0. 해시·정답 날짜·금지 입력·대소문자·MPS·경로 검사 및 Python3.11 문법125파일 통과.

- rolling 전체 완료: 월말6구간 + 엄격 여름30시드, 실제 3088.96초. 엄격 여름 원시 team·joint 차이0, local 최대1e-9. 이 출력으로 clean OOF와 최종 조립을 재실행해 최대 log1p 차이 1.29966598e-06를 측정했다. 나머지 모델은 캐시이며 전체 full 결과가 아니다. `verification/full/rolling_progress.json`, `verification/full/rolling_and_clean_oof/`.

## (b) 실행하지 못했거나 진행 중인 것

- native: A의30시드 완료, B 진행 중. 현재 MLP 시작 46/120회. A/B/C와 최종이 모두 끝난 단계는 아직 아니다. `verification/full/native_progress.json`.
- 모든 모델을 함께 새로 만든 strict full의 최종 차이는 아직 미측정이다. native 종료 뒤 나머지 전 단계를 잇는 CPU 백그라운드 실행을 남겼다.
- Linux·Kaggle·Colab·Python3.11·CUDA GPU 실제 실행 및 미확인 외부 자료의 전체 제거 재학습은 **미실행**이다. Linux wheel·경로 정적 점검은 실기를 대신하지 않는다.

## (c) 남은 위험

- KBO·K리그·일부 주거·행사 자료 이용·재배포 조건 미확인. 첫 설치에는 네트워크가 필요하고 Torch 다운로드가 클 수 있다.
- full 신경망 결과는 기준과 달라질 수 있다. 실제3시드 평균 행사 응답 차이와 라이브러리 버전 대조를 노트북에 기록했다. Python3.11은 XGB3.1.2 호환 분기로 전체 재학습 차이가 더 클 수 있다.
- full 전체 완료·클라우드 실기·원출처 권리 확인 없이 규칙7절과3절의 최종 적합성을 확정하지 않는다. Public 값으로 계수를 정하거나7월 이후 지하철 실측을 사용하지 않았으며 업로드하지 않았다.

## (d) Claude가 다음에 결정할 것

- 미확인 자료의 비상업 이용·비공개 Dataset 재배포 조건과 대회 적합성을 판단한다.
- 백그라운드 결과와 클라우드 실기를 확인하고 완성 후보 중 최종2개를 직접 선택한다. Public은 후보 선택에만 쓴다.
- 추가 보정은 공식 과거 검증 뒤 `CORRECTIONS` 두 항목의 enabled 한 줄로 켠다. 지금은 둘 다 꺼져 있다.

## 백그라운드 경로

- **주 상태**: `verification/background_full_original_versions_status.json`
- native와 이후 strict full: `outputs/sincon_full_20261112T152115_294398Z/run.json`, `logs/full_native.log` 및 이후 `logs/full_*.log`
- 주 제어기 로그: `.build/background_full_authoritative.log`
- 별도 rolling: `outputs/sincon_full_20261112T155913_404166Z/logs/full_rolling.log`
- 상세 완료 증거: `verification/full/`. 구 제어기는 중복 학습을 시작하지 못하게 예약 마커로 막았으며 `verification/background_controller_handoff.json`에 기록했다.

`.build/`와 `outputs/`는 로컬 학습용으로 유지하며 배포 ZIP에서 제외한다. 현재 기본 CSV와 동결 입력은 백그라운드 결과로 바꾸지 않는다. 제어기는 strict full 완료 시 검증 결과를 STATUS에 추가하고 ZIP을 다시 만든다.
