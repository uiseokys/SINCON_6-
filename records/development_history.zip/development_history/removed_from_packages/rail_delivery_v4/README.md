# rail_delivery_v4 — 전 노선(7호선·환승역 제외) 변화 옮기기 + 공휴일 수준 후보

작성: 2026-11-13, Claude. 팀 핫식스, SINCON 2026.

| 출력 | 내용 | Public (팀 제출) |
|---|---|---:|
| `submission_rail_factors_k12_on_xgb7.csv` | `final_stack_delivery` 최종 출력 + 전 노선 주성분 12개로 변화 옮기기(일반일 0.15·공휴일류 0.3) + 공휴일류 수준 보정 | 0.143545 |

**규칙 관련**: 다른 노선의 2026년 7~10월 일별 승차 실측을 쓴다. 팀장이 "운영진이 대회 대상이 아닌 노선의 실측 사용을 구두로 허용했다(7호선·환승역 제외)"고 전달해 만들었고, 서면 확인은 없다(2026-11-13 기준). 인천 1·2호선, 7호선, 그 환승역의 자료는 쓰지 않는다. 자세한 내용은 노트북 첫 셀과 `RAIL_PREREGISTRATION.md`.

- 자료: 서울 열린데이터광장 OA-12914 "서울시 지하철호선별 역별 승하차 인원 정보", 공공누리 1유형(출처표시), 저작권자 서울특별시·코레일·공항철도, 조회일 2026-11-13. https://data.seoul.go.kr/dataList/OA-12914/F/1/datasetView.do
- `cache/rail_all_allowed.csv.gz`: 26개 노선 561개 역의 2025-01-01~2026-10-31 일별 승차(그중 669일이 모두 있는 544개 역을 쓴다). 받는 스크립트 `provenance/fetch_all.py`, 제외 이름 목록 `cache/ban_list.json`.
- `predictions/xgbnb_test.npy`, `xgb_test.npy`: 공휴일 수준 층에 쓰는 두 XGBoost의 시험 기간 예측(보관 입력). 다시 만드는 스크립트 `provenance/nb_test.py`, `xgb_test.py`.
- 실행: `final_package` → `final_delivery_v2` → `final_stack_delivery` → 이 폴더의 `SINCON_rail_factors_k12.ipynb`.
- 이전 판: `rail_delivery/`(0.144427), `rail_delivery_v2/`(0.144280), `rail_delivery_v3/`(주성분 5개, 0.143777).
- 확인하지 못한 것: Kaggle·Colab 실행. 로컬 검증은 `VERIFICATION.md`.
