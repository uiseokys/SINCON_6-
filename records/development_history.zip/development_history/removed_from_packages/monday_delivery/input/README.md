1단계 출력 submission_clean_refined.csv를 이곳에 놓거나 BASELINE_CSV를 지정합니다. 없으면 동봉 수치 기준을 사용합니다.
