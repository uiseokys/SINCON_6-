# 로컬 검증 기록 (2026-11-13 18:23 KST, Claude)

ZIP을 빈 폴더에 풀어 읽기 전용으로 두고 실제 Jupyter 커널로 `SINCON_rail_factors_k30.ipynb` 전체 셀을 실행했다(macOS, CPU, 출력 폴더는 패키지 밖).

| 환경 | `submission_rail_factors_k30_on_xgb7.csv` | `submission_rail_factors_k30_hour_on_xgb7.csv` |
|---|---|---|
| Python 3.12.15, pandas 3.1.1, numpy 2.5.4 | 제출 파일과 바이트 일치 (SHA 13b0ff73fb7d…) | 바이트 일치 (SHA aa4557445565…) |
| Python 3.11.17, pandas 3.1.1, numpy 2.3.5 | 바이트 일치 | 바이트 일치 |

- 노트북이 타 노선 파일에 7호선 행과 환승역 행이 없는지, 보호 역·날짜의 값이 기반 파일과 같은지 확인한다.
- 확인하지 못한 것: Kaggle·Colab 실행(주성분 분해는 선형대수 라이브러리에 따라 끝자리가 달라질 수 있어, 다른 환경에서는 1e-9 이내 수치 일치를 기준으로 본다), 보관한 두 XGBoost 예측의 재학습 일치, OA-12914 원자료를 다시 받아 처음부터 만드는 실행.
