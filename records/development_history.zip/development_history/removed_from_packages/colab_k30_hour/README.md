# colab_k30_hour — Colab에서 `submission_rail_factors_k30_hour_on_xgb7.csv` 만들기

작성: 2026-11-13 18:40 KST, Claude. 팀 핫식스, SINCON 2026.

## 쓰는 법

1. Colab에서 `SINCON_colab_k30_hour.ipynb` 를 연다(파일 → 노트북 업로드).
2. 왼쪽 **파일** 창에 이 폴더의 ZIP 두 개를 끌어다 놓는다(`/content`). 올리지 않으면 노트북이 업로드 창을 띄운다. 구글 드라이브 `내 드라이브`에 넣고 드라이브를 연결해도 된다.
   - `SINCON_final_stack_delivery.zip` (약 78MB, SHA-256 aeefd5fbf1210395…)
   - `SINCON_rail_delivery_v5.zip` (약 14MB, SHA-256 3adf639a1c8bddc9…)
3. **런타임 → 모두 실행**. 1분 안팎에 끝나고 `/content/sincon_k30_hour/submission_rail_factors_k30_hour_on_xgb7.csv` 가 생기며 자동으로 내려받는다.

GPU와 패키지 설치가 필요 없다(pandas, numpy만 사용).

## 첫 셀의 설정

| 이름 | 뜻 |
|---|---|
| `ZIP_DIR` | 두 ZIP이 있는 폴더. 비우면 `/content` 와 드라이브에서 찾는다 |
| `BASELINE_CSV` | 앞 단계 노트북(`final_package` → `final_delivery_v2`)으로 만든 주후보의 경로. 비우면 패키지에 든 주후보(`submission_night_v4_main.csv`, Public 0.146049)에서 시작한다 |
| `PIN_VERSIONS` | `True` 면 pandas 3.1.1·numpy 2.5.4를 별도 폴더에 받아 그 버전으로 계산한다(런타임 재시작 불필요) |

## 로컬 확인 (macOS, 실제 Jupyter 커널, 2026-11-13)

| 환경 | 결과 | 기록 |
|---|---|---|
| Python 3.12.15, pandas 2.2.2, numpy 2.0.2 | 세 파일 수치 일치(최대 log 차이 1.8e-15), 바이트는 다름 | `verification/colab_run_report_final22.json`, `verification/executed_pandas222.ipynb` |
| 같은 환경, `PIN_VERSIONS = True` | 세 파일 바이트까지 일치 | `verification/colab_run_report_pin.json` |
| Python 3.12.15, pandas 3.1.1, numpy 2.5.4, `BASELINE_CSV` 에 팀 주후보 파일 지정 | 세 파일 바이트까지 일치 | `verification/colab_run_report_final312b.json` |
| Python 3.14.6, pandas 3.0.6, numpy 2.5.4 | 수치 일치(1.8e-15), 바이트는 다름 | 기록 파일 없음 |

세 파일은 `submission_xgb7_w10_on_curvature.csv`(0.144715), `submission_rail_factors_k30_on_xgb7.csv`(0.143123), `submission_rail_factors_k30_hour_on_xgb7.csv`(0.143043)이다.

## 확인하지 못한 것

- **Colab(리눅스)에서의 실제 실행.** 업로드 창과 내려받기는 Colab에서만 동작하는 코드라 로컬에서 실행해 보지 못했다.
- 리눅스에서는 버전을 맞춰도 바이트가 다를 수 있다. 노트북은 단계별 최대 log 차이가 1e-9를 넘으면 멈춘다.
- 주후보를 처음부터 다시 만드는 두 노트북(`final_package`, `final_delivery_v2`)은 이 노트북에 들어 있지 않다. 순서는 팀 폴더의 `HOWTO_KAGGLE_COLAB.md`.

## 규칙에 관한 기록

마지막 세 층은 다른 노선의 2026년 7~10월 일별 승차 실측을 쓴다. 규칙 4절 첫 항목의 문구에 해당하며, 허용 근거는 운영진의 구두 답변이다(서면 확인 없음). 인천 1·2호선, 7호선, 그 환승역 자료는 쓰지 않는다. 자세한 기록은 `rail_delivery_v5/RAIL_PREREGISTRATION.md`.

`make_notebook.py` 는 이 노트북을 만든 스크립트다.
