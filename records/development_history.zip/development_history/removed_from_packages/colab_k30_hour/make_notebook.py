"""Colab용 통합 노트북을 만든다. 사용: python make_nb.py <출력 ipynb>"""
import json, sys

cells = []
def md(text): cells.append({"cell_type": "markdown", "metadata": {}, "source": text.strip("\n").splitlines(keepends=True)})
def code(text): cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": text.strip("\n").splitlines(keepends=True)})

md("""
# SINCON 2026 핫식스 — Colab에서 `submission_rail_factors_k30_hour_on_xgb7.csv` 만들기

이 노트북 하나를 **모두 실행**하면 팀 제출 파일 `submission_rail_factors_k30_hour_on_xgb7.csv` (Public 0.143043)가 나온다. pandas와 numpy만 쓰고 GPU와 패키지 설치가 필요 없다. 실행 시간은 1분 안팎이다.

## 준비물 (ZIP 두 개)

| 파일 | 크기 | 내용 |
|---|---|---|
| `SINCON_final_stack_delivery.zip` | 약 78MB | 주후보(0.146049)에서 `submission_xgb7_w10_on_curvature.csv`(0.144715)까지의 7개 단계 |
| `SINCON_rail_delivery_v5.zip` | 약 14MB | 그 위에 다른 노선 변화 옮기기, 공휴일류 수준, 시간대별 반응 층 |

Colab 왼쪽 **파일** 창에 두 ZIP을 끌어다 놓거나(`/content`), 구글 드라이브 `내 드라이브`에 넣고 드라이브를 연결한다. 아무 데도 없으면 아래 셀이 업로드 창을 띄운다. 노트북은 두 ZIP의 SHA-256이 팀이 검증한 파일과 같은지 확인하고 푼다.

## 하는 일

1. `final_stack_delivery/SINCON_final_stack.ipynb` 의 코드 셀을 차례로 실행한다 → `submission_xgb7_w10_on_curvature.csv`
2. 그 출력을 입력으로 `rail_delivery_v5/SINCON_rail_factors_k30.ipynb` 의 코드 셀을 차례로 실행한다 → `submission_rail_factors_k30_on_xgb7.csv` (0.143123), `submission_rail_factors_k30_hour_on_xgb7.csv` (0.143043)
3. 단계마다 출력과 팀 제출 파일의 최대 log 차이를 잰다. 1e-9 이하면 재현으로 본다.

계산 코드는 두 ZIP 안의 노트북과 `.py` 파일에 있고, 이 노트북은 그것을 순서대로 실행한다. 방법 설명은 두 패키지의 노트북과 `README.md` 에 있다.

## 시작 입력

기본값은 패키지에 든 주후보 `submission_night_v4_main.csv` 다. 주후보부터 다시 만들려면 `final_package/SINCON_final.ipynb` → `final_delivery_v2/SINCON_final_step2_layers.ipynb` 를 먼저 실행하고(`HOWTO_KAGGLE_COLAB.md`), 그 출력 경로를 첫 셀의 `BASELINE_CSV` 에 적는다.

## 확인한 것과 못 한 것 (2026-11-13, 로컬 macOS, 실제 Jupyter 커널)

| 환경 | 결과 |
|---|---|
| Python 3.12.15, pandas 3.1.1, numpy 2.5.4 | 세 파일 모두 팀 제출 파일과 바이트까지 일치 |
| Python 3.12.15, pandas 2.2.2, numpy 2.0.2 | 수치 일치(최대 log 차이 1.8e-15), 바이트는 다름 |
| 위 pandas 2.2.2 환경에서 `PIN_VERSIONS = True` | 세 파일 모두 바이트까지 일치 |
| Python 3.14.6, pandas 3.0.6, numpy 2.5.4 | 수치 일치(최대 log 차이 1.8e-15), 바이트는 다름 |

- **Colab(리눅스)에서의 실제 실행은 확인하지 못했다.** 리눅스에서는 버전을 맞춰도 끝자리가 달라 바이트가 다를 수 있다. 마지막 셀이 단계별 최대 log 차이를 출력하고, 1e-9를 넘으면 멈춘다.
- 바이트까지 맞춰 보려면 첫 셀의 `PIN_VERSIONS = True` 로 실행한다.

## 규칙에 관한 기록

- 마지막 세 층은 **다른 노선의 2026년 7~10월 일별 승차 실측**을 쓴다(서울 열린데이터광장 OA-12914, 공공누리 1유형, 조회일 2026-11-13).
- 대회 규칙 4절은 "2026년 7월 이후의 실제 지하철 승차·하차 인원" 사용을 금지한다. 팀장이 2026-11-13에 "운영진이 대회 대상이 아닌 다른 노선의 실측 사용은 허용된다고 구두로 확인했다"고 전달해 이 층을 만들었다. 서면 확인은 이 노트북을 쓰는 시점에 없다.
- 인천 1·2호선, 7호선 전체, 그 노선들과의 환승역 자료는 쓰지 않는다. 패키지의 노트북이 실행할 때 다시 검사한다.
- 타 노선 자료를 쓰지 않은 파일은 1번의 출력 `submission_xgb7_w10_on_curvature.csv` 다.
""")

code("""
# ===== 설정 =====
ZIP_DIR = ""        # 두 ZIP을 둔 폴더. 비우면 /content 와 구글 드라이브(내 드라이브)에서 찾고, 없으면 업로드 창을 띄운다.
BASELINE_CSV = ""   # (선택) 앞 단계 노트북으로 만든 submission_night_v4_main.csv 의 경로. 비우면 패키지에 든 주후보를 쓴다.
WORK_DIR = ""       # 비우면 Colab은 /content/sincon_k30_hour, 그 밖에는 ./sincon_k30_hour
DOWNLOAD = True     # Colab에서 끝나면 최종 CSV를 내려받는다.
PIN_VERSIONS = False   # True면 팀이 검증에 쓴 pandas 3.1.1·numpy 2.5.4를 별도 폴더에 받아 그 버전으로 계산한다(인터넷 필요, 런타임 재시작 불필요).
""")

md("## 1. ZIP 찾기, 확인, 풀기")

code('''
import glob, hashlib, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path

ZIPS = {   # 이름: (풀리는 폴더, 팀이 검증한 ZIP의 SHA-256)
    "SINCON_final_stack_delivery.zip": ("final_stack_delivery", "aeefd5fbf1210395cf56b722298ac45225318b96c633a652f63f2c71e448ff3c"),
    "SINCON_rail_delivery_v5.zip": ("rail_delivery_v5", "3adf639a1c8bddc9a04bc051e89e27a24a66ffb6ec22f6c0b30d4e19ceb81a3b"),
}
EXPECTED = {   # 팀 제출 파일의 SHA-256
    "submission_xgb7_w10_on_curvature.csv": "596876180bb00eda250041cc6cf8ada4c6aa4702547f7e14a94ffe1340e3b1a6",
    "submission_rail_factors_k30_on_xgb7.csv": "13b0ff73fb7dfc96a92ca6ddb397c6779d645a05bba9e92e0f5698366633e86f",
    "submission_rail_factors_k30_hour_on_xgb7.csv": "aa455744556514d54ff2f3fe142117f331a04aa37141e59e6daf1cbfe0e8469c",
}
IN_COLAB = "google.colab" in sys.modules
ZIP_DIR = ZIP_DIR or os.environ.get("SINCON_COLAB_ZIP_DIR", "")
BASELINE_CSV = BASELINE_CSV or os.environ.get("SINCON_COLAB_BASELINE", "")
work = Path(WORK_DIR or os.environ.get("SINCON_COLAB_WORK", "") or ("/content/sincon_k30_hour" if Path("/content").is_dir() else "sincon_k30_hour")).resolve()
work.mkdir(parents=True, exist_ok=True)

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()

def find_zip(name, digest):
    """이름이 같은 ZIP(브라우저가 붙인 ' (1)' 같은 꼬리 포함) 가운데 SHA-256이 맞는 것을 찾는다."""
    stem = name[:-4]; seen = []
    for d in [ZIP_DIR, ".", "/content", "/content/drive/MyDrive", "/content/drive/MyDrive/*", "/content/drive/MyDrive/*/*"]:
        if not d:
            continue
        for hit in sorted(glob.glob(os.path.join(d, stem + "*.zip"))):
            if hit in seen:
                continue
            seen.append(hit)
            if sha256(hit) == digest:
                return Path(hit), seen
    return None, seen

found = {name: find_zip(name, digest) for name, (_, digest) in ZIPS.items()}
missing = [name for name, (hit, _) in found.items() if hit is None]
if missing and IN_COLAB:
    from google.colab import files
    print("업로드 창에서 다음 파일을 고르세요:", ", ".join(missing))
    files.upload()   # 현재 폴더(/content)에 저장된다
    found = {name: find_zip(name, digest) for name, (_, digest) in ZIPS.items()}
    missing = [name for name, (hit, _) in found.items() if hit is None]
for name in missing:
    others = found[name][1]
    print(name, "→", "이름은 같지만 SHA-256이 다른 파일만 있다: " + ", ".join(others) if others else "찾지 못했다")
assert not missing, "첫 셀의 ZIP_DIR 에 두 ZIP이 있는 폴더를 적거나 /content 에 올린 뒤 다시 실행한다."

for name, (folder, digest) in ZIPS.items():
    path = found[name][0]
    if (work / folder).exists():
        shutil.rmtree(work / folder)
    with zipfile.ZipFile(path) as z:
        z.extractall(work)
    assert (work / folder).is_dir(), f"{name} 안에 {folder} 폴더가 없다"
    print(f"{name}: SHA-256 일치 ({digest[:16]}…), {work / folder} 에 풀었다")

import numpy as np, pandas as pd
print("python", sys.version.split()[0], "| pandas", pd.__version__, "| numpy", np.__version__, "| 작업 폴더", work)
''')

md("""
## 2. 주후보 → `submission_xgb7_w10_on_curvature.csv` (7개 단계)

패키지의 `execute_notebook.py` 가 `SINCON_final_stack.ipynb` 의 코드 셀을 차례로 실행한다. 단계마다 팀 파일과의 최대 log 차이와 바이트 일치 여부를 출력한다.
""")

code('''
pinned = work / "pinned_packages"
if PIN_VERSIONS and not (pinned / "pandas").is_dir():
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--target", str(pinned), "pandas==3.1.1", "numpy==2.5.4"], check=True)

def run(cmd, extra_env=None):
    env = {**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1", **(extra_env or {})}
    if PIN_VERSIONS:
        env["PYTHONPATH"] = str(pinned) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    done = subprocess.run([str(c) for c in cmd], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    print(done.stdout)
    assert done.returncode == 0, "위 출력의 오류 때문에 멈췄다."

stack_root, stack_out = work / "final_stack_delivery", work / "outputs_stack"
cmd = [sys.executable, "-B", stack_root / "execute_notebook.py", "--output", stack_out]
if BASELINE_CSV:
    assert Path(BASELINE_CSV).is_file(), f"BASELINE_CSV 를 찾을 수 없다: {BASELINE_CSV}"
    cmd += ["--baseline", Path(BASELINE_CSV).resolve()]
run(cmd)
stack_final = stack_out / "submission_xgb7_w10_on_curvature.csv"
assert stack_final.is_file()
''')

md("""
## 3. 다른 노선 변화 옮기기 + 공휴일류 수준 + 시간대별 반응

2번의 출력을 입력으로 `SINCON_rail_factors_k30.ipynb` 의 코드 셀을 차례로 실행한다. 노트북이 다른 노선 자료에 7호선과 환승역 행이 없는지, 보호한 역·날짜의 값이 바뀌지 않았는지 검사한다.
""")

code('''
RUNNER = r"""
import json, os, sys
root, out, baseline = sys.argv[1:4]
os.environ["SINCON_RAIL_ROOT"] = root; os.environ["SINCON_OUTPUT_DIR"] = out
nb = json.loads(open(os.path.join(root, "SINCON_rail_factors_k30.ipynb"), encoding="utf-8").read())
ns = {"__name__": "__main__"}; first = True
for i, cell in enumerate(nb["cells"]):
    if cell["cell_type"] != "code":
        continue
    print(f"\\n--- code cell {i} ---", flush=True)
    exec(compile("".join(cell["source"]), f"SINCON_rail_factors_k30.ipynb:cell-{i}", "exec"), ns)
    if first:   # 설정 셀 바로 뒤: 입력을 2번의 출력으로 바꾼다
        ns["BASELINE_CSV"] = baseline; first = False
"""
rail_root, rail_out = work / "rail_delivery_v5", work / "outputs_rail"
rail_out.mkdir(parents=True, exist_ok=True)
(work / "run_rail_cells.py").write_text(RUNNER, encoding="utf-8")
run([sys.executable, "-B", work / "run_rail_cells.py", rail_root, rail_out, stack_final])
''')

md("## 4. 결과 확인과 내려받기")

code('''
stack_report = json.loads((stack_out / "stack_verification.json").read_text(encoding="utf-8"))
rail_report = json.loads((rail_out / "rail_verification.json").read_text(encoding="utf-8"))
rows = [{"파일": s["file"], "기준 파일과 최대 log 차이": s["max_abs_log1p_diff"], "바이트 일치": s["byte_identical"]} for s in stack_report["stages"]]
for name, r in rail_report["files"].items():
    rows.append({"파일": name, "기준 파일과 최대 log 차이": r["max_abs_log_diff_vs_reference"], "바이트 일치": r["sha256"] == r["reference_sha256"]})
table = pd.DataFrame(rows)
print(table.to_string(index=False))
assert (table["기준 파일과 최대 log 차이"] <= 1e-9).all(), "기준 파일과 수치가 다른 단계가 있다."

final_name = "submission_rail_factors_k30_hour_on_xgb7.csv"
produced = {"submission_xgb7_w10_on_curvature.csv": stack_final, "submission_rail_factors_k30_on_xgb7.csv": rail_out / "submission_rail_factors_k30_on_xgb7.csv", final_name: rail_out / final_name}
print()
for name, path in produced.items():
    digest = sha256(path)
    print(name, "| SHA-256", digest[:16] + "…", "| 팀 제출 파일과", "바이트 일치" if digest == EXPECTED[name] else "수치 일치(바이트는 다름)")
final_path = work / final_name
shutil.copyfile(produced[final_name], final_path)
sub = pd.read_csv(final_path)
print("\\n최종 파일:", final_path, "|", len(sub), "행 | 열", list(sub.columns), "| 결측", int(sub.isna().sum().sum()), "| 최솟값", float(sub.iloc[:, -1].min()))
print("계산에 쓴 버전: python", rail_report["python"], "| pandas", rail_report["pandas"], "| numpy", rail_report["numpy"])
(work / "colab_run_report.json").write_text(json.dumps({"python": rail_report["python"], "pandas": rail_report["pandas"], "numpy": rail_report["numpy"], "stack_pandas": stack_report["pandas"], "stack_numpy": stack_report["numpy"], "pinned": bool(PIN_VERSIONS), "platform": sys.platform, "baseline": BASELINE_CSV or "(패키지에 든 주후보)",
    "files": {n: {"sha256": sha256(p), "team_sha256": EXPECTED[n], "byte_identical": sha256(p) == EXPECTED[n]} for n, p in produced.items()}, "stages": rows}, ensure_ascii=False, indent=2, default=str) + "\\n", encoding="utf-8")
if IN_COLAB and DOWNLOAD:
    from google.colab import files
    files.download(str(final_path))
''')

nb = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python"}, "colab": {"provenance": []}}, "nbformat": 4, "nbformat_minor": 5}
for i, c in enumerate(cells): c["id"] = f"cell-{i:02d}"
json.dump(nb, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("wrote", sys.argv[1], len(cells), "cells")
