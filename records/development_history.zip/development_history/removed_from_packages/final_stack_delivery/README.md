# SINCON 2026 핫식스 최종 스택 재현 패키지

`SINCON_final_stack.ipynb` 하나가 주후보 입력부터 지정된 최종 CSV까지 0~7 단계를 계산한다. 기본 경로는 CPU에서 pandas·NumPy만 사용한다. 네트워크 접속이나 학습은 없다.

최종 기준은 `submission_xgb7_w10_on_curvature.csv`다. SHA-256은 `596876180bb00eda250041cc6cf8ada4c6aa4702547f7e14a94ffe1340e3b1a6`, Public은 사용자 전달 `0.144715`다. 이 패키지는 후보나 값을 새로 선택하지 않는다.

## 노트북 실행

1. ZIP을 풀고 `SINCON_final_stack.ipynb`를 연다.
2. 첫 코드 셀의 `ROOT`에 `stack_pipeline.py`가 있는 폴더를 지정한다. 자동으로 찾으면 비워도 된다.
3. `BASELINE_CSV`에 앞선 `final_package` → `final_delivery_v2` 노트북이 만든 주후보를 지정한다. 비우면 패키지의 보관 주후보를 사용한다.
4. `OUTPUT_DIR`에 패키지 밖의 쓰기 가능한 폴더를 지정하고 전체 셀을 순서대로 실행한다.

Kaggle의 `/kaggle/input`은 읽기 전용으로 사용한다. 기본 출력은 `/kaggle/working/sincon_outputs`다. Colab의 기본 출력은 `/content/outputs`다. `/content/final_stack_delivery`도 자동 검색한다. Kaggle의 Dataset 폴더 아래에 패키지가 중첩되어 있어도 `stack_pipeline.py`를 찾는다. 노트북 자체를 쓰기 가능한 작업 공간에서 열고, `ROOT`만 읽기 전용 데이터 폴더로 지정할 수도 있다. Kaggle에 업로드하는 작업은 이 패키지를 만들면서 수행하지 않았다.

실행 환경에 pandas·NumPy가 설치되어 있어야 한다. 검증 버전은 `requirements.txt`에 고정했다. 노트북은 설치 명령을 실행하지 않는다. 다른 버전은 매 단계의 수치 검사로 판단한다. 실제 Kaggle·Colab 실행은 확인하지 않았다.

각 단계에서 공식 test의 157,194개 ID·순서, 유한한 비음수 값, 기준 대비 최대 `log1p` 차이 `≤1e-9`, 바이트 일치 여부를 출력한다. 입력 주후보에도 같은 수치 기준을 적용하며 바이트 일치를 요구하지 않는다. CSV 파서는 원래 계산 단계의 기본 파서와 `round_trip` 파서를 구분해 원본의 연산과 직렬화 순서를 보존한다. 출력 CSV 7개와 `stack_verification.json`은 모두 `OUTPUT_DIR`에 생긴다.

실제 Jupyter 없이 코드 셀을 순서대로 실행하려면 다음 명령을 사용한다. 이 명령은 Jupyter 커널 검증을 대신했다고 주장하지 않는다.

```sh
python -B final_stack_delivery/execute_notebook.py --output outputs
```

환경변수 `SINCON_STACK_ROOT`, `SINCON_STACK_OUTPUT`, `SINCON_STACK_BASELINE`으로도 설정할 수 있다. 첫 코드 셀에 값을 입력하면 환경변수보다 우선한다.

## 재현 범위

| 단계 | 실행 내용 | 보관 입력과 기준 출력 |
|---|---|---|
| 0 | 앞선 두 패키지의 주후보를 읽고 동등성 검사 | 주후보는 이 노트북의 시작 입력이다. 앞선 모델의 재학습은 범위 밖이다. |
| 1 | K1 최근 84일·12 수축·0.25배·최소 6일 계산 | `hourbias_history_oof.csv.gz`, 달력·행사 보호표 |
| 2 | K1 위에 월요일 2,016행과 코리아컵·걷기 11행을 옮겨 K3 계산 | 원래 K3 정의에 명시된 두 후보 CSV를 보관 입력으로 사용한다. 두 후보를 만드는 모델은 여기서 재학습하지 않는다. |
| 3 | 검단 수준과 PLAVE 공연 중 보정을 과거 오차로 다시 적합 | 공식 train, 전체 중첩 OOF, 공연 일정 |
| 4 | 과거 기준일마다 K1 재현 후 계절층 재적합 | 전체 중첩 OOF와 보호표 |
| 5 | 제외 7개 역에 L1 확장 | K1과 같은 최근 OOF, 앞선 계산 출력 |
| 6 | 실측 프로필의 고주파 성분을 15% 반영 | 공식 train, 달력·행사 보호표 |
| 7 | 제외 7개 역 일반일에 XGBoost 차이 0.1배 반영 | 보관 npy 6개. 이 파일들은 시험기간 예측이며 실측이 아니다. |

단계 1~7의 출력 전체를 보관 입력으로 대체하는 우회 단계는 없다. 단계 2의 두 구성 후보와 단계 7의 모델 예측은 사용자 지시에 따른 보관 입력이다. `reference/`는 단계 출력 비교용이며, 계산된 중간 결과를 기준 CSV로 덮어쓰지 않는다.

K2 행의 소속은 원래 주후보와 두 구성 후보를 비교해 만든 `inputs/k2_overlay_keys.csv`로 고정했다. 따라서 허용 오차 안의 0번 입력 반올림 차이가 행사 행의 소속을 바꾸지 않는다. 검단의 원래 계절·요일 보정은 3107을 제외하므로 그 역의 적합에는 동일한 원 OOF를 사용한다. `stack_seasonal.py`, `stack_geomdan.py`, `stack_plave.py`, `stack_curvature.py`, `stack_k1_archive.py`의 계산 함수 본문은 원 스크립트에서 그대로 추출했다. 위치·원본 SHA·함수 목록은 `SOURCE_MANIFEST.json`에 있다.

## 입력 출처와 날짜

경로는 이 작업을 요청한 프로젝트 루트 기준이다. `team_baseline`은 별도 `sincon-2026/sincon-baseline` 체크아웃이다. 개별 파일의 출처·역할·크기·SHA는 `SOURCE_MANIFEST.json`, ZIP 전체 파일의 SHA는 `MANIFEST.json`에 기록한다.

| 패키지 입력 | 원래 위치 | 내용 |
|---|---|---|
| `data/train.csv`, `data/test.csv` | `hourbias_delivery/data/` | 대회 공식 CSV의 그대로인 복사본. 학습 실측은 2026-06-30까지, test는 2026-07-01~10-31의 키만 포함한다. |
| `cache/hourbias_history_oof.csv.gz` | `hourbias_delivery/cache/` | K1·L1용 과거 예측과 실측 log. 원래 `night13/measurements/downstream_oof_nested_main.csv.gz`의 날짜 부분집합이다. |
| `cache/downstream_oof_nested_main.csv.gz` | `night13/measurements/` | 전체 중첩 Night v4 OOF. 원본 전체를 복사했다. SHA `ef95f26d7ca7cbf3283a852fc25f37daf97af120d6e0a0ef972c46a37737d73a`. |
| `cache/calendar_flags.csv` | `hourbias_delivery/cache/` | K1·L1·XGBoost의 4개 달력 표시. |
| `cache/calendar_features.csv` | `final_package/payload/work/external_inputs/` | 계절·검단·curvature의 달력. K1과 계절층의 휴일 정의·제외 역은 서로 다르며 합쳐서 단순화하지 않았다. |
| `cache/events_frozen_v3.csv` | `hourbias_delivery/cache/`, 원출처 `goal_014/model/` | 행사 역·날짜. 출처·이용 조건·조회일을 포함한다. |
| `cache/protected_event_keys.csv` | `hourbias_delivery/cache/`, 원출처 `final_delivery_v2/cache/` | 주후보의 보호 행사 행. |
| `cache/events_daily.csv` | `final_package/payload/work/external_inputs/external/` | curvature가 추가로 보호하는 행사표. |
| `cache/festival_station_days.csv` | `final_package/payload/work/sincon_festival_station_days.csv` | curvature의 축제 보호표. |
| `cache/historical_concerts.csv` | `final_delivery_v2/cache/` | PLAVE 적합에 쓰는 과거 공연 시작 일정. |
| `inputs/submission_monday_main.csv` | `hourbias_delivery/reference/`, 원래 `monday_delivery` 출력 | K3 월요일 구성 후보. |
| `inputs/submission_night_v4_main_cup_walk.csv` | `hourbias_delivery/reference/`, 원래 `goal_014/release/` 출력 | K3 코리아컵·걷기 구성 후보. |
| `inputs/k2_overlay_keys.csv` | 위 두 후보와 원래 주후보에서 생성 | 차이 `>1e-12`인 2,027행의 ID·키·종류만 기록. 값은 두 보관 후보에서 가져온다. |
| `predictions/*.npy` | `xgb7_inputs/predictions/` | 단계 7 시험기간 log 예측 6개. |
| `reference/*.csv` | 주후보는 `final_delivery_v2/reference/`, K1·K3는 `hourbias_delivery/reference/`, 검단·계절은 `goal_014/release/`, L1·최종은 `xgb7_inputs/`, curvature는 `goal_014/graph_clean/` | 비교할 기준 출력 8개. |
| `training_scripts/team_features/` | `team_baseline`의 같은 이름 Python·external·data 파일 | 선택적 모델 재학습의 피처 생성 소스와 로컬 입력. 공식 train/test는 위 공식 복사본과 같다. |
| `evidence/` | `team_baseline`의 사전 기록·층별 점검, `goal_014/release/`와 관련 model·graph_clean·housing·bottleneck 보고서 | 보관된 검증 근거. 파일의 이전 Public 미측정 표시는 당시 상태다. 이번 실행 결과와 구분한다. |

노트북은 실측을 포함하는 모든 입력의 최대 날짜 `≤2026-06-30`을 검사한다. 두 OOF의 `y_log`를 공식 train의 동일 날짜·역·시간과 대조하고 `origin < date`도 검사한다. 다른 모든 입력도 최대 날짜를 출력한다. 2026년 7월 이후 달력·행사·날씨·야구 관중과 시험기간 예측은 지하철 승하차 실측이 아니다. `training_scripts/team_features/external/`의 경기 결과·관중·날씨는 원 피처 구성의 외생 자료이며 2026년 7월 이후 값도 포함한다. 원본 주석에 그 점이 명시되어 있다.

## 6개 모델 예측을 다시 만드는 방법

이 절은 보관 입력의 생성 방법이다. 기본 노트북은 아래 학습을 수행하지 않는다. 보관 npy에는 ID가 없으므로 순서는 사용자 제공 설명과 원 `build_xgb_delta.py`의 test 피처 키 확인에 근거한다. 이 패키지에서는 각 배열의 길이·유한값·SHA와 공식 test 순서를 고정하지만, 배열만 보고 원래 순서를 독립적으로 증명할 수는 없다.

`training_scripts/xgb_test.py`, `run3.py`, `run2.py`, `prep.py`, `prep_test.py`는 `xgb7_inputs/scripts/`에서 수정 없이 복사했다. `set2_build_l1.py`와 `build_xgb_delta.py`는 하드코딩 경로·작업 디렉터리를 제거한 실행 진입점이며 실제 계산은 노트북과 같은 함수를 쓴다. 원본의 상수·연산 순서는 바꾸지 않았다.

원 피처 목록은 `team_features/ensemble.py`의 `FEATURES`, 전처리는 `improved.enrich`, 달력은 `make_calendar.build_calendar`다. 전처리에는 달력·역·노선·경기·관중·행사·학교·날씨 특징을 사용한다. 승하차 목표는 공식 train의 2026-06-30까지뿐이다. `ensemble.py`는 피처 목록과 신경망 설정을 읽기 위해 import된다. 파일에 남아 있는 별도 제출 경로의 Public 기반 수준 보정 상수는 아래 스크립트에서 사용하지 않는다.

패키지를 읽기 전용으로 둔다면 `training_scripts/` 전체를 별도 쓰기 가능한 `training_work/`로 복사한다. 이 폴더에서 필요한 학습 라이브러리가 미리 설치된 환경으로 다음 순서로 실행한다. `requirements-training.txt`는 선택적 재학습용 버전 예시이며, 보관 학습 당시 전체 환경의 검증된 lockfile은 아니다. XGBoost 3.4.1은 사용자 제공 버전이다.

```sh
cd training_work
python -B prep.py team_features data.pkl
python -B prep_test.py team_features test.pkl
mkdir -p out3
python -B xgb_test.py
python -B run3.py data.pkl test.pkl base mps out3 0,1,2,3
```

Linux에서는 마지막 명령의 `mps`를 `cpu` 또는 `cuda`로 바꿀 수 있다. 그러면 새 예측이 만들어지지만 보관값과 같다고 볼 수 없다. 보관 파일을 자동으로 대체하지 않는다.

| 모델 | 원 설정 |
|---|---|
| XGBoost | 버전 3.4.1, `tree_method=hist`, 깊이 8, 학습률 0.05, 800그루, `subsample=0.8`, `colsample_bytree=0.8`, `enable_categorical=True`, `n_jobs=8`, seed 0. 목표는 float64 `log1p(boardings)`. |
| LightGBM | 600그루, regression, 학습률 0.05, 잎 63, 잎 최소 50행, 열·행 추출 0.8, `bagging_freq=1`, 8스레드, seed 0. 목표는 같은 log 승차. |
| 팀 base MLP | 시드 0~3, Mac GPU MPS 학습 보관본. 30 epoch, 폭 512·512·256, SiLU, dropout 0.15, AdamW 학습률 0.002·weight decay 1e-5, batch 2048, OneCycleLR `pct_start=0.1`. 학습 구간으로 수치형 절단·표준화와 log 목표 표준화를 적합한다. 임베딩 정의는 `run2.py`, 전체 적합은 `run3.py`. |

앙상블은 `0.5 × lgb + 0.5 × mean(base_s0..3)`이다. MLP 보관 배열은 float32이며 평균을 float64로 바꾸지 않는다. 최종 차이도 원 NumPy 연산 순서를 그대로 따른다. 제외 역은 `3107, 3108, 3109, 3127, 3139, 3209, 3754`다. 4개 달력 표시가 모두 0이고 `events_frozen_v3` 및 `protected_event_keys`의 역·날짜가 아닌 13,662행에만 0.1배 차이를 더한다. 원본과 같이 최종 log 예측을 0 이상으로 제한한다.

보관 MLP는 다른 하드웨어에서 수치가 달라지며, 이 작업에서는 6개 모델을 재학습하지 않았다. 피처 생성 소스와 입력도 함께 보관했지만 그것들로 해당 npy가 생성되었는지 학습을 다시 수행해 확인하지는 않았다.

## 검증 파일

`VERIFICATION.md`는 이번 순차 실행의 실제 결과와 확인하지 못한 항목을 기록한다. `verification/`에는 기계가 읽을 수 있는 결과와 실행 로그가 있다. `tools/verify_bundle.py`는 ZIP을 빈 폴더에 풀고 패키지를 읽기 전용으로 바꾼 뒤, 별도 출력 경로에서 노트북 코드 셀을 순서대로 실행하고 파일 SHA 불변성을 검사한다. `tools/package_delivery.py`로 ZIP과 파일 manifest를 다시 만들 수 있다.

`STATUS.md`는 ZIP 옆에 둔다. ZIP 자신의 SHA를 포함하는 파일을 ZIP 안에 넣는 자기 참조를 피하기 위해 이 파일은 ZIP에 포함하지 않는다. `.build/`의 로컬 환경·임시 실행본·생성 출력도 ZIP에서 제외한다. 패키지 런타임은 `tools/freeze_inputs.py`나 원 프로젝트 폴더를 필요로 하지 않는다.
