# 2026-11-13 순차 실행 검증

새 Python 3.12.15 가상환경에서 ZIP을 기존 파일이 없는 폴더에 풀었다. 패키지 전체의 파일 권한을 0444, 디렉터리를 0555로 바꾸고 `os.access(..., os.W_OK) == False`를 확인했다. 출력은 패키지 밖에 따로 지정했다. 한글과 공백이 있는 경로에서도 실행했다.

검증 환경은 macOS ARM64, CPU, pandas 3.1.1, NumPy 2.5.4다. 가상환경은 `include-system-site-packages=false`로 새로 만들었고, 네트워크 대신 기존 설치본의 NumPy·pandas와 의존 파일을 복사해 준비했다. 모델 학습 라이브러리나 Jupyter는 실행에 사용하지 않았다.

`execute_notebook.py`가 노트북의 코드 셀 11개를 같은 namespace에서 순서대로 `compile`·`exec`했다. `tools/verify_bundle.py`는 ZIP의 `MANIFEST.json`을 검증하고 실행 전후 패키지의 파일 목록·SHA가 변하지 않았음을 확인했다. 구체적인 검사 방법은 이 스크립트로 다시 실행할 수 있다.

```sh
python -B final_stack_delivery/tools/verify_bundle.py \
  --archive final_stack_delivery/SINCON_final_stack_delivery.zip \
  --work-dir new_empty_validation_folder
```

기본 보관 주후보 입력의 결과는 다음과 같다. 모든 단계에서 공식 test의 157,194개 ID·순서, 유한한 비음수 예측을 확인했다.

| 단계 | 기준 파일 | 최대 절대 log1p 차이 | 바이트 일치 |
|---:|---|---:|---|
| 0 | `submission_night_v4_main.csv` | 0 | 예 |
| 1 | `submission_k1_hourbias.csv` | 0 | 예 |
| 2 | `submission_k3_hourbias_holiday_events.csv` | 0 | 예 |
| 3 | `submission_k3_geomdan_plave.csv` | 0 | 예 |
| 4 | `submission_k3_geomdan_plave_seasonal_refit.csv` | 0 | 예 |
| 5 | `submission_set2_l1_on_refit.csv` | 0 | 예 |
| 6 | `submission_l1_hourly_curvature.csv` | 0 | 예 |
| 7 | `submission_xgb7_w10_on_curvature.csv` | 0 | 예 |

최종 SHA-256은 다음과 같다.

```text
596876180bb00eda250041cc6cf8ada4c6aa4702547f7e14a94ffe1340e3b1a6
```

변경·선택 행 수는 K1 129,636행, K3 월요일 2,016행·행사 11행, 검단 1,872행·PLAVE 4행, 계절 118,134행, L1 11,790행, curvature 113,274행, XGBoost 13,662행이다. 검단 재적합량은 `0.0748088716347378`, PLAVE 시작 두 시간의 재적합량은 각각 `−0.105`다. PLAVE의 과거 세 공연 12행 검증도 이번 실행에서 `0.5764907886217958 → 0.5089400857002413`으로 다시 계산됐다. 전체 과거 기준일 성능은 근거 문서에서 인용했으며, 이 실행이 그 모든 성능 평가를 다시 수행한 것은 아니다.

## 날짜와 입력 검사

실측을 포함하는 공식 train과 두 OOF 보관본의 최대 날짜는 모두 `2026-06-30`이다. 선택적 학습용으로 함께 넣은 train 복사본도 같다. OOF의 모든 `y_log`를 공식 train의 같은 날짜·역·시간과 대조해 절대 오차 `1e-12` 이내임을 확인했다. 모든 OOF에서 `origin < date`와 중복 키 없음도 확인했다.

달력·행사·외생 자료·test·시험기간 예측은 실측과 구분하여 입력별 최대 날짜를 출력했다. 시험기간 날짜가 있는 행사·날씨·경기 관중 자료는 지하철 실측이 아니다. 보관 npy는 각 `(157194,)`이며 유한값·SHA가 일치했다. 배열에 ID가 없으므로 그 자체에서 행 순서를 독립적으로 증명하지는 못했다. 제공된 test 순서라는 사용자 설명과 원 스크립트의 키 검사에 근거한다.

입력별 실제 날짜 출력과 단계별 SHA는 `verification/stack_verification.json`, 순차 실행 로그는 `verification/sequential_execution.log`에 있다. 공유 로그의 로컬 경로 표기는 `<read-only-package>`, `<separate-output>`으로 치환했다.

## 바이트가 다른 0번 입력

기준 파일은 수정하지 않고 별도 시험 입력 두 개를 만들었다.

- 수치는 그대로 두고 CSV 숫자를 `%.17e`로 저장한 입력은 단계 0에서 바이트가 달라도 통과했다. 단계 1~7은 모두 최대 차이 0·바이트 일치이며 최종 SHA도 지정값과 같다.
- 모든 log 예측에 `1e-10`을 더한 인공 시험 입력도 단계 0~7을 통과했다. 단계 7의 최대 차이는 `1.000017846308765e-10`으로 `1e-9`보다 작았다. 이 경우 최종 바이트와 SHA는 달라지는 것이 정상이다. 이 시험 입력은 새 후보나 제출 파일로 사용하지 않았다.

결과는 `verification/baseline_acceptance_checks.json`에 있다. 이 두 검사는 다른 Python 버전으로 주후보를 실제 재학습한 검사는 아니다.

## 확인하지 못한 것

- 실제 Jupyter 커널 실행. 샌드박스에서 소켓을 열 수 없어 코드 셀 순차 실행으로 검증했다. 실제 커널 검증은 Claude에게 남긴다.
- Kaggle·Colab Linux에서의 실제 실행. 코드의 경로와 입출력은 해당 환경을 지원하지만 이 검증은 macOS CPU에서 수행했다.
- 보관 XGBoost·LightGBM·MLP의 재학습 및 재학습 결과와 npy의 일치. 특히 MPS MLP는 다른 장치에서 같은 수치를 보장하지 않는다.
- 0번 이전 두 패키지의 학습 재실행 및 월요일·코리아컵·걷기대회 모델의 재학습. 지정된 보관 주후보와 K3 구성 입력을 사용했다.

단계 1~7 중 출력을 통째로 보관본으로 우회한 단계는 없다. 계산한 출력이 단계별 기준과 일치했다. 위 보관 입력 사용은 원래 요청된 범위이며 새 실패를 숨긴 대체가 아니다.
