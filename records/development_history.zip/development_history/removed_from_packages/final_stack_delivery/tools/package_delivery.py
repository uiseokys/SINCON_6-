"""Create a deterministic ZIP and an integrity manifest for all delivered files."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / 'SINCON_final_stack_delivery.zip'

def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and not any(part in ('.build', '__pycache__', '.DS_Store') for part in p.relative_to(ROOT).parts)
                  and p != ZIP and p.name != 'STATUS.md' and not p.name.endswith('.pyc'))

entries = []
for path in files():
    if path.name != 'MANIFEST.json':
        data = path.read_bytes()
        entries.append(dict(path=path.relative_to(ROOT).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(ROOT / 'MANIFEST.json').write_text(json.dumps(dict(files=entries), ensure_ascii=False, indent=2) + '\n')
with ZipFile(ZIP, 'w', compression=ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files():
        info = ZipInfo('final_stack_delivery/' + path.relative_to(ROOT).as_posix(), date_time=(2026, 11, 13, 8, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = (0o100644 << 16)
        archive.writestr(info, path.read_bytes())
print(json.dumps(dict(zip=ZIP.name, bytes=ZIP.stat().st_size, sha256=hashlib.sha256(ZIP.read_bytes()).hexdigest(),
                      packaged_files=len(files())), indent=2))
