"""Freeze the explicitly listed sources and extract unchanged pure calculation functions.

Authoring only. Usage: python tools/freeze_inputs.py --project-root PROJECT --team-root TEAM
All writes are constrained to this delivery folder.
"""
import argparse
import ast
import hashlib
import json
import shutil
from pathlib import Path

DEST = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--project-root', type=Path, required=True)
p.add_argument('--team-root', type=Path, required=True)
a = p.parse_args()
project, team = a.project_root.resolve(), a.team_root.resolve()
records = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy(base, source, target, role):
    src, dst = base / source, DEST / target
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    records.append(dict(path=target, source_scope='project' if base == project else 'team_baseline',
                        source=source, role=role, sha256=sha(dst), bytes=dst.stat().st_size))

for filename in ('train.csv', 'test.csv'):
    copy(project, 'hourbias_delivery/data/' + filename, 'data/' + filename,
         'subway_observations' if filename == 'train.csv' else 'unlabeled_test_keys')
for filename in ('hourbias_history_oof.csv.gz', 'calendar_flags.csv', 'events_frozen_v3.csv', 'protected_event_keys.csv'):
    copy(project, 'hourbias_delivery/cache/' + filename, 'cache/' + filename,
         'historical_oof_with_labels' if 'oof' in filename else 'calendar_or_event_metadata')
copy(project, 'night13/measurements/downstream_oof_nested_main.csv.gz',
     'cache/downstream_oof_nested_main.csv.gz', 'historical_oof_with_labels')
for source, target in (
    ('final_package/payload/work/external_inputs/calendar_features.csv', 'calendar_features.csv'),
    ('final_package/payload/work/external_inputs/external/events_daily.csv', 'events_daily.csv'),
    ('final_package/payload/work/sincon_festival_station_days.csv', 'festival_station_days.csv'),
    ('final_delivery_v2/cache/historical_concerts.csv', 'historical_concerts.csv'),
):
    copy(project, source, 'cache/' + target, 'calendar_or_event_metadata')
for name in ('submission_night_v4_main.csv', 'submission_k1_hourbias.csv',
             'submission_k3_hourbias_holiday_events.csv'):
    src = 'final_delivery_v2/reference/' + name if name == 'submission_night_v4_main.csv' else 'hourbias_delivery/reference/' + name
    copy(project, src, 'reference/' + name, 'comparison_prediction')
for name in ('submission_monday_main.csv', 'submission_night_v4_main_cup_walk.csv'):
    copy(project, 'hourbias_delivery/reference/' + name, 'inputs/' + name, 'archived_K2_prediction')
for name in ('submission_k3_geomdan_plave.csv', 'submission_k3_geomdan_plave_seasonal_refit.csv'):
    copy(project, 'goal_014/release/' + name, 'reference/' + name, 'comparison_prediction')
copy(project, 'goal_014/graph_clean/submission_l1_hourly_curvature.csv',
     'reference/submission_l1_hourly_curvature.csv', 'comparison_prediction')
for name in ('submission_set2_l1_on_refit.csv', 'submission_xgb7_w10_on_curvature.csv'):
    copy(project, 'xgb7_inputs/' + name, 'reference/' + name, 'comparison_prediction')
for name in ('xgb_test.npy', 'lgb_test.npy', *(f'base_test_s{s}.npy' for s in range(4))):
    copy(project, 'xgb7_inputs/predictions/' + name, 'predictions/' + name, 'archived_test_log_prediction')
copy(project, 'hourbias_delivery/hourbias_layer.py', 'hourbias_layer.py', 'runtime_code_unchanged')
for name in ('xgb_test.py', 'run3.py', 'run2.py', 'prep.py', 'prep_test.py'):
    copy(project, 'xgb7_inputs/scripts/' + name, 'training_scripts/' + name, 'training_code_unchanged')
for name in ('CANDIDATE_SET_PREREGISTRATION.md', 'CANDIDATE_SET2_PREREGISTRATION.md', 'STACK_AUDIT_1113.md'):
    copy(team, name, 'evidence/' + name, 'historical_evidence_snapshot')
for name in ('KSET_CODEX_COMBINATIONS.md', 'NIGHT_V4_GEOMDAN3107.md', 'NIGHT_V4_PLAVE_IN_SHOW.md',
             'NIGHT_V4_CUP_WALK.md', 'NIGHT_V4_GEOMDAN_PLAVE.md', 'NIGHT_V4_SEASONAL_SHAPE.md'):
    copy(project, 'goal_014/release/' + name, 'evidence/' + name, 'historical_evidence_snapshot')
for source, target in (
    ('goal_014/graph_clean/l1_hourly_curvature.json', 'l1_hourly_curvature.json'),
    ('goal_014/release/kset_combined_validation_nested.json', 'kset_combined_validation_nested.json'),
    ('goal_014/bottleneck/v4_plave_in_show_report.json', 'v4_plave_in_show_report.json'),
    ('goal_014/housing/v4_geomdan_weekday_report.json', 'v4_geomdan_weekday_report.json'),
    ('goal_014/graph_clean/k1_residual_replay.json', 'k1_residual_replay.json'),
    ('goal_014/graph_clean/v4_validation.json', 'v4_validation.json'),
    ('goal_014/graph_clean/V4_ORDINARY_PROTOCOL.md', 'V4_ORDINARY_PROTOCOL.md'),
):
    copy(project, source, 'evidence/' + target, 'historical_evidence_snapshot')

extractions = []
def extract(source, target, prelude, names):
    path = project / source
    text = path.read_text()
    tree = ast.parse(text)
    nodes = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    blocks = [ast.get_source_segment(text, nodes[n]) for n in names]
    dst = DEST / target
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text('"""Pure functions extracted unchanged from ' + source + '."""\n' + prelude + '\n\n' + '\n\n\n'.join(blocks) + '\n')
    extractions.append(dict(source=source, source_sha256=sha(path), destination=target, functions=names,
                            function_bodies_unchanged=True))

extract('goal_014/model/v4_seasonal_residual.py', 'stack_seasonal.py', '''import numpy as np
import pandas as pd
KEY = ['date', 'station_id', 'hour']
KEYS = ['station_id', 'weekend', 'hour']
CUTOFF = pd.Timestamp('2026-06-30')
EVENT_STATIONS = [3127, 3139, 3226, 3754]
EXCLUDED_STATIONS = [3107, 3108, 3109, *EVENT_STATIONS]
HOLIDAY_FLAGS = ['is_holiday', 'is_bridge_day', 'is_quasi_holiday', 'is_pre_long_offday', 'is_post_long_offday']''', ['ordinary_rows', 'fit_correction'])
extract('goal_014/housing/v4_geomdan_scale_probe.py', 'stack_geomdan.py', '''import numpy as np
import pandas as pd
KEY = ['date', 'station_id', 'hour']
STATIONS = (3107, 3108, 3109)
REGIME_WINDOW = 56
MINIMUM_MONTH_DAYS = 12
MINIMUM_MONTH_ERROR = .04
MAXIMUM_LOG_BIAS = .16
FRACTION = .5''', ['quiet_days', 'recent_regimes'])
extract('goal_014/bottleneck/build_v4_plave_in_show.py', 'stack_plave.py', '''import numpy as np
import pandas as pd
KEY = ['date', 'station_id', 'hour']
CUTOFF = pd.Timestamp('2026-06-30')
STATION = 3127
FIT_CLIP = (-.30, 0.)
SHRINK = .35
DONOR_ORIGINS = {'ye': '2025-06-30', 'muse': '2025-08-31', 'jin': '2025-09-30', 'park_hyo_shin': '2026-02-28'}''', ['read_history', 'fit', 'backtest'])
extract('goal_014/model/k3_network_variation.py', 'stack_curvature.py', '''import numpy as np
import pandas as pd
from stack_seasonal import EXCLUDED_STATIONS, KEY
DAY = KEY[:2]
EVENT_STATIONS = [*EXCLUDED_STATIONS, 3209, 3210]
GROUP = ['station_id', 'weekday']
HOURS = np.arange(6, 24)
N_HOURS = len(HOURS)
FREQUENCIES = np.arange(6, N_HOURS)
HIGH_FREQUENCY = np.sqrt(2 / N_HOURS) * np.cos(np.pi * (np.arange(N_HOURS) + .5)[:, None] * FREQUENCIES / N_HOURS)
PROJECTION = HIGH_FREQUENCY @ HIGH_FREQUENCY.T''', ['ordinary'])
curv = project / 'goal_014/graph_clean/l1_hourly_curvature.py'
src = curv.read_text(); tree = ast.parse(src)
blocks = [ast.get_source_segment(src, n) for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('complete_profiles', 'anchor')]
with (DEST / 'stack_curvature.py').open('a') as out:
    out.write('\n\n' + '\n\n\n'.join(blocks) + '\n')
extractions.append(dict(source=str(curv.relative_to(project)), source_sha256=sha(curv), destination='stack_curvature.py',
                        functions=['complete_profiles', 'anchor'], function_bodies_unchanged=True))

(DEST / 'SOURCE_MANIFEST.json').write_text(json.dumps({'files': records, 'function_extractions': extractions}, ensure_ascii=False, indent=2) + '\n')
print('Frozen', len(records), 'files; extracted', sum(len(e['functions']) for e in extractions), 'pure functions.')
extract('goal_014/graph_clean/k1_residual_replay.py', 'stack_k1_archive.py', '''import numpy as np
import pandas as pd
KEY = ['date', 'station_id', 'hour']
FIT_FIELDS = ['station_id', 'dow', 'hour']
EXCLUDED_STATIONS = {3107, 3108, 3109, 3127, 3139, 3209, 3754}''', ['k1_stats', 'k1_apply', 'k1_quiet'])
source = project / 'goal_014/model/kset_combined_validation.py'
src = source.read_text(); tree = ast.parse(src)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'k1_archive')
with (DEST / 'stack_k1_archive.py').open('a') as out:
    out.write('\n\n' + ast.get_source_segment(src, fn) + '\n')
extractions.append(dict(source=str(source.relative_to(project)), source_sha256=sha(source), destination='stack_k1_archive.py',
                        functions=['k1_archive'], function_bodies_unchanged=True))
(DEST / 'SOURCE_MANIFEST.json').write_text(json.dumps({'files': records, 'function_extractions': extractions}, ensure_ascii=False, indent=2) + '\n')
# Freeze K2 membership separately from input-baseline rounding differences.
import csv
import math
with (DEST / 'reference/submission_night_v4_main.csv').open(newline='') as f:
    original = list(csv.DictReader(f))
with (DEST / 'data/test.csv').open(newline='') as f:
    keys = list(csv.DictReader(f))
overlay_rows = []
for kind, name in [('monday', 'submission_monday_main.csv'), ('cup_walk', 'submission_night_v4_main_cup_walk.csv')]:
    with (DEST / 'inputs' / name).open(newline='') as f:
        donor = list(csv.DictReader(f))
    for base, patch, key in zip(original, donor, keys):
        assert base['example_id'] == patch['example_id'] == key['example_id']
        if abs(math.log1p(float(base['boardings'])) - math.log1p(float(patch['boardings']))) > 1e-12:
            overlay_rows.append(dict(example_id=key['example_id'], date=key['date'], station_id=key['station_id'], hour=key['hour'], overlay=kind))
path = DEST / 'inputs/k2_overlay_keys.csv'
with path.open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['example_id', 'date', 'station_id', 'hour', 'overlay'])
    writer.writeheader(); writer.writerows(overlay_rows)
records.append(dict(path='inputs/k2_overlay_keys.csv', source_scope='derived',
                    source='original v4 versus the two archived K2 inputs, abs(log1p difference)>1e-12',
                    role='archived_overlay_scope', sha256=sha(path), bytes=path.stat().st_size))

# Original feature-building dependencies are supplementary; the notebook uses archived npy.
for filename in ('baseline.py', 'ensemble.py', 'improved.py', 'make_calendar.py', 'external_features.py', 'nn_model.py'):
    copy(team, filename, 'training_scripts/team_features/' + filename, 'training_code_unchanged')
for filename in ('munhak_games.csv', 'crowd_munhak.csv', 'events_daily.csv', 'school_calendar.csv', 'weather_hourly.csv'):
    copy(team, 'external/' + filename, 'training_scripts/team_features/external/' + filename, 'training_exogenous_metadata')
copy(team, 'data/metaData.csv', 'training_scripts/team_features/data/metaData.csv', 'station_metadata')
for filename in ('train.csv', 'test.csv'):
    copy(project, 'hourbias_delivery/data/' + filename, 'training_scripts/team_features/data/' + filename,
         'subway_observations' if filename == 'train.csv' else 'unlabeled_test_keys')
(DEST / 'SOURCE_MANIFEST.json').write_text(json.dumps({'files': records, 'function_extractions': extractions}, ensure_ascii=False, indent=2) + '\n')
print('Final source manifest:', len(records), 'files')
