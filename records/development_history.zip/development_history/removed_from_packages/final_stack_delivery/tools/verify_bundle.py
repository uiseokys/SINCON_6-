"""Unzip in an empty folder, verify hashes, make inputs read-only, run notebook cells."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
from zipfile import ZipFile

sys.dont_write_bytecode = True
p = argparse.ArgumentParser()
p.add_argument('--archive', type=Path, required=True)
p.add_argument('--work-dir', type=Path, required=True)
p.add_argument('--baseline', type=Path)
a = p.parse_args()
work = a.work_dir.resolve()
assert not work.exists(), '검증 폴더는 없어야 합니다. 새 빈 폴더를 생성합니다.'
work.mkdir(parents=True)
with ZipFile(a.archive) as z:
    for name in z.namelist():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
    z.extractall(work)
package = work / 'final_stack_delivery'
def snapshot():
    return {str(f.relative_to(package)): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in package.rglob('*') if f.is_file()}
before = snapshot()
manifest = json.loads((package / 'MANIFEST.json').read_text())
assert set(before) == {row['path'] for row in manifest['files']} | {'MANIFEST.json'}
assert all(before[row['path']] == row['sha256'] for row in manifest['files'])
for path in package.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
for path in sorted((p for p in package.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
    path.chmod(0o555)
package.chmod(0o555)
assert not os.access(package, os.W_OK), '패키지는 실제로 읽기 전용이어야 합니다.'
output = work / 'outputs'
command = [sys.executable, '-B', str(package / 'execute_notebook.py'), '--root', str(package), '--output', str(output)]
if a.baseline:
    command += ['--baseline', str(a.baseline.resolve())]
started = time.monotonic()
with (work / 'execution.log').open('w') as log:
    result = subprocess.run(command, cwd=work, stdout=log, stderr=subprocess.STDOUT)
if result.returncode:
    print((work / 'execution.log').read_text())
    raise SystemExit(result.returncode)
after = snapshot()
assert before == after, '패키지 파일이나 내용이 실행 중 바뀌었습니다.'
report = json.loads((output / 'stack_verification.json').read_text())
assert len(report['stages']) == 8
summary = dict(python=sys.version.split()[0], platform=platform.platform(),
               numpy=report['numpy'], pandas=report['pandas'],
               elapsed_seconds=round(time.monotonic()-started, 2),
               package_readonly=True, package_files_unchanged=True,
               package_file_count=len(before), stages=report['stages'],
               final_sha256=report['final_sha256'], expected_final_sha256=report['expected_final_sha256'],
               archive_sha256=hashlib.sha256(a.archive.read_bytes()).hexdigest())
(work / 'bundle_verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
