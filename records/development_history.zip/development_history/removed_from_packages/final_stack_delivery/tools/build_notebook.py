"""Generate the single delivery notebook, without notebook-specific dependencies."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
cells = []
def md(text):
    cells.append(dict(cell_type='markdown', metadata={}, source=text.splitlines(keepends=True)))
def code(text):
    cells.append(dict(cell_type='code', metadata={}, execution_count=None, outputs=[], source=text.strip().splitlines(keepends=True)))

md((ROOT / 'FIRST_CELL.md').read_text())
code('''# ===== 사용자 설정 =====
ROOT = ""             # stack_pipeline.py가 있는 패키지 폴더. 비우면 자동 검색.
BASELINE_CSV = ""     # 앞선 두 노트북에서 만든 주후보. 비우면 패키지 보관 기준 파일.
OUTPUT_DIR = ""       # 패키지 밖의 쓰기 가능한 폴더. Kaggle은 /kaggle/working 자동 선택.
''')
code('''import glob, json, os, sys
from pathlib import Path
sys.dont_write_bytecode = True

def find_root():
    candidates = [ROOT, os.environ.get("SINCON_STACK_ROOT", ""), ".", "final_stack_delivery", "/content/final_stack_delivery"]
    candidates += sorted(glob.glob("/kaggle/input/**/stack_pipeline.py", recursive=True))
    for name in candidates:
        if not name:
            continue
        path = Path(name)
        if path.name == "stack_pipeline.py":
            path = path.parent
        if (path / "stack_pipeline.py").is_file() and (path / "SOURCE_MANIFEST.json").is_file():
            return path.resolve()
    raise FileNotFoundError("첫 코드 셀 ROOT에 패키지 폴더를 지정하세요.")

root = find_root()
requested_output = OUTPUT_DIR or os.environ.get("SINCON_STACK_OUTPUT", "")
if not requested_output:
    requested_output = "/kaggle/working/sincon_outputs" if Path("/kaggle/working").is_dir() else (
        "/content/outputs" if Path("/content").is_dir() else str(root.parent / "sincon_stack_outputs"))
out_dir = Path(requested_output).resolve()
assert out_dir != root and root not in out_dir.parents, "출력 폴더는 읽기 전용 패키지 밖에 지정하세요."
out_dir.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(root))
import numpy as np
import pandas as pd
import hourbias_layer as hb
import stack_pipeline as stack
print("Python", sys.version.split()[0], "| pandas", pd.__version__, "| NumPy", np.__version__)
print("패키지", root, "| 출력", out_dir)
paths = [out_dir / name for name in stack.STAGES]
results, details = [], {}
''')
md('## 입력 날짜 확인과 단계 0\n\n공식 train과 두 OOF 보관본의 실측 날짜는 2026-06-30 이하여야 한다. OOF의 실측 log 값은 공식 train의 동일 키와 대조한다. 달력·행사·예측의 시험기간 날짜는 실측 날짜와 구분한다. 기준 파일을 계산값으로 덮어쓰지 않는다.')
code('''ctx = stack.load_inputs(root)
test = ctx["test"]
input_audit = stack.audit_inputs(root, test)
baseline_path = Path(BASELINE_CSV or os.environ.get("SINCON_STACK_BASELINE", "") or root / "reference" / stack.STAGES[0]).resolve()
main = stack.read_prediction(baseline_path, test)
results.append(stack.verify_stage(0, baseline_path, root, test))
print("공식 학습 실측 최대 날짜", ctx["train"].date.max().date())
print("과거 예측 정답의 공식 train 일치와 기준일 < 대상 날짜 확인 완료")
''')
md('## 단계 1 · K1\n\n최근 84일 과거 오차로 일반일 시간대 모양을 적합한다. 역·날짜의 log 평균과 보호 행을 보존한다.')
code('''k1, details["1_k1"] = hb.build_k1(test, main, ctx["history"], root / "cache")
hb.check_submission(k1, test)
k1.to_csv(paths[1], index=False)
results.append(stack.verify_stage(1, paths[1], root, test))
print(json.dumps(details["1_k1"], ensure_ascii=False, indent=2))
''')
md('## 단계 2 · K3\n\n원래 K3 정의대로 두 보관 후보가 주후보와 다른 행을 옮긴다. 이 노트북에서 월요일·코리아컵·걷기대회 모델을 재학습하지 않는다.')
code('''monday = stack.read_prediction(root / "inputs/submission_monday_main.csv", test)
cup_walk = stack.read_prediction(root / "inputs/submission_night_v4_main_cup_walk.csv", test)
k3, details["2_k3"] = stack.build_k3(ctx, k1, monday, cup_walk)
hb.check_submission(k3, test)
k3.to_csv(paths[2], index=False)
results.append(stack.verify_stage(2, paths[2], root, test))
print(details["2_k3"])
''')
md('## 단계 3 · 검단 수준과 PLAVE 공연 중 4행\n\n검단의 과거 오차 중앙값과 PLAVE의 과거 공연별 오차를 다시 적합한다. 검단은 원래 계절·요일 모형의 제외 역이므로 그 역의 보관 원예측과 변환된 예측이 같다.')
code('''details["3_geomdan_plave"] = stack.build_geomdan_plave(ctx, baseline_path, paths[2], paths[3])
results.append(stack.verify_stage(3, paths[3], root, test))
print(json.dumps(details["3_geomdan_plave"], ensure_ascii=False, indent=2))
''')
md('## 단계 4 · 계절 재적합\n\n전체 보관 OOF의 각 기준일에서 K1을 재현하고, K1 이후 남은 오차로 계절층을 적합한다. 기존 K2·검단·PLAVE 역·날짜는 보호한다.')
code('''details["4_seasonal"] = stack.build_seasonal(ctx, baseline_path, paths[2], paths[3], paths[4])
results.append(stack.verify_stage(4, paths[4], root, test))
print(details["4_seasonal"])
''')
md('## 단계 5 · L1 제외 7개 역 확장\n\nK1과 같은 규칙을 제외 7개 역의 일반일에도 적용한다. 기존 휴일·행사·검단·PLAVE 변경 역·날짜는 건너뛴다.')
code('''details["5_l1"] = stack.build_l1(ctx, baseline_path, paths[1], paths[3], paths[4], paths[5])
results.append(stack.verify_stage(5, paths[5], root, test))
print(details["5_l1"])
''')
md('## 단계 6 · 시간대 고주파 패턴\n\n2026-06-30까지의 공식 실측 프로필을 만들고, 고주파 성분 차이만 반영한다. 달력과 행사 보호표를 합친 원래 범위를 사용한다.')
code('''details["6_curvature"] = stack.build_curvature(ctx, baseline_path, paths[5], paths[6])
results.append(stack.verify_stage(6, paths[6], root, test))
print(details["6_curvature"])
''')
md('## 단계 7 · 보관 모델 예측 차이\n\n6개 npy를 기본 입력으로 사용한다. float32 MLP 평균을 포함한 원본 NumPy 연산 순서를 유지한다. 다른 기기의 MLP 재학습은 동일 수치를 보장하지 않는다.')
code('''details["7_xgb_delta"] = stack.build_xgb_delta(ctx, paths[6], paths[7])
results.append(stack.verify_stage(7, paths[7], root, test))
print(details["7_xgb_delta"])
print("최종 파일", paths[7])
print("최종 SHA-256", stack.sha256(paths[7]))
print("지정된 최종 SHA와 일치", stack.sha256(paths[7]) == stack.FINAL_SHA256)
''')
md('## 실행 결과 저장\n\n기준과의 최대 차이·ID·바이트 일치, 입력 최대 날짜, 버전을 별도 출력 폴더에 저장한다. 허용 오차를 넘는 단계에서는 즉시 중단한다.')
code('''report = dict(python=sys.version.split()[0], pandas=pd.__version__, numpy=np.__version__,
              stages=results, details=details, input_audit=input_audit,
              final_sha256=stack.sha256(paths[7]), expected_final_sha256=stack.FINAL_SHA256)
(out_dir / "stack_verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=int) + "\\n", encoding="utf-8")
print(pd.DataFrame(results)[["stage", "max_abs_log1p_diff", "ids_and_order_match", "byte_identical"]].to_string(index=False))
print("실행 결과 저장", out_dir / "stack_verification.json")
''')
notebook = dict(cells=cells, metadata=dict(kernelspec=dict(display_name='Python 3', language='python', name='python3'),
                   language_info=dict(name='python', version='3.12')), nbformat=4, nbformat_minor=5)
for i, cell in enumerate(cells):
    cell['id'] = f'sincon-stack-{i:02d}'
(ROOT / 'SINCON_final_stack.ipynb').write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print('Created notebook:', len(cells), 'cells,', sum(c['cell_type']=='code' for c in cells), 'code cells')
