"""Execute notebook code cells sequentially, with no socket or Jupyter dependency."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--baseline', type=Path)
a = p.parse_args()
root = a.root.resolve()
os.environ['SINCON_STACK_ROOT'] = str(root)
os.environ['SINCON_STACK_OUTPUT'] = str(a.output.resolve())
if a.baseline:
    os.environ['SINCON_STACK_BASELINE'] = str(a.baseline.resolve())
nb = json.loads((root / 'SINCON_final_stack.ipynb').read_text())
ns = {'__name__': '__main__'}
started = time.monotonic()
for i, c in enumerate(nb['cells']):
    if c['cell_type'] == 'code':
        print(f'\n--- Code cell {i} ---', flush=True)
        exec(compile(''.join(c['source']), f'SINCON_final_stack.ipynb:cell-{i}', 'exec'), ns)
print(f'\nSequential execution completed in {time.monotonic()-started:.2f} seconds', flush=True)
