import json, sys
src, dst = sys.argv[1:3]
nb = json.load(open(src, encoding="utf-8")); cells = nb["cells"]
def src_of(i): return "".join(cells[i]["source"])
def put(i, text): cells[i]["source"] = text.splitlines(keepends=True)
def rep(i, a, b):
    t = src_of(i); assert t.count(a) == 1, (i, t.count(a), a[:50]); put(i, t.replace(a, b))
# 0: 안내
rep(0, "이 노트북은 `final_stack_delivery/SINCON_final_stack.ipynb` 의 최종 출력(`submission_xgb7_w10_on_curvature.csv`, Public 0.144715)에 두 층을 더해 두 파일을 만든다: `submission_rail_factors_k30_on_xgb7.csv`(팀 제출 Public 0.143123)와, 거기에 시간대별 반응 층을 더한 `submission_rail_factors_k30_hour_on_xgb7.csv`.",
    "이 노트북은 3단계 `3_stack/SINCON_final_stack.ipynb` 의 출력(`submission_xgb7_w10_on_curvature.csv`, Public 0.144715)에 다른 노선 자료를 쓰는 층을 더해 두 파일을 만든다.\n\n| 출력 | 구성 | Public |\n|---|---|---:|\n| `submission_rail_factors_k30_on_xgb7.csv` | 주성분 30개(일반일 0.2·공휴일류 0.3) + 공휴일류 수준 | 0.143123 |\n| `submission_rail_factors_k30_hour_on_xgb7.csv` | 위 + 시간대별 반응 층 | 0.143043 (**최종 예측**, `submission_final_main.csv`) |")
rep(0, "(7호선과 환승역은 제외)\"고 전달해 이 층을 만들었다. 서면 확인은 이 노트북을 쓰는 시점에 없다.", "(7호선과 환승역은 제외)\"고 전달해 이 층을 만들었다. 글로 남은 답변은 없다.")
rep(0, "(`provenance/fetch_all.py`, `cache/ban_list.json`)", "(`fetch/fetch_all.py`, `cache/ban_list.json`)")
rep(0, "- 타 노선 자료를 쓰지 않은 후보는 `final_stack_delivery` 의 출력 그대로다.", "- 타 노선 자료를 쓰지 않은 예측은 3단계(`3_stack`)의 출력 그대로다.")
rep(0, "1. `final_package/SINCON_final.ipynb` → 2. `final_delivery_v2/SINCON_final_step2_layers.ipynb` → 3. `final_stack_delivery/SINCON_final_stack.ipynb` → 4. 이 노트북.", "1. `1_base_models/SINCON_final.ipynb` → 2. `2_corrections/SINCON_final_step2_layers.ipynb` → 3. `3_stack/SINCON_final_stack.ipynb` → 4. 이 노트북. 한 번에 실행하려면 `code/run_all.py`.")
rep(0, "(`provenance/nb_test.py`, `xgb_test.py`, XGBoost 3.4.1)", "(`training/nb_test.py`, `training/xgb_test.py`, XGBoost 3.4.1)")
rep(0, "8. (두 번째 출력만) **시간대별 반응 층.**", "8. (두 번째 출력만) **시간대별 반응 층.**")
rep(0, "- 정의·기준·결과는 계산 전후로 `RAIL_PREREGISTRATION.md` 에 적었다. 처음 판은 주성분 5개, 가중 0.1·0.2였다(Public 0.143777, `rail_delivery_v3/`).", "- 정의·기준·결과는 계산 전후로 적어 두었다(`docs/METHOD.md` 6절, 원 기록은 `records/development_history.zip` 의 `RAIL_PREREGISTRATION.md`). 처음 판은 주성분 5개, 가중 0.1·0.2였다(Public 0.143777). 검증 스크립트와 결과는 `validation/`.")
rep(0, "(평균 −0.00049, `rail_delivery_v4/`, Public 0.143545)이 가장 좋았다. 두 구성을 각각 한 번씩 제출했고 이 노트북은 주성분 30개 판을 재현한다.", "(평균 −0.00049, Public 0.143545)이 가장 좋았다. 두 구성을 각각 한 번씩 제출했고 이 노트북은 주성분 30개 판을 만든다.")
rep(1, "ROOT = \"\"            # 패키지 폴더(rail_layer.py 가 있는 곳). 비우면 자동 검색.", "ROOT = \"\"            # 패키지 폴더(factor_layer.py 가 있는 곳). 비우면 자동 검색.")
rep(1, "BASELINE_CSV = \"\"    # final_stack 노트북의 최종 출력. 비우면 reference/ 의 기준 파일.", "BASELINE_CSV = \"\"    # 3단계 노트북의 최종 출력. 비우면 reference/ 의 기준 파일.")
rep(2, "\".\", \"rail_delivery_v5\", \"/content/rail_delivery_v5\"] + sorted(glob.glob(\"/kaggle/input/*/rail_delivery_v5\"))", "\".\", \"4_rail\", \"code/4_rail\", \"/content/4_rail\"] + sorted(glob.glob(\"/kaggle/input/*/4_rail\"))")
rep(9, "## 4. 시간대별 반응 층 (두 번째 출력)", "## 4. 시간대별 반응 층 (두 번째 출력, 최종 예측)")
for i, c in enumerate(cells): c["id"] = f"cell-{i:02d}"
json.dump(nb, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1); print("cells", len(cells))
