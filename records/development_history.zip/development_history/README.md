# 개발 기록 묶음

제출 폴더를 정리하면서 `code/` 와 `docs/` 에 남기지 않은 파일을 모았다. 최종 예측을 만드는 데는 필요 없고, 경과와 근거를 확인할 때 본다.

| 폴더 | 내용 |
|---|---|
| `dev_logs/team/` | 팀 작업 기록: `FINAL_REPORT.md`, `NIGHT_LOG.md`, 사전 기록(`*_PREREGISTRATION.md`), `STACK_AUDIT_1113.md`, `ALL_EVENTS_AND_CORRECTIONS.md`, `RULES_TEXT_AS_PASTED_20261113.md`, `DISRUPTION_TEST_1113.md` |
| `dev_logs/codex/` | 단계별 결과 문서, 독립 감사(`final_audit/`), 전체 재학습 결과(`full_verification/`), 출처 점검(`night6/`, `night_sources/`), Public 점수 관련 안내(`RULES_NOTICE_PUBLIC_SCORE.md`) |
| `dev_logs/experiment_scripts/` | 검증·탈락 실험 스크립트와 결과 |
| `removed_from_packages/` | 각 패키지에서 뺀 파일(원래 패키지 이름 그대로): 패키지 안내 문서, 검증 로그, 배포·감사용 스크립트, 근거 문서, 탈락한 타 노선 실험, 주성분 12개 판의 원래 패키지(`rail_delivery_v4/`), Colab용 노트북 |
| `previous_docs/` | 통합하기 전의 문서와 실행 스크립트, 과거 예측 생성 스크립트 전체, 탈락한 시간대별 타 노선 자료 |
| `make_master.py`, `make_rail_nb_single.py` | 전체 실행 노트북과 4단계 노트북을 만든 스크립트 |

문서에 적힌 "Public 미측정" 같은 표현과 파일 경로는 작성 시점의 상태다.
