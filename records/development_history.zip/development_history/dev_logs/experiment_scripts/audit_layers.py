"""Independent past-data audit of two Codex layers: hourly high-frequency anchor (curvature) and the 3107 level."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week
ev = pd.MultiIndex.from_frame(rows[hb.DAYKEY]).isin(events)
rows["quiet_all"] = ~rows.date.isin(days) & ~ev
rows["quiet"] = rows.quiet_all & ~rows.station_id.isin(hb.EXCLUDED_STATIONS)
train = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); train["y_log"] = np.log1p(train.boardings)
tq = ~train.date.isin(days) & ~pd.MultiIndex.from_frame(train[hb.DAYKEY]).isin(events)
OBS = train.loc[tq].pivot(index=["date", "station_id"], columns="hour", values="y_log").dropna()
N = 18; FREQ = np.arange(6, N); HF = np.sqrt(2 / N) * np.cos(np.pi * (np.arange(N) + .5)[:, None] * FREQ / N); PROJ = HF @ HF.T
def anchor(pred_wide, cutoff):
    d = OBS.index.get_level_values("date"); last = OBS[(d >= cutoff - pd.Timedelta(days=69)) & (d <= cutoff)]
    w = np.exp2(-(cutoff - last.index.get_level_values("date")).days / 28.0)
    g = [last.index.get_level_values("station_id"), last.index.get_level_values("date").dayofweek]
    num = last.mul(w, axis=0).groupby(g).sum(); den = pd.Series(w, index=last.index).groupby(g).agg(["sum", "size"])
    ref = num.div(den["sum"].where(den["size"].ge(6)), axis=0)
    idx = pd.MultiIndex.from_arrays([pred_wide.index.get_level_values("station_id"), pred_wide.index.get_level_values("date").dayofweek])
    prior = ref.reindex(idx).to_numpy(); target = pred_wide.to_numpy()
    shift = 0.15 * (np.where(np.isfinite(prior), prior - target, 0.0) @ PROJ)
    amp = np.maximum(np.abs(shift).max(1), 0.065); shift *= (0.065 / amp)[:, None]
    return pd.DataFrame(shift, index=pred_wide.index, columns=pred_wide.columns)
print("=== curvature-type layer on top of K1 (independent reimplementation, quiet days, all stations)")
dd = []
for origin, hold in rows.groupby("origin", sort=True):
    hist = hb.select_history(rows, origin)
    d1 = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)[0] if not hist.empty else np.zeros(len(hold))
    k1 = hold[hb.MODEL].to_numpy() + d1; y = hold.y_log.to_numpy()
    hq = hold.assign(k1=k1).loc[hold.quiet_all]
    wide = hq.pivot(index=["date", "station_id"], columns="hour", values="k1").dropna()
    adj = anchor(wide, origin).stack().rename("adj")
    delta = hold.join(adj, on=["date", "station_id", "hour"]).adj.fillna(0.0).to_numpy()
    lead = (hold.date - origin).dt.days.to_numpy(); e = lead <= 61
    r = rm(y, k1 + delta) - rm(y, k1); dd.append(r)
    print(origin.date(), f"delta {r:+.6f} | lead<=61 {rm(y[e], (k1+delta)[e]) - rm(y[e], k1[e]):+.6f}", (f"lead>61 {rm(y[~e], (k1+delta)[~e]) - rm(y[~e], k1[~e]):+.6f}" if (~e).any() else ""), f"| changed {int((delta != 0).sum())}", flush=True)
print("mean", f"{np.mean(dd):+.6f}", "worse", sum(x > 0 for x in dd), "of", len(dd))
print("=== station 3107/3108/3109: mean residual (actual - forecast, log) on quiet days by month, latest forecast per date")
lat = rows[rows.quiet_all].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
lat = lat.assign(err=lat.y_log - lat[hb.MODEL], month=lat.date.dt.to_period("M"))
print(lat[lat.station_id.isin([3107, 3108, 3109])].pivot_table(index="month", columns="station_id", values="err", aggfunc="mean").round(3).to_string())
print("=== 3107 by forecast origin: mean residual per month of the evaluation period")
s = rows[(rows.station_id == 3107) & rows.quiet_all].assign(err=lambda d: d.y_log - d[hb.MODEL], month=lambda d: d.date.dt.to_period("M"))
print(s.pivot_table(index="origin", columns="month", values="err", aggfunc="mean").round(3).to_string())
