"""L5: LightGBM residual model on K1-adjusted past forecasts. Forward validation only (<= 2026-06-30)."""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd, lightgbm as lgb
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
cal = pd.read_csv(P / "final_package/payload/work/external_inputs/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"], usecols=["date", "is_school_vacation", "school_vac_share"])
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
PARAMS = dict(objective="regression", learning_rate=0.03, num_leaves=31, min_data_in_leaf=200, feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, seed=0, verbose=-1, num_threads=6)
ROUNDS, FRACTION = 300, 0.5
FEATURES = ["station_id", "hour", "dow", "lead", "is_school_vacation", "school_vac_share", "k1pred", "day_mean"]

def prepare():
    rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
    rows = rows.merge(cal, on="date", how="left")
    rows["dow"] = rows.date.dt.day_of_week
    rows["quiet"] = hb.quiet_rows(rows, days, events)
    rows["k1pred"] = rows[hb.MODEL]
    for origin, hold in rows.groupby("origin", sort=True):
        hist = hb.select_history(rows, origin)
        if hist.empty: continue
        d, _ = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)
        rows.loc[hold.index, "k1pred"] = hold[hb.MODEL].to_numpy() + d
    rows["lead"] = (rows.date - rows.origin).dt.days
    rows["day_mean"] = rows.groupby(["origin", *hb.DAYKEY]).k1pred.transform("mean")
    rows["resid"] = rows.y_log - rows.k1pred
    rows["station_id"] = rows.station_id.astype("category")
    return rows

def fit(train):
    ds = lgb.Dataset(train[FEATURES], train.resid, categorical_feature=["station_id"], free_raw_data=False)
    return lgb.train(PARAMS, ds, ROUNDS)

if __name__ == "__main__":
    rows = prepare()
    out = {}
    for origin, hold in rows.groupby("origin", sort=True):
        train = rows.loc[rows.origin.lt(origin) & rows.date.le(origin) & rows.quiet].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
        if len(train) < 20000: continue
        model = fit(train)
        rhat = np.where(hold.quiet, model.predict(hold[FEATURES]), 0.0)
        y = hold.y_log.to_numpy(); k1 = hold.k1pred.to_numpy(); base = hold[hb.MODEL].to_numpy()
        r = {"base": rm(y, base), "k1": rm(y, k1), "l5": rm(y, k1 + FRACTION * rhat), "l5_full": rm(y, k1 + rhat), "l5_quarter": rm(y, k1 + 0.25 * rhat), "train_rows": int(len(train))}
        # split the residual prediction into station-day level and within-day shape
        h = hold.assign(rhat=rhat); lvl = h.groupby(hb.DAYKEY, observed=True).rhat.transform("mean").to_numpy()
        r["l5_shape_only"] = rm(y, k1 + FRACTION * (rhat - lvl)); r["l5_level_only"] = rm(y, k1 + FRACTION * lvl)
        out[str(origin.date())] = r
        print(origin.date(), f"train {r['train_rows']:>7} | k1 {r['k1']:.6f} | L5(0.5) {r['l5']-r['k1']:+.6f}  shape-only {r['l5_shape_only']-r['k1']:+.6f}  level-only {r['l5_level_only']-r['k1']:+.6f} | (0.25) {r['l5_quarter']-r['k1']:+.6f} (1.0) {r['l5_full']-r['k1']:+.6f}", flush=True)
    for k in ("l5", "l5_shape_only", "l5_level_only"):
        d = [v[k] - v["k1"] for v in out.values()]
        print(k, "mean", f"{np.mean(d):+.6f}", "worse", sum(x > 0 for x in d), "of", len(d))
    json.dump(out, open(Path(__file__).parent / "set2_l5.json", "w"), indent=1)
