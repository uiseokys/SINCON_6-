import pickle, numpy as np
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
FOLDS = {"A": ("2026-03-01", "2026-06-30"), "B": ("2026-01-01", "2026-04-30"), "C": ("2025-11-01", "2026-02-28")}
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
L = lambda v, f, seeds: [np.load(f"out2/{v}_{f}_s{s}.npy") for s in seeds]
print("fold | NN only: base8  base4+ple4  base4+per4  base4+ple2+per2 | with LGB 0.5: base8  base4+ple4  base4+per4  base4+ple2+per2")
for f, (vs, ve) in FOLDS.items():
    y = np.log1p(df.loc[df["date"].between(vs, ve), "boardings"].to_numpy(np.float64)); g = np.load(f"out2/lgb_{f}_test.npy")
    sets = {"base8": L("base", f, range(8)), "b4+ple4": L("base", f, range(4)) + L("ple", f, range(4)), "b4+per4": L("base", f, range(4)) + L("periodic", f, range(4)),
            "b4+ple2+per2": L("base", f, range(4)) + L("ple", f, range(2)) + L("periodic", f, range(2)), "base4(4-7)+ple4": L("base", f, range(4, 8)) + L("ple", f, range(4))}
    nn = {k: np.mean(v, 0) for k, v in sets.items()}
    b = rm(nn["base8"], y); bb = rm(0.5 * nn["base8"] + 0.5 * g, y)
    print(f, f"| {b:.5f}", " ".join(f"{k}:{rm(p, y)-b:+.5f}" for k, p in nn.items() if k != "base8"), f"| {bb:.5f}", " ".join(f"{k}:{rm(0.5*p+0.5*g, y)-bb:+.5f}" for k, p in nn.items() if k != "base8"))
