"""수준 전용 모델: 최근 수준 대비 변화를 직접 예측. 각 기준일 이전 자료만 사용."""
import sys, pickle, json, time, numpy as np, pandas as pd, lightgbm as lgb
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
A = pd.read_pickle("out4/all9.pkl"); D = pickle.load(open("data.pkl", "rb")); df = D["df"].copy(); df["date"] = pd.to_datetime(df["date"])
df["y_log"] = np.log1p(df["boardings"].to_numpy(np.float64))
DAYF = ["dow", "month", "is_school_vacation", "school_vac_share", "is_univ_vacation", "day_temp_mean", "day_precip", "is_rainy_day", "is_heatwave_day", "is_coldwave_day"]
daily = df.groupby(["date", "station_id"]).agg(level=("y_log", "mean"), line=("line", "first"), **{f: (f, "first") for f in DAYF}).reset_index()
daily["line"] = daily["line"].astype("category").cat.codes
ordkeys = A.loc[A.ord2, ["date", "station_id"]].drop_duplicates()            # ordinary station-days seen in the forecast archive (>= 2025-07)
import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); W = P / "final_package/payload/work"
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
fest = pd.read_csv(W / "sincon_festival_station_days.csv", parse_dates=["date"]); ev = pd.read_csv(W / "external_inputs/external/events_daily.csv", parse_dates=["date"], encoding="utf-8-sig").dropna(subset=["station_id"])
extra = pd.MultiIndex.from_frame(pd.concat([fest[["date", "station_id"]], ev[["date", "station_id"]].astype({"station_id": int})]).drop_duplicates())
k = pd.MultiIndex.from_frame(daily[["date", "station_id"]]); daily["ord"] = ~daily.date.isin(days) & ~k.isin(events) & ~k.isin(extra)
first = daily.groupby("station_id").date.min()
LV = daily.pivot(index="date", columns="station_id", values="level"); OK = daily.pivot(index="date", columns="station_id", values="ord").fillna(False).astype(bool)
LVo = LV.where(OK)
def anchors(o):
    """origin o: same-weekday mean level over the last 56 days, 28-day mean and trends (ordinary days only)."""
    w56 = LVo.loc[o - pd.Timedelta(days=55):o]; w28 = LVo.loc[o - pd.Timedelta(days=27):o]; p28 = LVo.loc[o - pd.Timedelta(days=55):o - pd.Timedelta(days=28)]; p56 = LVo.loc[o - pd.Timedelta(days=111):o - pd.Timedelta(days=56)]
    a = pd.DataFrame({"a28": w28.mean(), "n28": w28.notna().sum(), "trend28": w28.mean() - p28.mean(), "trend56": w56.mean() - p56.mean(), "sd28": w28.std()})
    dw = w56.groupby(w56.index.dayofweek).mean().T; dw.columns = [f"adow{c}" for c in dw.columns]
    return a.join(dw)
def frame(o, d0, d1):
    a = anchors(o); t = daily[(daily.date >= d0) & (daily.date <= d1)].merge(a, left_on="station_id", right_index=True, how="left")
    t["anchor"] = t.lookup_dow if False else np.choose(t.dow.to_numpy(), [t[f"adow{i}"].to_numpy() if f"adow{i}" in t else np.full(len(t), np.nan) for i in range(7)])
    t["anchor"] = t["anchor"].fillna(t.a28); t["lead"] = (t.date - o).dt.days; t["age"] = (o - t.station_id.map(first)).dt.days; t["omonth"] = o.month
    t["rel"] = t.level - t.anchor
    return t[t.n28.ge(8) & t.anchor.notna()]
FEAT = ["lead", "dow", "month", "omonth", "is_school_vacation", "school_vac_share", "is_univ_vacation", "day_temp_mean", "day_precip", "is_rainy_day", "is_heatwave_day", "is_coldwave_day", "a28", "trend28", "trend56", "sd28", "line", "age"]
PL = dict(objective="regression", learning_rate=0.05, num_leaves=31, min_data_in_leaf=100, feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, seed=0, verbose=-1, num_threads=8)
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
start = pd.Timestamp("2025-03-02"); res = {}; CLIP = 0.05; store = []
def betas(train, col):
    t = train.assign(rd=train.r * train[col], dd=train[col] ** 2).groupby("station_id")[["rd", "dd"]].sum(); return (t.rd / (t.dd + t.dd.median())).clip(0, 1)
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); t0 = time.time()
    tr = pd.concat([frame(o, o + pd.Timedelta(days=1), min(o + pd.Timedelta(days=123), origin)) for o in pd.date_range(start, origin - pd.Timedelta(days=7), freq="7D")], ignore_index=True)
    tr = tr[tr.ord]
    model = lgb.train(PL, lgb.Dataset(tr[FEAT], tr.rel), 400)
    te = frame(origin, pd.Timestamp(vs), pd.Timestamp(ve)); te["pred_level"] = te.anchor + model.predict(te[FEAT])
    m = A[A.origin.eq(origin)].merge(te[["date", "station_id", "pred_level", "anchor", "level"]], on=["date", "station_id"], how="left")
    m["main_lvl"] = m.groupby(["date", "station_id"])[hb.MODEL].transform("mean"); m["dl"] = (m.pred_level - m.main_lvl).fillna(0.0)
    store.append(m[["origin", *hb.KEY, "dl"]])
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); o_ = m.ord2.to_numpy() & m.pred_level.notna().to_numpy(); r0 = rm(p, y); r = {}
    q = o_; lv_true = m.groupby(["date", "station_id"]).y_log.transform("mean").to_numpy()
    r["level rmse main"] = rm(m.main_lvl[q], lv_true[q]); r["level rmse model"] = rm(m.pred_level[q], lv_true[q]); r["level rmse anchor"] = rm(m.anchor[q], lv_true[q])
    for w in (0.1, 0.25, 0.5): r[f"w{w}"] = rm(np.where(o_, p + np.clip(w * m.dl, -CLIP, CLIP), p), y) - r0
    res[end] = r
    print(end, f"train rows {len(tr)} | level RMSE (ordinary days): main {r['level rmse main']:.4f} level-model {r['level rmse model']:.4f} anchor-only {r['level rmse anchor']:.4f} |", " ".join(f"w{w}:{r[f'w{w}']*1e4:+.2f}" for w in (0.1, 0.25, 0.5)), f"| {time.time()-t0:.0f}s", flush=True)
ALL = A.merge(pd.concat(store), on=["origin", *hb.KEY], how="left"); ALL["dl"] = ALL.dl.fillna(0.0)
SKIP = pd.Timestamp("2025-06-30"); bres = {}
for origin, m in ALL.groupby("origin", sort=True):
    prior = ALL[ALL.origin.lt(origin) & ALL.origin.ne(SKIP) & ALL.date.le(origin) & ALL.ord2].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); o_ = m.ord2.to_numpy(); r0 = rm(p, y)
    if len(prior):
        b = betas(prior, "dl"); a = np.where(o_, np.clip(0.5 * m.station_id.map(b).fillna(0.0).to_numpy() * m.dl.to_numpy(), -CLIP, CLIP), 0.0); bres[str(origin.date())] = rm(p + a, y) - r0
for k_ in ("w0.1", "w0.25", "w0.5"):
    v = [r[k_] for r in res.values()]; print(k_, "mean", f"{np.mean(v)*1e4:+.2f}e-4", "worse", sum(x > 0 for x in v), "of", len(v))
print("half-beta per station:", {k_: round(v * 1e4, 2) for k_, v in bres.items()}, "mean", round(np.mean(list(bres.values())) * 1e4, 2), "worse", sum(v > 0 for v in bres.values()))
ALL.to_pickle("out4/all9_level.pkl"); json.dump(res, open("out4/level_model.json", "w"), indent=1)
