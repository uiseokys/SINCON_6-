"""Blocked cross-fitted LightGBM predictions for the residual-learning variant (past data only)."""
import sys, pickle, time
import numpy as np, pandas as pd, lightgbm as lgb
data, out = sys.argv[1], sys.argv[2]
D = pickle.load(open(data, "rb")); df, FEATURES = D["df"], D["features"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
P = dict(objective="regression", learning_rate=0.05, num_leaves=63, min_data_in_leaf=50, feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, seed=0, verbose=-1, num_threads=10)
X = df[FEATURES].copy()
for c in X.columns:
    if X[c].dtype == object: X[c] = X[c].astype("category")
X["station_id"] = X["station_id"].astype("category")
y = np.log1p(df["boardings"].to_numpy(np.float64))
def fit_predict(tr, te):
    m = lgb.train(P, lgb.Dataset(X[tr], y[tr]), 600); return m.predict(X[te])
for fold, (end, vs, ve) in FOLDS.items():
    t0 = time.time()
    tr = (df["date"] <= end).to_numpy(); te = df["date"].between(vs, ve).to_numpy()
    dates = np.sort(df.loc[tr, "date"].unique()); cuts = np.array_split(dates, 4)
    oof = np.full(tr.sum(), np.nan); dtr = df.loc[tr, "date"].to_numpy()
    for block in cuts:
        inb = np.isin(dtr, block); idx_tr = np.where(tr)[0]
        a = np.zeros(len(df), bool); a[idx_tr[~inb]] = True; b = np.zeros(len(df), bool); b[idx_tr[inb]] = True
        oof[inb] = fit_predict(a, b)
    test = fit_predict(tr, te)
    np.save(f"{out}/lgb_{fold}_trainoof.npy", oof); np.save(f"{out}/lgb_{fold}_test.npy", test)
    print(fold, "train-oof rmse", round(float(np.sqrt(np.mean((oof - y[tr]) ** 2))), 5), "test rmse", round(float(np.sqrt(np.mean((test - y[te]) ** 2))), 5), "sec", round(time.time() - t0), flush=True)
