import pickle, glob, json, numpy as np, pandas as pd
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
team = pd.read_csv(P + "final_package/payload/team/valid_predictions_ABC.csv.gz", parse_dates=["date"])
oof = pd.read_csv(P + "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", "date", "station_id", "hour", "y_log", "lunar3122"], parse_dates=["origin", "date"])
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
res = {}
for f, (end, vs, ve) in FOLDS.items():
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    for name in ("xgb", "cat", "et"):
        t[name] = np.load(f"out2/{name}_{f}.npy")
    g = sorted(glob.glob(f"out2/gru_{f}_s*.npy")); t["gru"] = np.mean([np.load(p) for p in g], 0) if g else np.nan
    t["mylgb"] = np.load(f"out2/lgb_{f}_test.npy")
    m = t.merge(team[team.fold.eq(f)], on=["date", "station_id", "hour"], how="left", validate="one_to_one").merge(oof[oof.origin.eq(end)][["date", "station_id", "hour", "lunar3122"]], on=["date", "station_id", "hour"], how="left")
    assert m.ens_log.notna().all() and m.lunar3122.notna().all()
    y = m.y_log.to_numpy(); ens = m.ens_log.to_numpy(); main = m.lunar3122.to_numpy()
    r = {"single": {k: rm(m[k], y) for k in ("lgb_log", "nn_log", "ens_log", "mylgb", "xgb", "cat", "et", "gru") if m[k].notna().all()}}
    r["ens"] = rm(ens, y); r["main"] = rm(main, y)
    for alt in ("xgb", "cat", "gru"):
        if m[alt].isna().any(): continue
        a = m[alt].to_numpy()
        r[alt] = {"replace_nn (0.5 lgb + 0.5 alt)": rm(0.5 * m.lgb_log + 0.5 * a, y) - r["ens"], "add (ens 2/3 + alt 1/3)": rm((2 * ens + a) / 3, y) - r["ens"],
                  **{f"ens + {w}*(alt-ens)": rm(ens + w * (a - ens), y) - r["ens"] for w in (0.1, 0.2)},
                  **{f"MAIN + {w}*(alt-ens)": rm(main + w * (a - ens), y) - r["main"] for w in (0.05, 0.1, 0.2)}}
    res[f] = r
    print(f, "single:", {k: round(v, 5) for k, v in r["single"].items()}, "| main", round(r["main"], 5))
    for alt in ("xgb", "cat", "gru"):
        if alt in r: print("   ", alt, {k: f"{v:+.5f}" for k, v in r[alt].items()})
json.dump(res, open("out2/alt_val.json", "w"), indent=1)
