"""MLP 대안: XGBoost, CatBoost, ExtraTrees. A/B/C, 2026-06-30 이전 자료만."""
import sys, pickle, time
import numpy as np, pandas as pd
D = pickle.load(open("data.pkl", "rb")); df, FEATURES = D["df"], D["features"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
y = np.log1p(df["boardings"].to_numpy(np.float64))
X = df[FEATURES].copy()
obj = [c for c in X.columns if X[c].dtype == object]
Xc = X.copy()
for c in obj + ["station_id"]: Xc[c] = Xc[c].astype("category")
Xn = X.copy()
for c in obj: Xn[c] = Xn[c].astype("category").cat.codes
Xn = Xn.fillna(-1.0).astype(np.float32)
which = sys.argv[1:] or ["xgb", "cat", "et"]
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
for fold, (end, vs, ve) in FOLDS.items():
    tr = (df["date"] <= end).to_numpy(); te = df["date"].between(vs, ve).to_numpy()
    if "xgb" in which:
        import xgboost as xgb
        t0 = time.time(); m = xgb.XGBRegressor(tree_method="hist", max_depth=8, learning_rate=0.05, n_estimators=800, subsample=0.8, colsample_bytree=0.8, enable_categorical=True, n_jobs=6, random_state=0)
        m.fit(Xc[tr], y[tr]); p = m.predict(Xc[te]); np.save(f"out2/xgb_{fold}.npy", p); print("xgb", fold, round(rm(p, y[te]), 5), "sec", round(time.time() - t0), flush=True)
    if "cat" in which:
        from catboost import CatBoostRegressor
        t0 = time.time(); Xs = X.copy()
        for c in obj + ["station_id"]: Xs[c] = Xs[c].astype(str)
        m = CatBoostRegressor(depth=8, learning_rate=0.08, iterations=1000, loss_function="RMSE", random_seed=0, thread_count=6, verbose=0, cat_features=obj + ["station_id"])
        m.fit(Xs[tr], y[tr]); p = m.predict(Xs[te]); np.save(f"out2/cat_{fold}.npy", p); print("cat", fold, round(rm(p, y[te]), 5), "sec", round(time.time() - t0), flush=True)
    if "et" in which:
        from sklearn.ensemble import ExtraTreesRegressor
        t0 = time.time(); m = ExtraTreesRegressor(n_estimators=300, min_samples_leaf=5, max_features=0.5, n_jobs=6, random_state=0)
        m.fit(Xn[tr], y[tr]); p = m.predict(Xn[te]); np.save(f"out2/et_{fold}.npy", p); print("et", fold, round(rm(p, y[te]), 5), "sec", round(time.time() - t0), flush=True)
