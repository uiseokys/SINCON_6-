import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
A = pd.read_pickle("out4/all9.pkl"); rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
SKIP = pd.Timestamp("2025-06-30")
def betas(train):
    g = train.assign(rd=train.r * train.d, dd=train.d ** 2).groupby("station_id")[["rd", "dd"]].sum()
    return (g.rd / (g.dd + g.dd.median())).clip(0, 1)
res = {}
for origin, hold in A.groupby("origin", sort=True):
    prior = A[A.origin.lt(origin) & A.origin.ne(SKIP) & A.date.le(origin) & A.ord].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    y = hold.y_log.to_numpy(); p = hold[hb.MODEL].to_numpy(); d = hold.d.to_numpy(); o = hold.ord.to_numpy(); r0 = rm(p, y)
    out = {"fixed7": rm(np.where(o & hold.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy(), p + 0.1 * d, p), y) - r0, "prior_rows": int(len(prior))}
    if len(prior):
        b = betas(prior); bb = hold.station_id.map(b).fillna(0.0).to_numpy()
        for k, f in (("full", 1.0), ("half", 0.5)): out[k] = rm(np.where(o, p + f * bb * d, p), y) - r0
        ex = hold.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy()
        out["full_ordinary_stations_only"] = rm(np.where(o & ~ex, p + bb * d, p), y) - r0; out["full_7_stations_only"] = rm(np.where(o & ex, p + bb * d, p), y) - r0
        out["n_pos"] = int((b > 0.05).sum()); out["top"] = {int(k): round(float(v), 2) for k, v in b.sort_values(ascending=False).head(6).items()}
        lead = (hold.date - origin).dt.days.to_numpy(); e = lead <= 61
        out["full_lead<=61"] = rm(np.where(o, p + bb * d, p)[e], y[e]) - rm(p[e], y[e]); out["full_lead>61"] = (rm(np.where(o, p + bb * d, p)[~e], y[~e]) - rm(p[~e], y[~e])) if (~e).any() else float("nan")
    res[str(origin.date())] = out
    if "full" in out: print(origin.date(), f"prior {out['prior_rows']:>7} | fixed7 {out['fixed7']:+.6f} | full {out['full']:+.6f} half {out['half']:+.6f} | ordinary stations {out['full_ordinary_stations_only']:+.6f} 7 stations {out['full_7_stations_only']:+.6f} | lead<=61 {out['full_lead<=61']:+.6f} >61 {out['full_lead>61']:+.6f} | n {out['n_pos']} top {out['top']}", flush=True)
    else: print(origin.date(), "no prior data -> not applied")
fired = [r for r in res.values() if "full" in r]
for k in ("fixed7", "full", "half", "full_ordinary_stations_only", "full_7_stations_only"):
    v = [r[k] for r in fired]; print(f"{k:28s} mean {np.mean(v):+.6f} worse {sum(x > 0 for x in v)} of {len(v)}")
json.dump(res, open("out4/s1b.json", "w"), indent=1)
