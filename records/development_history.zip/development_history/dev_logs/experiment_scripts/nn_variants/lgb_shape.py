import sys, pickle, time
import numpy as np, pandas as pd, lightgbm as lgb
D = pickle.load(open("data.pkl", "rb")); df, FEATURES = D["df"], D["features"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
P = dict(objective="regression", learning_rate=0.05, num_leaves=63, min_data_in_leaf=50, feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, seed=0, verbose=-1, num_threads=10)
X = df[FEATURES].copy()
for c in X.columns:
    if X[c].dtype == object: X[c] = X[c].astype("category")
X["station_id"] = X["station_id"].astype("category")
y = np.log1p(df["boardings"].to_numpy(np.float64)); y = y - pd.Series(y).groupby([df["date"].to_numpy(), df["station_id"].to_numpy()]).transform("mean").to_numpy()
for fold, (end, vs, ve) in FOLDS.items():
    t0 = time.time(); tr = (df["date"] <= end).to_numpy(); te = df["date"].between(vs, ve).to_numpy()
    m = lgb.train(P, lgb.Dataset(X[tr], y[tr]), 600); p = m.predict(X[te]); np.save(f"out2/lgbshape_{fold}.npy", p)
    print(fold, "shape rmse", round(float(np.sqrt(np.mean((p - y[te]) ** 2))), 5), "sec", round(time.time() - t0), flush=True)
