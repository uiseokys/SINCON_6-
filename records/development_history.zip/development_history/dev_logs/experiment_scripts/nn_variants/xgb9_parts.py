import sys, pickle, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week; rows["quiet"] = hb.quiet_rows(rows, days, events)
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
tab = {}; share = {}
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); hold = rows[rows.origin.eq(origin)].copy()
    hist = hb.select_history(rows, origin); d1 = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)[0] if not hist.empty else np.zeros(len(hold)); hold["k1"] = hold[hb.MODEL].to_numpy() + d1
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    t["d"] = np.load(f"out4/xgb_{end}.npy") - 0.5 * np.load(f"out4/lgb_{end}.npy") - 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0)
    m = hold.merge(t, on=hb.KEY, how="left", validate="one_to_one"); y = m.y_log.to_numpy(); k1 = m.k1.to_numpy(); d = m.d.to_numpy(); r0 = rm(k1, y)
    isday = m.date.isin(days).to_numpy(); isev = pd.MultiIndex.from_frame(m[hb.DAYKEY]).isin(events); isex = m.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy()
    parts = {"holiday-type days": isday, "event station-days (not holiday)": isev & ~isday, "excluded 7 stations (ordinary days)": isex & ~isday & ~isev, "ordinary": ~isday & ~isev & ~isex}
    row = {}
    for name, msk in parts.items():
        for w in (0.1, 0.2, 0.3, 0.5):
            row[f"{name} w{w}"] = rm(np.where(msk, k1 + w * d, k1), y) - r0
        share[name] = share.get(name, []) + [msk.mean()]
    for w in (0.2, 0.3, 0.5):
        row[f"holiday+excluded w{w}"] = rm(np.where(isday | (isex & ~isev), k1 + w * d, k1), y) - r0
    tab[end] = row
t = pd.DataFrame(tab).T
pd.set_option("display.width", 260); pd.set_option("display.max_columns", 40)
for name in ("holiday-type days", "event station-days (not holiday)", "excluded 7 stations (ordinary days)", "ordinary", "holiday+excluded"):
    cols = [c for c in t.columns if c.startswith(name + " w")]
    print(f"== {name}" + (f" (rows {np.mean(share[name]):.1%})" if name in share else "")); print((t[cols] * 1e4).round(2).rename(columns=lambda c: c.split(" ")[-1]).to_string()); print("   mean", (t[cols].mean() * 1e4).round(2).tolist(), "worse", (t[cols] > 0).sum().tolist())
print("(values are RMSLE change x 10^-4)")
