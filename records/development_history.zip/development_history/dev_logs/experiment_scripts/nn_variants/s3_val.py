import sys, pickle, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
A = pd.read_pickle("out4/all9.pkl"); D = pickle.load(open("data.pkl", "rb")); df = D["df"]; rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
parts = []
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); q = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); q["date"] = pd.to_datetime(q["date"]); q["origin"] = pd.Timestamp(end)
    sub = 0.5 * np.load(f"out4/lgb_{end}.npy") + 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0); q["dr"] = np.load(f"out4/xgbrec_{end}.npy") - sub; parts.append(q)
A = A.merge(pd.concat(parts), on=["origin", *hb.KEY], how="left"); assert A.dr.notna().all()
g = [A.origin, A.date, A.station_id]; A["d_lvl"] = A.d.groupby(g).transform("mean"); A["d_shp"] = A.d - A.d_lvl; A["dr_lvl"] = A.dr.groupby(g).transform("mean"); A["dr_shp"] = A.dr - A.dr_lvl
SKIP = pd.Timestamp("2025-06-30"); CLIP = 0.05
def betas(train, col):
    t = train.assign(rd=train.r * train[col], dd=train[col] ** 2).groupby("station_id")[["rd", "dd"]].sum(); return (t.rd / (t.dd + t.dd.median())).clip(0, 1)
res = {}
for origin, m in A.groupby("origin", sort=True):
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); o = m.ord2.to_numpy(); ex = m.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy(); r0 = rm(p, y)
    prior = A[A.origin.lt(origin) & A.origin.ne(SKIP) & A.date.le(origin) & A.ord2].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    r = {}
    for col in ("d", "dr", "d_lvl", "d_shp", "dr_lvl", "dr_shp"):
        if len(prior): a = np.where(o, np.clip(0.5 * m.station_id.map(betas(prior, col)).fillna(0.0).to_numpy() * m[col].to_numpy(), -CLIP, CLIP), 0.0)
        else: a = np.where(o & ex, np.clip(0.1 * m[col], -CLIP, CLIP), 0.0)
        r[col] = rm(p + a, y) - r0
    if len(prior):   # level and shape with their own betas, combined
        a = np.where(o, np.clip(0.5 * m.station_id.map(betas(prior, "d_lvl")).fillna(0.0).to_numpy() * m.d_lvl.to_numpy() + 0.5 * m.station_id.map(betas(prior, "d_shp")).fillna(0.0).to_numpy() * m.d_shp.to_numpy(), -CLIP, CLIP), 0.0)
    else: a = np.where(o & ex, np.clip(0.1 * m.d, -CLIP, CLIP), 0.0)
    r["d_lvl+d_shp separate betas"] = rm(p + a, y) - r0
    res[str(origin.date())] = r
T = pd.DataFrame(res).T * 1e4; pd.set_option("display.width", 220); print(T.round(2).to_string()); print("mean", T.mean().round(2).to_dict()); print("worse", (T > 0).sum().to_dict())
A.to_pickle("out4/all9b.pkl")
