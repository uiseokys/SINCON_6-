import pickle, time, numpy as np, pandas as pd, xgboost as xgb
from scipy.stats import poisson
D = pickle.load(open("data.pkl", "rb")); df, FEATURES = D["df"], D["features"]
cnt = df["boardings"].to_numpy(np.float64); y = np.log1p(cnt); X = df[FEATURES].copy()
for c in [c for c in X.columns if X[c].dtype == object] + ["station_id"]: X[c] = X[c].astype("category")
def elog1p(lam):
    lam = np.asarray(lam, float); out = np.log1p(lam) - lam / (2 * (1 + lam) ** 2)
    small = lam < 150
    if small.any():
        l = lam[small]; K = int(l.max() + 12 * np.sqrt(l.max()) + 30); k = np.arange(K + 1)
        res = np.empty(len(l))
        for i in range(0, len(l), 20000):
            res[i:i + 20000] = (poisson.pmf(k[None, :], l[i:i + 20000, None]) * np.log1p(k)[None, :]).sum(1)
        out[small] = res
    return out
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); t0 = time.time(); tr = (df["date"] <= end).to_numpy(); te = df["date"].between(vs, ve).to_numpy()
    m = xgb.XGBRegressor(objective="count:poisson", tree_method="hist", max_depth=8, learning_rate=0.05, n_estimators=800, subsample=0.8, colsample_bytree=0.8, enable_categorical=True, n_jobs=8, random_state=0, max_delta_step=0.7)
    m.fit(X[tr], cnt[tr]); lam = m.predict(X[te]); p = elog1p(lam); np.save(f"out4/pois_{end}.npy", p); np.save(f"out4/poislam_{end}.npy", lam)
    h = df.loc[te, "hour"].to_numpy(); late = h >= 21; px = np.load(f"out4/xgb_{end}.npy")
    print(end, f"poisson {rm(p, y[te]):.5f} (log1p(lam) {rm(np.log1p(lam), y[te]):.5f}) | mse-xgb {rm(px, y[te]):.5f} | late 21-23: pois {rm(p[late], y[te][late]):.5f} xgb {rm(px[late], y[te][late]):.5f} | day 6-20: pois {rm(p[~late], y[te][~late]):.5f} xgb {rm(px[~late], y[te][~late]):.5f} | sec {time.time()-t0:.0f}", flush=True)
