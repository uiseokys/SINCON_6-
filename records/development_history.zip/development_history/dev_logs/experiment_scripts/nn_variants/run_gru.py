"""MLP 대안: 하루 18시간을 한 번에 예측하는 순차 신경망(양방향 GRU). A/B/C, 2026-06-30 이전 자료만. 기기: MPS."""
import sys, time, pickle, json
import numpy as np, pandas as pd, torch, torch.nn as nn
data, fold, device, out, seeds = sys.argv[1:6]
D = pickle.load(open(data, "rb")); df, FEATURES = D["df"], D["features"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
EMBED_COLS = ("station_id", "hour", "dow", "month", "holiday_kind"); H, FIRST = 18, 6
end, vs, ve = FOLDS[fold]
train = df[df["date"] <= end]; target = df[df["date"].between(vs, ve)]
si = {s: i for i, s in enumerate(sorted(train["station_id"].unique()))}
num = [f for f in FEATURES if f not in EMBED_COLS]


def cats(d):
    rel = d["lunar_rel_day"].to_numpy()
    c = np.stack([d["station_id"].map(si).to_numpy(), (d["hour"] - FIRST).to_numpy(), d["dow"].to_numpy(), (d["month"] - 1).to_numpy(), d["holiday_kind"].to_numpy(),
                  np.where(np.isnan(rel), 11, rel + 5).astype(int)], 1).astype(np.int64)
    return c
EMB = [(len(si), 24), (H, 8), (7, 4), (12, 4), (4, 3), (12, 4)]


def numeric(d, nc=None):
    x = d[num].to_numpy(np.float32, copy=True); m = np.isnan(x)
    if nc is None: nc = [i for i in range(x.shape[1]) if m[:, i].any()]
    return np.nan_to_num(x, nan=0.0), m[:, nc].astype(np.float32), nc


def to_days(d):
    """rows -> (days, 18) index array ordered by hour; requires complete days."""
    key = d[["date", "station_id"]].astype(str).agg("|".join, axis=1).to_numpy()
    order = np.lexsort((d["hour"].to_numpy(), key)); k = key[order]
    assert len(d) % H == 0 and (k.reshape(-1, H) == k.reshape(-1, H)[:, :1]).all() and (d["hour"].to_numpy()[order].reshape(-1, H) == np.arange(FIRST, FIRST + H)).all()
    return order.reshape(-1, H)

xr_tr, mk_tr, nc = numeric(train); xr_te, mk_te, _ = numeric(target, nc)
xr_te = np.clip(xr_te, xr_tr.min(0), xr_tr.max(0)); mu, sd = xr_tr.mean(0), xr_tr.std(0); sd = np.where(sd < 1e-3, 1.0, sd)
xn_tr = np.concatenate([(xr_tr - mu) / sd, mk_tr], 1); xn_te = np.concatenate([(xr_te - mu) / sd, mk_te], 1)
y = np.log1p(train["boardings"].to_numpy(np.float32)); ym, ys = float(y.mean()), float(y.std()); yv = np.log1p(target["boardings"].to_numpy(np.float64))
itr, ite = to_days(train), to_days(target)
dev = torch.device(device)
XC = torch.tensor(cats(train)[itr], device=dev); XN = torch.tensor(xn_tr[itr], device=dev); Y = torch.tensor(((y - ym) / ys)[itr], device=dev)
VC = torch.tensor(cats(target)[ite], device=dev); VN = torch.tensor(xn_te[ite], device=dev)


class Seq(nn.Module):
    def __init__(s, n_num, hid=128, drop=0.15):
        super().__init__(); s.emb = nn.ModuleList([nn.Embedding(n, d) for n, d in EMB])
        s.inp = nn.Sequential(nn.Linear(n_num + sum(d for _, d in EMB), 256), nn.SiLU(), nn.Dropout(drop))
        s.gru = nn.GRU(256, hid, num_layers=2, batch_first=True, bidirectional=True, dropout=drop)
        s.out = nn.Sequential(nn.Linear(2 * hid + 256, 128), nn.SiLU(), nn.Linear(128, 1))
    def forward(s, xc, xn):
        z = s.inp(torch.cat([e(xc[..., i]) for i, e in enumerate(s.emb)] + [xn], -1)); h, _ = s.gru(z)
        return s.out(torch.cat([h, z], -1)).squeeze(-1)

epochs, bs, lr = 30, 128, 2e-3; n = len(itr); steps = epochs * ((n + bs - 1) // bs); res = {}
for seed in [int(x) for x in seeds.split(",")]:
    t0 = time.time(); torch.manual_seed(seed); net = Seq(xn_tr.shape[1]).to(dev)
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-5); sch = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr, total_steps=steps, pct_start=0.1)
    for _ in range(epochs):
        net.train(); perm = torch.randperm(n, device=dev)
        for i in range(0, n, bs):
            idx = perm[i:i + bs]; opt.zero_grad(set_to_none=True)
            loss = ((net(XC[idx], XN[idx]) - Y[idx]) ** 2).mean(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); sch.step()
    net.eval()
    with torch.no_grad():
        pd_ = torch.cat([net(VC[i:i + 2048], VN[i:i + 2048]) for i in range(0, len(ite), 2048)]).float().cpu().numpy() * ys + ym
    p = np.empty(len(target)); p[ite.ravel()] = pd_.ravel()
    np.save(f"{out}/gru_{fold}_s{seed}.npy", p); res[seed] = (float(np.sqrt(np.mean((p - yv) ** 2))), round(time.time() - t0, 1))
    print("gru", fold, seed, res[seed], flush=True)
