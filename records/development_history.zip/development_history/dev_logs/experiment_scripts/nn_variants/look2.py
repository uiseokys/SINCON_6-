import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
B = "/Users/jeong-uiseok/sincon-2026/sincon-baseline/"; P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"
name = pd.read_csv(B + "data/metaData.csv").set_index("station_id").station_name
t = pd.read_csv(B + "data/test.csv", parse_dates=["date"]); cur = pd.read_csv(P + "goal_014/graph_clean/submission_l1_hourly_curvature.csv"); new = pd.read_csv(B + "CANDIDATE_SET_1113/submission_xgbbeta_half_on_curvature.csv")
t["cur"] = cur.boardings.values; t["new"] = new.boardings.values; t["dl"] = np.log1p(t.new) - np.log1p(t.cur); t["st"] = t.station_id.map(name)
big = t[t.dl.abs() > 0.08]; print("rows with |change| > 0.08:", len(big)); print(big.groupby(["st", t.date.dt.strftime("%m-%d")]).agg(n=("dl", "size"), mean=("dl", "mean"), cur=("cur", "sum"), new=("new", "sum")).round(3).sort_values("n", ascending=False).head(14).to_string())
# Poisson difference: full grid, on top of main + fixed7, split by late hours and by the 7 stations
A = pd.read_pickle("out4/all9.pkl"); D = pickle.load(open("data.pkl", "rb")); df = D["df"]; rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
res = {}
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); q = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); q["date"] = pd.to_datetime(q["date"])
    q["pd"] = np.load(f"out4/pois_{end}.npy") - 0.5 * np.load(f"out4/lgb_{end}.npy") - 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0); q["px"] = np.load(f"out4/pois_{end}.npy") - np.load(f"out4/xgb_{end}.npy")
    m = A[A.origin.eq(pd.Timestamp(end))].merge(q, on=hb.KEY, how="left"); y = m.y_log.to_numpy(); ex = m.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy(); o = m.ord.to_numpy(); late = (m.hour >= 21).to_numpy()
    base = np.where(o & ex, m[hb.MODEL] + 0.1 * m.d, m[hb.MODEL]); r0 = rm(base, y); r = {}
    for w in (0.05, 0.1, 0.2):
        r[f"all w{w}"] = rm(base + w * m.pd, y) - r0; r[f"late w{w}"] = rm(np.where(late, base + w * m.pd, base), y) - r0
        r[f"ordinary stations, ordinary days w{w}"] = rm(np.where(o & ~ex, base + w * m.pd, base), y) - r0
        r[f"pois-xgb (all) w{w}"] = rm(base + w * m.px, y) - r0
    res[end] = r
T = pd.DataFrame(res).T * 1e4; pd.set_option("display.width", 250)
print("\nPoisson difference on top of (main + fixed 7 stations), RMSLE change x1e-4"); print(T.round(2).to_string()); print("mean", T.mean().round(2).to_dict()); print("worse", (T > 0).sum().to_dict())
