import sys, pickle, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"; W = P + "final_package/payload/work/"
A = pd.read_pickle("out4/all9.pkl"); D = pickle.load(open("data.pkl", "rb")); df = D["df"]; rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
fest = pd.read_csv(W + "sincon_festival_station_days.csv", parse_dates=["date"]); ev = pd.read_csv(W + "external_inputs/external/events_daily.csv", parse_dates=["date"], encoding="utf-8-sig").dropna(subset=["station_id"])
extra = pd.MultiIndex.from_frame(pd.concat([fest[["date", "station_id"]], ev[["date", "station_id"]].astype({"station_id": int})]).drop_duplicates())
A["ord2"] = A.ord & ~pd.MultiIndex.from_frame(A[hb.DAYKEY]).isin(extra); print("ordinary rows", int(A.ord.sum()), "-> with team event tables excluded", int(A.ord2.sum()))
SKIP = pd.Timestamp("2025-06-30"); CLIP = 0.05
def betas(train):
    g = train.assign(rd=train.r * train.d, dd=train.d ** 2).groupby("station_id")[["rd", "dd"]].sum(); return (g.rd / (g.dd + g.dd.median())).clip(0, 1)
res = {}
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); hold = A[A.origin.eq(origin)]
    q = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); q["date"] = pd.to_datetime(q["date"])
    q["pd"] = np.load(f"out4/pois_{end}.npy") - 0.5 * np.load(f"out4/lgb_{end}.npy") - 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0)
    m = hold.merge(q, on=hb.KEY, how="left"); y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); o = m.ord2.to_numpy(); late = (m.hour >= 21).to_numpy(); r0 = rm(p, y)
    prior = A[A.origin.lt(origin) & A.origin.ne(SKIP) & A.date.le(origin) & A.ord2].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    ex = m.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy()
    r = {"fixed7": rm(np.where(o & ex, p + np.clip(0.1 * m.d, -CLIP, CLIP), p), y) - r0}
    if len(prior):
        b = betas(prior); a = np.where(o, np.clip(0.5 * m.station_id.map(b).fillna(0.0).to_numpy() * m.d.to_numpy(), -CLIP, CLIP), 0.0)
    else: a = np.where(o & ex, np.clip(0.1 * m.d, -CLIP, CLIP), 0.0)     # no prior: fall back to the fixed rule
    r["ga_s1b"] = rm(p + a, y) - r0
    pl = np.where(o & late, np.clip(0.1 * m.pd.to_numpy(), -CLIP, CLIP), 0.0)
    r["na_s1b+pois_late"] = rm(p + a + pl, y) - r0; r["pois_late_alone_on_fixed7"] = rm(np.where(o & ex, p + np.clip(0.1 * m.d, -CLIP, CLIP), p) + pl, y) - r0 - r["fixed7"]
    res[end] = r
T = pd.DataFrame(res).T * 1e4; print(T.round(3).to_string()); print("mean", T.mean().round(3).to_dict()); print("worse", (T > 0).sum().to_dict())
json.dump(res, open("out4/s2_val.json", "w"), indent=1); A.to_pickle("out4/all9.pkl")
