"""One-epoch timing of the team MLP (same net, batch, data as fold A) on different devices / thread counts."""
import sys, time, pickle, re
import numpy as np, torch, torch.nn as nn
src = open(sys.argv[1].replace("data.pkl", "run.py")).read()
device, threads = sys.argv[2], int(sys.argv[3])
torch.set_num_threads(threads)
D = pickle.load(open(sys.argv[1], "rb")); df, FEATURES = D["df"], D["features"]
EMBED_COLS = ("station_id", "hour", "dow", "month", "holiday_kind"); N_HOURS, FIRST_HOUR = 18, 6
ns = {}
exec(src[src.index("def categorical"):src.index("end, vs, ve = FOLDS[fold]")], {"np": np, "nn": nn, "torch": torch, "N_HOURS": N_HOURS, "FIRST_HOUR": FIRST_HOUR}, ns)
categorical, Net = ns["categorical"], ns["Net"]
train = df[df["date"] <= "2026-02-28"]
si = {s: i for i, s in enumerate(sorted(train["station_id"].unique()))}
num = [f for f in FEATURES if f not in EMBED_COLS]
xc, emb = categorical(train, si)
x = train[num].to_numpy(np.float32, copy=True); m = np.isnan(x); nc = [i for i in range(x.shape[1]) if m[:, i].any()]
xn = np.concatenate([np.nan_to_num(x, nan=0.0), m[:, nc].astype(np.float32)], 1); mu, sd = xn.mean(0), xn.std(0); sd = np.where(sd < 1e-3, 1.0, sd); xn = (xn - mu) / sd
y = np.log1p(train["boardings"].to_numpy(np.float32)); y = (y - y.mean()) / y.std()
dev = torch.device(device)
xc_t, xn_t, y_t = torch.tensor(xc, device=dev), torch.tensor(xn, device=dev), torch.tensor(y, device=dev)
torch.manual_seed(0); net = Net(emb, xn.shape[1], 512, 0.15, False).to(dev)
opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-5); n, bs = len(y), 2048
def epoch():
    perm = torch.randperm(n, device=dev)
    for i in range(0, n, bs):
        idx = perm[i:i + bs]; opt.zero_grad(set_to_none=True)
        loss = ((net(xc_t[idx], xn_t[idx]) - y_t[idx]) ** 2).mean(); loss.backward(); opt.step()
    return float(loss)
epoch()  # warm-up
t0 = time.time(); epoch(); epoch()
if device == "mps": torch.mps.synchronize()
print(f"{device} threads={threads} rows={n} features={xn.shape[1]} sec/epoch={(time.time()-t0)/2:.2f}", flush=True)
