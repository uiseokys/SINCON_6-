import sys, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline"); W = P / "final_package/payload/work"
name = pd.read_csv(B / "data/metaData.csv").set_index("station_id").station_name
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
fest = pd.read_csv(W / "sincon_festival_station_days.csv", parse_dates=["date"]); ev = pd.read_csv(W / "external_inputs/external/events_daily.csv", parse_dates=["date"], encoding="utf-8-sig").dropna(subset=["station_id"])
extra = pd.MultiIndex.from_frame(pd.concat([fest[["date", "station_id"]], ev[["date", "station_id"]].astype({"station_id": int})]).drop_duplicates())
A = pd.read_pickle("out4/all9.pkl"); CLIP = 0.05
prior = A[A.origin.ne(pd.Timestamp("2025-06-30")) & A.ord2].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
g = prior.assign(rd=prior.r * prior.d, dd=prior.d ** 2).groupby("station_id")[["rd", "dd"]].sum(); beta = (g.rd / (g.dd + g.dd.median())).clip(0, 1)
w = 0.5 * beta; w.loc[3107] = min(w.loc[3107], 0.1)
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); src = P / "goal_014/graph_clean/submission_l1_hourly_curvature.csv"
assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("3d9a6f4f3eb2"); best = pd.read_csv(src); assert (best.example_id.values == test.example_id.values).all()
d = np.load("out3/xgb_test.npy") - 0.5 * np.load("out3/lgb_test.npy") - 0.5 * np.mean([np.load(f"out3/base_test_s{s}.npy") for s in range(4)], 0)
keys = pd.MultiIndex.from_frame(test[hb.DAYKEY]); sel = ~test.date.isin(days).to_numpy() & ~keys.isin(events) & ~keys.isin(protected) & ~keys.isin(extra)
add = np.where(sel, np.clip(test.station_id.map(w).fillna(0.0).to_numpy() * d, -CLIP, CLIP), 0.0)
lb = np.log1p(best.boardings.values); out = best.copy(); ch = add != 0; out.loc[ch, "boardings"] = np.expm1(np.maximum(lb[ch] + add[ch], 0.0)); hb.check_submission(out, test)
path = B / "CANDIDATE_SET_1113/submission_xgbbeta_v2_on_curvature.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); dd = np.log1p(back.boardings.values) - lb; x7 = pd.read_csv(B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv"); d7 = np.log1p(back.boardings.values) - np.log1p(x7.boardings.values)
by = test.assign(a=dd)[np.abs(dd) > 1e-12].groupby("station_id").a.agg(["size", "mean", lambda s: s.abs().mean()]); by.columns = ["rows", "mean", "mean_abs"]; by["w"] = w.reindex(by.index); by.index = by.index.map(name)
print(by.sort_values("mean_abs", ascending=False).head(10).round(4).to_string())
info = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows_changed_vs_curvature": int((np.abs(dd) > 1e-12).sum()), "rms_vs_curvature": float(np.sqrt((dd ** 2).mean())), "max_abs": float(np.abs(dd).max()), "rms_vs_xgb7": float(np.sqrt((d7 ** 2).mean())),
        "prior_rows": int(len(prior)), "weights": {int(k): round(float(v), 4) for k, v in w[w > 0.005].items()}}
print(json.dumps({k: v for k, v in info.items() if k != "weights"})); json.dump(info, open(B / "CANDIDATE_SET_1113/xgbbeta_v2_report.json", "w"), indent=2)
