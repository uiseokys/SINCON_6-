import pickle, numpy as np, glob, sys
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
FOLDS = {"A": ("2026-03-01", "2026-06-30"), "B": ("2026-01-01", "2026-04-30"), "C": ("2025-11-01", "2026-02-28")}
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
rows = {}
for fold, (vs, ve) in FOLDS.items():
    y = np.log1p(df.loc[df["date"].between(vs, ve), "boardings"].to_numpy(np.float64)); lgbp = np.load(f"out2/lgb_{fold}_test.npy")
    for v in ("base", "ple", "periodic", "resid"):
        ps = [np.load(p) for p in sorted(glob.glob(f"out2/{v}_{fold}_s*.npy"))]
        single = [rm(p, y) for p in ps]; avg = np.mean(ps, 0)
        rows[(v, fold)] = dict(n=len(ps), single_mean=np.mean(single), single_sd=np.std(single), avg=rm(avg, y), blend=rm(0.5 * avg + 0.5 * lgbp, y))
    rows[("lgb", fold)] = dict(avg=rm(lgbp, y))
print("variant   fold seeds  single(mean±sd)     4-seed avg   Δavg vs base   blend w/ LGB  Δblend vs base")
for v in ("base", "ple", "periodic", "resid"):
    for f in "ABC":
        r, b = rows[(v, f)], rows[("base", f)]
        print(f"{v:9s} {f}    {r['n']}     {r['single_mean']:.5f}±{r['single_sd']:.5f}   {r['avg']:.5f}    {r['avg']-b['avg']:+.5f}       {r['blend']:.5f}     {r['blend']-b['blend']:+.5f}")
print("lgb alone", {f: round(rows[('lgb', f)]['avg'], 5) for f in 'ABC'})
