import sys, pickle, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week; rows["quiet"] = hb.quiet_rows(rows, days, events)
ev = pd.MultiIndex.from_frame(rows[hb.DAYKEY]).isin(events); rows["quiet_all"] = ~rows.date.isin(days) & ~ev
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
A = (0.1, 0.2, 0.3, 0.5); res = {}
for f, (end, vs, ve) in FOLDS.items():
    origin = pd.Timestamp(end); hold = rows[rows.origin.eq(origin)].copy()
    hist = hb.select_history(rows, origin); d1, _ = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet); hold["k1"] = hold[hb.MODEL].to_numpy() + d1
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    t["nn_shape"] = np.mean([np.load(f"out2/shape_{f}_s{s}.npy") for s in range(4)], 0); t["lgb_shape"] = np.load(f"out2/lgbshape_{f}.npy")
    t["base_nn"] = np.mean([np.load(f"out2/base_{f}_s{s}.npy") for s in range(4)], 0)
    m = hold.merge(t, on=hb.KEY, how="left", validate="one_to_one"); assert m.nn_shape.notna().all()
    g = [m.date, m.station_id]; cen = lambda s: s - s.groupby(g).transform("mean")
    y = m.y_log.to_numpy(); k1 = m.k1.to_numpy(); mean_k1 = m.k1.groupby(g).transform("mean").to_numpy(); sh = k1 - mean_k1; q = m.quiet_all.to_numpy()
    shapes = {"nn": cen(m.nn_shape).to_numpy(), "lgb": cen(m.lgb_shape).to_numpy(), "nn+lgb": cen(0.5 * m.nn_shape + 0.5 * m.lgb_shape).to_numpy(), "control(base nn shape)": cen(m.base_nn).to_numpy()}
    ysh = cen(m.y_log).to_numpy()
    r0 = rm(k1, y); res[f] = {}
    print(f, f"K1 main {r0:.6f} | shape-only rmse on quiet rows: main {rm(sh[q], ysh[q]):.5f}", " ".join(f"{k} {rm(v[q], ysh[q]):.5f}" for k, v in shapes.items()))
    for k, v in shapes.items():
        res[f][k] = [rm(np.where(q, mean_k1 + (1 - a) * sh + a * v, k1), y) - r0 for a in A]
        print(f"   {k:24s}", " ".join(f"a{a}:{x:+.6f}" for a, x in zip(A, res[f][k])))
print("--- mean over A,B,C")
for k in ("nn", "lgb", "nn+lgb", "control(base nn shape)"):
    arr = np.array([res[f][k] for f in "ABC"]); i = arr.mean(0).argmin()
    print(f"   {k:24s}", " ".join(f"a{a}:{x:+.6f}" for a, x in zip(A, arr.mean(0))), f"| best a {A[i]}: folds improved {int((arr[:, i] < 0).sum())}/3")
json.dump(res, open("out2/shape_val.json", "w"), indent=1)
