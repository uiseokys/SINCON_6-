import pickle, hashlib, json, numpy as np, pandas as pd
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"; B = "/Users/jeong-uiseok/sincon-2026/sincon-baseline/"
te = pickle.load(open("test.pkl", "rb"))["df"]; test = pd.read_csv(B + "data/test.csv")
src = P + "goal_014/graph_clean/submission_l1_hourly_curvature.csv"
assert hashlib.sha256(open(src, "rb").read()).hexdigest().startswith("3d9a6f4f3eb2")
best = pd.read_csv(src)
assert len(best) == 157194 and (best.example_id.values == test.example_id.values).all()
assert (te["station_id"].values == test["station_id"].values).all() and (te["hour"].values == test["hour"].values).all() and (te["date"].astype(str).values == test["date"].astype(str).values).all()
L = lambda v: np.mean([np.load(f"out3/{v}_test_s{s}.npy") for s in range(4)], 0)
base, ple, per = L("base"), L("ple"), L("periodic")
cands = {"submission_nn_ple_w10_on_curvature.csv": 0.1 * 0.5 * (ple - base),
         "submission_nn_periodic_w20_on_curvature.csv": 0.2 * 0.5 * (per - base),
         "submission_nn_ple_periodic_w10_on_curvature.csv": 0.1 * ((ple + per + base) / 3 - base)}
lb = np.log1p(best.boardings.values); rep = {}
for name, d in cands.items():
    out = best.copy(); out["boardings"] = np.expm1(np.maximum(lb + d, 0.0))
    v = out.boardings.values; assert np.isfinite(v).all() and (v >= 0).all() and list(out.columns) == ["example_id", "boardings"]
    out.to_csv(B + "CANDIDATE_SET_1113/" + name, index=False)
    back = pd.read_csv(B + "CANDIDATE_SET_1113/" + name); dd = np.log1p(back.boardings.values) - lb
    rep[name] = {"sha256": hashlib.sha256(open(B + "CANDIDATE_SET_1113/" + name, "rb").read()).hexdigest(), "rms_log_diff_vs_best": float(np.sqrt((dd ** 2).mean())),
                 "mean_log_diff": float(dd.mean()), "max_abs_log_diff": float(np.abs(dd).max()), "rows": int(len(back))}
    print(name, json.dumps(rep[name]))
json.dump(rep, open(B + "CANDIDATE_SET_1113/nn_delta_report.json", "w"), indent=2)
