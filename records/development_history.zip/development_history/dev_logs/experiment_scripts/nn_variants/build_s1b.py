import sys, pickle, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
name = pd.read_csv(B / "data/metaData.csv").set_index("station_id").station_name
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
A = pd.read_pickle("out4/all9.pkl"); rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
# quick look: Poisson model as a difference source (all rows / late hours), w = 0.05
for line in open("out4/folds.txt"):
    end = line.split()[0]; h = A[A.origin.eq(pd.Timestamp(end))]
    # all9 rows are in merge order = hold order; rebuild alignment through keys
D = pickle.load(open("data.pkl", "rb")); df = D["df"]; tot = []
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    t["pd"] = np.load(f"out4/pois_{end}.npy") - 0.5 * np.load(f"out4/lgb_{end}.npy") - 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0)
    m = A[A.origin.eq(pd.Timestamp(end))].merge(t, on=hb.KEY, how="left"); y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); r0 = rm(p, y)
    tot.append((rm(p + 0.05 * m.pd, y) - r0, rm(np.where(m.hour >= 21, p + 0.05 * m.pd, p), y) - r0))
print("poisson difference w=0.05: all rows mean", f"{np.mean([a for a, _ in tot]):+.6f}", "worse", sum(a > 0 for a, _ in tot), "| late only mean", f"{np.mean([b for _, b in tot]):+.6f}", "worse", sum(b > 0 for _, b in tot), "of 9")
# ---- S1b for the test period
prior = A[A.origin.ne(pd.Timestamp("2025-06-30")) & A.ord].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
g = prior.assign(rd=prior.r * prior.d, dd=prior.d ** 2).groupby("station_id")[["rd", "dd"]].sum(); beta = (g.rd / (g.dd + g.dd.median())).clip(0, 1)
w = 0.5 * beta; w.loc[3107] = min(w.loc[3107], 0.1)
print("prior rows", len(prior), "dates", prior.date.min().date(), "~", prior.date.max().date(), "| stations with w>0.02:", int((w > 0.02).sum()))
print("largest w:", {name[k]: round(float(v), 3) for k, v in w.sort_values(ascending=False).head(12).items()})
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); src = P / "goal_014/graph_clean/submission_l1_hourly_curvature.csv"
assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("3d9a6f4f3eb2"); best = pd.read_csv(src); assert (best.example_id.values == test.example_id.values).all()
d = np.load("out3/xgb_test.npy") - 0.5 * np.load("out3/lgb_test.npy") - 0.5 * np.mean([np.load(f"out3/base_test_s{s}.npy") for s in range(4)], 0)
keys = pd.MultiIndex.from_frame(test[hb.DAYKEY]); sel = ~test.date.isin(days).to_numpy() & ~keys.isin(events) & ~keys.isin(protected)
ws = test.station_id.map(w).fillna(0.0).to_numpy(); lb = np.log1p(best.boardings.values); add = np.where(sel, ws * d, 0.0)
out = best.copy(); ch = add != 0; out.loc[ch, "boardings"] = np.expm1(np.maximum(lb[ch] + add[ch], 0.0)); hb.check_submission(out, test)
path = B / "CANDIDATE_SET_1113/submission_xgbbeta_half_on_curvature.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); dd = np.log1p(back.boardings.values) - lb
x7 = pd.read_csv(B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv"); d7 = np.log1p(back.boardings.values) - np.log1p(x7.boardings.values)
info = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows_changed_vs_curvature": int((np.abs(dd) > 1e-12).sum()), "rms_vs_curvature": float(np.sqrt((dd ** 2).mean())), "max_abs": float(np.abs(dd).max()),
        "rms_vs_xgb7": float(np.sqrt((d7 ** 2).mean())), "weights": {int(k): round(float(v), 4) for k, v in w[w > 0.005].items()}}
print(json.dumps({k: v for k, v in info.items() if k != "weights"})); json.dump(info, open(B / "CANDIDATE_SET_1113/xgbbeta_report.json", "w"), indent=2)
