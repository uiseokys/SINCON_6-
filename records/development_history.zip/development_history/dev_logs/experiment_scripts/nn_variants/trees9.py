"""9개 기준일: XGBoost(고정 설정)와 LightGBM(대체 앙상블용). 각 기준일 이전 자료만 학습."""
import pickle, time, numpy as np, pandas as pd, xgboost as xgb, lightgbm as lgb
D = pickle.load(open("data.pkl", "rb")); df, FEATURES = D["df"], D["features"]
y = np.log1p(df["boardings"].to_numpy(np.float64)); X = df[FEATURES].copy()
for c in [c for c in X.columns if X[c].dtype == object] + ["station_id"]: X[c] = X[c].astype("category")
PL = dict(objective="regression", learning_rate=0.05, num_leaves=63, min_data_in_leaf=50, feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, seed=0, verbose=-1, num_threads=8)
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); t0 = time.time()
    tr = (df["date"] <= end).to_numpy(); te = df["date"].between(vs, ve).to_numpy()
    m = xgb.XGBRegressor(tree_method="hist", max_depth=8, learning_rate=0.05, n_estimators=800, subsample=0.8, colsample_bytree=0.8, enable_categorical=True, n_jobs=8, random_state=0)
    m.fit(X[tr], y[tr]); px = m.predict(X[te]); np.save(f"out4/xgb_{end}.npy", px)
    pl = lgb.train(PL, lgb.Dataset(X[tr], y[tr]), 600).predict(X[te]); np.save(f"out4/lgb_{end}.npy", pl)
    print(end, "xgb", round(rm(px, y[te]), 5), "lgb", round(rm(pl, y[te]), 5), "rows", int(te.sum()), "sec", round(time.time() - t0), flush=True)
