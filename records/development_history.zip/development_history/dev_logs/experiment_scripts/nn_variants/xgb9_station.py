import sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = "/Users/jeong-uiseok/sincon-2026/sincon-baseline/"
name = pd.read_csv(B + "data/metaData.csv").set_index("station_id").station_name
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
tab = {}; lvl = {}
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); hold = rows[rows.origin.eq(origin)]
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    t["d"] = np.load(f"out4/xgb_{end}.npy") - 0.5 * np.load(f"out4/lgb_{end}.npy") - 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0)
    m = hold.merge(t, on=hb.KEY, how="left", validate="one_to_one"); y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); d = m.d.to_numpy(); r0 = rm(p, y)
    ok = (~m.date.isin(days)).to_numpy() & ~pd.MultiIndex.from_frame(m[hb.DAYKEY]).isin(events)
    row = {}
    for st in sorted(hb.EXCLUDED_STATIONS):
        msk = ok & m.station_id.eq(st).to_numpy(); row[name[st]] = (rm(np.where(msk, p + 0.1 * d, p), y) - r0) * 1e4
        lvl.setdefault(name[st], []).append(f"{(y - p)[msk].mean():+.2f}/{d[msk].mean():+.2f}")
    msk = ok & m.station_id.isin(hb.EXCLUDED_STATIONS - {3107}).to_numpy(); row["6 stations (no 3107) w0.1"] = (rm(np.where(msk, p + 0.1 * d, p), y) - r0) * 1e4; row["6 stations w0.2"] = (rm(np.where(msk, p + 0.2 * d, p), y) - r0) * 1e4
    # all other (non-excluded) stations individually: how many would improve
    tab[end] = row
t = pd.DataFrame(tab).T; pd.set_option("display.width", 250)
print("RMSLE change x1e-4 when the XGB difference (w=0.1) is added on one station's ordinary days"); print(t.round(2).to_string()); print("mean", t.mean().round(2).to_dict()); print("worse", (t > 0).sum().to_dict())
print("\nper station: mean residual of main (actual - forecast) / mean XGB difference, by origin"); 
for k, v in lvl.items(): print(f"{k:22s}", "  ".join(v))
