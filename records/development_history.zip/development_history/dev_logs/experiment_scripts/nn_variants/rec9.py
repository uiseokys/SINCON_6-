import pickle, time, numpy as np, pandas as pd, xgboost as xgb
D = pickle.load(open("data.pkl", "rb")); df, FEATURES = D["df"], D["features"]
y = np.log1p(df["boardings"].to_numpy(np.float64)); X = df[FEATURES].copy(); dates = pd.to_datetime(df["date"])
for c in [c for c in X.columns if X[c].dtype == object] + ["station_id"]: X[c] = X[c].astype("category")
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); tr = (df["date"] <= end).to_numpy(); te = df["date"].between(vs, ve).to_numpy()
    w = np.power(0.5, (pd.Timestamp(end) - dates[tr]).dt.days.to_numpy() / 120.0)
    m = xgb.XGBRegressor(tree_method="hist", max_depth=8, learning_rate=0.05, n_estimators=800, subsample=0.8, colsample_bytree=0.8, enable_categorical=True, n_jobs=8, random_state=0)
    m.fit(X[tr], y[tr], sample_weight=w); p = m.predict(X[te]); np.save(f"out4/xgbrec_{end}.npy", p)
    print(end, "recency xgb", round(rm(p, y[te]), 5), "| plain xgb", round(rm(np.load(f"out4/xgb_{end}.npy"), y[te]), 5), flush=True)
