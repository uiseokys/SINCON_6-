import sys, pickle, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
parts = []
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); hold = rows[rows.origin.eq(pd.Timestamp(end))]
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    t["d"] = np.load(f"out4/xgb_{end}.npy") - 0.5 * np.load(f"out4/lgb_{end}.npy") - 0.5 * np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0)
    parts.append(hold.merge(t, on=hb.KEY, how="left", validate="one_to_one"))
A = pd.concat(parts, ignore_index=True); A["r"] = A.y_log - A[hb.MODEL]
A["ord"] = ~A.date.isin(days) & ~pd.MultiIndex.from_frame(A[hb.DAYKEY]).isin(events)
A.to_pickle("out4/all9.pkl")
def betas(train):
    g = train.assign(rd=train.r * train.d, dd=train.d ** 2).groupby("station_id")[["rd", "dd"]].sum()
    return (g.rd / (g.dd + g.dd.median())).clip(0, 1)
res = {}
for origin, hold in A.groupby("origin", sort=True):
    prior = A[A.origin.lt(origin) & A.date.le(origin) & A.ord].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    if prior.empty: continue
    y = hold.y_log.to_numpy(); p = hold[hb.MODEL].to_numpy(); d = hold.d.to_numpy(); o = hold.ord.to_numpy(); r0 = rm(p, y)
    fixed = rm(np.where(o & hold.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy(), p + 0.1 * d, p), y) - r0
    out = {"fixed7_w0.1": fixed}
    for name, tr in (("a_all", prior), ("b_120d", prior[prior.date.gt(origin - pd.Timedelta(days=120))])):
        b = betas(tr); bb = hold.station_id.map(b).fillna(0.0).to_numpy()
        out[name] = rm(np.where(o, p + bb * d, p), y) - r0; out[name + "_half"] = rm(np.where(o, p + 0.5 * bb * d, p), y) - r0
        out[name + "_n_pos"] = int((b > 0.05).sum()); out[name + "_top"] = {int(k): round(float(v), 2) for k, v in b.sort_values(ascending=False).head(5).items()}
    res[str(origin.date())] = out
    print(origin.date(), f"fixed7 {fixed:+.6f} | (a) all {out['a_all']:+.6f} half {out['a_all_half']:+.6f} n>0.05 {out['a_all_n_pos']} | (b) 120d {out['b_120d']:+.6f} half {out['b_120d_half']:+.6f} n>0.05 {out['b_120d_n_pos']} top {out['b_120d_top']}", flush=True)
for k in ("fixed7_w0.1", "a_all", "a_all_half", "b_120d", "b_120d_half"):
    v = [r[k] for r in res.values()]; print(f"{k:14s} mean {np.mean(v):+.6f} worse {sum(x > 0 for x in v)} of {len(v)}")
json.dump(res, open("out4/s1.json", "w"), indent=1)
