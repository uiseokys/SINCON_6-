"""과거 검증: 주후보 과거 예측 + w × (혼합 신경망 − 기존 신경망). 대조군: 기존 신경망의 다른 시드."""
import pickle, numpy as np, pandas as pd, json
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
FOLDS = {"A": ("2026-02-28", "2026-03-01", "2026-06-30"), "B": ("2025-12-31", "2026-01-01", "2026-04-30"), "C": ("2025-10-31", "2025-11-01", "2026-02-28")}
oof = pd.read_csv(P + "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", "date", "station_id", "hour", "y_log", "lunar3122"], parse_dates=["origin", "date"])
rm = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))
L = lambda v, f, seeds: np.mean([np.load(f"out2/{v}_{f}_s{s}.npy") for s in seeds], 0)
W = (0.1, 0.2, 0.3, 0.4, 0.5); res = {}
for f, (end, vs, ve) in FOLDS.items():
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    o = oof[oof.origin.eq(end)]
    m = t.merge(o, on=["date", "station_id", "hour"], how="left", validate="one_to_one"); assert m.lunar3122.notna().all()
    y, main = m.y_log.to_numpy(), m.lunar3122.to_numpy(); base = L("base", f, range(4))
    deltas = {"ple": 0.5 * (L("ple", f, range(4)) - base), "periodic": 0.5 * (L("periodic", f, range(4)) - base),
              "ple+periodic": (L("ple", f, range(4)) + L("periodic", f, range(4)) + base) / 3 - base, "placebo(base 4-7)": 0.5 * (L("base", f, range(4, 8)) - base)}
    r0 = rm(main, y); res[f] = {k: [rm(main + w * d, y) - r0 for w in W] for k, d in deltas.items()}; res[f]["main"] = r0
    print(f, f"main {r0:.6f}"); [print(f"   {k:18s}", " ".join(f"w{w}:{v:+.6f}" for w, v in zip(W, vals))) for k, vals in res[f].items() if k != "main"]
print("--- mean over A,B,C")
for k in ("ple", "periodic", "ple+periodic", "placebo(base 4-7)"):
    a = np.array([res[f][k] for f in "ABC"]); print(f"   {k:18s}", " ".join(f"w{w}:{v:+.6f}" for w, v in zip(W, a.mean(0))), "| folds improved at best w:", int((a[:, a.mean(0).argmin()] < 0).sum()), "best w", W[a.mean(0).argmin()])
json.dump(res, open("out2/delta_val.json", "w"), indent=1)
