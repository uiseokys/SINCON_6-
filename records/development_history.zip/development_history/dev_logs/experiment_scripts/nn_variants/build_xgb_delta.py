import sys, pickle, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
name = pd.read_csv(B / "data/metaData.csv").set_index("station_id").station_name
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); src = P / "goal_014/graph_clean/submission_l1_hourly_curvature.csv"
assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("3d9a6f4f3eb2"); best = pd.read_csv(src)
assert (best.example_id.values == test.example_id.values).all()
te = pickle.load(open("test.pkl", "rb"))["df"]; assert (te["station_id"].values == test["station_id"].values).all() and (te["hour"].values == test["hour"].values).all()
sub = 0.5 * np.load("out3/lgb_test.npy") + 0.5 * np.mean([np.load(f"out3/base_test_s{s}.npy") for s in range(4)], 0)
d = np.load("out3/xgb_test.npy") - sub
keys = pd.MultiIndex.from_frame(test[hb.DAYKEY])
sel = test.station_id.isin(hb.EXCLUDED_STATIONS).to_numpy() & ~test.date.isin(days).to_numpy() & ~keys.isin(events) & ~keys.isin(protected)
W = 0.1; lb = np.log1p(best.boardings.values); out = best.copy(); out.loc[sel, "boardings"] = np.expm1(np.maximum(lb[sel] + W * d[sel], 0.0))
hb.check_submission(out, test)
path = B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); dd = np.log1p(back.boardings.values) - lb
by = test.assign(xgb_minus_ens=d, applied=dd)[sel].groupby("station_id").agg(rows=("applied", "size"), xgb_minus_ens=("xgb_minus_ens", "mean"), applied=("applied", "mean")).rename(index=name).round(4)
print(by.to_string())
print("all stations: mean XGB−ens on ordinary days by month:", test.assign(d=d, m=test.date.dt.month).groupby("m").d.mean().round(4).to_dict())
info = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows_changed": int((np.abs(dd) > 1e-12).sum()), "max_abs_log_change": float(np.abs(dd).max()), "rms_log_diff_vs_best": float(np.sqrt((dd ** 2).mean())), "w": W}
print(json.dumps(info)); json.dump(info, open(B / "CANDIDATE_SET_1113/xgb7_report.json", "w"), indent=2)
