import sys, pickle, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); import hourbias_layer as hb
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
D = pickle.load(open("data.pkl", "rb")); df = D["df"]
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week; rows["quiet"] = hb.quiet_rows(rows, days, events)
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
W = (0.05, 0.1, 0.2); res = {}
for line in open("out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end)
    hold = rows[rows.origin.eq(origin)].copy()
    hist = hb.select_history(rows, origin)
    d1 = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)[0] if not hist.empty else np.zeros(len(hold)); hold["k1"] = hold[hb.MODEL].to_numpy() + d1
    t = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); t["date"] = pd.to_datetime(t["date"])
    t["xgb"] = np.load(f"out4/xgb_{end}.npy"); t["lgb"] = np.load(f"out4/lgb_{end}.npy"); t["mlp"] = np.mean([np.load(f"out4/base_{end}_s{s}.npy") for s in range(4)], 0)
    m = hold.merge(t, on=hb.KEY, how="left", validate="one_to_one"); assert m.xgb.notna().all()
    y = m.y_log.to_numpy(); sub = 0.5 * m.lgb + 0.5 * m.mlp; d = (m.xgb - sub).to_numpy()
    q = m.quiet.to_numpy(); lead = (m.date - origin).dt.days.to_numpy()
    r = {"main": rm(m[hb.MODEL], y), "k1": rm(m.k1, y), "xgb": rm(m.xgb, y), "sub": rm(sub, y)}
    for w in W:
        r[f"main_w{w}"] = rm(m[hb.MODEL] + w * d, y) - r["main"]; r[f"k1_w{w}"] = rm(m.k1 + w * d, y) - r["k1"]
    r["k1_w0.1_ordinary"] = rm((m.k1 + 0.1 * d)[q], y[q]) - rm(m.k1[q], y[q]); r["k1_w0.1_special"] = rm((m.k1 + 0.1 * d)[~q], y[~q]) - rm(m.k1[~q], y[~q])
    e = lead <= 61; r["k1_w0.1_lead<=61"] = rm((m.k1 + 0.1 * d)[e], y[e]) - rm(m.k1[e], y[e]); r["k1_w0.1_lead>61"] = (rm((m.k1 + 0.1 * d)[~e], y[~e]) - rm(m.k1[~e], y[~e])) if (~e).any() else float("nan")
    res[end] = r
    print(end, f"main {r['main']:.5f} xgb {r['xgb']:.5f} sub-ens {r['sub']:.5f} | on main:", " ".join(f"w{w}:{r[f'main_w{w}']:+.6f}" for w in W), "| on K1:", " ".join(f"w{w}:{r[f'k1_w{w}']:+.6f}" for w in W),
          f"| w0.1 ordinary {r['k1_w0.1_ordinary']:+.6f} special {r['k1_w0.1_special']:+.6f} | lead<=61 {r['k1_w0.1_lead<=61']:+.6f} >61 {r['k1_w0.1_lead>61']:+.6f}", flush=True)
for base in ("main", "k1"):
    for w in W:
        v = [r[f"{base}_w{w}"] for r in res.values()]; print(f"{base} w{w}: mean {np.mean(v):+.6f} worse {sum(x > 0 for x in v)} of {len(v)}")
json.dump(res, open("out4/xgb9_val.json", "w"), indent=1)
