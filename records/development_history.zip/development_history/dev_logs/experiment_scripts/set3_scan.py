import sys, json
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
line = pd.read_csv(B / "data/metaData.csv").set_index("station_id")["canonical_line"]
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week; rows["line"] = rows.station_id.map(line)
rows["quiet"] = hb.quiet_rows(rows, days, events)
BUCKETS = [(1, 31), (32, 62), (63, 92), (93, 123)]; MULTS = (0, 0.5, 1, 1.5, 2, 3)
per = {}
for origin, hold in rows.groupby("origin", sort=True):
    hist = hb.select_history(rows, origin)
    if hist.empty: continue
    d, good = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)
    y = hold.y_log.to_numpy(); b = hold[hb.MODEL].to_numpy(); k1 = b + d
    h = hist.assign(err=hist.y_log - hist[hb.MODEL]); g = h.groupby(hb.DAYKEY).err
    h["err"] = (h.err - g.transform("mean")).where(g.transform("size").eq(18))
    out = {"k1": rm(y, k1)}
    for name, keys in (("net", ["dow", "hour"]), ("line", ["line", "dow", "hour"])):
        cell = h.groupby(keys).err.mean().rename("c")
        c = hold.join(cell, on=keys).c
        c = (c - c.groupby([hold.date, hold.station_id]).transform("mean")).where(hold.quiet, 0.0).fillna(0.0).to_numpy()
        for f in (0.25, 0.5): out[f"L7_{name}_{f}"] = rm(y, k1 + f * c)
    lead = (hold.date - origin).dt.days.to_numpy()
    out["sse"] = {i: {m: float(((y - (b + m * d)) ** 2)[(lead >= lo) & (lead <= hi)].sum()) for m in MULTS} for i, (lo, hi) in enumerate(BUCKETS)}
    out["n"] = {i: int(((lead >= lo) & (lead <= hi)).sum()) for i, (lo, hi) in enumerate(BUCKETS)}
    per[str(origin.date())] = out
    print(origin.date(), f"k1 {out['k1']:.6f} | L7 net f.25 {out['L7_net_0.25']-out['k1']:+.6f} f.5 {out['L7_net_0.5']-out['k1']:+.6f} | line f.25 {out['L7_line_0.25']-out['k1']:+.6f} f.5 {out['L7_line_0.5']-out['k1']:+.6f}", flush=True)
for k in ("L7_net_0.25", "L7_net_0.5", "L7_line_0.25", "L7_line_0.5"):
    dd = [v[k] - v["k1"] for v in per.values()]; print(k, "mean", f"{np.mean(dd):+.6f}", "worse", sum(x > 0 for x in dd), "of", len(dd))
# ---- L8: per-bucket rmsle deltas and leave-one-origin-out schedule
origins = list(per)
def bucket_rmse(o, i, m): return np.sqrt(per[o]["sse"][i][m] / per[o]["n"][i]) if per[o]["n"][i] else np.nan
print("bucket x multiplier: mean over origins of (rmsle_m - rmsle_1)")
for i, bk in enumerate(BUCKETS):
    print("  lead", bk, " ".join(f"x{m}:{np.nanmean([bucket_rmse(o, i, m) - bucket_rmse(o, i, 1) for o in origins]):+.6f}" for m in MULTS),
          "| origins preferring >1:", sum(min(MULTS, key=lambda m: per[o]["sse"][i][m]) > 1 for o in origins if per[o]["n"][i]), "<1:", sum(min(MULTS, key=lambda m: per[o]["sse"][i][m]) < 1 for o in origins if per[o]["n"][i]))
def schedule(train_origins):
    return [min(MULTS, key=lambda m: np.nanmean([bucket_rmse(o, i, m) for o in train_origins if per[o]["n"][i]])) for i in range(4)]
def total(o, sched):
    return np.sqrt(sum(per[o]["sse"][i][sched[i]] for i in range(4)) / sum(per[o]["n"].values()))
loo = []
for o in origins:
    s = schedule([x for x in origins if x != o]); dlt = total(o, s) - total(o, [1, 1, 1, 1]); loo.append(dlt)
    print("  LOO", o, "schedule", s, f"delta vs K1 {dlt:+.6f}")
print("L8 LOO mean", f"{np.mean(loo):+.6f}", "worse", sum(x > 0 for x in loo), "of", len(loo), "| schedule from all origins:", schedule(origins))
json.dump({o: {k: v for k, v in r.items()} for o, r in per.items()}, open(Path(__file__).parent / "set3_scan.json", "w"), indent=1, default=str)
