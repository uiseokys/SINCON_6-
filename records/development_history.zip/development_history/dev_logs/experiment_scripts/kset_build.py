"""Candidate set K1..K4 (see CANDIDATE_SET_PREREGISTRATION.md). Past data only (<= 2026-06-30)."""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
OUT = B / "CANDIDATE_SET_1113"
KEY = ["date", "station_id", "hour"]
DAYKEY = ["date", "station_id"]
MODEL = "lunar3122"
EXCLUDED = {3107, 3108, 3109, 3127, 3139, 3209, 3754}
FIT = ["station_id", "dow", "hour"]
WINDOW, SHRINK, SCALE, MIN_DAYS = 84, 12, 0.25, 6
BUILD = len(sys.argv) > 1 and sys.argv[1] == "build"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rmsle(y, p):
    return float(np.sqrt(np.mean(np.square(np.asarray(y) - np.asarray(p)))))


def protection():
    fields = ["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]
    cal = pd.read_csv(P / "final_package/payload/work/external_inputs/calendar_features.csv",
                      parse_dates=["date"], usecols=["date", *fields], encoding="utf-8-sig")
    days = cal.loc[cal[fields].ne(0).any(axis=1), "date"]
    ev = pd.read_csv(P / "goal_014/model/events_frozen_v3.csv", parse_dates=["date"])
    return days, pd.MultiIndex.from_frame(ev[DAYKEY])


def quiet(frame, days, events, extra=None):
    q = (~frame.date.isin(days) & ~frame.station_id.isin(EXCLUDED)
         & ~pd.MultiIndex.from_frame(frame[DAYKEY]).isin(events))
    if extra is not None:
        q &= ~pd.MultiIndex.from_frame(frame[DAYKEY]).isin(extra)
    return q


def fit_stats(history):
    history = history.copy()
    history["error"] = history.y_log - history[MODEL]
    g = history.groupby(DAYKEY).error
    history["error"] = (history.error - g.transform("mean")).where(g.transform("size").eq(18))
    stats = history.groupby(FIT).error.agg(["mean", "count"])
    stats["correction"] = (stats["mean"] * SCALE * stats["count"] / (stats["count"] + SHRINK)).where(stats["count"].ge(MIN_DAYS))
    return stats[["correction"]]


def apply_stats(target, stats, is_quiet):
    t = target.join(stats, on=FIT)
    good = is_quiet & t.groupby(DAYKEY).correction.transform("count").eq(18)
    delta = (t.correction - t.groupby(DAYKEY).correction.transform("mean")).where(good, 0.0)
    return delta.to_numpy(), good.to_numpy()


def history_for(rows, origin):
    m = (rows.date.gt(origin - pd.Timedelta(days=WINDOW)) & rows.date.le(origin) & rows.origin.lt(origin) & rows.quiet)
    return rows.loc[m].sort_values("origin").drop_duplicates(KEY, keep="last")


def load_oof(kind):
    rows = pd.read_csv(P / f"night13/measurements/downstream_oof_{kind}_main.csv.gz",
                       usecols=["origin", *KEY, "y_log", MODEL], parse_dates=["origin", "date"])
    rows["dow"] = rows.date.dt.day_of_week
    return rows


days, events = protection()
report = {"constants": {"window_days": WINDOW, "shrink": SHRINK, "scale": SCALE, "min_days": MIN_DAYS}}

# ---------- 1. independent re-check of the K1 validation ----------
train = pd.read_csv(B / "data/train.csv", parse_dates=["date"])
truth = np.log1p(train.set_index(KEY).boardings)
assert train.date.max() == pd.Timestamp("2026-06-30")
for kind in ("old", "nested"):
    rows = load_oof(kind)
    assert rows.date.gt(rows.origin).all() and rows.date.max() <= pd.Timestamp("2026-06-30")
    assert np.allclose(truth.reindex(pd.MultiIndex.from_frame(rows[KEY])).to_numpy(), rows.y_log.to_numpy(), atol=1e-12, rtol=0)
    rows["quiet"] = quiet(rows, days, events)
    out = {}
    for origin, hold in rows.groupby("origin", sort=True):
        hist = history_for(rows, origin)
        if hist.empty:
            continue
        delta, good = apply_stats(hold, fit_stats(hist), hold.quiet)
        if not good.any():
            continue
        base = rmsle(hold.y_log, hold[MODEL]); cand = rmsle(hold.y_log, hold[MODEL] + delta)
        out[str(origin.date())] = {"base": base, "candidate": cand, "delta": cand - base, "changed": int((delta != 0).sum())}
        print(kind, origin.date(), f"{base:.6f} -> {cand:.6f}  d={cand-base:+.6f}  changed={int((delta != 0).sum())}", flush=True)
    report[f"k1_validation_{kind}"] = out
    if kind == "nested":
        nested = rows

# ---------- 2. K4 ratio from past forecasts ----------
m = pd.read_csv(P / "night13/measurements/downstream_oof_old_main.csv.gz", usecols=["label", *KEY, "y_log", "baseline"], parse_dates=["date"])
c = pd.read_csv(P / "conservative/drop/layers_cache/final_stage_oof.csv.gz", usecols=["label", *KEY, "baseline"], parse_dates=["date"]).rename(columns={"baseline": "cons"})
j = m.merge(c, on=["label", *KEY], how="inner", validate="one_to_one")
grid = {}
for w in (0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0):
    grid[w] = {lab: rmsle(g.y_log, (1 - w) * g.baseline + w * g.cons) for lab, g in j.groupby("label")}
labels = sorted(grid[0.0])
print("K4 grid (per label)")
for w, d in grid.items():
    print(f"w={w:.1f} mean={np.mean(list(d.values())):.6f} " + " ".join(f"{lab}:{d[lab]-grid[0.0][lab]:+.5f}" for lab in labels))
means = {w: float(np.mean(list(d.values()))) for w, d in grid.items()}
best = min((0.1, 0.2, 0.3, 0.4, 0.5), key=lambda w: means[w])
k4_ok = means[best] < means[0.0]
report["k4"] = {"grid_mean": {str(k): v for k, v in means.items()}, "per_label": {str(k): v for k, v in grid.items()},
                "best_w": best, "built": bool(k4_ok)}
print("K4 best w", best, "mean", means[best], "main", means[0.0], "build", k4_ok)

if not BUILD:
    sys.exit(0)

# ---------- 3. build ----------
OUT.mkdir(exist_ok=True)
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"])
main = pd.read_csv(B / "FINAL_CANDIDATES/submission_night_v4_main.csv")
assert sha(B / "FINAL_CANDIDATES/submission_night_v4_main.csv").startswith("4c85257294be")
assert len(test) == len(main) == 157194 and (test.example_id.to_numpy() == main.example_id.to_numpy()).all()
test["dow"] = test.date.dt.day_of_week
test["log"] = np.log1p(main.boardings.to_numpy())
assert test.groupby(DAYKEY).hour.size().eq(18).all()

prot = pd.read_csv(P / "final_delivery_v2/cache/protected_event_keys.csv", parse_dates=["date"])
extra = pd.MultiIndex.from_frame(prot[DAYKEY].drop_duplicates())
origin = pd.Timestamp("2026-06-30")
hist = history_for(nested, origin)
assert hist.date.min() > origin - pd.Timedelta(days=WINDOW) and hist.date.max() <= origin
stats = fit_stats(hist)
tq = quiet(test, days, events, extra)
delta, good = apply_stats(test.rename(columns={"log": MODEL}), stats, tq)
assert np.abs(pd.Series(delta).groupby([test.date, test.station_id]).mean()).max() < 1e-12
k1_log = test["log"].to_numpy() + delta
assert (k1_log >= 0).all() and np.array_equal(k1_log[~good], test["log"].to_numpy()[~good])
k1 = main.copy(); k1.loc[good, "boardings"] = np.expm1(k1_log[good])

mon = pd.read_csv(B / "FINAL_CANDIDATES/submission_monday_main.csv")
cup = pd.read_csv(P / "goal_014/release/submission_night_v4_main_cup_walk.csv")
assert sha(B / "FINAL_CANDIDATES/submission_monday_main.csv").startswith("f503ec60") and sha(P / "goal_014/release/submission_night_v4_main_cup_walk.csv").startswith("1ee35f4d")
for f in (mon, cup):
    assert (f.example_id.to_numpy() == main.example_id.to_numpy()).all()
mb = main.boardings.to_numpy()
mon_rows = np.abs(np.log1p(mon.boardings.to_numpy()) - np.log1p(mb)) > 1e-12
cup_rows = np.abs(np.log1p(cup.boardings.to_numpy()) - np.log1p(mb)) > 1e-12
assert not (mon_rows & cup_rows).any()
k2 = main.copy()
k2.loc[mon_rows, "boardings"] = mon.boardings.to_numpy()[mon_rows]
k2.loc[cup_rows, "boardings"] = cup.boardings.to_numpy()[cup_rows]
k2_rows = mon_rows | cup_rows
k3 = k1.copy(); k3.loc[k2_rows, "boardings"] = k2.boardings.to_numpy()[k2_rows]

files = {"submission_k1_hourbias.csv": k1, "submission_k2_holiday_events.csv": k2, "submission_k3_hourbias_holiday_events.csv": k3}
if k4_ok:
    cons = pd.read_csv(B / "FINAL_CANDIDATES/submission_conservative_main.csv")
    assert (cons.example_id.to_numpy() == main.example_id.to_numpy()).all() and sha(B / "FINAL_CANDIDATES/submission_conservative_main.csv").startswith("99fdd9ce0587")
    k4 = main.copy(); k4["boardings"] = np.expm1((1 - best) * np.log1p(mb) + best * np.log1p(cons.boardings.to_numpy()))
    files[f"submission_k4_blend_w{int(best*100):02d}.csv"] = k4

sample = test  # official test.csv ids and order
report["files"] = {}
for name, frame in files.items():
    v = frame.boardings.to_numpy()
    assert list(frame.columns) == ["example_id", "boardings"] and len(frame) == 157194
    assert (frame.example_id.to_numpy() == sample.example_id.to_numpy()).all() and np.isfinite(v).all() and (v >= 0).all()
    path = OUT / name
    frame.to_csv(path, index=False)
    back = pd.read_csv(path)
    d = np.log1p(back.boardings.to_numpy()) - np.log1p(mb)
    info = {"sha256": sha(path), "rows_changed_vs_main": int((np.abs(d) > 1e-12).sum()), "rms_log_diff_vs_main": float(np.sqrt(np.mean(d * d))),
            "max_abs_log_diff_vs_main": float(np.abs(d).max()), "sum_boardings": float(back.boardings.sum()), "main_sum_boardings": float(mb.sum())}
    report["files"][name] = info
    print(name, json.dumps(info))
report["k1_test"] = {"history_rows": int(len(hist)), "history_dates": [str(hist.date.min().date()), str(hist.date.max().date())],
                     "history_origins": sorted(str(o.date()) for o in hist.origin.unique()),
                     "changed_rows": int(good.sum()), "station_days_changed": int(good.sum() // 18), "k2_rows": int(k2_rows.sum()),
                     "k1_rows_overwritten_by_k2": int((good & k2_rows).sum())}
print(json.dumps(report["k1_test"]))
(OUT / "build_report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
