"""H1: same-weekday holiday contrast (level included). Forward validation on nested OOF; build on request."""
import sys, json, hashlib
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
WIN, MINREF, CLIP, SCALE = 42, 3, 0.25, 0.5
cal = pd.read_csv(P / "final_package/payload/work/external_inputs/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"]).set_index("date")
FLAGS = ["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]
regular = set(cal.index[~cal[FLAGS].ne(0).any(axis=1)])
HOL = [d for d in cal.index[(cal.is_holiday == 1) & (cal.is_lunar_season == 0)]]
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
train = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); train["y_log"] = np.log1p(train.boardings)
ACT = train.pivot(index="date", columns=["station_id", "hour"], values="y_log")

def refs_for(day, index, lo=None, hi=None):
    r = [x for x in index if x in regular and x.dayofweek == day.dayofweek and abs((x - day).days) <= WIN and (lo is None or x >= lo) and (hi is None or x <= hi)]
    return r

def donor_contrast(target, cutoff):
    out = []
    for d in HOL:
        if d > cutoff or d.dayofweek != target.dayofweek or d not in ACT.index: continue
        r = refs_for(d, ACT.index, hi=cutoff)
        if len(r) < MINREF: continue
        out.append((d, ACT.loc[d] - ACT.loc[r].median()))
    return out

def effect_for(pred_panel, target, cutoff):
    donors = donor_contrast(target, cutoff)
    if not donors or target not in pred_panel.index: return None, []
    r = refs_for(target, pred_panel.index)
    if len(r) < MINREF: return None, []
    pc = pred_panel.loc[target] - pred_panel.loc[r].median()
    gap = (pd.DataFrame([c for _, c in donors]).median() - pc).clip(-CLIP, CLIP)
    return SCALE * gap, [d for d, _ in donors]

def apply(frame, col, cutoff, targets, extra_protect=None):
    """frame: rows with date, station_id, hour, col. returns delta array aligned to frame."""
    panel = frame.pivot(index="date", columns=["station_id", "hour"], values=col)
    delta = pd.Series(0.0, index=frame.index); info = {}
    keys = pd.MultiIndex.from_frame(frame[["date", "station_id"]])
    ok = ~frame.station_id.isin(hb.EXCLUDED_STATIONS) & ~keys.isin(events) & ~keys.isin(protected)
    if extra_protect is not None: ok &= ~keys.isin(extra_protect)
    for t in targets:
        eff, donors = effect_for(panel, t, cutoff)
        if eff is None: continue
        sel = frame.date.eq(t) & ok
        e = eff.reindex(pd.MultiIndex.from_frame(frame.loc[sel, ["station_id", "hour"]])).fillna(0.0).to_numpy()
        delta.loc[sel] = e; info[str(t.date())] = {"donors": [str(d.date()) for d in donors], "rows": int(sel.sum()), "mean_effect": float(e.mean())}
    return delta.to_numpy(), info

if __name__ == "__main__":
    def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
    rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
    per_origin, per_date = {}, {}
    for origin, hold in rows.groupby("origin", sort=True):
        hold = hold.reset_index(drop=True)
        targets = [d for d in HOL if hold.date.min() <= d <= hold.date.max()]
        delta, info = apply(hold, hb.MODEL, origin, targets)
        y, b = hold.y_log.to_numpy(), hold[hb.MODEL].to_numpy()
        per_origin[str(origin.date())] = (rm(y, b + delta) - rm(y, b), len(info))
        for t, v in info.items():
            m = (hold.date == t).to_numpy() & (delta != 0)
            per_date.setdefault(t, []).append((str(origin.date()), rm(y[m], b[m]), rm(y[m], (b + delta)[m]), v["mean_effect"], v["donors"]))
        print(origin.date(), f"overall delta {per_origin[str(origin.date())][0]:+.6f} | holidays applied {len(info)}", flush=True)
    print("--- by holiday date (changed rows)")
    better = 0
    for t in sorted(per_date):
        rec = per_date[t]; d = np.mean([a - b for _, b, a, _, _ in rec]); better += d < 0
        print(t, cal.loc[t, "holiday_name"], ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][pd.Timestamp(t).dayofweek], "| " + "  ".join(f"{o[5:]}: {b:.4f}->{a:.4f} (eff {e:+.3f})" for o, b, a, e, _ in rec), "| donors", rec[-1][4])
    fired = {o: v for o, v in per_origin.items() if v[1] > 0}
    print("origins fired", len(fired), "mean delta", f"{np.mean([v[0] for v in fired.values()]):+.6f}", "worse", sum(v[0] > 0 for v in fired.values()), "| holiday dates improved", better, "of", len(per_date))
