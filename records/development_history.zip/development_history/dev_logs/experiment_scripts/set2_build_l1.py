import sys, json, hashlib
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
OUT = B / "CANDIDATE_SET_1113"
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); test["dow"] = test.date.dt.day_of_week
main = pd.read_csv(B / "FINAL_CANDIDATES/submission_night_v4_main.csv")
k1 = pd.read_csv(OUT / "submission_k1_hourbias.csv")
best = pd.read_csv(P / "goal_014/release/submission_k3_geomdan_plave_seasonal_refit.csv")
assert hashlib.sha256((P / "goal_014/release/submission_k3_geomdan_plave_seasonal_refit.csv").read_bytes()).hexdigest().startswith("e46feb831db6")
for f in (main, k1, best): assert (f.example_id.values == test.example_id.values).all()
rows = pd.read_csv(P / "hourbias_delivery/cache/hourbias_history_oof.csv.gz", parse_dates=["origin", "date"]); rows["dow"] = rows.date.dt.day_of_week
ev = pd.MultiIndex.from_frame(rows[hb.DAYKEY]).isin(events)
rows["quiet"] = ~rows.date.isin(days) & ~ev                      # L1: no station exclusion
stats = hb.fit_stats(hb.select_history(rows))
frame = test[["example_id", *hb.KEY, "dow"]].copy(); frame[hb.MODEL] = np.log1p(main.boardings.values)
tk = pd.MultiIndex.from_frame(frame[hb.DAYKEY])
q = ~frame.date.isin(days) & ~tk.isin(events) & ~tk.isin(protected)
delta, good = hb.apply_stats(frame, stats, q)
# keep only the 7 stations K1 skipped, and skip station-days already changed by Geomdan / PLAVE / K2 rows
lm, lk, lb = np.log1p(main.boardings.values), np.log1p(k1.boardings.values), np.log1p(best.boardings.values)
gp = pd.read_csv(P / "goal_014/release/submission_k3_geomdan_plave.csv"); lg = np.log1p(gp.boardings.values)
touched_rows = np.abs(lg - lk) > 1e-12                           # K2 rows + Geomdan + PLAVE relative to K1
touched_days = pd.MultiIndex.from_frame(frame.loc[touched_rows, hb.DAYKEY].drop_duplicates())
sel = good & frame.station_id.isin(hb.EXCLUDED_STATIONS).values & ~tk.isin(touched_days) & (np.abs(lk - lm) <= 1e-12)
sel_days = frame.loc[sel].groupby(hb.DAYKEY).hour.size()
assert sel_days.eq(18).all()
assert np.abs(pd.Series(delta[sel]).groupby([frame.date.values[sel], frame.station_id.values[sel]]).mean()).max() < 1e-12
out = best.copy(); out.loc[sel, "boardings"] = np.expm1(lb[sel] + delta[sel])
hb.check_submission(out, test)
path = OUT / "submission_set2_l1_on_refit.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); d = np.log1p(back.boardings.values) - lb
info = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows_changed_vs_refit": int((np.abs(d) > 1e-12).sum()), "station_days": int(len(sel_days)),
        "by_station": frame.loc[sel].groupby("station_id").date.nunique().to_dict(), "max_abs_log_change": float(np.abs(d).max()), "rms_log_diff_vs_refit": float(np.sqrt((d * d).mean()))}
print(json.dumps(info, default=int)); (OUT / "set2_l1_report.json").write_text(json.dumps(info, indent=2, default=int) + "\n")
