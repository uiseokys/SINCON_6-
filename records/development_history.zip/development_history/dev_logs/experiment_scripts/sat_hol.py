import numpy as np, pandas as pd
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"; B = "/Users/jeong-uiseok/sincon-2026/sincon-baseline/"
cal = pd.read_csv(P + "final_package/payload/work/external_inputs/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"])
tr = pd.read_csv(B + "data/train.csv", parse_dates=["date"]); tr["ylog"] = np.log1p(tr.boardings)
special = set(cal.loc[cal[["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]].ne(0).any(axis=1), "date"])
sat_h = cal[(cal.is_holiday == 1) & (cal.date.dt.dayofweek == 5) & (cal.date <= "2026-10-31")]
print("Saturday holidays in calendar:", [(d.strftime("%Y-%m-%d"), n) for d, n in zip(sat_h.date, sat_h.holiday_name)])
def ref_sats(d, k=4):
    out = []; 
    for step in (-7, 7, -14, 14, -21, 21, -28, 28):
        x = d + pd.Timedelta(days=step)
        if x not in special and x <= pd.Timestamp("2026-06-30") and x >= pd.Timestamp("2025-01-01"): out.append(x)
        if len(out) == k: break
    return out
for d in sat_h.date[sat_h.date <= "2026-06-30"]:
    refs = ref_sats(d); a = tr[tr.date.eq(d)].set_index(["station_id", "hour"]).ylog
    r = tr[tr.date.isin(refs)].groupby(["station_id", "hour"]).ylog.mean()
    diff = (a - r).dropna(); sd = diff.groupby("station_id").mean()
    print(d.date(), "refs", [x.strftime("%m-%d") for x in refs], f"| actual − normal Saturday (log): mean {diff.mean():+.4f}, station-day mean: median {sd.median():+.4f}, share of stations below 0: {(sd < 0).mean():.2f}")
    print("   by hour:", " ".join(f"{h}:{v:+.2f}" for h, v in diff.groupby("hour").mean().items()))
# what did past forecasts do on 2026-06-06?
oof = pd.read_csv(P + "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", "date", "station_id", "hour", "y_log", "lunar3122"], parse_dates=["origin", "date"])
o = oof[oof.date.eq("2026-06-06")]
for org, g in o.groupby("origin"):
    e = g.y_log - g.lunar3122; print("forecast of 2026-06-06 from", org.date(), f"rmsle {np.sqrt((e**2).mean()):.4f} mean err {e.mean():+.4f} | by hour:", " ".join(f"{h}:{v:+.2f}" for h, v in e.groupby(g.hour).mean().items()))
# what does the current main predict for the test Saturday holidays vs neighbouring Saturdays
te = pd.read_csv(B + "data/test.csv", parse_dates=["date"]); main = pd.read_csv(B + "FINAL_CANDIDATES/submission_night_v4_main.csv"); te["p"] = np.log1p(main.boardings.values)
for d in ("2026-08-15", "2026-10-03", "2026-09-26"):
    d = pd.Timestamp(d); refs = [d + pd.Timedelta(days=s) for s in (-14, -7, 7, 14)]; refs = [x for x in refs if x not in special and pd.Timestamp("2026-07-01") <= x <= pd.Timestamp("2026-10-31")]
    a = te[te.date.eq(d)].set_index(["station_id", "hour"]).p; r = te[te.date.isin(refs)].groupby(["station_id", "hour"]).p.mean()
    diff = a - r; print("main prediction", d.date(), "vs Saturdays", [x.strftime("%m-%d") for x in refs], f"mean log diff {diff.mean():+.4f} | by hour:", " ".join(f"{h}:{v:+.2f}" for h, v in diff.groupby("hour").mean().items()))
