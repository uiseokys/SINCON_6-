"""행사별: 작년 같은 행사의 실제 초과 승차 vs 올해 예측의 초과 승차. 2026-06-30 이전 실측과 현재 예측만 사용."""
import re, sys, numpy as np, pandas as pd
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"; W = P + "final_package/payload/work/"; B = "/Users/jeong-uiseok/sincon-2026/sincon-baseline/"
meta = pd.read_csv(B + "data/metaData.csv").set_index("station_id").station_name
cal = pd.read_csv(W + "external_inputs/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"])
special = set(cal.loc[cal[["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]].ne(0).any(axis=1), "date"])
tr = pd.read_csv(B + "data/train.csv", parse_dates=["date"]); te = pd.read_csv(B + "data/test.csv", parse_dates=["date"])
best = pd.read_csv(P + "goal_014/graph_clean/submission_l1_hourly_curvature.csv"); te["boardings"] = best.boardings.values
fest = pd.read_csv(W + "sincon_festival_station_days.csv", parse_dates=["date"]); ev = pd.read_csv(W + "external_inputs/external/events_daily.csv", parse_dates=["date"], encoding="utf-8-sig").dropna(subset=["station_id"])
ev["station_id"] = ev.station_id.astype(int); ev["series"] = ev.event_name.map(lambda s: re.sub(r"(20\d\d|\d+회|제|\s|\[.*?\])", "", s)) + "@" + ev.venue
allev = pd.concat([fest[["date", "station_id", "series", "event_name"]], ev[["date", "station_id", "series", "event_name"]]], ignore_index=True)
event_days = set(map(tuple, allev[["date", "station_id"]].drop_duplicates().itertuples(index=False, name=None)))
def excess(frame, station, day):
    """그날 시간대별 승차 − 앞뒤 5주 같은 요일 평소 날(행사·공휴일 아닌 날)의 중앙값."""
    f = frame[frame.station_id.eq(station)]
    refs = [day + pd.Timedelta(days=7 * k) for k in (-5, -4, -3, -2, -1, 1, 2, 3, 4, 5)]
    refs = [r for r in refs if r not in special and (r, station) not in event_days and r in set(f.date)]
    if len(refs) < 3 or day not in set(f.date): return None
    a = f[f.date.eq(day)].set_index("hour").boardings; b = f[f.date.isin(refs)].groupby("hour").boardings.median()
    return (a - b), b
out = []
for series, g in allev.groupby("series"):
    d25 = g[(g.date >= "2025-01-01") & (g.date <= "2026-06-30")]; d26 = g[(g.date >= "2026-07-01") & (g.date <= "2026-10-31")]
    if d25.empty or d26.empty: continue
    for st in sorted(set(d25.station_id) & set(d26.station_id)):
        e25 = [excess(tr, st, d) for d in sorted(d25[d25.station_id.eq(st)].date.unique())]; e26 = [excess(te, st, d) for d in sorted(d26[d26.station_id.eq(st)].date.unique())]
        e25 = [e for e in e25 if e is not None]; e26 = [e for e in e26 if e is not None]
        if not e25 or not e26: continue
        a = np.mean([x[0].clip(lower=0).sum() for x in e25]); p = np.mean([x[0].clip(lower=0).sum() for x in e26]); base = np.mean([x[1].sum() for x in e26])
        peak25 = pd.concat([x[0] for x in e25], axis=1).mean(axis=1); peak26 = pd.concat([x[0] for x in e26], axis=1).mean(axis=1)
        out.append(dict(event=g.event_name.iloc[-1][:22], station=meta.get(st, st), days25=len(e25), days26=len(e26), last_year_excess_per_day=round(a), predicted_excess_per_day=round(p), ratio=round(p / a, 2) if a > 50 else np.nan,
                        ordinary_day_total=round(base), peak_hours_25=",".join(str(h) for h in peak25.sort_values(ascending=False).index[:3]), peak25=round(peak25.max()), peak26=round(peak26.max())))
r = pd.DataFrame(out).sort_values("last_year_excess_per_day", ascending=False)
pd.set_option("display.width", 250); print(r.to_string(index=False))
r.to_csv(sys.argv[1], index=False)
