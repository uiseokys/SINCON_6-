import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, shape_lib as sl
import rail_shift as rs
A, days = rs.A, rs.days; rm = rs.rm; B = rs.B; CLIP = 0.1
S, dupinfo = sl.other_shapes("rail_hourly_allowed.csv.gz"); print("other-line monthly shapes", S.shape, S.index.min(), "~", S.index.max(), dupinfo)
train = pd.read_csv(B / "data/train.csv", parse_dates=["date"])
P = rs.P; d_, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
rows = A.copy(); rows["dow"] = rows.date.dt.day_of_week; rows["quiet"] = hb.quiet_rows(rows, d_, events)
res = {}
for origin, hold in rows.groupby("origin", sort=True):
    hold = hold.reset_index(drop=True); hist = hb.select_history(rows, origin)
    d1 = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)[0] if not hist.empty else np.zeros(len(hold))
    p = hold[hb.MODEL].to_numpy() + d1; y = hold.y_log.to_numpy(); free = hold.free.to_numpy(); r0 = rm(p, y)
    c = sl.shape_term(hold, p, train[train.date <= origin], S, origin); ok = free & np.isfinite(c); c = np.where(ok, c, 0.0)
    c = c - pd.Series(c).groupby([hold.date.to_numpy(), hold.station_id.to_numpy()]).transform("mean").to_numpy()      # keep the station-day mean
    r = {f"w{w}": rm(p + np.clip(w * c, -CLIP, CLIP), y) - r0 for w in (0.1, 0.2, 0.3, 0.5)}
    r["rows"] = int(ok.sum()); r["corr"] = float(np.corrcoef((y - p)[ok], c[ok])[0, 1]) if ok.any() else np.nan
    hol = hold.date.isin(d_).to_numpy(); q = p + np.clip(0.2 * c, -CLIP, CLIP); r["ordinary w0.2"] = rm(q[~hol], y[~hol]) - rm(p[~hol], y[~hol])
    res[str(origin.date())] = r
T = pd.DataFrame(res).T; show = T[["w0.1", "w0.2", "w0.3", "w0.5", "ordinary w0.2"]] * 1e4; pd.set_option("display.width", 200)
print(show.round(2).assign(rows=T.rows.astype(int), corr=T["corr"].round(3)).to_string()); print("mean", show.mean().round(2).to_dict()); print("worse", (show > 0).sum().to_dict())
json.dump(res, open("shape_val.json", "w"), indent=1)
