import sys, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, rail_layer as rl
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline"); W = P / "final_package/payload/work"
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
fest = pd.read_csv(W / "sincon_festival_station_days.csv", parse_dates=["date"]); ev = pd.read_csv(W / "external_inputs/external/events_daily.csv", parse_dates=["date"], encoding="utf-8-sig").dropna(subset=["station_id"])
extra = pd.MultiIndex.from_frame(pd.concat([fest[["date", "station_id"]], ev[["date", "station_id"]].astype({"station_id": int})]).drop_duplicates())
blocked = events.union(protected).union(extra)
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); train = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); rail = pd.read_csv("rail_allowed.csv.gz", parse_dates=["date"])
src = B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv"; assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("596876180bb0"); best = pd.read_csv(src)
assert (best.example_id.values == test.example_id.values).all()
new, info = rl.apply(test, best.boardings.values, train, rail, days, blocked)
out = best.copy(); out["boardings"] = new; hb.check_submission(out, test)
path = B / "CANDIDATE_SET_1113/submission_rail_shift_on_xgb7.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); d = np.log1p(back.boardings.values) - np.log1p(best.boardings.values)
info.update(sha256=hashlib.sha256(path.read_bytes()).hexdigest(), rms_log_diff_vs_base=float(np.sqrt((d ** 2).mean())))
hol = test.date.isin(days).to_numpy(); t = test.assign(d=d)
print(json.dumps(info, ensure_ascii=False, indent=1))
print("largest daily mean changes:", t.groupby("date").d.mean().sort_values().head(6).round(4).to_dict(), t.groupby("date").d.mean().sort_values().tail(4).round(4).to_dict())
json.dump(info, open(B / "CANDIDATE_SET_1113/rail_shift_report.json", "w"), indent=2, ensure_ascii=False)
