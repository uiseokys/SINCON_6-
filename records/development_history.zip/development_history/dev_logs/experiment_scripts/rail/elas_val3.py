import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, RB, LV, days = rs.A, rs.RB, rs.LV, rs.days; rm = rs.rm; CLIP = 0.15; B = rs.B
special = set(days); RBm = RB.mean(axis=1)                         # other lines: mean log boardings of the 25 stations, by date
def roll_anom(frame): return frame - pd.concat([frame.shift(7 * k) for k in range(1, 9)], keys=range(8)).groupby(level=1).median()
AO = roll_anom(RBm.to_frame("o")).o; AL = roll_anom(LV)            # rolling anomalies (same weekday, previous 8 weeks)
tr = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); tr["y_log"] = np.log1p(tr.boardings)
LH = tr.pivot(index="date", columns=["station_id", "hour"], values="y_log"); AH = roll_anom(LH)
def elast(X, o, lo=0.0, hi=2.0):
    """X: date x columns anomalies of ours. returns (e_ordinary, e_holiday) per column using dates <= o."""
    d = X.index[(X.index <= o)]; a = AO.reindex(d); ok = a.notna().to_numpy(); hol = np.array([t in special for t in d])
    out = []
    for m in (ok & ~hol, ok & hol):
        x = a.to_numpy()[m]; Y = X.loc[d[m]]; num = Y.mul(x, axis=0).sum(skipna=True); den = (Y.notna().mul(x ** 2, axis=0)).sum(); out.append((num / den.replace(0, np.nan)))
    eo, eh = out; pooled = float(np.nanmedian(eh)); eh = 0.5 * eh.fillna(pooled) + 0.5 * pooled
    return eo.clip(lo, hi).fillna(1.0), eh.clip(lo, hi)

import pickle
D = pickle.load(open("../nnexp/data.pkl", "rb")); df = D["df"]
WO, WH = 0.2, 0.3; res = {}
for line in open("../nnexp/out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); m = A[A.origin.eq(origin)].reset_index(drop=True)
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); free = m.free.to_numpy(); hol = m.date.isin(days).to_numpy()
    lun = (m.station_id.eq(3122) & m.date.isin(pd.to_datetime(["2025-10-05", "2025-10-06", "2026-02-16", "2026-02-17"]))).to_numpy(); free = free & ~lun
    dts = pd.DatetimeIndex(sorted(m.date.unique())); ob = rs.dow_base(RB, origin); abar = (RB.reindex(dts) - ob.reindex(dts.dayofweek).to_numpy()).mean(axis=1).reindex(m.date.to_numpy()).to_numpy()
    sb = rs.dow_base(LV, origin).stack().rename("b").reset_index(); sb.columns = ["dow", "station_id", "b"]
    lvl = m.groupby(["date", "station_id"])[hb.MODEL].transform("mean").to_numpy(); b = m[["date", "station_id"]].assign(dow=m.date.dt.dayofweek).merge(sb, on=["dow", "station_id"], how="left").b.to_numpy(); ahat = lvl - b
    c0 = np.where(free & np.isfinite(abar - ahat), abar - ahat, 0.0); v0 = p + np.clip(np.where(hol, 0.2, 0.1) * c0, -CLIP, CLIP)
    eo, eh = elast(AL, origin); e = np.where(hol, m.station_id.map(eh).to_numpy(), m.station_id.map(eo).to_numpy()); c1 = e * abar - ahat; c1 = np.where(free & np.isfinite(c1), c1, 0.0)
    s1 = p + np.clip(np.where(hol, WH, WO) * c1, -CLIP, CLIP)
    q = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); q["date"] = pd.to_datetime(q["date"]); q["dn"] = np.load(f"../nnexp/out4/xgbnb_{end}.npy") - np.load(f"../nnexp/out4/xgb_{end}.npy")
    dn = np.where(free, m.merge(q, on=hb.KEY, how="left").dn.to_numpy(), 0.0); lv = pd.Series(dn).groupby([m.date.to_numpy(), m.station_id.to_numpy()]).transform("mean").to_numpy()
    cur = np.where(hol, v0 + np.clip(0.5 * lv, -CLIP, CLIP), v0); r0 = rm(p, y); rc = rm(cur, y)
    r = {"current vs main": rc - r0}
    for wo in (0.1, 0.15, 0.2):
        r[f"ordinary e_s w{wo}, holidays as now"] = rm(np.where(hol, cur, p + np.clip(wo * c1, -CLIP, CLIP)), y) - rc
    r["ordinary e_s w0.15 + holiday (e_s, 0.2) + level 0.5"] = rm(np.where(hol, p + np.clip(0.2 * c1, -CLIP, CLIP) + np.clip(0.5 * lv, -CLIP, CLIP), p + np.clip(0.15 * c1, -CLIP, CLIP)), y) - rc
    res[end] = r
T = pd.DataFrame(res).T * 1e4; pd.set_option("display.width", 250); print(T.round(2).to_string()); print("mean", T.mean().round(2).to_dict()); print("worse than current", (T.iloc[:, 1:] > 1e-9).sum().to_dict())
json.dump(res, open("elas_val3.json", "w"), indent=1)
