import sys, json, pickle, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, days = rs.A, rs.days; rm = rs.rm; CLIP = 0.15; res = {}
def split(m, c, hol, free):
    """station-day c -> centred 15-day rolling mean over ordinary free days (trend) and the remainder (shock)."""
    sd = pd.DataFrame({"date": m.date.to_numpy(), "station_id": m.station_id.to_numpy(), "c": c, "ok": free & ~hol}).drop_duplicates(["date", "station_id"])
    w = sd[sd.ok].pivot(index="date", columns="station_id", values="c").sort_index(); w = w.reindex(pd.date_range(w.index.min(), w.index.max()))
    tr = w.rolling(15, center=True, min_periods=5).mean().stack().rename("t").reset_index(); tr.columns = ["date", "station_id", "t"]
    t = m[["date", "station_id"]].merge(tr, on=["date", "station_id"], how="left").t.to_numpy(); t = np.where(np.isfinite(t), t, 0.0)
    return t, c - t
for origin, hold in A.groupby("origin", sort=True):
    m = hold.reset_index(drop=True); y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); free = m.free.to_numpy(); hol = m.date.isin(days).to_numpy()
    c = rs.shift_terms(m, origin)["all25"]; c = np.where(free & np.isfinite(c), c, 0.0); cur = p + np.clip(np.where(hol, 0.2, 0.1) * c, -CLIP, CLIP); rc = rm(cur, y)
    t, s = split(m, c, hol, free); r = {}
    for wt in (0.1, 0.2, 0.3):
        for ws in (0.05, 0.1, 0.2):
            add = np.where(hol, 0.2 * c, np.where(free, wt * t + ws * s, 0.0)); r[f"t{wt}_s{ws}"] = rm(p + np.clip(add, -CLIP, CLIP), y) - rc
    r["sd trend"] = float(np.std(t[free & ~hol])); r["sd shock"] = float(np.std(s[free & ~hol])); res[str(origin.date())] = r
T = pd.DataFrame(res).T; cols = [c_ for c_ in T.columns if c_.startswith("t")]; pd.set_option("display.width", 220)
print((T[cols] * 1e4).round(2).to_string()); print("mean", (T[cols].mean() * 1e4).round(2).to_dict()); print("worse than current", (T[cols] > 1e-9).sum().to_dict()); print("sd trend/shock", T[["sd trend", "sd shock"]].round(3).mean().to_dict())
json.dump(res, open("trend_val.json", "w"), indent=1)
