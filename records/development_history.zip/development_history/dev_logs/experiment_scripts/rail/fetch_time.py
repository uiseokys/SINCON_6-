import os, pandas as pd
ALLOW = {"경인선": ["백운", "동암", "간석", "부개", "송내", "중동", "부천", "소사", "역곡", "도화", "제물포", "도원", "동인천", "인천"],
         "수인선": ["인천", "신포", "숭의", "인하대", "송도", "연수", "남동인더스파크", "호구포", "인천논현", "소래포구", "월곶"]}
for enc in ("cp949", "utf-8-sig"):
    try: d = pd.read_csv("raw_time.csv", encoding=enc, dtype={0: str}); break
    except UnicodeDecodeError: continue
d = d.rename(columns={d.columns[0]: "month", d.columns[1]: "line", d.columns[2]: "station"})
ok = pd.Series(False, index=d.index)
for ln, sts in ALLOW.items(): ok |= d.line.eq(ln) & d.station.isin(sts)
print("all rows", len(d), "months", d.month.min(), "~", d.month.max(), "| line names with 수인/경인:", sorted(x for x in d.line.unique() if "수인" in x or "경인" in x))
d = d[ok & d.month.between("202501", "202610")].copy()               # everything else is dropped here
cols = {f"{h:02d}시-{h+1:02d}시 승차인원": f"b{h}" for h in range(6, 24)}
miss = [c for c in cols if c not in d.columns]; assert not miss, (miss, list(d.columns)[:12])
out = d[["month", "line", "station", *cols]].rename(columns=cols); out.to_csv("rail_hourly_allowed.csv.gz", index=False); os.remove("raw_time.csv")
print("kept rows", len(out), "months", out.month.nunique(), "stations", out.groupby(["line", "station"]).ngroups, "| per month station count:", out.groupby("month").size().unique().tolist(), "| dups", int(out.duplicated(["month", "line", "station"]).sum()))
