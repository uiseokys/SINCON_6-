import sys, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, hol_layer as hl
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
days, events, protected = hb.read_protection(P / "rail_delivery/cache"); team = pd.read_csv(P / "rail_delivery/cache/team_event_station_days.csv", parse_dates=["date"])
blocked = events.union(protected).union(pd.MultiIndex.from_frame(team[["date", "station_id"]]))
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); src = B / "CANDIDATE_SET_1113/submission_rail_shift_on_xgb7.csv"; assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("e8313425bff3")
base = pd.read_csv(src); assert (base.example_id.values == test.example_id.values).all()
new, info = hl.apply(test, base.boardings.values, np.load("../nnexp/out3/xgbnb_test.npy"), np.load("../nnexp/out3/xgb_test.npy"), days, blocked)
out = base.copy(); out["boardings"] = new; hb.check_submission(out, test); path = B / "CANDIDATE_SET_1113/submission_rail_shift_hol_on_xgb7.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); d = np.log1p(back.boardings.values) - np.log1p(base.boardings.values); info.update(sha256=hashlib.sha256(path.read_bytes()).hexdigest(), rms_log_diff_vs_base=float(np.sqrt((d ** 2).mean())))
print(json.dumps(info, ensure_ascii=False)); json.dump(info, open(B / "CANDIDATE_SET_1113/rail_hol_report.json", "w"), indent=2, ensure_ascii=False)
