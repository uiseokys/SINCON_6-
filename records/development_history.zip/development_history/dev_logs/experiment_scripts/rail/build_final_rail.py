import sys, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, rail_layer as rl, hol_layer as hl
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
meta = pd.read_csv(B / "data/metaData.csv"); sid = meta.set_index("station_name").station_id
days, events, protected = hb.read_protection(P / "rail_delivery/cache"); team = pd.read_csv(P / "rail_delivery/cache/team_event_station_days.csv", parse_dates=["date"])
SPECIAL = [("2026-09-24", 3122), ("2026-09-25", 3122), ("2026-07-11", int(sid["송도달빛축제공원"])), ("2026-07-29", int(sid["부천종합운동장"])), ("2026-10-17", int(sid["인천대공원"]))]
print("extra protected station-days:", SPECIAL)
special = pd.MultiIndex.from_tuples([(pd.Timestamp(d), s) for d, s in SPECIAL])
blocked = events.union(protected).union(pd.MultiIndex.from_frame(team[["date", "station_id"]])).union(special)
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); train = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); rail = pd.read_csv("rail_allowed.csv.gz", parse_dates=["date"])
src = B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv"; assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("596876180bb0"); base = pd.read_csv(src)
s1, i1 = rl.apply(test, base.boardings.values, train, rail, days, blocked)
s2, i2 = hl.apply(test, s1, np.load("../nnexp/out3/xgbnb_test.npy"), np.load("../nnexp/out3/xgb_test.npy"), days, blocked)
out = base.copy(); out["boardings"] = s2; hb.check_submission(out, test); path = B / "CANDIDATE_SET_1113/submission_rail_final_on_xgb7.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); lb = np.log1p(base.boardings.values); d = np.log1p(back.boardings.values) - lb
k = pd.MultiIndex.from_frame(test[["date", "station_id"]]); assert np.abs(d[k.isin(blocked)]).max() == 0.0
old = pd.read_csv(B / "CANDIDATE_SET_1113/submission_rail_shift_on_xgb7.csv"); dv = np.log1p(back.boardings.values) - np.log1p(old.boardings.values)
m = (test.station_id == 3122) & test.date.isin(pd.to_datetime(["2026-09-24", "2026-09-25"]))
info = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows_changed_vs_xgb7": int((np.abs(d) > 1e-12).sum()), "rms_vs_xgb7": float(np.sqrt((d ** 2).mean())), "rows_changed_vs_submitted_rail_shift": int((np.abs(dv) > 1e-12).sum()),
        "rms_vs_submitted_rail_shift": float(np.sqrt((dv ** 2).mean())), "bupyeong_samgeori_0924_25_total": float(back.boardings[m].sum()), "shift": {k_: i1[k_] for k_ in ("changed_rows", "blocked_rows")}, "holiday": i2, "special": SPECIAL}
print(json.dumps(info, ensure_ascii=False)); json.dump(info, open(B / "CANDIDATE_SET_1113/rail_final_report.json", "w"), indent=2, ensure_ascii=False)
