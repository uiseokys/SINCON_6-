"""타 노선(경인선·수인선) 변화 옮기기 층. 값은 RAIL_PREREGISTRATION.md 에 고정한 것."""
import numpy as np, pandas as pd
ORIGIN = pd.Timestamp("2026-06-30"); W_ORDINARY, W_HOLIDAY, CLIP, WEEKS = 0.1, 0.2, 0.15, 8
ALLOW = {"경인선": ["백운", "동암", "간석", "부개", "송내", "중동", "부천", "소사", "역곡", "도화", "제물포", "도원", "동인천", "인천"],
         "수인선": ["인천", "신포", "숭의", "인하대", "송도", "연수", "남동인더스파크", "호구포", "인천논현", "소래포구", "월곶"]}
FLAGS = ["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]

def dow_base(frame, origin=ORIGIN):
    w = frame.loc[origin - pd.Timedelta(days=7 * WEEKS - 1):origin]
    return w.groupby(w.index.dayofweek).median()

def other_line_change(rail, dates, origin=ORIGIN):
    """날짜별: 허용 25개 역의 log(1+승차)가 기준일 직전 8주 같은 요일 중앙값에서 얼마나 변했는지의 평균."""
    ok = pd.Series(False, index=rail.index)
    for line, sts in ALLOW.items(): ok |= rail["line"].eq(line) & rail["station"].isin(sts)
    assert ok.all(), "허용 목록 밖의 행이 들어 있다"
    rb = np.log1p(rail.pivot(index="date", columns=["line", "station"], values="board")).sort_index()
    assert rb.shape[1] == 25 and not rb.loc[origin - pd.Timedelta(days=55):].isna().any().any()
    dts = pd.DatetimeIndex(dates); a = rb.reindex(dts) - dow_base(rb, origin).reindex(dts.dayofweek).to_numpy()
    return a.mean(axis=1)

def apply(test, pred, train, rail, special_days, blocked_station_days, origin=ORIGIN):
    """test: example_id,date,station_id,hour. pred: boardings (same order). 반환: 새 boardings, 정보."""
    assert train["date"].max() <= origin
    lv = np.log1p(train.set_index(["date", "station_id", "hour"])["boardings"]).groupby(level=[0, 1]).mean().unstack()
    base = dow_base(lv, origin).stack().rename("b").reset_index(); base.columns = ["dow", "station_id", "b"]
    lp = np.log1p(np.asarray(pred, float)); f = test[["date", "station_id"]].copy(); f["dow"] = f["date"].dt.dayofweek
    lvl = pd.Series(lp).groupby([f["date"].to_numpy(), f["station_id"].to_numpy()]).transform("mean").to_numpy()
    b = f.merge(base, on=["dow", "station_id"], how="left")["b"].to_numpy()
    abar = other_line_change(rail, sorted(f["date"].unique()), origin).reindex(f["date"].to_numpy()).to_numpy()
    c = abar - (lvl - b)
    hol = f["date"].isin(special_days).to_numpy()
    free = ~pd.MultiIndex.from_frame(f[["date", "station_id"]]).isin(blocked_station_days) & np.isfinite(c)
    add = np.where(free, np.clip(np.where(hol, W_HOLIDAY, W_ORDINARY) * np.nan_to_num(c), -CLIP, CLIP), 0.0)
    out = np.asarray(pred, float).copy(); ch = add != 0; out[ch] = np.expm1(np.maximum(lp[ch] + add[ch], 0.0))
    info = {"changed_rows": int(ch.sum()), "blocked_rows": int((~free).sum()), "max_abs_log_change": float(np.abs(add).max()), "mean_log_change": float(add.mean()),
            "by_month_mean_change": {int(m): round(float(v), 5) for m, v in pd.Series(add).groupby(f["date"].dt.month.to_numpy()).mean().items()},
            "by_month_other_line_change": {int(m): round(float(v), 4) for m, v in pd.Series(abar).groupby(f["date"].dt.month.to_numpy()).mean().items()},
            "by_month_our_forecast_change": {int(m): round(float(v), 4) for m, v in pd.Series(lvl - b).groupby(f["date"].dt.month.to_numpy()).mean().items()}}
    return out, info
