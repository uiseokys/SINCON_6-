import sys, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, rail_lib as rl
from pathlib import Path
A = pd.read_pickle("../nnexp/out4/all9.pkl"); Z = rl.signals("rail_allowed.csv.gz")
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
k = pd.MultiIndex.from_frame(A[hb.DAYKEY]); A["free"] = ~k.isin(events)
print("How much of the main candidate's station-day error could these signals explain at best (coefficients fitted on the evaluation period itself = upper bound)")
for origin, hold in A.groupby("origin", sort=True):
    h = hold[hold.free]; sd = h.groupby(["date", "station_id"], as_index=False).r.mean()
    m = rl.fit(sd, Z, "both", a1=1e-6, a2=1e9)          # global least squares on the evaluation period, no per-station part
    c = np.where(hold.free, rl.predict(m, hold, Z, False), 0.0); y = hold.y_log.to_numpy(); p = hold[hb.MODEL].to_numpy()
    lv = sd.merge(Z, left_on="date", right_index=True); day = lv.groupby("date").r.mean()            # network-wide daily mean error
    zc = Z.reindex(day.index); cor = {c_: round(float(np.corrcoef(day, zc[c_])[0, 1]), 2) for c_ in ("G1_board", "G2_board", "G4_board")}
    hol = hold.date.isin(days).to_numpy()
    print(origin.date(), f"main {rm(p, y):.5f} | oracle global fit: {(rm(p + c, y) - rm(p, y))*1e4:+.2f}e-4 | station-day error sd {sd.r.std():.4f}, network-day mean error sd {day.std():.4f} | corr(network-day error, signal) {cor} | main's error on holiday rows {rm(p[hol], y[hol]):.4f}")
