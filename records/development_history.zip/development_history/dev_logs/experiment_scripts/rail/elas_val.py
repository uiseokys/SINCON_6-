import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, RB, LV, days = rs.A, rs.RB, rs.LV, rs.days; rm = rs.rm; CLIP = 0.15; B = rs.B
special = set(days); RBm = RB.mean(axis=1)                         # other lines: mean log boardings of the 25 stations, by date
def roll_anom(frame): return frame - pd.concat([frame.shift(7 * k) for k in range(1, 9)], keys=range(8)).groupby(level=1).median()
AO = roll_anom(RBm.to_frame("o")).o; AL = roll_anom(LV)            # rolling anomalies (same weekday, previous 8 weeks)
tr = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); tr["y_log"] = np.log1p(tr.boardings)
LH = tr.pivot(index="date", columns=["station_id", "hour"], values="y_log"); AH = roll_anom(LH)
def elast(X, o, lo=0.0, hi=2.0):
    """X: date x columns anomalies of ours. returns (e_ordinary, e_holiday) per column using dates <= o."""
    d = X.index[(X.index <= o)]; a = AO.reindex(d); ok = a.notna().to_numpy(); hol = np.array([t in special for t in d])
    out = []
    for m in (ok & ~hol, ok & hol):
        x = a.to_numpy()[m]; Y = X.loc[d[m]]; num = Y.mul(x, axis=0).sum(skipna=True); den = (Y.notna().mul(x ** 2, axis=0)).sum(); out.append((num / den.replace(0, np.nan)))
    eo, eh = out; pooled = float(np.nanmedian(eh)); eh = 0.5 * eh.fillna(pooled) + 0.5 * pooled
    return eo.clip(lo, hi).fillna(1.0), eh.clip(lo, hi)
res = {}
for origin, hold in A.groupby("origin", sort=True):
    m = hold.reset_index(drop=True); y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); free = m.free.to_numpy(); hol = m.date.isin(days).to_numpy()
    dts = pd.DatetimeIndex(sorted(m.date.unique())); ob = rs.dow_base(RB, origin); abar = (RB.reindex(dts) - ob.reindex(dts.dayofweek).to_numpy()).mean(axis=1).reindex(m.date.to_numpy()).to_numpy()
    sb = rs.dow_base(LV, origin).stack().rename("b").reset_index(); sb.columns = ["dow", "station_id", "b"]
    lvl = m.groupby(["date", "station_id"])[hb.MODEL].transform("mean").to_numpy(); b = m[["date", "station_id"]].assign(dow=m.date.dt.dayofweek).merge(sb, on=["dow", "station_id"], how="left").b.to_numpy(); ahat = lvl - b
    c0 = np.where(free & np.isfinite(abar - ahat), abar - ahat, 0.0); cur = p + np.clip(np.where(hol, 0.2, 0.1) * c0, -CLIP, CLIP); rc = rm(cur, y)
    eo, eh = elast(AL, origin); e = np.where(hol, m.station_id.map(eh).to_numpy(), m.station_id.map(eo).to_numpy())
    c1 = e * abar - ahat; c1 = np.where(free & np.isfinite(c1), c1, 0.0); r = {"cur vs main": rc - rm(p, y)}
    for wo in (0.1, 0.15, 0.2):
        for wh in (0.2, 0.3, 0.5): r[f"S o{wo} h{wh}"] = rm(p + np.clip(np.where(hol, wh, wo) * c1, -CLIP, CLIP), y) - rc
    # hourly version
    hb_ = rs.dow_base(LH, origin).stack(level=[0, 1]).rename("b").reset_index(); hb_.columns = ["dow", "station_id", "hour", "b"]
    bh = m[["date", "station_id", "hour"]].assign(dow=m.date.dt.dayofweek).merge(hb_, on=["dow", "station_id", "hour"], how="left").b.to_numpy()
    eoh, ehh = elast(AH, origin); key = pd.MultiIndex.from_frame(m[["station_id", "hour"]]); eh_ = np.where(hol, ehh.reindex(key).to_numpy(), eoh.reindex(key).to_numpy())
    ch = eh_ * abar - (p - bh); ch = np.where(free & np.isfinite(ch), ch, 0.0)
    r["H o0.1 h0.2"] = rm(p + np.clip(np.where(hol, 0.2, 0.1) * ch, -CLIP, CLIP), y) - rc; r["H o0.05 h0.2"] = rm(p + np.clip(np.where(hol, 0.2, 0.05) * ch, -CLIP, CLIP), y) - rc
    r["H holidays only (h0.2) + cur ordinary"] = rm(np.where(hol, p + np.clip(0.2 * ch, -CLIP, CLIP), cur), y) - rc
    r["e_ord median"] = float(eo.median()); r["e_hol median"] = float(eh.median()); res[str(origin.date())] = r
T = pd.DataFrame(res).T; cols = [c for c in T.columns if c[0] in "SH"]; pd.set_option("display.width", 320); pd.set_option("display.max_columns", 30)
print((T[cols] * 1e4).round(2).to_string()); print("mean", (T[cols].mean() * 1e4).round(2).to_dict()); print("worse than current", (T[cols] > 1e-9).sum().to_dict()); print(T[["e_ord median", "e_hol median"]].round(2).T.to_string())
json.dump(res, open("elas_val.json", "w"), indent=1)
