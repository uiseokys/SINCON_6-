import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, rail_lib as rl
A = pd.read_pickle("../nnexp/out4/all9.pkl"); Z = rl.signals("rail_allowed.csv.gz"); print("signals", Z.shape, Z.index.min().date(), "~", Z.index.max().date())
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); W = P / "final_package/payload/work"
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
fest = pd.read_csv(W / "sincon_festival_station_days.csv", parse_dates=["date"]); ev = pd.read_csv(W / "external_inputs/external/events_daily.csv", parse_dates=["date"], encoding="utf-8-sig").dropna(subset=["station_id"])
extra = pd.MultiIndex.from_frame(pd.concat([fest[["date", "station_id"]], ev[["date", "station_id"]].astype({"station_id": int})]).drop_duplicates())
k = pd.MultiIndex.from_frame(A[hb.DAYKEY]); A["free"] = ~k.isin(events) & ~k.isin(extra)          # holidays stay in; event station-days are out
rm = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2))); CLIP = 0.15
R = A[A.free].groupby(["origin", "date", "station_id"], as_index=False).r.mean()
res = {}; rows = []
for origin, hold in A.groupby("origin", sort=True):
    prior = R[(R.origin < origin) & (R.date <= origin)].sort_values("origin").drop_duplicates(["date", "station_id"], keep="last")
    if prior.date.nunique() < 20: continue
    y = hold.y_log.to_numpy(); p = hold[hb.MODEL].to_numpy(); free = hold.free.to_numpy(); r0 = rm(p, y); late = (hold.hour >= 21).to_numpy(); r = {"base": r0, "prior_days": int(prior.date.nunique())}
    for which in ("both", "gyeongin", "suin"):
        m = rl.fit(prior, Z, which)
        for tag, ps in (("M1", False), ("M2", True)):
            c = np.where(free, np.clip(rl.predict(m, hold, Z, ps), -CLIP, CLIP), 0.0); q = p + c
            r[f"{which}_{tag}"] = rm(q, y) - r0
            if which == "both":
                r[f"late_{tag}"] = rm(q[late], y[late]) - rm(p[late], y[late])
                hol = hold.date.isin(days).to_numpy(); r[f"holiday_days_{tag}"] = rm(q[hol], y[hol]) - rm(p[hol], y[hol]); r[f"ordinary_days_{tag}"] = rm(q[~hol], y[~hol]) - rm(p[~hol], y[~hol])
                mon = hold.date.dt.strftime("%Y-%m"); r[f"month_{tag}"] = {mm: round((rm(q[(mon == mm).to_numpy()], y[(mon == mm).to_numpy()]) - rm(p[(mon == mm).to_numpy()], y[(mon == mm).to_numpy()])) * 1e4, 2) for mm in sorted(mon.unique())}
    res[str(origin.date())] = r
    print(origin.date(), f"base {r0:.5f} prior days {r['prior_days']:>3} |", " ".join(f"{k_}:{r[k_]*1e4:+.2f}" for k_ in ("both_M1", "both_M2", "gyeongin_M1", "gyeongin_M2", "suin_M1", "suin_M2")), f"| late M2 {r['late_M2']*1e4:+.2f} holiday M2 {r['holiday_days_M2']*1e4:+.2f} ordinary M2 {r['ordinary_days_M2']*1e4:+.2f}", flush=True)
    print("    by month (M2, both):", r["month_M2"])
T = pd.DataFrame({o: {k_: v for k_, v in r.items() if isinstance(v, float) and k_ != "base"} for o, r in res.items()}).T * 1e4
print("mean (x1e-4):", T.mean().round(2).to_dict()); print("worse:", (T > 0).sum().to_dict())
json.dump(res, open("rail_val.json", "w"), indent=1, ensure_ascii=False)
