import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, RB, days = rs.A, rs.RB, rs.days; rm = rs.rm; CLIP = 0.15
rs.SETS = {"all25": list(RB.columns), "all23": [c for c in RB.columns if c[1] not in ("동암", "제물포")]}
res = {}; win = {}
for origin, hold in A.groupby("origin", sort=True):
    hold = hold.reset_index(drop=True); terms = rs.shift_terms(hold, origin); y = hold.y_log.to_numpy(); p = hold[hb.MODEL].to_numpy(); free = hold.free.to_numpy(); hol = hold.date.isin(days).to_numpy(); r0 = rm(p, y); r = {}
    c = np.where(free & np.isfinite(terms["all25"]), terms["all25"], 0.0); c23 = np.where(free & np.isfinite(terms["all23"]), terms["all23"], 0.0)
    for w in (0.05, 0.1, 0.15): r[f"ord w{w}"] = rm(np.where(~hol, p + np.clip(w * c, -CLIP, CLIP), p), y) - r0
    for w in (0.1, 0.2, 0.3, 0.5): r[f"hol w{w}"] = rm(np.where(hol, p + np.clip(w * c, -CLIP, CLIP), p), y) - r0
    r["all23 - all25 (w0.1)"] = rm(p + np.clip(0.1 * c23, -CLIP, CLIP), y) - rm(p + np.clip(0.1 * c, -CLIP, CLIP), y)
    res[str(origin.date())] = r; hold["c"] = c; hold["hol"] = hol; win[origin] = hold
T = pd.DataFrame(res).T * 1e4; pd.set_option("display.width", 250); print(T.round(2).to_string()); print("mean", T.mean().round(2).to_dict()); print("worse", (T > 0).sum().to_dict())
json.dump(res, open("rail_tune.json", "w"), indent=1)
pick = {}
for grp, ws in (("ord", (0.05, 0.1, 0.15)), ("hol", (0.1, 0.2, 0.3, 0.5))):
    ok = [w for w in ws if (T[f"{grp} w{w}"] > 0).sum() <= 1]; pick[grp] = min(ok, key=lambda w: T[f"{grp} w{w}"].mean()) if ok else None
print("picked:", pick); json.dump(pick, open("rail_pick.json", "w"))
# the three windows named in the request, with the picked weights
def apply(h): return h[hb.MODEL].to_numpy() + np.clip(np.where(h.hol, pick["hol"], pick["ord"]) * h.c.to_numpy(), -CLIP, CLIP)
for name, org, d0, d1 in (("2025-08~10 (origin 2025-07-31)", "2025-07-31", "2025-08-01", "2025-10-31"), ("2026-03~04 (origin 2026-02-28)", "2026-02-28", "2026-03-01", "2026-04-30"), ("2026-05~06 (origin 2026-04-30)", "2026-04-30", "2026-05-01", "2026-06-30")):
    h = win[pd.Timestamp(org)]; h = h[(h.date >= d0) & (h.date <= d1)]; y = h.y_log.to_numpy(); p = h[hb.MODEL].to_numpy(); q = apply(h); late = (h.hour >= 21).to_numpy(); mon = h.date.dt.strftime("%Y-%m")
    print(f"{name}: overall {rm(p, y):.6f} -> {rm(q, y):.6f} ({(rm(q, y)-rm(p, y))*1e4:+.2f}e-4) | 21-23h {(rm(q[late], y[late])-rm(p[late], y[late]))*1e4:+.2f}e-4 | by month", {m: round((rm(q[(mon == m).to_numpy()], y[(mon == m).to_numpy()]) - rm(p[(mon == m).to_numpy()], y[(mon == m).to_numpy()])) * 1e4, 2) for m in sorted(mon.unique())})
