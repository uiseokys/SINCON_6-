import sys, pickle, json, time, numpy as np, pandas as pd, lightgbm as lgb
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, RB, days = rs.A, rs.RB, rs.days; rm = rs.rm; CLIP = 0.15
rail = pd.read_csv("rail_allowed.csv.gz", parse_dates=["date"]); RA = np.log1p(rail.pivot(index="date", columns=["line", "station"], values="alight")).sort_index()
GY = [c for c in RB.columns if c[0] == "경인선"]; SU = [c for c in RB.columns if c[0] == "수인선"]
D = pickle.load(open("../nnexp/data.pkl", "rb")); df = D["df"].copy(); df["date"] = pd.to_datetime(df["date"]); df["y_log"] = np.log1p(df["boardings"].to_numpy(np.float64))
DAYF = ["dow", "month", "is_school_vacation", "school_vac_share", "is_univ_vacation", "day_temp_mean", "day_precip", "is_rainy_day", "is_holiday", "is_offday", "holiday_kind"]
daily = df.groupby(["date", "station_id"]).agg(level=("y_log", "mean"), line=("line", "first"), **{f: (f, "first") for f in DAYF}).reset_index(); daily["line"] = daily["line"].astype("category").cat.codes
freekeys = pd.MultiIndex.from_frame(A.loc[~A.free, ["date", "station_id"]].drop_duplicates())
k = pd.MultiIndex.from_frame(daily[["date", "station_id"]]); ev_all = pd.MultiIndex.from_frame(pd.read_csv(rs.P / "rail_delivery/cache/team_event_station_days.csv", parse_dates=["date"])[["date", "station_id"]]).union(rs.events)
daily["free"] = ~k.isin(ev_all); first = daily.groupby("station_id").date.min()
LV = daily.pivot(index="date", columns="station_id", values="level"); LVf = LV.where(daily.pivot(index="date", columns="station_id", values="free").fillna(False).astype(bool))
special = set(days)
LVo = LVf[~LVf.index.isin(special)]                      # baselines from ordinary days only
def dowmed(frame, o, n=56):
    w = frame.loc[o - pd.Timedelta(days=n - 1):o]; return w.groupby(w.index.dayofweek).median()
def frame(o, d0, d1):
    t = daily[(daily.date >= d0) & (daily.date <= d1)].copy()
    b = dowmed(LVo, o).stack().rename("anchor").reset_index(); b.columns = ["dow", "station_id", "anchor"]; t = t.merge(b, on=["dow", "station_id"], how="left")
    w28 = LVo.loc[o - pd.Timedelta(days=27):o]; p28 = LVo.loc[o - pd.Timedelta(days=55):o - pd.Timedelta(days=28)]
    t["trend28"] = t.station_id.map(w28.mean() - p28.mean()); t["a28"] = t.station_id.map(w28.mean())
    dts = pd.DatetimeIndex(sorted(t.date.unique()))
    for name, fr, cols in (("oc_all", RB, list(RB.columns)), ("oc_gy", RB, GY), ("oc_su", RB, SU), ("oc_alight", RA, list(RA.columns))):
        base = dowmed(fr[~fr.index.isin(special)], o); ch = (fr.reindex(dts) - base.reindex(dts.dayofweek).to_numpy())[cols].mean(axis=1); t[name] = t.date.map(ch)
    t["lead"] = (t.date - o).dt.days; t["age"] = (o - t.station_id.map(first)).dt.days; t["rel"] = t.level - t.anchor; t["sid"] = t.station_id.astype("category")
    return t[t.anchor.notna()]
FEAT = ["lead", "dow", "month", "is_school_vacation", "school_vac_share", "is_univ_vacation", "day_temp_mean", "day_precip", "is_rainy_day", "is_holiday", "is_offday", "holiday_kind", "a28", "trend28", "line", "age", "oc_all", "oc_gy", "oc_su", "oc_alight", "sid"]
PL = dict(objective="regression", learning_rate=0.05, num_leaves=31, min_data_in_leaf=100, feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, seed=0, verbose=-1, num_threads=8)
cats = sorted(daily.station_id.unique()); res = {}; start = pd.Timestamp("2025-03-02")
DN = pickle.load(open("../nnexp/data.pkl", "rb"))["df"]
for line in open("../nnexp/out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); t0 = time.time()
    tr = pd.concat([frame(o, o + pd.Timedelta(days=1), min(o + pd.Timedelta(days=123), origin)) for o in pd.date_range(start, origin - pd.Timedelta(days=7), freq="7D")], ignore_index=True); tr = tr[tr.free]
    tr["sid"] = pd.Categorical(tr.station_id, categories=cats); te = frame(origin, pd.Timestamp(vs), pd.Timestamp(ve)); te["sid"] = pd.Categorical(te.station_id, categories=cats)
    model = lgb.train(PL, lgb.Dataset(tr[FEAT], tr.rel), 400); te["pred_level"] = te.anchor + model.predict(te[FEAT])
    m = A[A.origin.eq(origin)].reset_index(drop=True).merge(te[["date", "station_id", "pred_level"]], on=["date", "station_id"], how="left")
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); free = m.free.to_numpy() & m.pred_level.notna().to_numpy(); hol = m.date.isin(days).to_numpy(); r0 = rm(p, y)
    main_lvl = m.groupby(["date", "station_id"])[hb.MODEL].transform("mean").to_numpy(); dl = np.where(free, m.pred_level.to_numpy() - main_lvl, 0.0); lv_true = m.groupby(["date", "station_id"]).y_log.transform("mean").to_numpy()
    c = rs.shift_terms(m, origin)["all25"]; c = np.where(m.free.to_numpy() & np.isfinite(c), c, 0.0); v0 = p + np.clip(np.where(hol, 0.2, 0.1) * c, -CLIP, CLIP)
    q = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); q["dn"] = np.load(f"../nnexp/out4/xgbnb_{end}.npy") - np.load(f"../nnexp/out4/xgb_{end}.npy")
    dn = np.where(m.free.to_numpy(), m.merge(q, on=hb.KEY, how="left").dn.to_numpy(), 0.0); lvl = pd.Series(dn).groupby([m.date.to_numpy(), m.station_id.to_numpy()]).transform("mean").to_numpy(); cur = np.where(hol, v0 + np.clip(0.5 * lvl, -CLIP, CLIP), v0)
    r = {"current (shift+holiday)": rm(cur, y) - r0, "level rmse main": rm(main_lvl[free], lv_true[free]), "level rmse model": rm(m.pred_level.to_numpy()[free], lv_true[free]), "level rmse current": rm((main_lvl + (cur - p))[free], lv_true[free])}
    for w in (0.25, 0.5, 0.75, 1.0): r[f"level model w{w}"] = rm(p + np.clip(w * dl, -CLIP, CLIP), y) - r0
    r["hol only w0.5 + shift on ordinary"] = rm(np.where(hol, p + np.clip(0.5 * dl, -CLIP, CLIP), v0), y) - r0; r["ordinary only w0.25 + current on holidays"] = rm(np.where(hol, cur, p + np.clip(0.25 * dl, -CLIP, CLIP)), y) - r0
    res[end] = r
    print(end, f"level RMSE: main {r['level rmse main']:.4f} | current layers {r['level rmse current']:.4f} | level model {r['level rmse model']:.4f} || vs main x1e-4: current {r['current (shift+holiday)']*1e4:+.2f} |", " ".join(f"w{w}:{r[f'level model w{w}']*1e4:+.2f}" for w in (0.25, 0.5, 0.75, 1.0)), f"| hol-only {r['hol only w0.5 + shift on ordinary']*1e4:+.2f} ord-only {r['ordinary only w0.25 + current on holidays']*1e4:+.2f} | {time.time()-t0:.0f}s", flush=True)
T = pd.DataFrame(res).T; cols = [c for c in T.columns if "rmse" not in c]; print("mean x1e-4", (T[cols].mean() * 1e4).round(2).to_dict()); print("worse than current", {c: int((T[c] > T["current (shift+holiday)"]).sum()) for c in cols if c != "current (shift+holiday)"})
json.dump(res, open("level_rail.json", "w"), indent=1)
