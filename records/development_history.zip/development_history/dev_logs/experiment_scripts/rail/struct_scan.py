import sys, json, pickle, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, RB, LV, days = rs.A, rs.RB, rs.LV, rs.days; rm = rs.rm; CLIP = 0.15; K, ALPHA = 5, 5.0
allr = pd.read_csv("rail_all_allowed.csv.gz", parse_dates=["date"]); OB = np.log1p(allr.pivot_table(index="date", columns=["line", "station"], values="board", aggfunc="sum")).sort_index()
OB = OB.loc[:, OB.notna().sum().eq(669)]; print("other-line stations used:", OB.shape[1], "| lines:", OB.columns.get_level_values(0).nunique())
def roll_anom(frame): return frame - pd.concat([frame.shift(7 * k) for k in range(1, 9)], keys=range(8)).groupby(level=1).median()
AOB = roll_anom(OB); AL = roll_anom(LV)
D = pickle.load(open("../nnexp/data.pkl", "rb")); df = D["df"]
def pcs(origin, K):
    d = AOB.index[(AOB.index <= origin) & AOB.notna().all(axis=1).to_numpy()]; X = AOB.loc[d].to_numpy(); mu = X.mean(0); U, s, Vt = np.linalg.svd(X - mu, full_matrices=False)
    V = Vt[:K].T; F = (X - mu) @ V; sd = F.std(0); return d, mu, V, sd, F / sd
def ridge(F, Y, K, ALPHA, minn=60):
    Bc = {}
    for sid in Y.columns:
        yv = Y[sid].to_numpy(); ok = np.isfinite(yv) & np.isfinite(F).all(1)
        if ok.sum() >= minn: Bc[sid] = np.linalg.solve(F[ok].T @ F[ok] + ALPHA * np.eye(K), F[ok].T @ yv[ok])
    return Bc
def fit(origin, K, ALPHA, mode):
    d, mu, V, sd, F = pcs(origin, K); Y = AL.reindex(d)
    if mode == "cur": return mu, V, sd, ridge(F, Y, K, ALPHA)
    if mode == "E2":
        wk = (d.dayofweek < 5) & ~d.isin(days); return mu, V, sd, (ridge(F[wk], Y[wk], K, ALPHA), ridge(F[~wk], Y[~wk], K, ALPHA))
    if mode == "E4":
        Fs, Ys = [], []; po = origin - pd.Timedelta(days=28)
        while po >= OB.index[0] + pd.Timedelta(days=56 + 28):
            dd = pd.date_range(po + pd.Timedelta(days=1), min(po + pd.Timedelta(days=123), origin))
            Zo = (OB.reindex(dd) - rs.dow_base(OB, po).reindex(dd.dayofweek).to_numpy()).to_numpy(); Zl = LV.reindex(dd) - rs.dow_base(LV, po).reindex(dd.dayofweek).to_numpy()
            Fs.append(((Zo - mu) @ V) / sd); Ys.append(Zl); po -= pd.Timedelta(days=28)
        return mu, V, sd, ridge(np.vstack(Fs), pd.concat(Ys), K, ALPHA)
CONF = {"cur": (30, 5.0, 0.2, 0.3, "cur"), "E2": (30, 5.0, 0.2, 0.3, "E2"), "E4": (30, 5.0, 0.2, 0.3, "E4")}
res = {}
for line in open("../nnexp/out4/folds.txt"):
    end, vs, ve = line.split(); origin = pd.Timestamp(end); m = A[A.origin.eq(origin)].reset_index(drop=True)
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); hol = m.date.isin(days).to_numpy()
    lun = (m.station_id.eq(3122) & m.date.isin(pd.to_datetime(["2025-10-05", "2025-10-06", "2026-02-16", "2026-02-17"]))).to_numpy(); free = m.free.to_numpy() & ~lun
    dts = pd.DatetimeIndex(sorted(m.date.unique())); sb = rs.dow_base(LV, origin).stack().rename("b").reset_index(); sb.columns = ["dow", "station_id", "b"]
    lvl = m.groupby(["date", "station_id"])[hb.MODEL].transform("mean").to_numpy(); b = m[["date", "station_id"]].assign(dow=m.date.dt.dayofweek).merge(sb, on=["dow", "station_id"], how="left").b.to_numpy(); ahat = lvl - b
    q = df.loc[df["date"].between(vs, ve), ["date", "station_id", "hour"]].reset_index(drop=True); q["date"] = pd.to_datetime(q["date"]); q["dn"] = np.load(f"../nnexp/out4/xgbnb_{end}.npy") - np.load(f"../nnexp/out4/xgb_{end}.npy")
    dn = np.where(free, m.merge(q, on=hb.KEY, how="left").dn.to_numpy(), 0.0); lv = pd.Series(dn).groupby([m.date.to_numpy(), m.station_id.to_numpy()]).transform("mean").to_numpy(); hl = np.where(hol, np.clip(0.5 * lv, -CLIP, CLIP), 0.0)
    Z = (OB.reindex(dts) - rs.dow_base(OB, origin).reindex(dts.dayofweek).to_numpy()).to_numpy(); r = {}
    for name, (K_, A_, wo, wh, mode) in CONF.items():
        mu, V, sd, Bc = fit(origin, K_, A_, mode); Fd = pd.DataFrame(((Z - mu) @ V) / sd, index=dts); sids = m.station_id.to_numpy(); nanv = np.full(K_, np.nan)
        if mode == "E2":
            wkrow = ((m.date.dt.dayofweek < 5) & ~m.date.isin(days)).to_numpy(); Bm = np.stack([(Bc[0] if w else Bc[1]).get(s, nanv) for s, w in zip(sids, wkrow)])
        else: Bm = np.stack([Bc.get(s, nanv) for s in sids])
        chat = (Fd.reindex(m.date.to_numpy()).to_numpy() * Bm).sum(1)
        c2 = np.where(free & np.isfinite(chat - ahat), chat - ahat, 0.0); r[name] = rm(p + np.clip(np.where(hol, wh, wo) * c2, -CLIP, CLIP) + hl, y)
    res[end] = r
T = pd.DataFrame(res).T; D_ = T.sub(T["cur"], axis=0).drop(columns="cur") * 1e4; pd.set_option("display.width", 250)
print(D_.round(2).to_string()); print("mean", D_.mean().round(2).to_dict()); print("worse than current", (D_ > 1e-9).sum().to_dict())
json.dump(res, open("struct_scan.json", "w"), indent=1)
