import sys, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, hour_layer as hr
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
days, events, protected = hb.read_protection(P / "rail_delivery_v4/cache"); team = pd.read_csv(P / "rail_delivery_v4/cache/team_event_station_days.csv", parse_dates=["date"])
SPECIAL = [("2026-09-24", 3122), ("2026-09-25", 3122), ("2026-07-11", 3139), ("2026-07-29", 3754), ("2026-10-17", 3226)]
blocked = events.union(protected).union(pd.MultiIndex.from_frame(team[["date", "station_id"]])).union(pd.MultiIndex.from_tuples([(pd.Timestamp(d), s) for d, s in SPECIAL]))
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); train = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); rail_all = pd.read_csv("rail_all_allowed.csv.gz", parse_dates=["date"])
src = B / "CANDIDATE_SET_1113/submission_rail_factors_k30_on_xgb7.csv"; assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("13b0ff73fb7d"); base = pd.read_csv(src)
x7 = pd.read_csv(B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv")
new, info = hr.apply(test, base.boardings.values, x7.boardings.values, train, rail_all, blocked)
out = base.copy(); out["boardings"] = new; hb.check_submission(out, test); path = B / "CANDIDATE_SET_1113/submission_rail_factors_k30_hour_on_xgb7.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); k = pd.MultiIndex.from_frame(test[["date", "station_id"]]); assert np.array_equal(back.boardings.values[k.isin(blocked)], base.boardings.values[k.isin(blocked)])
info["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest(); print(json.dumps(info, ensure_ascii=False)); json.dump(info, open(B / "CANDIDATE_SET_1113/rail_k30_hour_report.json", "w"), indent=2, ensure_ascii=False)
