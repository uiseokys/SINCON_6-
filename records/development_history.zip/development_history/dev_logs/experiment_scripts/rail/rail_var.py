import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb
import rail_shift as rs
A, RB, LV, days = rs.A, rs.RB, rs.LV, rs.days; rm = rs.rm; CLIP = 0.15; B = rs.B
rail = pd.read_csv("rail_allowed.csv.gz", parse_dates=["date"]); RA = np.log1p(rail.pivot(index="date", columns=["line", "station"], values="alight")).sort_index()
G = {"G1": ["백운", "동암", "간석", "부개"], "G2": ["송내", "중동", "부천", "소사", "역곡"], "G3": ["도화", "제물포", "도원", "동인천", "인천"], "G4": ["송도", "연수", "남동인더스파크", "호구포", "인천논현", "소래포구", "월곶"], "G5": ["인천", "신포", "숭의", "인하대"]}
GL = {"G1": "경인선", "G2": "경인선", "G3": "경인선", "G4": "수인선", "G5": "수인선"}
line = pd.read_csv(B / "data/metaData.csv").set_index("station_id").canonical_line; print("lines:", line.value_counts().to_dict())
def change(frame, origin, dts): return frame.reindex(dts) - rs.dow_base(frame, origin).reindex(dts.dayofweek).to_numpy()
res = {}; store = []
for origin, hold in A.groupby("origin", sort=True):
    hold = hold.reset_index(drop=True); dts = pd.DatetimeIndex(sorted(hold.date.unique())); a = change(RB, origin, dts); aa = change(RA, origin, dts)
    sb = rs.dow_base(LV, origin).stack().rename("b").reset_index(); sb.columns = ["dow", "station_id", "b"]
    lvl = hold.groupby(["date", "station_id"])[hb.MODEL].transform("mean").to_numpy(); b = hold[["date", "station_id"]].assign(dow=hold.date.dt.dayofweek).merge(sb, on=["dow", "station_id"], how="left").b.to_numpy(); ahat = lvl - b
    d2 = hold.date.to_numpy(); all25 = a.mean(axis=1).reindex(d2).to_numpy(); both = (0.5 * a.mean(axis=1) + 0.5 * aa.mean(axis=1)).reindex(d2).to_numpy()
    g = {k: a[[(GL[k], s) for s in v]].mean(axis=1) for k, v in G.items()}
    ln = hold.station_id.map(line).to_numpy()
    near = np.where(ln == 7, g["G2"].reindex(d2).to_numpy(), np.where(ln == 2, ((g["G1"] + g["G3"] + g["G5"]) / 3).reindex(d2).to_numpy(), ((g["G1"] + g["G4"]) / 2).reindex(d2).to_numpy()))
    y = hold.y_log.to_numpy(); p = hold[hb.MODEL].to_numpy(); free = hold.free.to_numpy(); hol = hold.date.isin(days).to_numpy(); w = np.where(hol, 0.2, 0.1); late = (hold.hour >= 21).to_numpy(); r0 = rm(p, y)
    def term(sig): c = sig - ahat; return np.where(free & np.isfinite(c), c, 0.0)
    c0 = term(all25); v0 = p + np.clip(w * c0, -CLIP, CLIP); r = {"V0": rm(v0, y) - r0}
    r["V1 day only"] = rm(np.where(late, p, v0), y) - r0; r["V2 late half"] = rm(np.where(late, p + np.clip(0.5 * w * c0, -CLIP, CLIP), v0), y) - r0
    r["V3 nearest"] = rm(p + np.clip(w * term(near), -CLIP, CLIP), y) - r0; r["V4 board+alight"] = rm(p + np.clip(w * term(both), -CLIP, CLIP), y) - r0
    hold["c0"] = c0; hold["w"] = w; store.append(hold[["origin", "date", "station_id", "hour", "c0", "w", "free"]])
    res[str(origin.date())] = r
ALL = A.merge(pd.concat(store)[["origin", "date", "station_id", "hour", "c0", "w"]], on=["origin", "date", "station_id", "hour"], how="left")
SKIP = pd.Timestamp("2025-06-30")
for origin, m in ALL.groupby("origin", sort=True):
    prior = ALL[ALL.origin.lt(origin) & ALL.origin.ne(SKIP) & ALL.date.le(origin) & ALL.free].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    y = m.y_log.to_numpy(); p = m[hb.MODEL].to_numpy(); r0 = rm(p, y)
    if len(prior):
        t = prior.assign(rd=prior.r * prior.c0, dd=prior.c0 ** 2).groupby("station_id")[["rd", "dd"]].sum(); beta = (t.rd / (t.dd + t.dd.median())).clip(0, 1)
        q = p + np.clip(0.5 * m.station_id.map(beta).fillna(0.0).to_numpy() * m.c0.to_numpy(), -CLIP, CLIP)
    else: q = p + np.clip(m.w.to_numpy() * m.c0.to_numpy(), -CLIP, CLIP)
    res[str(origin.date())]["V5 station beta"] = rm(q, y) - r0
T = pd.DataFrame(res).T * 1e4; pd.set_option("display.width", 200); print(T.round(2).to_string()); print("mean", T.mean().round(2).to_dict()); print("worse than main", (T > 0).sum().to_dict()); print("worse than V0", {c: int((T[c] > T["V0"]).sum()) for c in T.columns if c != "V0"})
json.dump(res, open("rail_var.json", "w"), indent=1)
