import sys, hashlib, json, numpy as np, pandas as pd
sys.path.insert(0, "../hb_pkg"); sys.path.insert(0, "."); import hourbias_layer as hb, factor_layer as fl, hol_layer as hl
from pathlib import Path
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
days, events, protected = hb.read_protection(P / "rail_delivery/cache"); team = pd.read_csv(P / "rail_delivery/cache/team_event_station_days.csv", parse_dates=["date"])
SPECIAL = [("2026-09-24", 3122), ("2026-09-25", 3122), ("2026-07-11", 3139), ("2026-07-29", 3754), ("2026-10-17", 3226)]
blocked = events.union(protected).union(pd.MultiIndex.from_frame(team[["date", "station_id"]])).union(pd.MultiIndex.from_tuples([(pd.Timestamp(d), s) for d, s in SPECIAL]))
test = pd.read_csv(B / "data/test.csv", parse_dates=["date"]); train = pd.read_csv(B / "data/train.csv", parse_dates=["date"]); rail_all = pd.read_csv("rail_all_allowed.csv.gz", parse_dates=["date"])
src = B / "CANDIDATE_SET_1113/submission_xgb7_w10_on_curvature.csv"; assert hashlib.sha256(src.read_bytes()).hexdigest().startswith("596876180bb0"); base = pd.read_csv(src)
K_, WO_, WH_, TAG = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), sys.argv[4]
s1, i1 = fl.apply(test, base.boardings.values, train, rail_all, days, blocked, K=K_, W_ORDINARY=WO_, W_HOLIDAY=WH_)
s2, i2 = hl.apply(test, s1, np.load("../nnexp/out3/xgbnb_test.npy"), np.load("../nnexp/out3/xgb_test.npy"), days, blocked)
out = base.copy(); out["boardings"] = s2; hb.check_submission(out, test); path = B / f"CANDIDATE_SET_1113/submission_rail_factors_{TAG}_on_xgb7.csv"; out.to_csv(path, index=False)
back = pd.read_csv(path); k = pd.MultiIndex.from_frame(test[["date", "station_id"]]); assert np.array_equal(back.boardings.values[k.isin(blocked)], pd.read_csv(src).boardings.values[k.isin(blocked)])
prev = pd.read_csv(B / "CANDIDATE_SET_1113/submission_rail_factors_on_xgb7.csv"); d = np.log1p(back.boardings.values) - np.log1p(prev.boardings.values); d0 = np.log1p(back.boardings.values) - np.log1p(base.boardings.values)
info = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rms_vs_0.143777_file": float(np.sqrt((d ** 2).mean())), "rows_changed_vs_0.143777_file": int((np.abs(d) > 1e-12).sum()), "rms_vs_xgb7": float(np.sqrt((d0 ** 2).mean())), "factor_layer": i1, "holiday_layer_rows": i2["changed_rows"]}
print(TAG, json.dumps({k: v for k, v in info.items() if k != "factor_layer"}, ensure_ascii=False), "| month mean change", info["factor_layer"]["by_month_mean_change"], "| var explained", round(info["factor_layer"]["variance_explained"], 3)); json.dump(info, open(B / f"CANDIDATE_SET_1113/rail_factors_{TAG}_report.json", "w"), indent=2, ensure_ascii=False)
