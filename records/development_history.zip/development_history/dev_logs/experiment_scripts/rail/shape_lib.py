import numpy as np, pandas as pd
HOURS = list(range(6, 24)); HC = [f"b{h}" for h in HOURS]
def other_shapes(path):
    """month (Period) x hour: mean over the 25 allowed stations of the centred log hourly share of boardings."""
    d = pd.read_csv(path, dtype={"month": str})
    dup = d.duplicated(["month", "line", "station"], keep=False)
    same = d[dup].groupby(["month", "line", "station"])[HC].nunique().max().max() if dup.any() else 1
    d = d.drop_duplicates(["month", "line", "station"], keep="last")
    assert d.groupby("month").size().eq(25).all()
    L = np.log(d[HC].to_numpy(float) + 1.0); L = L - L.mean(1, keepdims=True)
    S = pd.DataFrame(L, columns=HOURS).groupby(d["month"].to_numpy()).mean(); S.index = pd.PeriodIndex(S.index, freq="M")
    return S, {"duplicate_rows": int(dup.sum()), "duplicates_identical": bool(same == 1), "duplicate_months": sorted(d.loc[dup.reindex(d.index, fill_value=False), "month"].unique().tolist()) if dup.any() else []}
def month_shapes(frame, value):
    """frame: date, station_id, hour, value(counts). returns (station, month) x hour centred log share of monthly sums."""
    m = frame.assign(month=frame["date"].dt.to_period("M")).groupby(["station_id", "month", "hour"])[value].sum().unstack("hour")[HOURS]
    L = np.log(m.to_numpy(float) + 1.0); return pd.DataFrame(L - L.mean(1, keepdims=True), index=m.index, columns=HOURS)
def base_months(origin): p = origin.to_period("M"); return [p - 1, p]
def shape_term(hold, pred_log, train, S, origin):
    """per row: (other-line shape change since the base months) − (our forecast's shape change since the base months). NaN where the month is incomplete."""
    bm = base_months(origin); dS = S - S.loc[bm].mean()
    tb = train[train["date"].dt.to_period("M").isin(bm)]; base = month_shapes(tb.assign(v=tb["boardings"]), "v").groupby(level="station_id").mean()
    h = hold[["date", "station_id", "hour"]].assign(v=np.expm1(pred_log)); ours = month_shapes(h, "v")
    mon = hold["date"].dt.to_period("M"); days_in = hold.groupby(mon)["date"].nunique(); full = {m for m, n in days_in.items() if n == m.days_in_month}
    st = hold["station_id"].to_numpy(); hr = hold["hour"].to_numpy(); mo = mon.to_numpy()
    o = ours.stack().rename("o"); b = base.stack().rename("b"); d = dS.stack().rename("d")
    key = pd.MultiIndex.from_arrays([st, mo, hr]); ov = o.reindex(key).to_numpy(); bv = b.reindex(pd.MultiIndex.from_arrays([st, hr])).to_numpy(); dv = d.reindex(pd.MultiIndex.from_arrays([mo, hr])).to_numpy()
    c = dv - (ov - bv); c[~np.isin(mo, list(full))] = np.nan
    return c
