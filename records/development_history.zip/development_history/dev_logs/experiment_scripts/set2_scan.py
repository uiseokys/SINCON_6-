"""Past-data scan for CANDIDATE_SET2 (L1, L2, L3) on top of K1. Nested forward OOF only."""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", "adjusted", "station025", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week
rows["dtype"] = np.where(rows.dow.eq(5), 1, np.where(rows.dow.eq(6), 2, 0))
ev = pd.MultiIndex.from_frame(rows[hb.DAYKEY]).isin(events)
q_all = ~rows.date.isin(days) & ~ev
q_k1 = q_all & ~rows.station_id.isin(hb.EXCLUDED_STATIONS)
out = {}
for origin, hold in rows.groupby("origin", sort=True):
    rows["quiet"] = q_k1
    hist = hb.select_history(rows, origin)
    if hist.empty: continue
    d_k1, good = hb.apply_stats(hold, hb.fit_stats(hist), q_k1.loc[hold.index])
    rows["quiet"] = q_all
    hist_all = hb.select_history(rows, origin)
    d_ext, good_ext = hb.apply_stats(hold, hb.fit_stats(hist_all), q_all.loc[hold.index])
    y = hold.y_log.to_numpy(); base = hold[hb.MODEL].to_numpy(); k1 = base + d_k1
    r = {"base": rm(y, base), "k1": rm(y, k1), "L1": rm(y, base + d_ext)}
    st = (hold.station025 - hold.adjusted).to_numpy()
    for m in (2, 3, 4):
        r[f"L2_m{m}"] = rm(y, k1 + (m - 1) * st)
    # L3: station x daytype level from station-day mean errors in the K1 history window
    h = hist.assign(err=hist.y_log - hist[hb.MODEL])
    sd = h.groupby([*hb.DAYKEY, "dtype"]).err.agg(["mean", "size"]).reset_index()
    sd = sd[sd["size"].eq(18)]
    stt = sd.groupby(["station_id", "dtype"])["mean"].agg(["mean", "count"])
    stt["lvl"] = (stt["mean"] * hb.SCALE * stt["count"] / (stt["count"] + hb.SHRINK)).where(stt["count"].ge(hb.MIN_DAYS))
    lvl = hold.join(stt[["lvl"]], on=["station_id", "dtype"]).lvl.where(q_k1.loc[hold.index], np.nan).fillna(0).to_numpy()
    r["L3"] = rm(y, k1 + lvl)
    r["L3_rows"] = int((lvl != 0).sum())
    out[str(origin.date())] = r
    print(origin.date(), f"base {r['base']:.6f} k1 {r['k1']-r['base']:+.6f} | vs k1: L1 {r['L1']-r['k1']:+.6f}  L2 m2 {r['L2_m2']-r['k1']:+.6f} m3 {r['L2_m3']-r['k1']:+.6f} m4 {r['L2_m4']-r['k1']:+.6f}  L3 {r['L3']-r['k1']:+.6f}", flush=True)
keys = ["L1", "L2_m2", "L2_m3", "L2_m4", "L3"]
for k in keys:
    d = [v[k] - v["k1"] for v in out.values()]
    print(k, "mean", f"{np.mean(d):+.6f}", "worse", sum(x > 0 for x in d), "of", len(d))
json.dump(out, open(Path(__file__).parent / "set2_scan.json", "w"), indent=1)
