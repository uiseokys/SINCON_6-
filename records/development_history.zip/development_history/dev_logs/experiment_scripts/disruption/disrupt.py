"""파업·지연 사례의 영향. 2026-06-30 이전 공식 train 과 허용된 타 노선 자료만 쓴다."""
import sys, json, numpy as np, pandas as pd
root = sys.argv[1]; sys.path.insert(0, root); import hourbias_layer as hb, factor_layer as fl
train = pd.read_csv(f"{root}/data/train.csv", parse_dates=["date"]); meta = pd.read_csv(sys.argv[2]); line = meta.set_index("station_id")["canonical_line"]
rail = pd.read_csv(f"{root}/cache/rail_all_allowed.csv.gz", parse_dates=["date"]); days, events, protected = hb.read_protection(f"{root}/cache" if False else __import__("pathlib").Path(root) / "cache")
special = pd.DatetimeIndex(sorted(set(days)))
lv = np.log1p(train.set_index(["date", "station_id", "hour"])["boardings"]).groupby(level=[0, 1]).mean().unstack()
an = fl.roll_anom(lv)                                     # 같은 요일 직전 8주 중앙값 대비
ordinary = an.index[(an.index.dayofweek < 5) & ~an.index.isin(special) & (an.index >= "2025-03-01")]
out = {}
print("== A. 서울 시내버스 파업 2026-01-13(화), 14(수): 역·날짜 수준의 증감(log), 노선별 평균")
lm = an.T.groupby(line).mean().T                           # 날짜 × 노선
for d in ("2026-01-12", "2026-01-13", "2026-01-14", "2026-01-15", "2026-01-16"):
    row = lm.loc[d]; ref = lm.loc[ordinary]
    print(d, {int(k): (round(float(row[k]), 4), "일반 평일 분포에서의 백분위 %d" % round(100 * (ref[k] < row[k]).mean())) for k in row.index})
print("일반 평일의 노선 평균 증감: 표준편차", {int(k): round(float(v), 4) for k, v in lm.loc[ordinary].std().items()})
# 타 노선 층(기준일 2025-12-31, K=30)이 이 이틀을 설명하는가
origin = pd.Timestamp("2025-12-31"); tr = train[train["date"] <= origin]
ob = fl.other_matrix(rail); ao = fl.roll_anom(ob); lv0 = np.log1p(tr.set_index(["date", "station_id", "hour"])["boardings"]).groupby(level=[0, 1]).mean().unstack(); al = fl.roll_anom(lv0)
K, ALPHA = 30, 5.0
d = ao.index[(ao.index <= origin) & ao.notna().all(axis=1).to_numpy()]; X = ao.loc[d].to_numpy(); mu = X.mean(0); _, s, vt = np.linalg.svd(X - mu, full_matrices=False)
V = vt[:K].T; F = (X - mu) @ V; sd = F.std(0); F = F / sd; Y = al.reindex(d); coef = {}
for sid in Y.columns:
    yv = Y[sid].to_numpy(); ok = np.isfinite(yv)
    if ok.sum() >= 60: coef[sid] = np.linalg.solve(F[ok].T @ F[ok] + ALPHA * np.eye(K), F[ok].T @ yv[ok])
dts = pd.date_range("2026-01-02", "2026-02-27"); Z = ob.reindex(dts) - fl.dow_base(ob, origin).reindex(dts.dayofweek).to_numpy()
Ft = ((Z.to_numpy() - mu) @ V) / sd; C = pd.DataFrame({sid: Ft @ c for sid, c in coef.items()}, index=dts)          # 예상 변화
Aact = lv.reindex(dts) - fl.dow_base(lv0, origin).reindex(dts.dayofweek).to_numpy(); Aact = Aact[C.columns]            # 실제 변화
wk = dts[(dts.dayofweek < 5) & ~dts.isin(special)]
print("\n기준일 2025-12-31, 평가 2026-01-02~02-27. 역 평균(전체 71개 역 중 계수 있는 %d개)" % len(coef))
tab = pd.DataFrame({"실제 변화": Aact.mean(1), "타 노선 층의 예상 변화": C.mean(1), "남는 차이": (Aact - C).mean(1)})
print(tab.loc[["2026-01-12", "2026-01-13", "2026-01-14", "2026-01-15"]].round(4).to_string())
o = tab.loc[wk.difference(pd.to_datetime(["2026-01-13", "2026-01-14"]))]
print("다른 일반 평일(%d일): 실제 변화 평균 %.4f 표준편차 %.4f | 남는 차이 평균 %.4f 표준편차 %.4f" % (len(o), o["실제 변화"].mean(), o["실제 변화"].std(), o["남는 차이"].mean(), o["남는 차이"].std()))
print("타 노선 544개 역의 평균 증감(같은 요일 직전 8주 대비):", {str(k.date()): round(float(v), 4) for k, v in ao.mean(1).loc["2026-01-12":"2026-01-15"].items()})
# 시간대
hl = np.log1p(train.set_index(["date", "station_id", "hour"])["boardings"]).unstack("hour"); ha = hl.groupby(level="station_id", group_keys=False).apply(lambda g: g.droplevel("station_id").pipe(fl.roll_anom).assign(station_id=g.name).set_index("station_id", append=True))
hm = ha.groupby(level="date").mean()
print("\n시간대별 증감(전 역 평균, log):"); print(hm.loc[["2026-01-13", "2026-01-14"]].round(3).to_string()); print("일반 평일 표준편차:"); print(hm.loc[hm.index.isin(ordinary)].std().round(3).to_frame().T.to_string(index=False))
print("\n== B. 짧은 지연")
hline = ha.copy(); hline["line"] = hline.index.get_level_values("station_id").map(line); 
for d, ln, hours, what in (("2026-05-06", 2, [17, 18, 19], "인천 2호선 가정역 14분 지연(17:44)"), ("2026-04-29", 1, [7, 8, 9], "인천 1호선 캠퍼스타운 출입문 고장 4~5분 지연(07:35)")):
    g = hline[hline["line"].eq(ln)].drop(columns="line").groupby(level="date").mean(); ref = g.loc[g.index.isin(ordinary)]
    print(what, d); print("  ", {h: (round(float(g.loc[d, h]), 4), "일반 평일 표준편차 %.4f" % ref[h].std(), "백분위 %d" % round(100 * (ref[h] < g.loc[d, h]).mean())) for h in hours})
    out[d] = {int(h): float(g.loc[d, h]) for h in hours}
json.dump(out, open("disrupt.json", "w"), indent=1)
