import sys, numpy as np, pandas as pd
root = sys.argv[1]; sys.path.insert(0, root); import factor_layer as fl
rail = pd.read_csv(f"{root}/cache/rail_all_allowed.csv.gz", parse_dates=["date"]); ob = fl.other_matrix(rail); ao = fl.roll_anom(ob)
seoul = [c for c in ob.columns if c[0] in ("1호선", "2호선", "3호선", "4호선", "5호선", "6호선", "8호선", "9호선")]
m = pd.DataFrame({"전체 544역": ao.mean(1), "서울 1~9호선(7호선 제외)": ao[seoul].mean(1), "그 밖": ao.drop(columns=seoul).mean(1)})
wk = m.index[(m.index.dayofweek < 5) & (m.index >= "2025-03-01")]
print("일반 평일 표준편차(공휴일 포함):", m.loc[wk].std().round(4).to_dict())
for a, b in (("2026-01-12", "2026-01-16"), ("2026-09-14", "2026-09-18"), ("2026-10-28", "2026-10-30")):
    print(m.loc[a:b].round(4).to_string())
