"""Measurement only: past-data curve of the hour-shape correction size (no file is built from this)."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd"); B = Path("/Users/jeong-uiseok/sincon-2026/sincon-baseline")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows["dow"] = rows.date.dt.day_of_week
rows["quiet"] = hb.quiet_rows(rows, days, events)
mult = (1, 2, 3, 4, 6, 8)
tab = {}
for origin, hold in rows.groupby("origin", sort=True):
    hist = hb.select_history(rows, origin)
    if hist.empty: continue
    d, good = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)
    y = hold.y_log.to_numpy(); b = hold[hb.MODEL].to_numpy(); r0 = rm(y, b)
    # by lead: first 61 days vs later
    lead = (hold.date - origin).dt.days.to_numpy()
    tab[str(origin.date())] = [rm(y, b + m * d) - r0 for m in mult]
    early = lead <= 61
    print(origin.date(), " ".join(f"x{m}:{v:+.6f}" for m, v in zip(mult, tab[str(origin.date())])),
          "| x1 lead<=61:", f"{rm(y[early], (b+d)[early])-rm(y[early], b[early]):+.6f}", "lead>61:", (f"{rm(y[~early], (b+d)[~early])-rm(y[~early], b[~early]):+.6f}" if (~early).any() else "n/a"), flush=True)
a = np.array(list(tab.values()))
print("mean", " ".join(f"x{m}:{v:+.6f}" for m, v in zip(mult, a.mean(0))))
print("worse count", " ".join(f"x{m}:{int((a[:, i] > 0).sum())}" for i, m in enumerate(mult)))
# which stations did the Codex seasonal refit change?
t = pd.read_csv(B / "data/test.csv")
gp = pd.read_csv(P / "goal_014/release/submission_k3_geomdan_plave.csv"); new = pd.read_csv(P / "goal_014/release/submission_k3_geomdan_plave_seasonal_refit.csv")
ch = np.abs(np.log1p(new.boardings) - np.log1p(gp.boardings)) > 1e-12
print("seasonal refit touches excluded stations:", sorted(set(t.station_id[ch]) & hb.EXCLUDED_STATIONS), "| stations touched", t.station_id[ch].nunique())
