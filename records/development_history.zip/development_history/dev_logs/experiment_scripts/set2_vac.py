import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
cal = pd.read_csv(P / "final_package/payload/work/external_inputs/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"], usecols=["date", "is_school_vacation", "school_vac_share"])
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
rows = rows.merge(cal, on="date", how="left")
rows["dow"] = rows.date.dt.day_of_week
rows["quiet"] = hb.quiet_rows(rows, days, events)
print("test-period vacation days:", cal[(cal.date >= "2026-07-01") & (cal.date <= "2026-10-31")].groupby(cal.date.dt.month).is_school_vacation.sum().to_dict())
print("history window 2026-04-08..06-30 vacation days:", int(cal[(cal.date >= "2026-04-08") & (cal.date <= "2026-06-30")].is_school_vacation.sum()))
FIT4 = ["station_id", "dow", "hour", "is_school_vacation"]
res = []
for origin, hold in rows.groupby("origin", sort=True):
    hist = hb.select_history(rows, origin)
    if hist.empty: continue
    d1, good1 = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)
    # L4: status-matched cells
    h = hist.copy(); h["error"] = h.y_log - h[hb.MODEL]
    g = h.groupby(hb.DAYKEY).error
    h["error"] = (h.error - g.transform("mean")).where(g.transform("size").eq(18))
    st = h.groupby(FIT4).error.agg(["mean", "count"])
    st["correction"] = (st["mean"] * hb.SCALE * st["count"] / (st["count"] + hb.SHRINK)).where(st["count"].ge(hb.MIN_DAYS))
    t = hold.join(st[["correction"]], on=FIT4)
    good4 = hold.quiet & t.groupby(hb.DAYKEY).correction.transform("count").eq(18)
    d4 = (t.correction - t.groupby(hb.DAYKEY).correction.transform("mean")).where(good4, 0.0).to_numpy()
    y = hold.y_log.to_numpy(); b = hold[hb.MODEL].to_numpy(); v = hold.is_school_vacation.to_numpy() == 1
    hv = hist.drop_duplicates("date").is_school_vacation.mean()
    def part(mask, d):
        return (rm(y[mask], (b + d)[mask]) - rm(y[mask], b[mask])) if mask.any() else float("nan")
    r = dict(origin=str(origin.date()), hist_vac_share=round(float(hv), 2), k1=rm(y, b + d1) - rm(y, b), l4=rm(y, b + d4) - rm(y, b),
             k1_on_vac=part(v, d1), k1_on_term=part(~v, d1), vac_rows=int(v.sum()), l4_rows=int(good4.sum()), k1_rows=int(good1.sum()))
    res.append(r)
    print(r["origin"], f"hist vac share {r['hist_vac_share']:.2f} | K1 {r['k1']:+.6f} (vac days {r['k1_on_vac']:+.6f}, term days {r['k1_on_term']:+.6f}) | L4 {r['l4']:+.6f} | L4-K1 {r['l4']-r['k1']:+.6f} rows {r['l4_rows']}/{r['k1_rows']}", flush=True)
d = [r["l4"] - r["k1"] for r in res]
print("L4 vs K1 mean", f"{np.mean(d):+.6f}", "worse", sum(x > 0 for x in d), "of", len(d))
