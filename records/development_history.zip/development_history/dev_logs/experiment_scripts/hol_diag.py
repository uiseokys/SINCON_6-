import numpy as np, pandas as pd
P = "/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/"
cal = pd.read_csv(P + "final_package/payload/work/external_inputs/calendar_features.csv", encoding="utf-8-sig", parse_dates=["date"])
flags = ["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday", "is_substitute", "is_lunar_holiday"]
rows = pd.read_csv(P + "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", "date", "station_id", "hour", "y_log", "lunar3122"], parse_dates=["origin", "date"])
rows = rows.sort_values("origin").drop_duplicates(["date", "station_id", "hour"], keep="last")   # most recent forecast of each row
rows = rows.merge(cal[["date", "holiday_name", "dow", *flags]], on="date", how="left")
rows["err"] = rows.y_log - rows.lunar3122
rows["special"] = rows[["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]].ne(0).any(axis=1)
tot = (rows.err ** 2).sum()
for name, m in (("ordinary", ~rows.special), ("special (any flag)", rows.special), ("is_holiday", rows.is_holiday.eq(1)), ("lunar_season not holiday", rows.is_lunar_season.eq(1) & rows.is_holiday.eq(0)), ("bridge/quasi only", rows.special & rows.is_holiday.eq(0) & rows.is_lunar_season.eq(0))):
    e = rows.err[m]; print(f"{name:26s} rows {m.mean():6.2%}  rmsle {np.sqrt((e**2).mean()):.4f}  share of squared error {(e**2).sum()/tot:6.2%}  mean err {e.mean():+.4f}")
t = cal[(cal.date >= "2026-07-01") & (cal.date <= "2026-10-31")]
print("test period special days:", int(t[["is_holiday", "is_lunar_season", "is_bridge_day", "is_quasi_holiday"]].ne(0).any(axis=1).sum()), "of 123 | holidays:", t.loc[t.is_holiday.eq(1), ["date", "holiday_name"]].assign(date=lambda d: d.date.dt.strftime("%m-%d")).values.tolist())
print("test lunar_season days:", t.loc[t.is_lunar_season.eq(1), "date"].dt.strftime("%m-%d").tolist(), "| bridge:", t.loc[t.is_bridge_day.eq(1), "date"].dt.strftime("%m-%d").tolist(), "| quasi:", t.loc[t.is_quasi_holiday.eq(1), "date"].dt.strftime("%m-%d").tolist())
h = rows[rows.special].groupby("date").agg(name=("holiday_name", "first"), dow=("dow", "first"), hol=("is_holiday", "first"), lunar=("is_lunar_season", "first"), rmsle=("err", lambda e: np.sqrt((e**2).mean())), mean_err=("err", "mean"), lead=("origin", lambda o: 0))
sd = rows[rows.special].groupby(["date", "station_id"]).err.mean().groupby("date").agg(lambda v: np.sqrt((v**2).mean()))
h["station_day_level_rms"] = sd
print(h.drop(columns="lead").round(4).to_string())
