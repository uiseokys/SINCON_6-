import sys, json
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent / "hb_pkg"))
import hourbias_layer as hb
P = Path("/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd")
days, events, protected = hb.read_protection(P / "hourbias_delivery/cache")
def rm(y, p): return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))
WIN, THR, FRAC, MIN = 60, 0.03, 0.5, 10

def station_levels(rows, origin, quiet_col="quiet_all"):
    m = rows.date.gt(origin - pd.Timedelta(days=WIN)) & rows.date.le(origin) & rows.origin.lt(origin) & rows[quiet_col]
    h = rows.loc[m].sort_values("origin").drop_duplicates(hb.KEY, keep="last")
    sd = h.assign(err=h.y_log - h[hb.MODEL]).groupby(hb.DAYKEY).err.agg(["mean", "size"]).reset_index()
    sd = sd[sd["size"].eq(18)]
    sd["late"] = sd.date.gt(origin - pd.Timedelta(days=WIN // 2))
    g = sd.groupby(["station_id", "late"])["mean"].agg(["median", "count"]).unstack()
    med_all = sd.groupby("station_id")["mean"].median()
    ok = (g[("count", False)].ge(MIN) & g[("count", True)].ge(MIN) & (np.sign(g[("median", False)]) == np.sign(g[("median", True)]))
          & g[("median", False)].abs().ge(THR) & g[("median", True)].abs().ge(THR))
    return (FRAC * med_all[ok[ok].index]).rename("lvl")

if __name__ == "__main__":
    rows = pd.read_csv(P / "night13/measurements/downstream_oof_nested_main.csv.gz", usecols=["origin", *hb.KEY, "y_log", hb.MODEL], parse_dates=["origin", "date"])
    rows["dow"] = rows.date.dt.day_of_week
    ev = pd.MultiIndex.from_frame(rows[hb.DAYKEY]).isin(events)
    rows["quiet_all"] = ~rows.date.isin(days) & ~ev
    rows["quiet"] = rows.quiet_all & ~rows.station_id.isin(hb.EXCLUDED_STATIONS)
    out = {}
    for origin, hold in rows.groupby("origin", sort=True):
        hist = hb.select_history(rows, origin)
        if hist.empty: continue
        d, _ = hb.apply_stats(hold, hb.fit_stats(hist), hold.quiet)
        lv = station_levels(rows, origin)
        add = np.where(hold.quiet_all, hold.station_id.map(lv).fillna(0).to_numpy(), 0.0)
        y = hold.y_log.to_numpy(); k1 = hold[hb.MODEL].to_numpy() + d
        r = {"k1": rm(y, k1), "l6": rm(y, k1 + add), "stations": {int(k): round(float(v), 4) for k, v in lv.items()}}
        out[str(origin.date())] = r
        print(origin.date(), f"k1 {r['k1']:.6f} L6 {r['l6']-r['k1']:+.6f} | stations {r['stations']}", flush=True)
    dd = [v["l6"] - v["k1"] for v in out.values()]
    print("L6 mean", f"{np.mean(dd):+.6f}", "worse", sum(x > 0 for x in dd), "of", len(dd))
    # what the rule would select at the test origin
    print("test origin 2026-06-30:", {int(k): round(float(v), 4) for k, v in station_levels(rows, pd.Timestamp("2026-06-30")).items()})
    json.dump(out, open(Path(__file__).parent / "set2_l6.json", "w"), indent=1)
