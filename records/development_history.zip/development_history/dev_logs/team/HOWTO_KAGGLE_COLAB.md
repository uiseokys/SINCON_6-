# Kaggle·Colab에서 최종 예측을 다시 만드는 방법

작성: 2026-11-13 새벽, Claude. 두 노트북을 순서대로 실행하면 주후보 `submission_night_v4_main.csv` 가 나온다. 보수적 후보는 별도 노트북 하나로 만든다(아래 "보수적 후보").

- 1단계: `final_package/SINCON_final.ipynb` → `submission_clean_refined.csv`
- 2단계: `final_delivery_v2/SINCON_final_step2_layers.ipynb` → 주후보 (스위치를 켜면 별도 후보 15행도)

패키지 위치 (Codex 폴더 `/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/`):

| 파일 | 크기 | 내용 |
|---|---|---|
| `final_package/SINCON_final_package.zip` | 약 234MB | 1단계. 공식 CSV, 모델별 보관 예측, 학습 코드 포함 |
| `final_delivery_v2/SINCON_final_delivery_v2.zip` | 약 45MB | 2단계. 공식 CSV는 들어 있지 않다 |

## 무엇을 확인했고 무엇을 못 했나

| 확인한 것 (로컬 macOS, 실제 Jupyter 커널) | 결과 |
|---|---|
| 1단계를 새 Python 3.12 환경에서 설치 셀부터 실행 | 기준 파일과 바이트까지 일치 |
| 1단계를 새 Python 3.11 환경에서 같은 방식으로 실행 | 수치 일치(최대 log1p 차이 9e-16), 파일 해시는 다름 |
| 1단계 결과를 2단계에 넣어 이어서 실행 (3.12, 3.11 각각) | 주후보·별도 후보(15행) 모두 기준 파일과 log 차이가 1e-10을 넘는 행 0 (최대 9e-16) |
| 패키지 폴더를 읽기 전용으로 만들고 실행 (Kaggle의 `/kaggle/input` 과 같은 조건) | 1단계·2단계 모두 정상 |

**확인하지 못한 것**: Kaggle·Colab(리눅스)에서의 실제 실행. 아래 순서로 한 번 돌려 보고, 막히면 오류 메시지를 그대로 알려 주면 된다.

## Kaggle

1. 두 ZIP을 각각 풀어 **비공개 Dataset** 두 개로 올린다(`final_package` 폴더, `final_delivery_v2` 폴더). 외부 자료의 재배포 조건이 확인되지 않았으므로 공개로 올리지 않는다.
2. 새 Notebook을 만들고 오른쪽 **Add Input** 에서 위 Dataset 두 개와 대회 데이터를 붙인다. **Settings → Internet 을 켠다**(1단계의 패키지 설치에 필요).
3. `SINCON_final.ipynb` 를 File → Import Notebook 으로 불러와 **Run All**.
   - 첫 셀이 "이전 버전이 이미 로드되어 있습니다"로 멈추면 Run → Restart 후 다시 Run All 한다(설치는 이미 끝나 있다).
   - 결과: `/kaggle/working/sincon_assemble_<시각>/submission_clean_refined.csv` (1~2분).
4. 같은 방식으로 `SINCON_final_step2_layers.ipynb` 를 불러온다. 첫 설정 셀에서
   - `ROOT` 에 2단계 패키지 폴더를 적는다. 예: `/kaggle/input/<올린 Dataset 이름>/final_delivery_v2`
   - `BASELINE_CSV` 에 3번 결과의 **절대 경로**를 적는다. `/kaggle/input` 은 읽기 전용이라 패키지의 `input/` 폴더에 복사할 수 없기 때문이다. 비워 두면 패키지에 든 기준 파일로 진행한다(Python 3.12에서는 3번 결과와 바이트까지 같다).
   - **Run All** → `/kaggle/working/sincon_step2_<시각>/submission_night_v4_main.csv`
5. 별도 후보가 필요하면 `ENABLE_HEDGES = True` 로 바꿔 다시 실행한다 → `submission_night_v5_events_hedged15.csv`.

3번과 4번을 서로 다른 Notebook에서 돌리면 3번의 결과 파일이 4번에서 보이지 않는다. 한 Notebook 세션에서 이어서 돌리거나, 3번 Notebook의 출력을 4번 Notebook의 입력(Add Input → Notebook Output)으로 붙인다.

## Colab

1. 두 ZIP을 `/content` 에 올리고 푼다.
   ```
   !unzip -q /content/SINCON_final_package.zip -d /content
   !unzip -q /content/SINCON_final_delivery_v2.zip -d /content
   ```
2. `SINCON_final.ipynb` 를 열어 **모두 실행**. 첫 셀이 "이전 버전이 이미 로드되어 있습니다"로 멈추면 런타임 → 세션 다시 시작 후 모두 실행.
   - 결과: `/content/sincon_assemble_<시각>/submission_clean_refined.csv`
3. 그 파일을 `/content/final_delivery_v2/input/` 에 복사하고, 대회에서 받은 `train.csv`, `test.csv`, `metaData.csv` 를 `/content/final_delivery_v2/data/` 에 넣는다(같은 파일이 1단계 패키지의 `/content/final_package/payload/team/data/` 에 있다).
   ```
   !cp /content/sincon_assemble_*/submission_clean_refined.csv /content/final_delivery_v2/input/
   !cp /content/final_package/payload/team/data/{train,test,metaData}.csv /content/final_delivery_v2/data/
   ```
4. `SINCON_final_step2_layers.ipynb` 를 열고 첫 설정 셀의 `ROOT` 에 `"/content/final_delivery_v2"` 를 적은 뒤 **모두 실행** → `/content/sincon_step2_<시각>/submission_night_v4_main.csv`
   - `ROOT` 를 비워 두면 자동으로 찾지만, 보수적 후보 패키지까지 같은 `/content` 에 풀어 두면 패키지가 둘로 잡혀 멈춘다. 그래서 직접 적는 편이 안전하다.
   - 1단계를 여러 번 돌려 `sincon_assemble_*` 폴더가 여럿이면 위 복사 명령의 `*` 대신 쓸 폴더 이름을 직접 적는다.

## 1.5배 후보 (`submission_amp15_main.csv`)

주후보의 2단계 대신 쓰는 노트북이다. 1단계(`SINCON_final.ipynb`)는 똑같이 먼저 돌린다.

- 패키지: Codex 폴더 `amp_delivery/SINCON_amp15_delivery.zip` (약 33MB, 공식 CSV는 들어 있지 않다)
- Kaggle: ZIP을 풀어 비공개 Dataset으로 올리고 대회 데이터와 함께 Notebook에 붙인다. `SINCON_amp15.ipynb` 첫 셀의 `ROOT` 에 `/kaggle/input/<Dataset 이름>/amp_delivery`, `BASELINE_CSV` 에 1단계 결과의 절대 경로를 적고 Run All. 결과는 `/kaggle/working/sincon_amp15_<시각>/submission_amp15_main.csv`.
- Colab: `!unzip -q /content/SINCON_amp15_delivery.zip -d /content` 후 1단계 결과를 `/content/amp_delivery/input/` 에, 공식 CSV 세 개를 `/content/amp_delivery/data/` 에 복사한다. `ROOT` 에 `"/content/amp_delivery"` 를 적고 모두 실행.
- numpy·pandas만 쓰고 몇 초면 끝난다.
- 내가 확인한 것: 읽기 전용 패키지 폴더에서 실제 Jupyter 커널로 실행해 Python 3.12·3.11 모두 후보와 같은 값(최대 log 차이 2e-15).

## 월요일 대체공휴일 후보 (`submission_monday_main.csv`)

1.5배 후보와 같은 방식으로, 주후보의 2단계 대신 쓰는 노트북이다. 1단계는 똑같이 먼저 돌린다.

- 패키지: Codex 폴더 `monday_delivery/SINCON_monday_delivery.zip` (약 39MB, 공식 CSV는 들어 있지 않다)
- 첫 셀에서 `ROOT`(패키지 폴더), `BASELINE_CSV`(1단계 결과의 경로)를 적고 모두 실행. Kaggle은 `/kaggle/input/<Dataset 이름>/monday_delivery`, Colab은 `"/content/monday_delivery"` 이고 공식 CSV 세 개를 그 안의 `data/` 에 둔다(Kaggle은 대회 데이터를 붙이면 된다).
- 결과: `sincon_monday_<시각>/submission_monday_main.csv`. numpy·pandas만 쓰고 몇 초면 끝난다.
- 내가 확인한 것: 읽기 전용 패키지 폴더에서 실제 Jupyter 커널로 실행해 Python 3.12·3.11 모두 후보와 차이 0.

## 보수적 후보 (`submission_conservative_main.csv`)

예측 기간의 생활이동·버스 자료를 쓰지 않는 후보는 노트북 하나로 다시 만든다. 위 두 노트북과는 별개다.

- 패키지: Codex 폴더 `conservative_delivery/SINCON_conservative_delivery.zip` (약 237MB, 공식 CSV 포함, 제외한 생활이동·버스 원자료는 들어 있지 않다)
- 노트북: `conservative_delivery/SINCON_conservative.ipynb`
- Kaggle: ZIP을 풀어 비공개 Dataset으로 올리고 Notebook에 붙인 뒤(Internet 켜기), 노트북을 불러와 Run All. 폴더를 못 찾으면 첫 셀의 `ROOT` 에 `/kaggle/input/<Dataset 이름>/conservative_delivery` 를 적는다. 결과는 `/kaggle/working/sincon_conservative_<시각>/submission_conservative_main.csv`.
- Colab: `!unzip -q /content/SINCON_conservative_delivery.zip -d /content` 후 노트북을 열어 모두 실행. 결과는 `/content/sincon_conservative_<시각>/`.
- 설치 셀이 "설치 전 버전이 메모리에 있습니다"로 멈추면 런타임을 다시 시작하고 모두 실행한다.
- 기본 모드(`REFIT=False`)는 보관한 보수적 모델 예측에서 최종 CSV를 조립한다(1분 안팎). `REFIT=True` 는 영향받은 모델을 생활이동·버스 열 없이 다시 맞춘다(로컬 CPU에서 구간당 1~5분, 11개 구간. 패키지 검사에서는 노트북 전체가 약 23분. Kaggle·Colab에서는 재지 못했다).
- 내가 확인한 것: 읽기 전용 패키지 폴더에서 실제 Jupyter 커널로 실행해 Python 3.12는 기준 파일과 바이트까지 일치, Python 3.11은 수치 일치(해시는 다름).

## 알아 둘 점

- 1단계 노트북은 Python 3.11·3.12에서만 실행된다(첫 셀에서 검사). Colab은 2025-08에 3.12로 올라갔고 Kaggle도 2025-12에 3.12 전환 작업이 있었다(웹 검색으로 확인, 2026-11-13 조회).
- 1단계의 기본 모드 `RUN_MODE="assemble"` 은 보관한 모델별 예측에서 최종 CSV를 조립한다. `RUN_MODE="full"` 은 train.csv부터 주요 모델을 다시 학습한다(2025년 벡터 입력의 일부 선행 예측은 패키지에 든 보관본을 다시 쓴다).
  - 로컬 CPU에서 `full` 전체에 약 5.5시간이 걸렸다(기본 신경망 30시드 3.9시간, rolling 51분, 스택 10분, 시간별 XGBoost 6분, 행사 응답 19분, TabICL 4분, 벡터 3분). Kaggle·Colab에서의 시간은 재지 못했다. GPU를 켜고 돌리는 편이 안전하다.
  - `full` 결과는 제출 기준 파일과 99.85%의 행이 log 차이 0.01 이내로 같고(RMS log 차이 0.0027), 검증 점수는 A/B/C 모두 0.00005 이내로 같았다. 기본 신경망과 rolling 은 먼저 끝난 재학습 결과를 이어받아 잰 값이다. 바이트로는 같지 않다(신경망이 기기에 따라 조금 달라짐).
- 2단계는 numpy·pandas만 쓰고 몇 초면 끝난다. 난수·GPU를 쓰지 않는다.
- 2단계는 1단계 결과가 기준 파일과 수치로 같을 때만(최대 log1p 차이 1e-9 이하) 진행한다. `full` 재학습 결과는 신경망 때문에 그보다 크게 달라질 수 있어 2단계가 멈춘다. 그 경우는 보관 예측(`assemble`)으로 만든 파일이 제출 파일의 기준이라는 점을 설명에 적어야 한다.

## K1·K3 후보 (11/13 오후 추가) — `hourbias_delivery/SINCON_hourbias.ipynb`

1. 1단계 `final_package/SINCON_final.ipynb` → `submission_clean_refined.csv`
2. 2단계 `final_delivery_v2/SINCON_final_step2_layers.ipynb` → `submission_night_v4_main.csv`
3. `hourbias_delivery/SINCON_hourbias.ipynb` 첫 코드 셀의 `BASELINE_CSV` 에 2번 출력의 절대 경로를 적고 전체 셀 실행 → `submission_k1_hourbias.csv`, `submission_k3_hourbias_holiday_events.csv`

- pandas와 numpy만 쓰고 1분 안에 끝난다. GPU 불필요.
- Kaggle: `SINCON_hourbias_delivery.zip` 을 비공개 Dataset으로 올리면 `/kaggle/input/<이름>/hourbias_delivery` 를 자동으로 찾는다. 출력은 `/kaggle/working`.
- Colab: `/content` 에 ZIP을 풀면 `/content/hourbias_delivery` 를 자동으로 찾는다. 출력은 `/content/outputs`.
- `BASELINE_CSV` 를 비워 두면 패키지에 든 기준 파일로 진행한다.
- 마지막 셀이 출력과 팀 제출 파일의 최대 log 차이를 출력한다(1e-9 이하면 재현).

## 현재 최고 파일까지의 전체 순서 (11/13 18:30 추가)

현재 최고는 `submission_rail_factors_k30_hour_on_xgb7.csv` (Public 0.143043)이다. 노트북 네 개를 차례로 실행한다. 뒤의 두 개는 pandas와 numpy만 쓰고 GPU가 필요 없다.

| 순서 | 패키지 (Codex 폴더) | 노트북 | 입력 | 출력 |
|---|---|---|---|---|
| 1 | `final_package/` | `SINCON_final.ipynb` | 공식 CSV, 보관 예측 | `submission_clean_refined.csv` |
| 2 | `final_delivery_v2/` | `SINCON_final_step2_layers.ipynb` | 1번 출력 | `submission_night_v4_main.csv` (0.146049) |
| 3 | `final_stack_delivery/` | `SINCON_final_stack.ipynb` | 2번 출력 | 7개 단계의 CSV. 마지막이 `submission_xgb7_w10_on_curvature.csv` (0.144715, 타 노선 자료 없음) |
| 4 | `rail_delivery_v5/` | `SINCON_rail_factors_k30.ipynb` | 3번의 마지막 출력 | `submission_rail_factors_k30_on_xgb7.csv` (0.143123), `submission_rail_factors_k30_hour_on_xgb7.csv` (0.143043) |

- 3번과 4번은 첫 코드 셀의 `BASELINE_CSV` 에 앞 단계 출력의 절대 경로를 적는다. 비워 두면 패키지에 든 기준 파일로 진행한다.
- Kaggle: 각 ZIP을 풀어 비공개 Dataset으로 올리면 노트북이 `/kaggle/input/<이름>/<패키지 폴더>` 를 찾는다. 출력은 `/kaggle/working`. 3번은 `/kaggle/working/sincon_outputs`.
- Colab: `/content` 에 ZIP을 풀면 `/content/final_stack_delivery`, `/content/rail_delivery_v5` 를 찾는다. 출력은 `/content/outputs`.
- 3번은 단계마다, 4번은 마지막 셀에서 출력과 팀 제출 파일의 최대 log 차이를 출력한다(1e-9 이하면 재현).
- 로컬 확인: 3번과 4번 모두 읽기 전용으로 푼 패키지에서 실제 Jupyter 커널(Python 3.12, 3.11)로 실행해 제출 파일과 바이트까지 일치했다. 4번의 입력은 패키지에 든 기준 파일(3번 출력과 바이트 일치)로 확인했다.
- **확인하지 못한 것**: Kaggle·Colab 실행, 1번부터 4번까지를 한 세션에서 이어 돌린 실행.
- 4번은 다른 노선의 2026년 7~10월 일별 승차 실측을 쓴다. 규칙 4절 첫 항목의 문구에 해당하며 허용 근거는 운영진의 구두 답변이다(`RULES_TEXT_AS_PASTED_20261113.md`, `RAIL_PREREGISTRATION.md`). 타 노선 자료 없이 끝내려면 3번 출력이 최종이다.

## Colab에서 한 번에 실행 (11/13 18:40 추가)

위 표의 3번과 4번을 한 노트북으로 묶었다: Codex 폴더의 `colab_k30_hour/SINCON_colab_k30_hour.ipynb`.

1. Colab에서 노트북을 열고, 같은 폴더의 ZIP 두 개(`SINCON_final_stack_delivery.zip`, `SINCON_rail_delivery_v5.zip`)를 왼쪽 파일 창에 올린다(올리지 않으면 업로드 창이 뜬다).
2. 모두 실행 → `/content/sincon_k30_hour/submission_rail_factors_k30_hour_on_xgb7.csv` (자동 내려받기).

- 기본 시작 입력은 패키지에 든 주후보다. 1번·2번 노트북으로 만든 주후보에서 시작하려면 첫 셀의 `BASELINE_CSV` 에 그 경로를 적는다.
- 로컬 확인: pandas 2.2.2·numpy 2.0.2 커널에서 수치 일치(최대 log 차이 1.8e-15), pandas 3.1.1·numpy 2.5.4 또는 `PIN_VERSIONS = True` 에서 바이트 일치. **Colab 실행은 확인하지 못했다.**
