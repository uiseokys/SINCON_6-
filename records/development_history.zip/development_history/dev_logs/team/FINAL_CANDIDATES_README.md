# 제출할 파일 (2026-11-13 새벽 정리)

자세한 설명은 한 단계 위 폴더의 `FINAL_REPORT.md` 에 있다. 마감은 11/13(금) 21:00.

| 순서 | 파일 | 무엇 | 주후보와 다른 행 | SHA-256 앞 12자리 |
|---|---|---|---|---|
| 1 | `submission_night_v4_main.csv` | **주후보.** 깨끗한 출발점 + 검증을 통과한 보정 6개. **Public 0.146049** | — | 4c85257294be |
| 1-b | `submission_amp15_main.csv` | 주후보 + 1단계의 역 프로필·벡터 두 층 1.5배. 사전 기록한 기준 충족(과거 8개 기준일 모두 개선, 폭은 작음). **Public 0.146197 → 최종에서 제외** | 157,192 | 06f589ba349f |
| 1-c | `submission_monday_main.csv` | 주후보 + 월요일 대체공휴일(8/17, 10/5) 보정. 사전 기록한 기준 충족(발동한 과거 기준일 4개 모두 개선, 폭은 0.00001~0.00003) | 2,016 | f503ec607953 |
| **1-d** | `submission_k1_hourbias.csv` | **새 주후보 (11/13 오후).** 주후보 + 일반일 역·요일·시간대 오차 보정(K1). 과거 7개 기준일 중 5개 개선·2개 악화. **Public 0.145606** | 129,636 | b8d7499f2151 |
| 1-e | `submission_k3_hourbias_holiday_events.csv` | K1 + 월요일 대체공휴일 + 코리아컵 4행 + 걷기대회 7행. **Public 0.145606** (K1과 여섯 자리까지 같음) | 131,656 | 92a0f8dd6b0f |
| 2 | `submission_night_v5_events_hedged15.csv` | 주후보 + 문학경기장역 행사 추정 15행 (검증하지 못한 추정). **Public 0.146236 → 최종에서 제외** | 15 | 9b01382c398f |
| 3 | `submission_conservative_main.csv` | **보수적 후보.** 예측 기간(7~10월)의 생활이동·버스 자료를 쓰지 않은 경로. 검증에서 주후보 경로보다 0.001~0.007 나쁨 | 157,192 | 99fdd9ce0587 |
| 예비 | `submission_night_v5_main_no_ticket.csv` | 주후보에서 PLAVE 예매 수량을 쓴 2행만 되돌림. 예매 수량(KOPIS)의 이용 조건이 끝내 확인되지 않을 때 주후보 대신 쓴다 | 2 | 5127c80e5ab7 |

여섯 파일 모두 157,194행, `example_id` 순서가 `test.csv` 와 같고, 값은 유한한 양수다. Public은 1번 0.146049, 1-b 0.146197, 1-c 0.146049(1번과 여섯 자리까지 같음), 2번 0.146236. 3번과 예비는 아직 미측정.

## 최종 2개 고르기

**결정 갱신 (2026-11-13 14:20): 1-d(K1) + 3번 보수적 후보.** 제출 한도가 100회로 늘어, 값을 과거 자료로 먼저 고정한 후보 K1·K2·K3를 한 번씩 제출했다(`../CANDIDATE_SET_PREREGISTRATION.md`). Public은 K1 0.145606, K2 0.146049, K3 0.145606. 사전에 적은 대로 Public이 가장 좋은 것을 주후보 자리에 둔다. K1과 K3는 점수가 같아, 재현에 필요한 단계가 적은 K1을 고른다. 점수를 본 뒤 K1의 값(0.25, 84일 등)을 바꾸거나 다른 배율을 만들지 않는다. K1·K3의 재현 노트북은 `hourbias_delivery/SINCON_hourbias.ipynb`.

**이전 결정 (2026-11-13 오전): 1번 주후보 + 3번 보수적 후보.** 1-b(0.146197)는 1번(0.146049)보다 낮아 사전 기록대로 1번을 골랐다. 결과를 보고 값을 다시 고치지 않는다. 아래는 그 결정의 배경과 예외 조건이다.

- Public 점수를 보고 **이 파일들 중에서 고르는 것**은 규칙이 허용한다. 점수를 보고 값을 다시 고치는 것은 안 된다.
- 1번과 2번은 15행만 다르다. 점수 차이는 재지 못했다(두 예측 사이의 전체 RMS log 거리는 0.0069).
- 예측 기간의 생활이동·버스 자료 사용을 운영진이 문제 삼을 가능성을 걱정한다면 **1번(또는 2번) + 3번**, 걱정하지 않는다면 **1번 + 2번**.
- 1번의 Public이 이미 제출한 출발점 `submission_clean_refined.csv`(0.148046)보다 나쁘면 출발점을 최종으로 골라도 된다(깨끗한 파일, 1단계 노트북으로 재현됨).
- **고르면 안 되는 제출**: 이미 올라가 있는 0.147741 파일(`submission_0p15126_event_cancel_fix.csv`)과 그 이전 제출들. Public 점수로 정한 값이 들어 있다. 최종 2개를 직접 고르지 않으면 Kaggle이 Public 점수 순으로 자동으로 골라 이 파일이 들어갈 수 있다.

## 각 파일을 다시 만드는 방법

| 파일 | 노트북 |
|---|---|
| 1, 2, 예비 | 1단계 `final_package/SINCON_final.ipynb` → 2단계 `final_delivery_v2/SINCON_final_step2_layers.ipynb` (2번은 `ENABLE_HEDGES = True`. 예비는 `ENABLED` 의 `plave22=False` 로 바꿔 실행하면 `EXPERIMENT_layers_disabled.csv` 라는 이름으로 나온다. 예비 파일과 바뀐 행 0임을 확인했다) |
| 3 | `conservative_delivery/SINCON_conservative.ipynb` (노트북 하나, 기본 모드로 1분 안팎) |
| 1-b | 1단계 `final_package/SINCON_final.ipynb` → `amp_delivery/SINCON_amp15.ipynb` |
| 1-c | 1단계 `final_package/SINCON_final.ipynb` → `monday_delivery/SINCON_monday.ipynb` |
| 1-d, 1-e | 1단계 → 2단계 `final_delivery_v2/SINCON_final_step2_layers.ipynb` → `hourbias_delivery/SINCON_hourbias.ipynb` (1-e는 `monday_delivery` 출력과 `goal_014/release` 의 코리아컵·걷기대회 파일도 입력으로 받는다. 비워 두면 패키지의 기준 파일을 쓴다) |

실행 순서는 한 단계 위 폴더의 `HOWTO_KAGGLE_COLAB.md`.

---

## 갱신 (2026-11-13 17:15)

| 파일 | 무엇 | Public | 재현 노트북 |
|---|---|---:|---|
| `submission_xgb7_w10_on_curvature.csv` (SHA 596876180bb0) | 주후보 → K1 → K3 → 검단·PLAVE → 계절 재적합 → L1 → 시간대 고주파 패턴 → 7개 역 XGBoost 차이 10% | **0.144715** | **있음.** `final_stack_delivery/SINCON_final_stack.ipynb`. Claude가 ZIP(SHA aeefd5fbf121…)을 빈 폴더에 풀어 읽기 전용으로 두고 실제 Jupyter 커널(Python 3.12, 3.11)로 실행해 0~7단계 출력이 모두 기준 파일과 바이트 일치함을 확인 |
| `submission_xgbbeta_v2_on_curvature.csv` (SHA db1020fc0923) | 위에서 마지막 층만 "역별 절반 β"로 바꾼 것 | 0.144705 | 없음 |

- **현재 권고**: 최종 첫 번째 자리는 `submission_xgb7_w10_on_curvature.csv`(재현 검증 완료), 두 번째는 `submission_conservative_main.csv`.
- `submission_xgbbeta_v2_on_curvature.csv` 는 Public이 0.00001 좋지만 노트북이 없다. 노트북을 만들어 검증하기 전에는 최종으로 고르지 않는다.
- 과거 검증과 사전 기록은 `../CANDIDATE_SET_PREREGISTRATION.md`, `../CANDIDATE_SET2_PREREGISTRATION.md`, 층별 점검은 `../STACK_AUDIT_1113.md`.

## 갱신 (2026-11-13 17:45)

| 파일 | 무엇 | Public | 재현 노트북 |
|---|---|---:|---|
| `submission_rail_shift_on_xgb7.csv` (SHA e8313425bff3) | 0.144715 파일 + 타 노선(경인선·수인선 25개 역) 변화 옮기기. **7~10월 타 노선 실측을 쓴다. 운영진 허용은 구두 확인뿐** | **0.144427** | 있음. `rail_delivery/SINCON_rail_shift.ipynb` (ZIP SHA 2f889f18d014c4ce…). 실제 커널 Python 3.12·3.11에서 바이트 일치 |

- 이 파일을 최종으로 고르려면 운영진의 서면 확인을 받아 두는 것이 안전하다. 사전 기록과 한계는 `../RAIL_PREREGISTRATION.md`.
- 권고: 첫 번째 `submission_rail_shift_on_xgb7.csv`, 두 번째 `submission_xgb7_w10_on_curvature.csv`(타 노선 자료 미사용, 0.144715). 이렇게 두면 타 노선 자료 사용이 문제 돼도 한 파일이 남는다. 다만 이 경우 예측 기간의 생활이동·버스 자료 사용에 대한 대비(보수적 후보)는 빠진다. 어느 위험을 대비할지는 팀이 정한다.

## 갱신 (2026-11-13 18:45)

| 파일 | 무엇 | Public | 재현 노트북 |
|---|---|---:|---|
| `submission_rail_final_on_xgb7.csv` (SHA e45824619989) | 0.144715 파일 + 타 노선 변화 옮기기 + 공휴일류 수준 보정, 기존 행사·명절 보정 역·날짜 보호. **7~10월 타 노선 실측 사용(구두 허용 전제)** | **0.144280** | 있음. `rail_delivery_v2/SINCON_rail_final.ipynb` (ZIP SHA a5b5df5ae950bf0d…). 실제 커널 Python 3.12·3.11에서 바이트 일치 |

- **현재 권고**: 첫 번째 `submission_rail_final_on_xgb7.csv`(0.144280), 두 번째 `submission_xgb7_w10_on_curvature.csv`(0.144715, 타 노선 자료 미사용). 실행 순서: `final_package` → `final_delivery_v2` → `final_stack_delivery` → `rail_delivery_v2`.

## 갱신 (2026-11-13 18:00)

| 파일 | 무엇 | Public | 재현 노트북 |
|---|---|---:|---|
| `submission_rail_factors_on_xgb7.csv` (SHA 719fb4fb966b) | 0.144715 파일 + 전 노선(7호선·환승역 제외 544개 역) 주성분으로 변화 옮기기 + 공휴일류 수준 보정. **7~10월 타 노선 실측 사용(구두 허용 전제)** | **0.143777** | 있음. `rail_delivery_v3/SINCON_rail_factors.ipynb` (ZIP SHA 69c3b064dfcdeb62…). 실제 커널 Python 3.12·3.11에서 바이트 일치 |

- **현재 권고**: 첫 번째 `submission_rail_factors_on_xgb7.csv`(0.143777), 두 번째 `submission_xgb7_w10_on_curvature.csv`(0.144715, 타 노선 자료 미사용). 실행 순서: `final_package` → `final_delivery_v2` → `final_stack_delivery` → `rail_delivery_v3`.

## 갱신 (2026-11-13 18:25)

| 파일 | 무엇 | Public | 재현 노트북 |
|---|---|---:|---|
| `submission_rail_factors_k12_on_xgb7.csv` (SHA b3767450472b) | 0.144715 파일 + 전 노선(7호선·환승역 제외 544개 역) 주성분 12개로 변화 옮기기(일반일 0.15·공휴일류 0.3) + 공휴일류 수준 보정. **7~10월 타 노선 실측 사용(구두 허용 전제)** | **0.143545** | 있음. `rail_delivery_v4/SINCON_rail_factors_k12.ipynb` (ZIP SHA 087ba3184d4d8b19…). 실제 커널 Python 3.12·3.11에서 바이트 일치 |

- **현재 권고**: 첫 번째 `submission_rail_factors_k12_on_xgb7.csv`(0.143545), 두 번째 `submission_xgb7_w10_on_curvature.csv`(0.144715, 타 노선 자료 미사용).
- **규칙 관련 주의**: 첫 번째 파일은 규칙 4절 문구("2026년 7월 이후의 실제 지하철 승차·하차 인원")만 보면 금지 범위에 든다. 운영진의 구두 허용(대회 대상이 아닌 노선은 가능, 7호선·환승역 제외)에 기대고 있다. 서면 확인이 없으면 최종 검증에서 근거를 대기 어렵다.

## 갱신 (2026-11-13 18:23)

| 파일 | 무엇 | Public | 재현 노트북 |
|---|---|---:|---|
| `submission_rail_factors_k30_on_xgb7.csv` (SHA 13b0ff73fb7d) | 0.144715 파일 + 전 노선 주성분 30개로 변화 옮기기(일반일 0.2·공휴일류 0.3) + 공휴일류 수준 보정 | **0.143123** | 있음. `rail_delivery_v5/SINCON_rail_factors_k30.ipynb` (ZIP SHA 3adf639a1c8bddc9…), 실제 커널 Python 3.12·3.11 바이트 일치 |
| `submission_rail_factors_k30_hour_on_xgb7.csv` (SHA aa4557445565) | 위 + 시간대별 반응 층(0.1) | 미측정 | 같은 노트북의 두 번째 출력, 바이트 일치 |

- **규칙 주의(변함없음)**: 타 노선의 7~10월 실측을 쓰는 파일은 규칙 4절 첫 항목의 문구에 해당한다(`../RULES_TEXT_AS_PASTED_20261113.md`). 허용 근거는 운영진의 구두 답변뿐이다. 타 노선 자료를 쓰지 않은 파일은 `submission_xgb7_w10_on_curvature.csv`(0.144715)이다.

## 갱신 (2026-11-13 18:27)

- `submission_rail_factors_k30_hour_on_xgb7.csv` Public **0.143043** (사용자 전달). 현재 최고. 재현은 `rail_delivery_v5/SINCON_rail_factors_k30.ipynb`.
- (18:40) Colab에서 한 번에 실행하는 노트북: Codex 폴더 `colab_k30_hour/SINCON_colab_k30_hour.ipynb` (+ ZIP 두 개). 로컬 커널 확인만 했고 Colab 실행은 미확인.
