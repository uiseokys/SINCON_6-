# 최종 패키지 안내 (2026-11-13 05:30 KST, Claude 작성)

이 폴더에는 작업 폴더가 많다. 최종 제출과 재현에 쓰는 것은 아래 세 패키지뿐이다. 전체 설명은 팀 폴더의 문서를 먼저 본다.

- 전체 보고: `/Users/jeong-uiseok/sincon-2026/sincon-baseline/FINAL_REPORT.md`
- 실행 순서: `/Users/jeong-uiseok/sincon-2026/sincon-baseline/HOWTO_KAGGLE_COLAB.md`
- 제출 파일: `/Users/jeong-uiseok/sincon-2026/sincon-baseline/FINAL_CANDIDATES/`

| 패키지 | ZIP (SHA-256 앞 16자리) | 노트북 | 만드는 것 |
|---|---|---|---|
| `final_package/` | `SINCON_final_package.zip` (aae2742cb7b6c560) | `SINCON_final.ipynb` | 1단계 `submission_clean_refined.csv` |
| `final_delivery_v2/` | `SINCON_final_delivery_v2.zip` (636ace33b614da5a) | `SINCON_final_step2_layers.ipynb` | 2단계 주후보 `submission_night_v4_main.csv`, 선택 시 15행 별도 후보 |
| `conservative_delivery/` | `SINCON_conservative_delivery.zip` (38cb75a74e35aaa3) | `SINCON_conservative.ipynb` | 보수적 후보 `submission_conservative_main.csv` |
| `amp_delivery/` (11/13 아침 추가) | `SINCON_amp15_delivery.zip` (ea4677501b7b4e99) | `SINCON_amp15.ipynb` | 1.5배 후보 `submission_amp15_main.csv` (1단계 출력을 입력으로 받음) |
| `monday_delivery/` (11/13 오전 추가) | `SINCON_monday_delivery.zip` (c2970b5827753a2b) | `SINCON_monday.ipynb` | 월요일 대체공휴일 후보 `submission_monday_main.csv` (1단계 출력을 입력으로 받음) |
| `hourbias_delivery/` (11/13 오후 추가) | `SINCON_hourbias_delivery.zip` (fb14e89d29ced04a) | `SINCON_hourbias.ipynb` | **현재 주후보 K1** `submission_k1_hourbias.csv` (Public 0.145606)와 K3. 2단계 출력(주후보)을 입력으로 받음 |
| `final_stack_delivery/` (11/13 17시 추가, Codex 작성·Claude 검증) | `SINCON_final_stack_delivery.zip` (aeefd5fbf1210395) | `SINCON_final_stack.ipynb` | **현재 최종 후보** `submission_xgb7_w10_on_curvature.csv` (Public 0.144715). 주후보(2단계 출력)를 입력으로 받아 0~7단계를 차례로 계산. 실제 커널 Python 3.12·3.11에서 모든 단계 바이트 일치 |
| `rail_delivery_v2/` (11/13 18:45 추가) | `SINCON_rail_delivery_v2.zip` (a5b5df5ae950bf0d) | `SINCON_rail_final.ipynb` | **현재 최고** `submission_rail_final_on_xgb7.csv` (Public 0.144280). `final_stack_delivery` 출력을 입력으로 받음. 경인선·수인선 7~10월 실측 사용(구두 허용 전제, `RAIL_PREREGISTRATION.md`). `rail_delivery/` 는 그 앞 판(0.144427) |
| `rail_delivery_v3/` (11/13 18:00 추가) | `SINCON_rail_delivery_v3.zip` (69c3b064dfcdeb62) | `SINCON_rail_factors.ipynb` | **현재 최고** `submission_rail_factors_on_xgb7.csv` (Public 0.143777). `final_stack_delivery` 출력을 입력으로 받음. 7호선·환승역을 뺀 전 노선 544개 역의 7~10월 실측 사용(구두 허용 전제) |
| `rail_delivery_v4/` (11/13 18:25 추가) | `SINCON_rail_delivery_v4.zip` (087ba3184d4d8b19) | `SINCON_rail_factors_k12.ipynb` | **현재 최고** `submission_rail_factors_k12_on_xgb7.csv` (Public 0.143545). 주성분 12개, 일반일 0.15·공휴일류 0.3. v3는 주성분 5개 판(0.143777) |
| `rail_delivery_v5/` (11/13 18:23 추가) | `SINCON_rail_delivery_v5.zip` (3adf639a1c8bddc9) | `SINCON_rail_factors_k30.ipynb` | **현재 최고** `submission_rail_factors_k30_on_xgb7.csv` (Public 0.143123)와 시간대 층을 더한 `submission_rail_factors_k30_hour_on_xgb7.csv`(미측정). v4는 주성분 12개 판(0.143545) |
| `colab_k30_hour/` (11/13 18:40 추가) | 위 두 ZIP(`SINCON_final_stack_delivery.zip`, `SINCON_rail_delivery_v5.zip`)의 사본 | `SINCON_colab_k30_hour.ipynb` | Colab에서 한 번에 실행하는 노트북. 주후보에서 `submission_rail_factors_k30_hour_on_xgb7.csv` (Public 0.143043)까지. 로컬 커널 확인만 했고 Colab 실행은 미확인 |

## 패키지 문서에서 달라진 점 (패키지 파일은 고치지 않았다)

- `final_package/STATUS.md` 는 01:52 기준이다. 그 뒤의 전체 재학습 결과는 `full_verification/FULL_RUN_RESULT.md` 에 있다. 백그라운드 실행은 04:15에 오래된 실행 사본 문제로 멈췄고, 현재 패키지로 이어 돌려 끝냈다(재학습 결과와 기준 파일의 RMS log 차이 0.0027, 검증 A/B/C 차이 0.00005 이내).
- `final_delivery_v2/README.md` 의 Kaggle 안내는 "1단계 출력을 `input/` 에 복사"라고 적혀 있다. Kaggle의 `/kaggle/input` 은 읽기 전용이라 복사할 수 없다. 노트북 첫 셀의 `BASELINE_CSV` 에 1단계 출력의 절대 경로를 적거나, 비워 두고 패키지에 든 기준 파일로 진행한다.
- `final_delivery/` 는 옛 v1이다. v2를 쓴다.
- `conservative/reproduce.py` 는 작업용 CLI다. 제외한 생활이동·버스 원자료를 해시 확인용으로 연다(수치로는 쓰지 않음). 배포용 `conservative_delivery/` 에는 그 원자료가 들어 있지 않다.

## 검증·감사 문서

| 무엇 | 어디 |
|---|---|
| 주후보 독립 감사 | `final_audit/AUDIT_REPORT.md` |
| 감사 후속 (순방향 검증, 15행 검토) | `night11/ROUND11_RESULT.md` |
| 보정 크기 검증 (넣지 않음) | `night12/ROUND12_RESULT.md` |
| 보수적 후보 측정 | `conservative/CONSERVATIVE_RESULT.md` |
| 보수적 후보 독립 감사 | `conservative_audit/AUDIT_REPORT.md` |
| 전체 재학습 검증 | `full_verification/FULL_RUN_RESULT.md` |
| 외부 자료 출처와 이용 조건 | `night6/SOURCES_FINAL.md`, `night_sources/SOURCES_AUDIT.md` |

## 규칙 관련 주의

- Public 점수로 값을 정하지 않는다. 완성된 후보 중에서 고르는 데만 쓴다. 자세한 경위는 `RULES_NOTICE_PUBLIC_SCORE.md`.
- 2026년 7월 이후 지하철 승하차 실측은 쓰지 않는다.
- 패키지에는 외부 자료와 대회 공식 CSV가 들어 있다. Kaggle Dataset으로 올릴 때는 비공개로 올린다.
