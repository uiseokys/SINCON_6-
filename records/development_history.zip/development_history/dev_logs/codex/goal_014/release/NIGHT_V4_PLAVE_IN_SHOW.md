# PLAVE 공연 중 승차 예측 보정

문학경기장역의 2026년 9월 12·13일 19시와 20시 네 행을 보정했다. 공식 공연 공지에서 양일 19시 시작을 확인했다. 같은 장소의 과거 공연마다 시작 시각이 속한 시간과 그다음 한 시간을 맞춰 비교했다. 일정 확인에는 공식 예매처와 공연 주최 공지의 날짜·시각을 사용했고, 조회일은 2026-11-13 KST다. [PLAVE 공식 공지](https://weverse.io/plave/notice/36575?hl=ko) · [과거 공연 일정 출처](../../night5/research_sources.csv) · [대회 외부 자료 출처](../../final_package/docs/SINCON_EXTERNAL_SOURCES.md)

과거 공연별로 `log1p(실제 승차) − log1p(보관 예측)`의 중앙값을 구하고, 같은 시간대에서 공연별 중앙값을 한 번 더 집계했다. 각 검증에는 예측 기준일보다 먼저 전 회차가 끝난 다른 공연만 사용했다. 계산한 오차를 −0.30~0 범위로 제한하고 35%를 적용했다. 최종 적용량은 두 시간대 모두 −0.105다. 학습 승차는 공식 train의 2026-06-30까지 자료다.

| 시간 순서 검증 | 평가 행 | 기존 RMSLE | 보정 RMSLE |
|---|---:|---:|---:|
| MUSE | 2 | 0.221176 | 0.174672 |
| 진 | 4 | 0.683219 | 0.632128 |
| 박효신 | 6 | 0.580676 | 0.491405 |
| 통합 | 12 | 0.576491 | 0.508940 |

기준은 문학경기장역의 보관 Night v4 예측이다. 계절·요일 보정은 이 역을 제외한다. 검증은 세 공연 계열의 시작 두 시간만 평가했고, 전체 평가 기간 점수의 개선을 입증하는 규모는 아니다. 먼저 열린 YE는 후속 공연의 추정에만 썼다. 새 보정은 예매 건수를 사용하지 않는다. 기존 22시 보정에는 사용자가 확인한 KOPIS 예매 수치 23,120건·19,494건이 이미 들어 있다. 실제 입장객 수나 종료 시각은 이 수치로 확인할 수 없다. [기존 22시 계산](../../final_delivery_v2/final_layers.py:211) · [KOPIS 인용 예매 수치](https://public.ai.kr/ko/performances/plave-world-tour-keep-it-manic-%EC%9D%B8%EC%B2%9C-PF294050) · [공연시설별통계 API 이용 조건](https://www.data.go.kr/data/15097819/openapi.do?recommendDataYn=Y)

아래 명령은 공식 대회 ZIP과 보관 예측, 지정한 계절·요일 CSV를 읽어 새 CSV를 만든다. Python 3.12.15, NumPy 2.5.4, pandas 3.1.1에서 실행했다. 난수는 사용하지 않는다.

```sh
python -B goal_014/bottleneck/build_v4_plave_in_show.py \
  --official /path/to/sincon-2026.zip \
  --base goal_014/release/submission_night_v4_main_seasonal_weekday.csv \
  --output /tmp/submission_night_v4_main_seasonal_weekday_plave_in_show.csv \
  --report /tmp/v4_plave_in_show_report.json
```

기존 모델부터 재현하려면 [계절·요일 보정 안내](NIGHT_V4_SEASONAL_WEEKDAY.md)를 먼저 실행한다. 공식 `test.csv`의 ID 157,194개와 순서가 일치하며 157,190행은 원본과 바이트 단위로 같다. 기존 보호표 298행과 두 공연의 21~23시 예측을 확인했다. 계절·요일 기준 출력 SHA-256은 `d6d9628fad40161d19d1ec9515f3c96f5fbc27ade236a966270d904c1bb62ca3`다. [제출 CSV](submission_night_v4_main_seasonal_weekday_plave_in_show.csv) · [검증 및 행별 값](../bottleneck/v4_plave_in_show_report.json)
