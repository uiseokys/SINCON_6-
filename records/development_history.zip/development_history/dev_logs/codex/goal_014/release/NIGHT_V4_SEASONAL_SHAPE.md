# Night v4 계절별 시간대 보정

대회 공식 train의 2026-06-30까지 승차 실측과 Night v4의 보관 검증 예측을 사용한다. 별도의 외부 자료를 추가하지 않는다. 달력과 행사 보호표는 v4 조립 패키지와 동일하다. [기존 외부 입력 출처](../../final_package/docs/SINCON_EXTERNAL_SOURCES.md) · [기존 이용 조건 감사](../../night_sources/SOURCES_AUDIT.md)

각 기준일보다 앞서 생성됐고 해당 기준일까지 실제 승차를 관측한 검증 행만 사용한다. 같은 날짜·역·시간의 예측이 여럿이면 가장 최근 기준일의 예측을 쓴다. `log1p(실제) - log1p(예측)`을 ±0.45로 제한하고 역·날짜의 하루 평균을 뺀다. 역·시간·평일/주말별로 목표 월 15일의 전후 92일 이내 과거 값을 가까운 순서에 가중해 집계한다. 관측이 적은 그룹은 분모에 28일을 더해 0으로 수축한다. 보정은 ±0.12 제한 후 35%를 반영하고, 날짜·역 단위에서 로그 보정의 평균을 다시 0으로 맞춘다. 공휴일 인접일, 보호 행사, 신규 3개 역과 문학경기장·송도달빛축제공원·인천대공원·부천종합운동장역은 제외한다. 기존 코리아컵·걷기대회 보정도 이 두 행사역에 있다. 후보는 기준인 원본 Night v4에서 생성했다.

중첩 검증의 적용 가능한 8개 기준일 중 7개 개선, B에서 0.000071 악화했다. 적용 구간은 서로 겹친다. 날짜가 겹치지 않는 A·C 통합은 0.154719에서 0.154599로, 2025년 7월 말 기준의 이후 검증은 0.174278에서 0.174161로 개선했다. 가장 이른 2025년 6월 말 기준은 보관 선행 예측이 없어 적용할 수 없다. 월별 날짜 반분 점검은 관측된 과거에서의 민감도이며 대회 비공개 날짜와 무관하다. 로컬 검증 예측은 v4 모델의 동결 구성에서 재조립한 것이며 모델 전체를 다시 학습하지 않았다. [중첩 검증](../model/v4_seasonal_residual_results.json) · [기존 검증 재계산](../model/v4_seasonal_residual_old_results.json)

원본 v4는 [1단계 재현 안내](../../final_package/README.md)와 [2단계 재현 안내](../../final_delivery_v2/README.md)를 따른다. 아래 명령은 동결 원본 CSV로 마지막 보정 단계를 재실행한다. Python 3.12.15, pandas 3.1.1, NumPy 2.5.4에서 확인했다. 보정에 난수는 없으며 검증의 날짜 반분에만 seed 0을 쓴다. Kaggle·Colab 전체 재학습은 미검증이다.

```sh
python -B goal_014/model/v4_seasonal_residual.py \
  --official /path/to/sincon-2026.zip \
  --oof night14/measurements/downstream_oof_nested_main.csv.gz \
  --calendar final_package/payload/work/external_inputs/calendar_features.csv \
  --events final_delivery_v2/cache/protected_event_keys.csv \
  --output /tmp/v4_seasonal_report.json \
  --base final_delivery_v2/reference/submission_night_v4_main.csv \
  --candidate /tmp/submission_night_v4_main_seasonal_shape.csv
```

출력 SHA-256은 `e054f22367f442ce3eefd3cf7ddb5bd9bb50ecf6c6fda75538500a7ecb14fa92`다. [제출 CSV](submission_night_v4_main_seasonal_shape.csv)
