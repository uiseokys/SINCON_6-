# 핫식스 2026-11-13 시험 정답 사용 점검

점검 범위는 Public 0.144804로 보고된 `submission_l1_hourly_curvature.csv`의 로컬 보관본, 그 상위 Night v4→L1 경로, 그리고 신규 인접역·합창제 후보다. 이 점검에서 공개됐다는 2026년 7~10월 지하철 실측을 찾거나 열지 않았다.

| 직접 확인한 항목 | 결과 |
| --- | --- |
| 공식 ZIP의 `train.csv` | 688,176행. 승차·하차 실측의 마지막 날짜는 2026-06-30이다. |
| 공식 ZIP의 `test.csv` | 157,194행. 열은 `example_id,date,station_id,hour` 네 개다. |
| 중첩·기존 경로 각각의 main·monday 검증 캐시 네 개 | 각 1,283,112행. 모두 예측 기준일 이후, 2026-06-30 이하이고, 각 라벨을 날짜·역·시간으로 공식 train과 연결했을 때 `log1p(boardings)`의 최대 차이가 모두 0이다. 기준일이 다른 예측이 있어 동일한 관측 키가 반복된다. |
| 현재 제출 경로 | Night v4 → K1/K2/K3 → 검단·PLAVE → 계절 재적합 → L1 → 시간대 곡률. 새 인접역 보정은 과거 승차와 역 위치, 새 합창제 보정은 과거 승차와 인천시 공연 일정을 사용한다. |
| 초기 Public 유래 조정 | 초기 전체 수준 및 역별 배율을 새 계산 경로에서 제외했다. 해당 보정 파일을 읽지 못하게 한 상태에서 clean 기준을 동일하게 재현한 기록이 있다. 이전 제출 이력은 별개이며 지우거나 숨기지 않는다. |

서울시·KT 생활이동 OA-22655의 동결 입력 22개, 779,022행을 확인했다. 팀 집계에는 광역버스·일반버스·도보·차량만 있고 지하철 수단은 집계 전에 제외한다. 인천시 버스 피처는 버스 정류장 집계이며 주변 지하철역 위치에 연결한다. [생활이동 가공 코드](../../final_package/payload/work/sincon_mobility_data.py) · [서울시 산출 설명](https://data.seoul.go.kr/dataVisual/seoul/capitalRegionLivingMigration.do) · [동결 입력 분포](../../night_sources/results/mobility_scope.json)

**확인 범위의 한계.** 서울시·KT가 비철도 이동량을 산출하면서 대회 기간의 인천 지하철 실측을 내부 보조 자료로 사용했는지는 공개 설명으로 확인하지 못했다. 보관된 모델 예측을 사용한 재조립은 검증됐지만, 당시 모델 전부를 원자료부터 독립 재학습해 같은 CSV를 만든 것은 아니다. 과거 검증에서 확인된 공식 학습 기간 안의 층 선택 시점 문제는 이 공지에서 말하는 2026년 7~10월 실측 사용과 별개다. 팀원 개인의 별도 로컬 작업과 모든 과거 제출을 이 점검으로 보증할 수 없다.

현재 후보에서 시험 기간 지하철 실측을 직접 사용한 경로는 확인되지 않았다. 소명할 때는 외부 이동 자료의 네 수단과 위 확인 범위를 함께 공개한다. 운영진이 이 자료의 간접 사용까지 금지한다고 해석하거나 허용 여부를 확인할 수 없으면, 영향받은 모델에서 생활이동·버스를 제거해 재적합한 기존 보수 후보를 검토한다. 이 후보도 전체 원시 모델을 새로 학습한 결과는 아니다.

- [출처 감사](../../night_sources/SOURCES_AUDIT.md) · [저장소 검사](../../final_audit/AUDIT_REPORT.md)
- [Public 사용 감사](../../SINCON_PUBLIC_SCORE_AUDIT.md) · [입력 차단 재현 결과](../../final_package/docs/sincon_clean_replay_verification.json)
- [L1 실행 범위](../reproduce/L1_BUNDLE_README.md) · [전체 재학습 차이](../../full_verification/FULL_RUN_RESULT.md)
- [보수 후보와 실행 방법](../../conservative_delivery/README.md)
