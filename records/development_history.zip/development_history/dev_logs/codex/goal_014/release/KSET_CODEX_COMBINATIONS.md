# K 후보에 적용한 계절·검단·PLAVE 보정

팀이 제공한 Public RMSLE는 K1 0.145606, K2 0.146049, K3 0.145606이다. 세 CSV를 공식 test와 대조했다. K3는 K1 위에 K2의 2,027개 휴일·행사 예측값을 사용한다. K2가 K1과 함께 바꾸는 7행은 인천사랑 걷기대회다. 기존 Codex 계절·요일 보정과 K1·K3가 바꾸는 행의 교집합은 116,334행이다. 모든 새 보정값은 과거 승차와 당시 예측으로 정했다. [팀 후보 정의](/Users/jeong-uiseok/sincon-2026/sincon-baseline/CANDIDATE_SET_PREREGISTRATION.md) · [행별 조합 검증](kset_transfer_report.json)

| 후보 | 추가한 보정 | A·C 비중복 | 3~6월 비중복 |
|---|---|---:|---:|
| [K3 + 검단·PLAVE + 계절 재적합](submission_k3_geomdan_plave_seasonal_refit.csv) | K1 적용 후 남은 오차로 계절별 역·시간대 보정을 재적합 | 0.154591 → 0.154054 | 0.146029 → 0.145258 |
| [K3 + 검단·PLAVE](submission_k3_geomdan_plave.csv) | 검단호수공원역 일반일 1,872행과 PLAVE 공연 중 4행 | 0.154591 → 0.154113 | 0.146029 → 0.145374 |
| [K2 + 계절·요일 + 검단·PLAVE](submission_k2_seasonal_weekday_geomdan_plave.csv) | 기존 Codex 계절·요일에 검단·PLAVE를 적용한 값을 K2와 결합 | 0.154714 → 0.154039 | 0.146381 → 0.145329 |

전체 점수는 K1을 기준일마다 재현하고 보관된 월요일 대체공휴일 효과를 더한 과거 검증이다. 2026년 코리아컵·걷기대회·PLAVE와 동일한 시험기간 행은 전체 점수에 포함되지 않는다. PLAVE의 별도 검증은 같은 경기장 과거 세 공연 12행에서 0.576491에서 0.508940이었다. 검단역과 적용 조건을 정할 때 평가 날짜 일부를 참고했다. 기존 경로를 사용해 다시 계산한 점수는 같은 날짜에 대한 민감도 점검이다. 세 후보의 Public은 미측정이다. [중첩 검증](kset_combined_validation_nested.json) · [기존 검증 경로](kset_combined_validation_old.json) · [PLAVE 검증](NIGHT_V4_PLAVE_IN_SHOW.md) · [검단 검증](NIGHT_V4_GEOMDAN3107.md)

계절 보정만 놓고 보면 K1 이후 재적합은 A·C 통합에서 0.0000595, 최근 3~6월에서 0.0001150 개선했다. 기준일 8개 중 6개가 개선됐고 2025-08-31과 B에서 악화했다. 2025-06-30 기준에는 이전 검증 예측이 없다. 기존 계절 보정의 92일 계절 가중·28일 수축·35% 적용을 고정했다. 각 검증 기준일 이전의 K1 예측 중 그날까지 승차 실측이 있는 행만 사용했다. 공휴일과 행사 역·날짜는 보호하고, 최종 후보에서 K2·검단·PLAVE 적용 역·날짜를 보호 범위에 추가했다. [K1 이후 재적합 비교](../graph_clean/k1_residual_replay.json) · [기존 계절 보정](NIGHT_V4_SEASONAL_SHAPE.md)

기본 모델 실행 순서와 패키지 버전은 [요일별 후보 재현 안내](NIGHT_V4_SEASONAL_WEEKDAY.md)를 따른다. 팀의 K 후보는 팀이 제공한 KSET 스크립트와 기록으로 생성한다. 요일별 후보와 검단·PLAVE 파일을 준비한 뒤 아래 두 명령을 실행한다. Python 3.12.15, NumPy 2.5.4, pandas 3.1.1에서 확인했다. 추정에 난수를 사용하지 않으며 과거 날짜 반분 점검에만 seed 0을 쓴다.

~~~sh
KSET=/path/to/CANDIDATE_SET_1113
OFFICIAL=/path/to/sincon-2026.zip
V4=final_delivery_v2/reference/submission_night_v4_main.csv
EVENTS=final_delivery_v2/cache/protected_event_keys.csv
RELEASE=goal_014/release

python -B goal_014/model/transfer_kset_overlays.py \
  --official "$OFFICIAL" --v4 "$V4" --events "$EVENTS" \
  --k1 "$KSET/submission_k1_hourbias.csv" \
  --k2 "$KSET/submission_k2_holiday_events.csv" \
  --k3 "$KSET/submission_k3_hourbias_holiday_events.csv" \
  --weekday "$RELEASE/submission_night_v4_main_seasonal_weekday.csv" \
  --local "$RELEASE/submission_night_v4_main_seasonal_weekday_geomdan_plave.csv" \
  --local-k3 /tmp/submission_k3_geomdan_plave.csv \
  --weekday-k2 /tmp/submission_k2_seasonal_weekday_geomdan_plave.csv \
  --report /tmp/kset_transfer_report.json

python -B goal_014/model/kset_combined_validation.py \
  --official "$OFFICIAL" --v4 "$V4" --events "$EVENTS" \
  --oof night13/measurements/downstream_oof_nested_main.csv.gz \
  --monday night14/measurements/downstream_oof_nested_monday.csv.gz \
  --calendar final_package/payload/work/external_inputs/calendar_features.csv \
  --k2 "$KSET/submission_k2_holiday_events.csv" \
  --k3 "$KSET/submission_k3_hourbias_holiday_events.csv" \
  --local-k3 /tmp/submission_k3_geomdan_plave.csv \
  --seasonal-output /tmp/submission_k3_geomdan_plave_seasonal_refit.csv \
  --report /tmp/kset_combined_validation_nested.json
~~~

공식 ID 157,194개의 순서와 유한한 비음수 값을 확인했다. 세 후보 모두 별도 폴더에서 바이트 단위로 재현했다. 계절 재적합 후보 SHA-256은 e46feb831db69a8805317aced422abe2e443e006779e0b476048caf73afddcbb다.
