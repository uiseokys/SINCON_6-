# Night v4 계절·요일별 시간대 보정

Public 0.145956을 기록한 계절별 시간대 CSV에서 시작한다. 평일과 주말 각각의 기존 역·시간대 오차를 기준으로, 월~일 각각에서 추가로 반복되는 오차를 구한다. 역·날짜의 하루 평균 로그 오차를 뺀 뒤, 앞서 검증한 오차에 반감기 120일을 적용한다. 요일별 추정치를 12일에 해당하는 크기로 0 쪽에 수축하고, 최대 ±0.12에서 자른 뒤 40%를 반영한다. 각 역·날짜의 시간별 로그 보정 합계를 다시 0으로 맞춘다.

공식 train 2026-06-30까지의 승차와 기준일별 보관 예측을 쓴다. 각 기준일보다 이른 예측 중 해당 기준일까지 실측이 있는 행만 쓴다. 과거 후보 예측에 계절별 보정을 적용할 때도 당시 기준일 안에서 따로 적합한다. 공휴일과 그 인접일, 보호 행사 역·날짜, 신규 3개 역, 주요 행사 4개 역을 적용 범위에서 제외한다. 추가 외부 입력은 없으며 기존 달력과 행사 보호표를 사용한다. Public 0.145956은 후보 기록에만 사용했다. [기존 계절 보정](NIGHT_V4_SEASONAL_SHAPE.md) · [기존 외부 입력 기록](../../final_package/docs/SINCON_EXTERNAL_SOURCES.md)

| 검증 | 계절 보정 | 요일 보정 추가 | 변화 |
|---|---:|---:|---:|
| 2025년 7월 말 기준 | 0.174161 | 0.174129 | −0.000033 |
| A·C 통합 | 0.154599 | 0.154522 | −0.000077 |
| B | 0.166055 | 0.166021 | −0.000034 |
| 2026년 4월 말 기준 | 0.142521 | 0.142247 | −0.000274 |

중첩 검증과 기존 검증에서 각각 적용 가능한 8개 기준일 모두 개선됐다. 전체 기준일의 평가 날짜는 일부 겹친다. A와 C는 평가 날짜가 겹치지 않는다. 2025년 6월 말 기준에는 이전 보관 예측이 없어 두 보정을 적용하지 않는다. 모델 전체를 재학습한 비교는 아니다. [중첩 검증](../model/v4_weekday_residual_results.json) · [기존 검증](../model/v4_weekday_residual_old_results.json)

먼저 [계절 보정 안내](NIGHT_V4_SEASONAL_SHAPE.md)에 따라 1·2단계 v4와 계절별 시간대 CSV를 생성한다. 아래 명령은 마지막 단계를 실행한다. Python 3.12.15, NumPy 2.5.4, pandas 3.1.1을 사용했다. 예측에는 난수가 없고 과거 월별 날짜 반분 평가에만 seed 0을 쓴다.

```sh
python -B goal_014/model/v4_weekday_residual.py \
  --official /path/to/sincon-2026.zip \
  --oof night14/measurements/downstream_oof_nested_main.csv.gz \
  --calendar final_package/payload/work/external_inputs/calendar_features.csv \
  --events final_delivery_v2/cache/protected_event_keys.csv \
  --output /tmp/v4_weekday_report.json \
  --base /path/to/submission_night_v4_main_seasonal_shape.csv \
  --candidate /tmp/submission_night_v4_main_seasonal_weekday.csv
```

후보는 공식 157,194행 중 119,340행을 바꾼다. 공식 ID 순서, 보호 행의 동일성, 역·날짜별 로그 보정 합계, 기준일 뒤 정답을 바꾼 두 검증, 별도 폴더에서 재생성한 CSV의 바이트 일치를 확인했다. SHA-256은 `135c0e2a0800e84907cb6e7baad4da804e262b4a610b95ca8e3ae300f5588c2e`다. [제출 CSV](submission_night_v4_main_seasonal_weekday.csv) · [파일 검산](v4_weekday_verification.json)
