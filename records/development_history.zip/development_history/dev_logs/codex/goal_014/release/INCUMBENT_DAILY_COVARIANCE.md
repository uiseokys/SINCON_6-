# 함께 움직이는 역을 이용한 일별 수요 보정

Public 0.144722를 기록한 `submission_joint_geomdan_illustration_shape.csv`를 기준으로 삼았다. 같은 요일의 앞뒤 1~3주 예측을 이용해 역별 일일 수요의 일시적인 변동을 구한 뒤, 그날 전 노선의 중앙값 변동을 뺐다. 역별 일일 수요는 18시간의 `log1p(boardings)` 평균이다.

기준일을 포함한 직전 182일의 일반일 실측에서 같은 방법으로 만든 변동의 역간 공분산을 구했다. 평일과 주말을 따로 계산하고, 표준화한 공분산의 고윳값이 1.25를 넘는 성분을 공유 변동으로 분류했다. 미래 예측에 나타난 공유 변동은 10% 더하고, 나머지 변동은 22% 줄였다. 역마다 한 달 안의 같은 요일 평균을 중심화한 뒤 로그 변화는 최대 0.045로 제한했다. 이 보정은 하루의 18시간에 같은 값을 더한다.

| 검증 | 기존 RMSLE | 새 RMSLE | 변화 |
| --- | ---: | ---: | ---: |
| 중첩 2025년 8~10월 | 0.17760580 | 0.17757586 | −0.00002993 |
| 중첩 2026년 3~6월 | 0.14512306 | 0.14511134 | −0.00001172 |
| 기존 2025년 8~10월 | 0.17727642 | 0.17725148 | −0.00002494 |
| 기존 2026년 3~6월 | 0.14481300 | 0.14480042 | −0.00001258 |

두 검증 경로에서 일곱 달 모두 개선됐다. 중첩 검증에서 달마다 날짜를 무작위 반으로 나눈 2,000회 진단 중 양쪽 모두 개선된 비율은 가을 100%, 봄 98.3%였다. 같은 검증 기간의 재표집이다. 공유 변동을 키우지 않는 버전과도 비교했고, 두 경로·두 기간에서 가장 작은 개선 폭이 더 큰 버전을 채택했다. 별도로 과거 검증만 사용해 계수를 적합한 결과가 고정 버전을 앞서지 않았다. [결과](incumbent_daily_covariance.json) · [계수 적합 비교](../model/incumbent_covariance_crossfit.json)

공식 ID 157,194개와 순서, 유한한 비음수 예측, 검단 5역과 기존 보호일 및 공휴일의 불변을 확인했다. 107,136행이 바뀌었고 50,058행은 바이트 단위로 같았다. 재실행한 결과 JSON과 CSV가 일치했다. SHA-256은 `985ccdf646a4a11374a9d7b6ffe06d27723e3a689673bcf838448625aa77a8d4`다.

보정의 입력은 공식 대회 학습 자료, 학습 기간의 검증 예측, 현재 기준 CSV 및 기존 제외 목록이다. Public은 기준 선택에만 썼다. Python 3.12.15, NumPy 2.5.4, pandas 3.1.1 환경에서 계산했다. 날짜 반분 진단만 seed 0을 사용했다.

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 final_package/.build/venv/bin/python -B \
  goal_014/model/incumbent_daily_covariance.py --official /path/to/sincon-2026.zip \
  --report /tmp/incumbent_daily_covariance.json --output /tmp/submission_incumbent_daily_covariance.csv
```

[기존 모델 재현 범위](../reproduce/L1_BUNDLE_README.md) · [기존 모델의 시험 정답 사용 점검](TEST_TARGET_AUDIT_1113.md)
