# K3 조합의 추석 전날 보정

`submission_k3_geomdan_plave_seasonal_refit.csv`에서 2026년 9월 24일 61개 역의 1,098행을 조정했다. 원래 모델의 명절 보정은 같은 날 65개 역 1,170행에 log1p −0.08을 적용했다. 새 보정은 그 뒤에 남은 차이를 줄이는 두 번째 보정이다. 두 보정을 합치면 해당 행의 로그 변화는 −0.142~−0.121이다. 보호 행사, K2가 바꾼 2,027행, 부평삼거리역(3122)을 포함한 제외 역을 확인했다. 바뀐 1,098행을 제외한 156,096행은 원본과 바이트 단위로 같다. [기존 명절 단계](../../final_package/payload/work/sincon_clean_model_layers.py:252) · [기존 단계의 과거 재현](../../night11/reproduce_nested.py:149)

평소 일요일과 비교해 명절 전날의 승차가 얼마나 줄었는지 네 시간대로 계산했다. 과거 세 번의 명절 전날은 각 기준일까지 공개된 `train.csv`로 계산하고, 목표 날짜는 현재 모델의 예측과 주변 일요일 예측으로 계산했다. 차이를 로그 ±0.20에서 자른 뒤 40%를 반영했다. 최종 log1p 변화는 06~09시 −0.05784, 10~15시 −0.06168, 16~20시 −0.05913, 21~23시 −0.04134다. 날짜를 고르는 데 사용한 기존 달력의 명절일은 한국천문연구원 자료와 대조했다. 조회일은 2026-11-13 KST다. [2025년 월력요항](https://astro.kasi.re.kr/kor/life/post/calendarData?year=2025) · [2026년 월력요항](https://astro.kasi.re.kr/kor/life/post/calendarData?year=2026)

| 중첩 순방향 검증 | 범위 | 기준 RMSLE | 보정 RMSLE |
|---|---|---:|---:|
| 2025-09-30 기준 | 2025-10-05 추석 전날 적용 행 | 0.220091 | 0.212741 |
| 2025-10-31 기준 | 2026-02-16 설날 전날 적용 행 | 0.196551 | 0.183679 |
| 2025-07-31 기준 | 2025년 8~10월 전체 | 0.177813 | 0.177784 |
| A·C 통합 | 겹치지 않는 전체 309,276행 | 0.154054 | 0.153997 |
| 2026-04-30 기준 | 5~6월 전체, 적용일 없음 | 0.141488 | 0.141488 |

적용 가능한 여섯 기준일의 결과는 실제로 두 날짜를 반복 평가한 것이다. 2025년 추석 전날과 2026년 설날 전날 모두 개선했으며, 보관 예측의 기존 경로에서도 같은 방향이었다. 2026년 설날 당일은 보정을 넣으면 오차가 늘어 9월 25일에는 적용하지 않았다. 과거 달력은 올해와 요일 및 연휴 길이가 다르다. 이번 결과는 기존 명절 보정 뒤에 남은 오차에 대한 검증이며 Kaggle 점수는 미측정이다. [기준일과 날짜별 결과](../bottleneck/k3_chuseok_eve_report.json)

[K3 조합 안내](KSET_CODEX_COMBINATIONS.md)에 따라 먼저 기준 CSV를 만든다. 아래 명령으로 같은 파일을 재현할 수 있다. Python 3.12.15, NumPy 2.5.4, pandas 3.1.1에서 검증했다. 난수는 사용하지 않는다.

```sh
python -B goal_014/bottleneck/build_k3_chuseok_eve.py \
  --official /path/to/sincon-2026.zip \
  --base goal_014/release/submission_k3_geomdan_plave_seasonal_refit.csv \
  --k2 /path/to/submission_k2_holiday_events.csv \
  --report /tmp/k3_chuseok_eve_report.json \
  --output /tmp/submission_k3_geomdan_plave_seasonal_chuseok_eve.csv
```

공식 시험 ID 157,194개와 순서를 확인했다. CSV의 SHA-256은 `830d09e570f7de52fa2bfb7772792dc438abb358581d6ef0ddb0e029e453409e`다. [제출 CSV](submission_k3_geomdan_plave_seasonal_chuseok_eve.csv)
