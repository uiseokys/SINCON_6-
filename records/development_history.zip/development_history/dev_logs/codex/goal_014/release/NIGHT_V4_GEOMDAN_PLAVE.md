# 요일별 후보의 검단호수공원역·PLAVE 보정

팀이 Public 0.145757을 확인한 요일별 후보에서 두 변경을 결합했다. 비교 기록의 당시 1위는 0.144933이다. 두 수치는 후보 평가 기록에만 사용했다. 새 후보는 Kaggle 점수가 아직 없다.

- 검단호수공원역은 최근 두 달에 과소예측이 이어졌을 때 과거 로그 오차 중앙값의 절반을 적용했다. 기준일까지의 일반일 50개에서 산출한 최종 보정은 log1p +0.07480887이다. 최종 104일의 1,872행에 적용했다. 날짜가 겹치지 않는 3~4월과 5~6월 전체의 통합 RMSLE는 0.146005에서 0.145350으로 내려갔다. 역과 적용 조건을 정할 때 같은 검증 자료를 살펴봤다. [검단호수공원역 재현 및 검증](NIGHT_V4_GEOMDAN3107.md)
- 9/12·13 문학경기장역 19·20시 네 행은 같은 공연장의 과거 공연 시작 시각에 맞춰 log1p −0.105를 적용했다. 서로 다른 세 공연의 12행 검증 RMSLE는 0.576491에서 0.508940으로 내려갔다. 기존 22시 보정은 23,120·19,494건을 이미 사용한다. 인천터미널·선학역에 예매 규모 비례 보정을 절반만 적용해도 두 과거 공연 24행에서 0.322393에서 0.360293으로 악화했다. 문학경기장역 22시 비율을 공연 계열 중앙값으로 교체하면 네 행 통합은 개선됐지만 MUSE 한 회차는 악화돼 기존 비율을 유지했다. [공연 시작 보정과 재현](NIGHT_V4_PLAVE_IN_SHOW.md) · [인접역과 22시 검증](../bottleneck/plave_neighbor_validation.json)

예매 집계는 KOPIS를 인용한 공개 페이지에서 사용자 제공 값과 일치했다. 예술경영지원센터 KOPIS 시설별 통계 API의 이용허락범위는 제한 없음이며, 해당 회차의 공식 API 원본 응답은 직접 확인하지 못했다. 공식 예매 공지에서 행사 장소와 19시 시작을 확인했다. 수치는 예매 건수다. 조회일은 2026-11-13이다. [예매 수치 출처 기록](../bottleneck/plave_bookings.csv) · [공식 공연 공지](https://weverse.io/plave/notice/36575?hl=ko) · [KOPIS 시설별 통계](https://www.data.go.kr/data/15097819/openapi.do)

공식 157,194개 ID와 순서, 유한한 비음수 값, 두 보정의 변경 행이 겹치지 않음을 확인했다. 다른 155,318행은 요일별 후보와 바이트 단위로 일치한다. 두 검증은 서로 다른 평가 범위를 사용하므로 하나의 통합 성능으로 합산하지 않는다. 조합 단계는 Python 3.12.15·pandas 3.1.1·NumPy 2.5.4로 검산했으며 난수를 쓰지 않는다.

먼저 [요일별 후보 재현 안내](NIGHT_V4_SEASONAL_WEEKDAY.md)를 따라 기본 CSV를 생성한다. 위 두 재현 안내의 명령으로 각각의 보정 CSV를 만든 뒤 아래 명령으로 조합한다.

~~~sh
python -B goal_014/model/combine_weekday_local_overlays.py \
  --official /path/to/sincon-2026.zip \
  --base goal_014/release/submission_night_v4_main_seasonal_weekday.csv \
  --geomdan goal_014/release/submission_night_v4_main_seasonal_weekday_geomdan3107.csv \
  --plave goal_014/release/submission_night_v4_main_seasonal_weekday_plave_in_show.csv \
  --events final_delivery_v2/cache/protected_event_keys.csv \
  --output /tmp/submission_night_v4_main_seasonal_weekday_geomdan_plave.csv
~~~

출력 SHA-256은 883a7b98be91bd4cffde83fd466d6e82b657ca26f84ce829540a2c40a50432bb다. [조합 CSV](submission_night_v4_main_seasonal_weekday_geomdan_plave.csv) · [행·해시 검증](submission_night_v4_main_seasonal_weekday_geomdan_plave.json)
