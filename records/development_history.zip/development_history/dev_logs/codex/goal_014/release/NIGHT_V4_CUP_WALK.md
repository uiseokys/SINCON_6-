# Night v4 코리아컵·걷기대회

2026-11-13 팀이 기존 Night v4 외부 입력의 이용 조건을 해결했다고 확인했다. 기존 입력의 출처와 재현성 기록은 상위 패키지에 있다. 두 행사에서 사용하는 날짜·시각은 동봉 CSV에 권리자, 이용 조건, 조회일과 함께 기록했다. [기존 외부 출처](../../final_package/docs/SINCON_EXTERNAL_SOURCES.md) · [추가 출처 감사](../../night_sources/SOURCES_AUDIT.md)

- 코리아컵은 대회 공식 학습 자료에서 앞선 정규시간 경기의 평소 대비 시간대별 초과분을 모아 하한을 계산한다. 공식 축구협회 자료로 경기 사실을 교차 확인했다. 정규시간 2025-04-16과 연장전 2025-05-14의 각 경기 전 검증을 통과했다. 별도 2025-08-27 경기의 20~23시 중첩 OOF는 1.251701에서 0.344696으로 줄었다. [경기별 출처와 이용 조건](../graph_clean/bucheon_cup_facts.csv) · [검증](../graph_clean/v4_validation.json)
- 걷기대회는 2025년 같은 대회의 일반 토요일 대비 양의 초과 승차 중 50%를 적용한다. 그 이전 유아차 걷기대회에서 예측한 2025-10-25 인천사랑 걷기대회 검증에서 12~18시 RMSLE가 0.44168에서 0.32776으로 줄었다. 시간대 검증은 행사 1건이다. [행사별 출처와 이용 조건](../bottleneck/incheon_walk.csv) · [검증](../bottleneck/night_v4_diagnostic.json)

## 재실행

1. 기본 모델의 실행 순서, seed, 패키지 버전은 [1단계 노트북과 안내](../../final_package/README.md)와 [2단계 안내](../../final_delivery_v2/README.md)를 따른다. 로컬에서 동결 입력으로 1·2단계와 v4를 재생했다. 별도 CPU 전체 재학습의 1단계 결과는 동결 기준과 최대 log1p 0.153038 차이가 났고, Kaggle·Colab 전체 재학습은 검증하지 않았다. [CPU 재학습 결과](../../full_verification/outputs/sincon_full_20261112T191929_797587Z/verification.json)
2. 동봉 ZIP을 풀고 아래 명령에서 공식 대회 ZIP과 위 단계의 v4 CSV 위치를 지정한다. Kaggle에서는 대회에 연결된 `train.csv`와 `test.csv`가 있는 디렉터리를 `--official`에 지정할 수 있다. 조합 단계는 난수를 사용하지 않는다. Python 3.12.15, pandas 3.1.1, NumPy 2.5.4에서 확인했다.

```sh
python -B model/build_v4_cup_walk.py \
  --official /path/to/sincon-2026.zip \
  --base /path/to/submission_night_v4_main.csv \
  --calendar inputs/calendar_features.csv \
  --protected inputs/protected_event_keys.csv \
  --output submission_night_v4_main_cup_walk.csv
```

2단계 재실행 CSV가 원본 v4와 직렬화만 다르면 `--reference /path/to/frozen/submission_night_v4_main.csv`를 추가한다. 동결 원본의 SHA-256과 두 CSV의 최대 log1p 차이 1e-10 이하를 검사한다. 실행 결과에 사용한 CSV 해시를 기록한다. 정본 조합은 `1ee35f4d5808974e7c2c54756fd7bff5123f31e4dc7d2ab4ac98a3c34aced37b`다. [행별 검증 결과](submission_night_v4_main_cup_walk.json)
