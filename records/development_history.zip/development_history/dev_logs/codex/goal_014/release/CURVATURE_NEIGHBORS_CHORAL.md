# 인접역 하루 수요와 인천 합창제 보정

Public 0.144804로 사용자가 확인한 시간대 곡률 CSV를 기준으로 고정했다. 현재 파일의 Public은 미측정이다. 같은 노선에서 3km 안에 있는 가까운 두 역을 대조군으로 삼고, 직전 84일의 같은 요일 대비 역의 하루 로그 수요 차이 10%를 반영한다. 해당 노선의 하루 평균 보정은 0으로 맞췄다. 인천시 공공누리 제1유형 공연 날짜를 기준으로, 센트럴파크역 9월 8~11일 20~22시에 별도로 적용한다. 합창제 역·날짜 전체에는 인접역 보정을 겹치지 않는다.

| 검증 | 기준 RMSLE | 결합 | 변화 |
| --- | ---: | ---: | ---: |
| 중첩 2025년 8~10월 | 0.17767697 | 0.17764050 | −0.00003646 |
| 중첩 2026년 3~6월 | 0.14521859 | 0.14519271 | −0.00002588 |
| 기존 2025년 8~10월 | 0.17733687 | 0.17730662 | −0.00003025 |
| 기존 2026년 3~6월 | 0.14490638 | 0.14488290 | −0.00002348 |

과거 10월과 3월은 악화했다. 가을의 합창제는 같은 행사 4일, 봄의 합창제 보정 검증은 같은 장소의 다른 공연 3일이다. 두 보정을 각각 추가했을 때도 두 기간의 전체 RMSLE가 개선됐다. 두 보정에 쓰인 승차 실측은 각 예측 기준일까지만 사용했다. Public 점수는 기준으로 삼을 완성 파일을 선택하는 데만 사용했다. 현재 검증 개선폭은 목표 Public 0.143대와의 차이를 메우기에 작으며 Kaggle 점수를 예측하지 않는다.

공식 ID와 순서, 157,194행, 유한한 비음수 값, 보호 구간 불변을 확인했다. 102,018행이 달라졌고 이 중 12행이 합창제다. 새 폴더에서 동일 파일과 보고서를 재현했다. SHA-256은 `e1680aca99c91a420c1f0c5b7f0a183e7d7e1ab12d79d48d53bf64105b7b6b2f`다.

```sh
final_package/.build/venv/bin/python -B goal_014/model/curvature_neighbors_choral.py \
  --official /path/to/sincon-2026.zip \
  --report /tmp/curvature_neighbors_choral.json \
  --output /tmp/submission_curvature_neighbors_choral.csv
```

Python 3.12.15, NumPy 2.5.4, pandas 3.1.1. 보정에는 난수가 없고 검증 날짜 반분 진단만 seed 0을 쓴다. [역 위치와 인접역 보정](../housing/CURVATURE_LOCAL_NEIGHBORS.md) · [합창제 출처와 검증](../bottleneck/L1_CHORAL_CITY.md) · [결합 결과](curvature_neighbors_choral.json) · [상위 파일의 재현 범위](../reproduce/L1_BUNDLE_README.md) · [시험 정답 점검](TEST_TARGET_AUDIT_1113.md)
