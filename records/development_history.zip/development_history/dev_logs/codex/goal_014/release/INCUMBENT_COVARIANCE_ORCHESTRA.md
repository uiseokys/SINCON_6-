# 센트럴파크 정기연주회와 역간 일별 수요 보정

Public 0.144722의 보관 예측에서 기존 일별 공분산 보정을 그대로 재현했다. 그 위에 2026년 10월 23일 인천시립교향악단 정기연주회의 센트럴파크역 21시 한 행을 추가했다. 보정값은 기준일 이전 같은 장소·교향악단의 19시 30분 공연과 이전 같은 요일 일반일의 차이에서 구했다. 중앙값의 절반을 적용하고 로그 변화량은 0.20으로 제한했다. 해당 행의 승차 예측은 공분산 후보 기준 227.7930명에서 278.4484명으로 바뀐다.

인천시 공공누리 제1유형 공지에서 행사 날짜·공연장·시작 시각을 확인했다. 조회일은 2026-11-13 KST다. 10월 8일 녹음 공연은 시작 시각과 연휴 전날 조건이 검증 공연과 달라 진단만 했다. 예매 수량이나 실제 종료 시각은 계산에 쓰지 않았다. [인천시 공연 공지](https://www.incheon.go.kr/IC010205/view?repSeq=DOM_0000000015597975) · [공공누리 이용 조건](https://www.kogl.or.kr/info/license.do) · [센트럴파크역과 아트센터인천](https://www.ictr.or.kr/main/subway/subwayStation.do?line_no=1&station_no=137) · [학습·검증 행사 출처](../bottleneck/aci_orchestra_schedule.csv)

| 검증 | 원래 기준 | 공분산 | 공분산·정기연주회 |
| --- | ---: | ---: | ---: |
| 중첩 2025년 8~10월 | 0.17760580 | 0.17757586 | 0.17756632 |
| 중첩 2026년 3~6월 | 0.14512306 | 0.14511134 | 0.14510128 |
| 기존 2025년 8~10월 | 0.17727642 | 0.17725148 | 0.17724184 |
| 기존 2026년 3~6월 | 0.14481300 | 0.14480042 | 0.14479033 |

과거 정기연주회 5건에서 각각 오차 제곱이 줄었다. 21시를 시험하는 결정은 앞선 과거 오차 진단을 참고했다. 전체 검증의 개선 폭은 작고 Kaggle 점수는 미측정이다. [검증 결과](incumbent_covariance_orchestra.json)

부천시청 10월 9일의 복사골예술제 오기입을 재현했다. 과거 행사 예측에 같은 오기입 효과를 넣은 뒤 제거하는 모의 실험은 두 기간에서 개선됐으나, 가장 가까운 2025년 시민어울림한마당 사례에서는 22~23시 제거도 악화했다. 지역 축제 계산을 같은 행사장 기록의 중앙값으로 바꾸는 실험은 가을 90행과 봄 188행에서 통합 RMSLE가 줄었지만, 봄 3월은 악화했고 가을에 검증한 행사와 실제 적용할 행사 구성이 달랐다. 이 두 보정은 후보에 포함하지 않았다. [부천시청 검증](../model/incumbent_city_hall.json) · [지역 축제 검증](../model/incumbent_festival_transfer.json)

공식 시험 ID 157,194개와 원래 순서, 유한한 비음수 값을 확인했다. 공분산 CSV와 비교해 `J146247` 한 행이 바뀐다. 0.144722 CSV와 비교해 107,136행이 바뀐다. CSV SHA-256은 `e300c6b744cb69617b150e20fa4e2e6683d08e25e46a771237e9a2ed7349a091`이다. 별도 임시 폴더에서 CSV와 검증 JSON을 각각 바이트 단위로 재현했다. 입력은 공식 대회 파일, 보관 검증 예측과 기준 CSV, 행사 날짜·보호 목록이다. 새 적합에는 2026-06-30까지의 승차만 썼다. Public 점수는 기준 선택에 사용했다.

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 final_package/.build/venv/bin/python -B \
  goal_014/model/build_incumbent_covariance_orchestra.py --official /path/to/sincon-2026.zip \
  --report /tmp/incumbent_covariance_orchestra.json --output /tmp/submission_incumbent_covariance_orchestra.csv
```

Python 3.12.15, NumPy 2.5.4, pandas 3.1.1에서 실행했다. 후처리는 결정적이다. 이 명령은 보관된 상위 모델 예측을 사용한다. [상위 재현 범위](../reproduce/L1_BUNDLE_README.md)
