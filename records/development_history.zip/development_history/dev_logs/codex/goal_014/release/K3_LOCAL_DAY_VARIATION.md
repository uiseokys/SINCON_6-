# K3의 역별 일 수요 변동 보정

기준은 `submission_k3_geomdan_plave_seasonal_refit.csv`다. 사용자가 보고한 Public 점수는 이 기준과 추석 전날 후보가 모두 0.145104다. 이 점수는 두 완성 후보를 비교하는 데만 사용했다.

일반일에 같은 역의 같은 요일을 앞뒤 3주에서 비교한다. K3 예측값의 역별 하루 평균 `log1p` 차이에서 같은 날의 네트워크 중앙값과 그 역의 요일 평균을 뺀다. 기존 예측이 평소보다 크게 움직이는 날에 이 차이가 실제 오차로 이어졌는지 과거 검증에서 측정했다. 각 기준일에 45일 이상 확인된 과거 예측과 실측만으로 평일·주말 계수를 각각 추정한다. 120일 반감기와 릿지 수축을 적용하고 추정값의 절반을 반영한다. 최종 신호의 배율은 평일 약 −0.07086, 주말 약 −0.06402였다. 해당 역·날짜의 18시간에 같은 보정을 넣으므로 시간대별 로그 예측의 차이는 유지된다.

| 시간순 검증 | 기존 K3 | 역별 일 변동 보정 |
| --- | ---: | ---: |
| A·C 통합, 중복 날짜 제외 | 0.15405382 | 0.15403063 |
| 2026년 3~6월, 중복 날짜 제외 | 0.14525848 | 0.14524355 |
| A·C, 기존 예측 경로로 반복 | 0.15373414 | 0.15372092 |
| 2026년 3~6월, 기존 예측 경로로 반복 | 0.14494636 | 0.14493928 |

두 예측 경로 모두 적용 가능한 기준일 7개에서 개선됐다. 앞선 기준일 2개는 45일을 충족하지 못해 보정하지 않았다. 기존 경로는 같은 날짜에 대한 민감도 확인이다. 위 점수는 로컬 검증이다. 새 후보의 Public과 Private은 미측정이다. [중첩 검증](../model/k3_local_day_variation_nested.json) · [기존 경로](../model/k3_local_day_variation_old.json)

`test.csv`의 157,194개 ID와 순서를 사용한다. 101,466행을 변경했고 공휴일·행사 보호 구간은 유지했다. `boardings`는 유한한 비음수다. 새 외부 입력은 추가하지 않았다. 원래 외부 입력과 학습 경로는 [K3 계절 재적합 재현 안내](KSET_CODEX_COMBINATIONS.md)를 따른다. 이 단계에는 난수가 없으며 날짜 반분 진단만 NumPy seed 0을 쓴다. 확인 환경은 Python 3.12.15, NumPy 2.5.4, pandas 3.1.1이다.

재현 안내에 따라 K3 계절 재적합 파일과 해당 과거 예측을 준비한 뒤 작업 폴더에서 실행한다.

~~~sh
python -B goal_014/model/k3_local_day_variation.py \
  --official /path/to/sincon-2026.zip \
  --oof night13/measurements/downstream_oof_nested_main.csv.gz \
  --monday night14/measurements/downstream_oof_nested_monday.csv.gz \
  --calendar final_package/payload/work/external_inputs/calendar_features.csv \
  --events final_delivery_v2/cache/protected_event_keys.csv \
  --venues final_package/payload/work/external_inputs/external/events_daily.csv \
  --festivals final_package/payload/work/sincon_festival_station_days.csv \
  --base goal_014/release/submission_k3_geomdan_plave_seasonal_refit.csv \
  --k2 /path/to/CANDIDATE_SET_1113/submission_k2_holiday_events.csv \
  --v4 final_delivery_v2/reference/submission_night_v4_main.csv \
  --report /tmp/k3_local_day_variation_nested.json \
  --candidate /tmp/submission_k3_seasonal_local_day.csv
~~~

SHA-256: `9362c1d610974fcacfefd1a77cde1e341342f96d2847e4fb8963b1cd2b559273`.
