# SINCON 데이터 출처와 이용 조건

학습 정답은 대회 공식 `train.csv`의 2025-01-01~2026-06-30 승차 인원이다. `test.csv`는 날짜·역·시간·ID만 사용한다. 역과 노선은 공식 `metaData.csv`다. 세 파일을 대회 ZIP과 바이트 단위로 대조한다. [SINCON Data](https://www.kaggle.com/competitions/sincon-2026/data)

| 입력 | 출처와 가공 | 조회 기록 및 이용 조건 |
| --- | --- | --- |
| 공휴일, 명절, 선거 | [우주항공청 월력요항](https://www.kasa.go.kr/prog/bbsArticle/BBSMSTR_000000000010/view.do?nttId=B000000000633Wg5pO7), [공휴일 법령](https://www.law.go.kr/법령/공휴일에관한법률), [공휴일 제도 개정 이력](https://law.go.kr/LSW/lsRvsRsnListP.do?chrClsCd=010102&lsId=002404) | 달력 날짜와 분류를 코드화했다. 달력 이미지와 기사 본문은 사용하지 않는다. 팀 최초 기록 2026-11-11, 2026-11-13 재확인. |
| 시간별 기상 재분석 | Open-Meteo·ECMWF/Copernicus. 4권역의 시간별 값을 역에 연결하고 일별 강수와 기온 범위 등을 집계했다. [Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api), [API 이용 조건](https://open-meteo.com/en/terms) | CC BY 4.0. 무료 API는 비상업 이용 조건이다. 팀 최초 기록 2026-11-11, 2026-11-13 재확인. |
| 학교 방학·재량휴업 | 교육부·NEIS 인천 학교 학사일정의 날짜별 비율. [공공데이터포털 15137088](https://www.data.go.kr/data/15137088/openapi.do) | 포털 표시 이용허락범위 제한 없음. 팀 최초 기록 2026-11-11, 2026-11-13 재확인. API의 연간 계획 갱신 시각은 학교별로 다를 수 있다. |
| 문학 야구 및 부천 축구 | 나무위키 기여자의 경기 날짜, 개최·취소, 실제 시각, 관중 규모를 별도로 취득한 `sports/*.csv`. [출처·기여자·변경표](sports/CC_ATTRIBUTION.csv) | [CC BY-NC-SA 2.0 KR](https://creativecommons.org/licenses/by-nc-sa/2.0/kr/). 2026-11-13 조회. 시각/날짜를 정규화했고, 2025-06-15 야구 관중은 출처 간 차이로 결측 처리했다. 축구 종료는 킥오프+1.9시간으로 추정한다. |
| 축제·공연 | `goal_014/model/events_frozen_v3.csv`의 57 역일, 각 행에 원문 링크, 저작권자, 조회일, 이용 조건을 기록했다. 행사 날짜·장소 및 확인된 시각만 쓰고, 역 연결은 자체 판단이다. | 공공누리 1·2유형 및 CC BY-NC-SA 2.0 KR. 2026-11-13 조회. 일정표에 없는 행사와 확인되지 않은 시각은 미확인이다. |
| TabICL 공개 사전학습 모델 | [BSD-3-Clause 체크포인트와 공개 SHA-256](https://huggingface.co/jingang/TabICL/blob/main/tabicl-regressor-v2-20260212.ckpt), [프로젝트 라이선스](https://github.com/soda-inria/tabicl/blob/main/LICENSE) | 회귀 체크포인트 BSD-3-Clause. 2026-11-13 재확인. 시드 2026, 2개 추정기, 공식 기준일 이전 관측만 컨텍스트 학습에 넣었다. |

행사 두 곳의 인접역(3138·3210)은 동일 행사에서 과거 역별 시간대 승차 증가를 확인한 범위다. 2026년 펜타포트는 2025년과 행사장 입·퇴장 동선이 다르다. [2025년 인천시 결과](https://www.incheon.go.kr/mayor_9/MA05010000/view?repSeq=DOM_0000000012845291) · [2026년 인천시 결과](https://www.incheon.go.kr/mayor_8/MA040101/view?curPage=19&repSeq=DOM_0000000015262157)

이번 후보는 팀의 예전 예측 CSV, 예매 수량, K-apt 자료, 원수집 KBO 응답, 실제 생활이동, 시험 기간 지하철 승하차와 Public 점수에 의존하지 않는다. 외부 자료의 출처표시와 각 재사용 조건을 유지한다. 공식 대회 자료와 후보는 팀 범위에서 보관한다. [규칙 3·4·7절](https://www.kaggle.com/competitions/sincon-2026/rules)

## 추가 외부 자료

- 송도맥주축제 개막은 인천시 2026년 8월 17~23일 주간 일정 첨부의 8월 22일 18:30 항목을 사용했다. 인천광역시, 공공누리 제1유형, 2026-11-13 조회. 2025년 동일 행사의 기간과 장소 역시 인천시 자료를 사용했다. [2026년 공지](https://www.incheon.go.kr/IC010101/view?nttNo=2046078) · [2025년 공지](https://www.incheon.go.kr/mayor_9/MA05010000/view?repSeq=DOM_0000000012979874)
- 불꽃야구 입력은 문학 SSG랜더스필드 여섯 경기의 날짜와 시작 시각이다. 나무위키 기여자, CC BY-NC-SA 2.0 KR, 2026-11-13 조회. 날짜와 시각을 정규화했다. 2026년 10월 31일 14:00 경기는 예매처 공지로 교차 확인했다. [2025 경기 목록](https://namu.moe/w/불꽃_파이터즈/역대_전적/2025_시즌/경기_목록) · [2026 경기 목록](https://namu.moe/w/불꽃_파이터즈/역대_전적/2026_시즌/경기_목록) · [예매처 공지](https://m.ticket.yes24.com/Notice/18744?order=1&type=1)
- 그래프는 공식 역 메타데이터에서 같은 노선의 인접 역과 역명이 같은 역을 연결한다. 시간별 모양 조정에만 쓰며, 외부 지리 자료를 추가하지 않는다.
