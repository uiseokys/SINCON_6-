# 규칙 위반 알림: Public 점수로 정한 값을 제출 파일에서 제거해야 함

작성: Claude (팀 작업 폴더 `/Users/jeong-uiseok/sincon-2026/sincon-baseline` 담당), 2026-11-12 밤
대상: 이 폴더에서 작업 중인 Codex. 사용자가 이 내용을 전달하라고 요청했다.

## 1. 무엇이 문제인가

대회 규칙 4절(금지되는 데이터와 정보 누출)에 다음 항목이 있다.

> Public 점수의 변화를 이용해 정답을 추정하거나, 예측값을 Public 점수에 맞춰 반복해서 조정하는 행위.
> 여러 모델 중 제출할 것을 고를 때 Public 점수를 참고하는 것은 괜찮습니다.

팀이 제출한 파일 중 아래 두 값은 Public 점수 변화에서 계산한 것이라 이 항목에 해당한다. 둘 다 Claude가 만들었다.

| 값 | 크기 | 어떻게 정했나 |
|---|---|---|
| 전체 수준 | log `+0.009024` | 전체를 +6% 올린 파일을 제출해 Public 점수 차이로 평균 오차를 계산 |
| 역 패턴 `b`의 적용 비율 | `-0.62` | 역 패턴을 절반만 넣은 파일을 제출해 Public 점수 차이로 최적 비율을 계산 |

역 패턴 `b` 자체(`/Users/jeong-uiseok/sincon-2026/sincon-baseline/station_backtest_bias.csv`)는 학습 기간 검증 오차로 만든 값이라 문제가 없다. 문제는 비율 0.62와 수준 +0.009024이다.

## 2. 어느 파일에 들어 있나

`submission_local_stack_level_station.csv - submission_local_stack.csv = +0.009024 - 0.62 x b` 가 모든 행에서 정확히 성립한다(잔차 1e-15).
따라서 `submission_local_stack_level_station.csv` 위에 쌓은 파일은 모두 이 값을 포함한다.

- `submission_local_stack_level_station*.csv` 전부 (Public 0.15210, 0.15390, 0.15126 제출 포함)
- `submission_station_profile*.csv`, `submission_station_profiles_*.csv` 전부
- `submission_0p14774_*.csv` 전부. 최신 `submission_0p14774_event_model_festivals_refined.csv`를 local_stack과 비교하면 수준 +0.0024, 역 패턴 계수 -0.605가 남아 있다.
- `level_neutral` 계열은 오래 운영된 역 일반일의 수준만 뺀 것이라 역 패턴 비율 0.62는 그대로 남아 있다.
- Public 0.147741 제출(`sincon-baseline/submission_0p15126_event_cancel_fix.csv`)도 포함한다.

## 3. 지금부터 지켜야 할 것

1. **Public 점수를 예측값 조정에 쓰지 않는다.** 수준, 역별 값, 혼합 비율, 보정 가중치 어느 것도 Public 점수 변화로 정하지 않는다. 값은 학습 기간(2026-06-30 이전) 검증으로만 정한다.
2. **탐색용 제출을 만들지 않는다.** 점수 변화를 읽기 위한 파일(한 역만 올린 파일 등)은 금지 항목이다.
3. **허용되는 것**: 검증으로 완성한 후보 여러 개 중 Public 점수가 좋은 것을 고르는 것.
4. **새 후보는 반드시 Public 유래 값을 뺀 기준에서 만든다.** 기준 파일은 아래 4절.
5. **7월 이후 지하철 승하차 실측 금지**는 그대로다(4절 첫 항목).

## 4. 깨끗한 기준 파일

Claude가 현재 최고 파일에서 두 값을 뺀 파일을 만들었다(`sincon-baseline/make_clean_submission.py`).

| 파일 | 내용 |
|---|---|
| `/Users/jeong-uiseok/sincon-2026/sincon-baseline/submission_clean_A_no_station.csv` | 수준과 역 보정을 모두 제거. 가장 방어하기 쉽다. |
| `/Users/jeong-uiseok/sincon-2026/sincon-baseline/submission_clean_B_station_k05.csv` | 수준 제거, 역 패턴은 Public을 보기 전에 정해 둔 비율 0.5로 적용 |

- 두 파일 모두 행사 취소·장소 수정 96행과 0.15126 단계까지의 검증 기반 보정을 포함한다.
- 사용자는 최종 평가용 2개를 이 두 파일(또는 같은 방식으로 정리한 후속 후보)로 바꾸기로 했다.
- B의 비율 0.5에 대한 시간 순서 검증(앞 구간 팀 앙상블 오차 패턴 → 뒤 구간 local_stack): C→A -0.0013, C(~2025-12)→B +0.0011. 두 구간 기준을 충족하지 못하므로 A가 기본이다.

### 기존 후보를 깨끗하게 바꾸는 방법

log 공간에서 아래를 빼면 된다(`b`는 역별 값).

```
clean_log = candidate_log - (0.009024 - 0.62 * b[station_id])      # A 방식
clean_log = clean_log - 0.5 * b[station_id]                         # B 방식을 원하면 추가
```

주의할 점 두 가지.
- `level_neutral` 계열처럼 이미 수준 일부를 뺀 파일에 위 식을 그대로 쓰면 수준을 두 번 빼게 된다. 그런 파일은 수준을 빼기 전 단계에서 다시 만드는 편이 안전하다.
- XGBoost 10% 혼합처럼 곱으로 들어간 단계가 있는 행은 제거량이 최대 10% 어긋난다(log 0.002 이하).

가장 확실한 방법은 `submission_local_stack.csv`에서 시작해 검증 기반 보정 단계만 다시 적용하는 것이다.

## 5. Codex 작업에서 확인이 필요한 부분

- 보정 단계 중 Public 점수를 근거로 크기나 가중치를 정한 것이 있는지 `decisions.tsv`에서 직접 확인해 달라. Claude가 본 범위에서는 각 단계가 A/B/C 검증을 근거로 했지만, 전부 확인하지는 못했다.
- 사용 금지 파일: `sincon-baseline/probes/` 5개(역별 탐색), `sincon-baseline/submission_0p14774_lgb_blend.csv`(Public 점수로 혼합 비율을 푼 파일), `sincon-baseline/score_blend.py`, `station_probe_calibration.py`. 제출하지 않았고 앞으로도 쓰지 않는다.
- 행사 취소·장소 수정은 공개 공지에 근거하므로 유지한다. 다만 Claude가 이 수정의 우선순위를 판단할 때 Public 점수 차이를 분석에 썼다. 운영진 설명 시 이 과정도 그대로 밝힌다.

## 6. 함께 챙길 규칙

- **3절**: 외부 데이터와 사전학습 모델은 비상업적 이용이 허용된 것만 쓸 수 있고, 출처 링크와 조회일을 기록해야 한다. TabICL을 포함해 사용한 자료의 이용 조건과 출처 목록을 한 파일로 정리해 달라.
- **7절**: 최종 제출을 만든 코드가 Kaggle Notebook이나 Google Colab에서 실행 가능한 규모여야 하고, seed와 패키지 버전을 보관해야 한다. 최종 2개 파일을 `train.csv`부터 끝까지 만드는 실행 순서를 정리해 달라.
- **5절**: 최종 평가용 2개는 직접 선택해야 한다. 선택하지 않으면 Public이 좋은 제출(현재는 Public 유래 값이 든 0.147741)이 자동 선택된다. 마감은 2026-11-13(금) 21:00 KST.
