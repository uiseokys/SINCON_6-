# 핫식스 최종 후보 독립 감사

작성 시각: 2026-11-12T17:15:12.704794+00:00 UTC. 작업 9번, Claude 검토용. 읽기 전용 감사이며 후보를 승인하거나 교체하지 않았다.

## 먼저 확인할 문제

1. **OOF의 엄격한 시간 독립성이 깨진다.** 기준일 이후 정답만 바꿔도 TabICL 층의 전역 채택 판단이 달라지고, 2025-06-30 기준 OOF의 102,006행이 최대 log 0.02561184036428621 달라진다. 기준일별 적합 계수의 누출 검사만으로는 잡히지 않는다.
2. **현재 별도 후보와 이전 17행 감사가 서로 다른 버전이다.** 7행의 값이 바뀌었고 기존 감사 스크립트는 현재 후보에서 assertion으로 실패한다. 현재 `event_hedges.py` 자체의 산술은 17행 모두 정확히 재현됐다.
3. **규칙 3절의 출처 증빙이 완성되지 않았다.** 최종 경로는 기존 KBO 자료 등을 그대로 소비한다. CC 위키 대조와 부분 재학습을 전체 입력 교체·권리 확인 완료로 설명하면 안 된다. PLAVE 예매 23,120·19,494의 원출처도 미확인이다.

2026년 7월 이후 **지하철 승하차 실측을 직접 사용한 파일은 검사 범위에서 발견하지 못했다.** 위 OOF 문제는 2026-06-30까지의 학습 기간 안에서 과거 검증의 미래 정답을 사용하는 문제다. 이를 곧바로 대회 금지 실측 사용이나 실격 사유로 단정하지 않는다.

## 판정표

| 항목 | 판정 | 근거 파일·행 및 핵심 결과 |
| --- | --- | --- |
| 1. Public 유래 값 | 문제 없음 | 감사한 조립·최종층 경로에서 알려진 금지 값·파생 제출의 입력 미발견. [sincon_clean_15126_replay.py:76](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_clean_15126_replay.py:76), [final_layers.py:168](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/final_layers.py:168), `runtime_data_reads.csv:1`, `regression_layers.csv:1`. 아래 범위 한계 적용. |
| 2. 시간 누출 | 문제 있음 | [sincon_clean_model_layers.py:143](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_clean_model_layers.py:143)의 전역 채택 판단과 [sincon_clean_model_layers.py:268](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_clean_model_layers.py:268)의 OOF 반영. `oof_global_gate_counterfactual.json:1`. 명절 옛 코드의 누출도 재현, 현재 최종 36행에는 영향 없음. |
| 3. 7월 이후 지하철 실측 | 문제 없음 | 검사한 직접 입력에서 미발견. 공식 train 마지막 2026-06-30, test에 정답 열 없음. [final_layers.py:141](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/final_layers.py:141), [sincon_mobility_data.py:15](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/sincon_mobility_data.py:15), `count_like_date_scan.csv:1`, `archive_count_scan.csv:1`. 공급자 내부 간접 이용은 확인 불가. |
| 4. 형식·무결성 | 문제 없음 | 두 후보 모두 157,194행·공식 순서·ID 중복 0·유한·비음수. [event_hedges.py:50](/Users/jeong-uiseok/sincon-2026/sincon-baseline/event_hedges.py:50), `format.json:1`, `hedges_17_recomputed.csv:1`. |
| 5. 문서·실제 일치 | 문제 있음 | 수치 36개 검산, 8개 불일치. [ROUND7_RESULT.md:118](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/ROUND7_RESULT.md:118), [NIGHT_LOG.md:39](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/NIGHT_LOG.md:39), `document_numeric_checks.csv:1`. 추가 서술·계획 오류 아래 기재. |
| 6. 별도 후보 17행 | 문제 있음 | 산술과 변경 ID는 일치. 하지만 이전 감사와 7행이 다르고 W·시간 비중의 독립 검증 및 예매 원출처 부족. [event_hedges.py:12](/Users/jeong-uiseok/sincon-2026/sincon-baseline/event_hedges.py:12), [audit_events.py:89](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/audit_events.py:89), [FINAL_REPORT.md:78](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/FINAL_REPORT.md:78). |
| 7. 남은 운영 위험 | 문제 있음 | 이용 허락 증빙, OOF의 선택 편향, 현재 별도 후보 검토 버전, 전체 재학습·클라우드 실기 미확인. [SOURCES_FINAL.md:5](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night6/SOURCES_FINAL.md:5), [STATUS.md:15](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/STATUS.md:15). |

`문제 없음`은 아래 실행·파일 검사 범위의 판정이다. 원시 모델 전부를 이번 감사에서 다시 학습한 판정이나 저장소 전체에 숨은 값이 없다는 수학적 증명은 아니다. 새 웹 검색·다운로드, Public 기반 값 선택, Kaggle 업로드는 하지 않았다.

## 감사 범위와 고정한 파일

대상 폴더는 프로젝트 루트와 `/Users/jeong-uiseok/sincon-2026/sincon-baseline`이다. 후보·공식 train/test·최종층 캐시·대상 문서 26개를 `snapshot/`에 복사하고 해시를 고정했다. 계산 종료 검사 당시에는 원본 해시가 전부 같았으나, 마지막 확인 중 **Claude 병행 작업으로 FINAL_REPORT와 NIGHT_LOG 두 문서가 갱신됐다.** 후보·공식 데이터·최종층 입력 24개와 감사한 코드 110개는 그대로다. 최종 확인은 `verification_summary.json:1`, 문서 변경은 `concurrent_source_changes.json:1` 및 `*.concurrent.diff`에 보존했다. 이 문서에서 두 팀 문서의 행 번호 링크는 감사 당시 `snapshot/team/` 사본을 가리킨다.

갱신본은 2단계 노트북 안내와 02:15 진행 기록을 추가하고, 옛 structural_floor·평균 제출 계획을 현재 두 후보로 수정했다. **옛 제출 계획 오류는 최신 문서에서 해결됨**으로 처리한다. 정량 불일치 8개와 OOF gate·출처 문제에 영향을 주는 변경은 이 diff에서 발견되지 않았다. `FINAL_REPORT.md.latest`, `NIGHT_LOG.md.latest`가 마지막 관찰본이며 그 뒤의 추가 작업은 이 감사 범위 밖이다.

상위 경로·동적 실행 스크립트를 포함한 110개 Python 모듈의 코드, 숫자 상수 4,205개와 데이터 파일 문자열 566개를 AST로 열거하고 `snapshot_code/`에 보존했다. 열거 자체가 모든 상수의 외부 사실 검증을 뜻하지는 않는다. 주요 보정 상수는 아래에서 별도 계산했다.

| 파일 | SHA-256 |
| --- | --- |
| 주후보 `submission_night_v4_main.csv` | `4c85257294be267c47396587f3a71a2d1e238dc93f957a634cfe662f8e379965` |
| 별도 후보 `submission_night_v4_events_hedged.csv` | `7cc7f4de5d89036b8553ab49ba4d0fd063b22f66c946ccd849eb629204cf44a5` |
| 1단계 기준 `submission_clean_refined.csv` | `519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199` |

`night7/submission_round7_main.csv`는 주후보와 **수치상 동등**하지만 바이트는 다르다. 최대 log1p 차이는 8.8817841970012523e-16, SHA-256은 `b1b8a74dfece0eeded0c88e66033668eb70552f89544f4bb8a764cfe99d40d76`다. 이는 [ROUND7_RESULT.md:208](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/ROUND7_RESULT.md:208)에 이미 적힌 직렬화 차이와 일치한다.

## 1. Public 유래 값과 층별 분해

1단계 `pipeline.Run(mode="assemble")`를 실제 실행했다. 하위 프로세스의 파일 변경 목적지를 `final_audit/`로 제한하고 네트워크를 차단했다. 공식 입력 및 보관 예측에서 만든 결과는 `submission_clean_refined.csv`와 최대 차이 0, 바이트·해시까지 일치했다. 증거는 `assemble_stdout.log:1`, `stage1_run_location.json:1`, `read_01_early.json:1`부터 `read_04_events_after_model.json:1`까지다. 2단계도 실제 함수를 실행해 주후보와 위 정밀도로 일치했다.

활성 경로는 다음과 같다.

```text
보정 전 local_stack + conditional_stack + 공식 train/test + 외부 사실·모델 예측 ZIP
 → clean_15126_replay: 행사 일정, 성숙역 XGB·날씨, 계양·귤현·심야
 → clean_event_replay(before_model): 취소·장소·경기·과학·원미
 → clean_model_layers: 역 프로필, TabICL, 동춘, 명절, 검단 아침, 벡터
 → clean_event_replay(after_model): 최종 축제·과학·둘레길
 → clean_refined
 → timecapsule → plave_existing → station025 → friday → plave22 → lunar3122
 → main
 → event_hedges의 고정 17행 → events_hedged
```

실제 데이터 읽기와 ZIP 내부 항목은 `runtime_data_reads.csv:1`, `runtime_zip_members.csv:1`에 해시와 함께 있다. 금지 probe·점수 혼합·`level_station` 제출·`station_backtest_bias.csv`는 후보 생성 프로세스의 데이터 입력으로 읽히지 않았다. `b` 파일은 **이 감사의 회귀 진단에서만** 읽었다. `read_assemble.json`의 일부 파일 읽기는 전체 payload 해시 검사이며, 계산 입력은 하위 단계별 trace로 구분한다.

옛 파일명 문자열은 미호출 함수 등에 13곳 남아 있다. `public_pattern_static_hits.csv:1`에 전부 기록했다. 예를 들어 [sincon_songdo_schedule.py:24](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_songdo_schedule.py:24)의 CHAMPION 이름은 남지만 이번 경로의 해당 읽기 함수는 호출되지 않았다. 패키지의 [sincon_apply_final_calibration.py:1](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_apply_final_calibration.py:1)와 [sincon_complementary_blend.py:59](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_complementary_blend.py:59)는 옛 Public 보정을 호출하면 예외를 내게 막혀 있다. 원본 팀 `ensemble.py`의 +0.0217 main과 달리, 패키지 [ensemble.py:18](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/team/ensemble.py:18)는 원시 두 모델 예측 함수만 남겼다. 옛 코드의 존재와 현재 입력 소비를 구분해야 한다.

`+0.009024`, 실제 원값 `+0.0090238206986512966`, `−0.62×b`, 초기 `+0.021742424607211323`, Public 역산 배율 약 `1.021177`이 활성 상수로 들어온 증거는 없다. 결과 문서의 검증 기반 `1.021496...`와 Public 역산 `1.021177...`은 서로 다른 숫자다. 숫자 접두어가 같다는 이유로 같은 출처라고 판정하지 않았다. 관련 기록은 [SINCON_PUBLIC_SCORE_AUDIT.md:7](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/SINCON_PUBLIC_SCORE_AUDIT.md:7) 및 `all_numeric_constants.csv:1`에 있다.

회귀는 공식 157,194행 전부에서 다음 식으로 계산했다. 모든 역의 행 수가 같고 b의 평균이 거의 0이므로 절편은 평균 로그 차이와 같다.

```text
log1p(후보) − log1p(local_stack) = a + c × b[station] + residual
```

| layer | intercept | b_coefficient |
| --- | --- | --- |
| stage1_early | +0.001404962309 | -0.028748695530 |
| stage1_events | -0.000718788270 | -0.015511514568 |
| stage1_model | -0.000762405107 | -0.006546069119 |
| stage1_submission_clean_refined | +0.000048561105 | +0.000863452565 |
| stage1_total | -0.000027669962 | -0.049942826653 |
| timecapsule | +0.000016523310 | +0.000536648110 |
| plave_existing | +0.000012507763 | +0.000171965750 |
| station025 | +0.000000000000 | -0.139179939418 |
| friday | +0.000000000000 | +0.000106281328 |
| plave22 | +0.000005754400 | +0.000079115647 |
| lunar3122 | +0.000066287561 | +0.000096267547 |
| main_minus_local | +0.000073403072 | -0.188132487688 |

전체 평균 로그 차이는 `7.34030722589823e-05`, 즉 1+승차의 기하평균 비로 약 **+0.0073406%**다. 승차 합계는 `51929113.462801 → 51904862.413788`, 합계 비는 `0.999532997053`다. 로그 중앙값 차이는 `-0.000667193285`다. 한 가지 일정한 수준 이동으로 설명되는 변화가 아니다.

남은 b 계수 `−0.188132488` 중 `−0.139179939`는 최근 60일·0.25배 층에서 직접 나온다. 이 층을 공식 정답과 OOF에서 **독립 계산**한 최대 차이는 4.42e-16다. 나머지 `−0.049942827` 등은 재실행한 1단계와 희귀 행사층의 기여로 닫힌다. `regression_closure.json:1`의 최종 분해 잔차는 1e-15 수준이고, 1단계 모델 내부 층 합은 `stage1_inner_closure.json:1`에서 차이 0이다. 따라서 회귀 계수를 곧바로 제거해야 할 Public 배율로 해석하면 안 된다.

모델 내부의 추가 분해는 `regression_stage1_details.csv:1`에 있다. 시간 모양만 바꾸는 TabICL·벡터 층은 절편과 b 기여가 수치 오차 수준이다. 단, 이 층들을 채택한 OOF의 독립성 문제는 다음 절에 남는다. 이번에는 원시 native·graph·XGB·TabICL 전체 재학습까지 하지 않았으므로, 보관 원시 예측의 전 생애 이력을 실행만으로 완전히 입증하지는 못했다.

## 2. 시간 누출

### 발견 F1: 전역 검증 점수로 과거 OOF 층 채택 여부가 바뀜

[sincon_clean_model_layers.py:130](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_clean_model_layers.py:130)는 기준일별 TabICL 가중치를 앞선 정답으로만 적합한다. 하지만 같은 파일 143~150행은 A/C·여름·warm 전체 검증 정답을 보고 fixed/guarded의 채택을 정한다. 216~225행과 268~271행은 그 전역 판단을 과거 OOF에도 소급 적용한다. 동춘 240~248행과 벡터 293~300행에도 같은 구조의 전역 채택 gate가 있다. **뒤 두 gate의 실제 출력 변화는 이번에 별도로 입증하지 않았으며, 같은 구조라는 정적 위험으로만 기록한다.**

`temporal_gates.py`는 실제 함수와 실제 역 프로필 보정 후 OOF를 사용했다. 원시 예측과 기준일 이전 관측을 고정하고 2025-06-30 이후의 OOF 정답만 `log1p(999999999)`로 바꿨다. 이 수치는 민감도 검사를 위한 합성값이며 실제 수요 자료가 아니다.

| 검사 | 원본 | 변조 후 |
| --- | --- | --- |
| 2025-06-30 적합 가중치 | 0.20, prior_dates=0 | 0.20, prior_dates=0 |
| guarded 전역 채택 | true | false |
| 최종 반환 가중치 | 0.30 | 0.10 |
| 그 기준일의 달라진 OOF | 0 | 102,006행 |
| 최대 로그 차이 | 0 | 0.025611840364286209 |

재현 명령은 `README.md`에 있다. 상세 증거는 `oof_global_gate_counterfactual.json:1`과 `temporal_stdout.log:1`이다. 이는 **채택 gate와 그에 따라 OOF에 들어가는 열의 변화 검사**이며, 원시 모델을 모두 재학습한 반사실 실험은 아니다. 그럼에도 “각 기준일 OOF가 그 뒤 실측에 전혀 의존하지 않는다”는 강한 주장은 성립하지 않는다. 이 OOF를 최근 역별 오차의 입력으로도 사용하므로, 독립 검증 이득을 그대로 확정값으로 인용하면 안 된다.

권고: 기준일마다 그 이전 자료만으로 층 채택을 정하는 중첩 순방향 검증을 하거나, 별도 개발 구간에서 채택을 고정한 뒤 독립 구간 OOF를 다시 생성한다. 수정 OOF로 최근 60일 층을 재적합하고 후보를 다시 비교해야 한다. 이번 감사는 후보나 캐시를 변경하지 않았다.

### 나머지 시간 경계의 실제 검사

| 대상 | 판정 | 실제 확인 |
| --- | --- | --- |
| 공식 정답·시험 격자 | 문제 없음 | train 688,176행, 2025-01-01~2026-06-30, 이후 행 0. test 2026-07-01~10-31, boardings 열 없음. `official_data.json:1`. |
| OOF 키·정답 | 문제 없음 | 1,283,112행·9 origins, date>origin, date≤2026-06-30, 공식 정답 오차 1e-10 미만. 이것만으로 생성 과정의 무누출을 증명하지는 못함. `oof_overview.json:1`. |
| 역별 60일 | 문제 없음 | 2026-05-02~06-30, 최신 origin 04-30, 230,040행. 고유 실측 키 76,680, 3회 중복 포함은 기존 지정 규칙. 기준일 이후 y_log만 +1000한 검사에서 모든 기준일의 적합 변화 0. [final_layers.py:60](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/final_layers.py:60). |
| PLAVE 기존 21·22시 층 | 문제 없음 | 기준일까지 완결된 공연 계열만 기증. 모든 origin 이후 train 값을 바꿔도 donor_total 동일. `station_concert_counterfactual.json:1`, [final_layers.py:41](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/final_layers.py:41). |
| 타임캡슐 | 문제 없음 | 2025-06-14 실측 272/489/88, 평소 80/78/55, 목표 평소 102/77/58을 공식 train에서 재계산. 최종 평소의 마지막 실측 2026-06-27. `timecapsule_independent.json:1`, [timecapsule_floor_check_v3.py:48](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night/research_songdo/timecapsule_floor_check_v3.py:48). |
| 부평삼거리 최종층 | 문제 없음 | 기증 명절 2025-01-29·10-06·2026-02-17과 전날. 기증 평소 실측은 ≤cutoff, 목표 주변 일요일은 예측. 미래 합성 실측 157,194행을 추가해도 최종 kernel 변화 0. [final_layers.py:97](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/final_layers.py:97), `post_cutoff_kernel_poison.json:1`. |
| 부평삼거리 옛 검증 | 문제 있음 | [lunar_station_surge.py:47](/Users/jeong-uiseok/sincon-2026/sincon-baseline/lunar_station_surge.py:47)는 명절만 자르고 주변 일요일은 자르지 않음. 2025-10-31 기준에서 11/2·11/9 혼입. 전날·당일의 strict/unsafe 차이 0.02811950·0.05623899를 독립 재현. 현재 최종 36행에서는 차이 없음. |
| 부평삼거리 수정 검증 | 문제 없음 | 독립 구현의 12개 명절일 예측은 모든 origin 이후 관측 +1000 변조에도 차이 0. `lunar_independent_counterfactual.csv:1`. 전체 점수도 독립 재계산해 `lunar_scores_independent.csv:1`에 저장. |
| PLAVE 22시 계수 | 문제 없음 | 실제 27개 정답, 평소 120일·같은 요일·행사/야구 제외를 모두 재계산. 캐시의 actual·ordinary·ratio22와 차이 0. 최종 계수 0.173226702067872. [reproduce_night5.py:142](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night5/reproduce_night5.py:142), `concert_rates_independent.csv:1`. |
| 금요일 공휴일 | 문제 없음 | 5개 활성 origin에서 이후 실측 +1000 변조에도 변화 0. 최종 donor 2025-06-06·08-15·2026-05-01, 모든 대조 실측 cutoff 이내. 미래 합성 실측 추가에도 최종 변화 0. [sincon_clean_friday_calendar.py:58](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/sincon_clean_friday_calendar.py:58), `friday_origin_counterfactual.json:1`. |
| 상위 원시 모델 전체 | 확인 불가 | 날짜 자르기·정답 없는 target·학습 전용 정규화 코드를 확인했지만 이번 감사에서 전 모델 재학습과 전 origin 반사실 재학습까지 하지는 않음. [sincon_conditional_candidate.py:52](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_conditional_candidate.py:52), [sincon_graph_network.py:74](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_package/payload/work/sincon_graph_network.py:74). |

“모든 자료가 6월 이전”이라는 표현은 맞지 않는다. 대회가 허용한 미래 기간의 날씨·행사·관중·비철도 이동·버스 자료는 들어 있다. 여기서 시간 경계 검사는 **지하철 정답과 그 정답으로 적합하는 계수**에 대한 것이다. 미래의 행사 사실을 과거 origin 당시에 알 수 있었다는 의미의 실시간 운영 검증도 아니다.

## 3. 저장소의 7월 이후 승하차처럼 보이는 자료

파일 목록 16,100개, CSV 헤더·첫 표본 2,472개, 날짜와 승하차/observed/y_log 열을 가진 CSV 165개의 해당 열 전체를 조사했다. ZIP의 CSV 328개 항목도 조사했고 내용 중복을 제외한 고유 항목은 140개다. UTF-8 실패 파일은 CP949로 다시 읽었고 최종 검사 오류는 0이다. 결과는 `repository_inventory.csv:1`, `csv_headers_and_samples.csv:1`, `count_like_date_scan.csv:1`, `archive_count_scan.csv:1`이다.

| 파일·열 | 구분·결과 |
| --- | --- |
| `sincon_station_bus_traffic.csv`의 bus_boardings / bus_alightings / bus_city_* | 1,349행 중 213행이 2026-07 이후. 역 주변 **버스 월 집계**다. 기존 local_stack의 버스 모델은 이 입력을 사용한다. 새 팀원 정류장 37157 파일과 다르다. |
| `night5/bus_timing_auxiliary.csv`의 21(승차)·22(승차)·23(승차) | 2026-09-09~22의 정류장 37157 **버스** 14행. 9/12는 3/76/5, 9/13은 5/42/6. 최종 후보 생성 함수에는 파일 경로·숫자 배열 입력이 없다. |
| `mobility_monthly/*.csv.gz`의 arrivals·mode | 22개월 파일을 직접 읽음. mode는 regional_bus / local_bus / walking / car 네 종류만 존재. subway·rail mode 없음. `mobility_modes.json:1`, [sincon_mobility_data.py:15](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/sincon_mobility_data.py:15). 공급자 내부 추정에서 실측 보정 여부는 확인 불가. |
| KBO·축구의 attendance·start_kst·end_kst | 관중·경기 시각이며 지하철 승차 수치가 아님. 사용 허락은 별도 문제. |
| `night5/current_rows.csv:boardings`, `other_event_checks.csv:current_day_boardings` | 후보 예측값. 공식 정답의 이후 실측이 아님. |
| `submission*.csv:boardings` | 예측 CSV. 날짜가 ID에서 연결되는 것을 공식 test와 맞춰 확인. 열 이름만으로 실측으로 판정하지 않음. |

팀원 STCIS 파일의 **직접 수치 입력 미사용**은 확인했으나, **의사결정 참고까지 전혀 없었다**고 말할 수는 없다. [ROUND5_RESULT.md:81](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night5/ROUND5_RESULT.md:81) 및 [FINAL_REPORT.md:77](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/FINAL_REPORT.md:77)는 22시 집중을 보조 확인하는 데 참고했다고 적는다. 현재 별도 후보의 10/85/5는 코드에 고정되어 있고, 박효신 실측 비중 평균 약 14/84/2를 참고했다는 설명이다. 파일의 직접 미사용과 사람이 자료를 보고 가설을 정한 경위를 구분해 공개해야 한다.

한계: `.build`, 가상환경, `.git`, `__pycache__`는 제외했다. `final_package/outputs`의 중복 실행 작업공간은 파일 목록만 조사했다. 임의 바이너리·모든 JSON 자유문까지 표준화해 전수 분석한 것은 아니다. 이 범위와 공급자 내부 간접 이용 때문에 저장소 어느 곳에도 금지 정보가 절대 없다고 보증하지 않는다.

## 4. 형식·무결성

| 검사 | 주후보 | 별도 후보 |
| --- | ---: | ---: |
| 행·고유 ID | 157,194 / 157,194 | 157,194 / 157,194 |
| 공식 ID 순서 | 일치 | 일치 |
| 중복 ID / 비유한 / 음수 | 0 / 0 / 0 | 0 / 0 / 0 |
| 최솟값 | 2.602686342274 | 2.602686342274 |
| 최댓값 | 4901.646704210929 | 5271.451973266019 |
| 0인 예측 | 0 | 0 |
| clean_refined 대비 변경 | 157,194 | 157,194 |
| 주후보 대비 변경 | 0 | 17 |

최소 주후보는 `J148625`, 2026-10-25 문학3127 23시의 2.602686342274명이다. 최대 주후보는 `J004209`, 2026-07-04 문학3127 21시의 4,901.646704211명이다. 별도 후보 최대는 PLAVE 9/12 22시 `J093670`의 5,271.451973266명이다. 수치 폭만으로 형식상 이상치는 발견되지 않았으며, 이 판단이 희귀 행사 규모의 정확성을 보증하지는 않는다.

요청한 상·하위 각 20행은 `main_extremes.csv:1`, `events_hedged_extremes.csv:1`에 전부 있다. 기준 대비 모든 변경 행은 `main_changes_from_clean.csv.gz`, `events_hedged_changes_from_clean.csv.gz`, 6개 층의 행별 로그 차이는 `stage2_layers.csv.gz`다. 순차 층별 변경 행은 3 / 4 / 157,194 / 2,016 / 2 / 36으로 문서와 일치한다. 겹치는 층의 행 수를 더해 전체 고유 변경 행이라고 세면 안 된다.

## 5. 문서와 실제의 불일치

수치 36개를 확인해 28개는 표시 정밀도 안에서 일치하고 8개는 달랐다. `document_numeric_checks.csv:1`에 원문 파일·행, 허용오차, 실제 값을 모두 저장했다. ROUND2 행사 7행·하한값, ROUND3 RMSLE, ROUND5 PLAVE, ROUND7 층 크기·명절 합계, FINAL_REPORT의 현재 후보 수치를 포함한다.

### 발견 F2: 이전 17행 감사와 현재 별도 후보의 7행 차이

| example_id | ROUND7 기록 | 현재 후보 |
| --- | --- | --- |
| J093669 | 414.152955 | 849.214439 |
| J093671 | 571.355121 | 311.283255 |
| J094947 | 298.448736 | 651.477399 |
| J094949 | 441.172367 | 240.234711 |
| J138398 | 1602.818389 | 1317.330595 |
| J138399 | 2026.883730 | 2190.255054 |
| J138400 | 323.491803 | 496.018180 |

원문은 [ROUND7_RESULT.md:118](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/ROUND7_RESULT.md:118)부터의 표, 기계 판정표는 `night7/event_validation_v2/hedges_17_judgments.csv:1`이다. 옛 PLAVE 3/85/12가 현재 10/85/5로, 랜더스 FULL 3255/3513/366이 현재 2199/4102/860으로 바뀌었다. 기존 [audit_events.py:89](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night7/audit_events.py:89)도 옛 규칙을 사용한다. 현재 후보를 넣어 실제 실행하면 104행 `assert abs(expected-x.hedged)<1e-8`에서 실패했다. `old_hedge_failure_result.json:1`과 `old_hedge_audit_stderr.log:1` 참조. 재현은 `python3 -B final_audit/reproduce_expected_failure.py`다.

이전 “17행 모두 근거 부족” 판정의 방향은 현재 가정에도 남는 우려지만, **현재 숫자 17행을 독립 검산한 증거**로 옛 표를 제시하면 안 된다. [FINAL_REPORT.md:70](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/FINAL_REPORT.md:70)에 현재 파일 해시와 새 감사 범위를 붙이는 것이 필요하다.

### 그 밖의 오류·범위 누락

| 위치 | 문제 | 실제·권고 |
| --- | --- | --- |
| [NIGHT_LOG.md:39](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/NIGHT_LOG.md:39) | 2025 설 당일 5.5배 | 같은 일요일 정의로 8127/1551=5.239845배. ROUND7의 수정값과 불일치. 원시 학습값은 반올림 요약을 쓰지 않음. |
| [NIGHT_LOG.md:42](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/NIGHT_LOG.md:42) | 별도 17행의 PLAVE 시간을 21·23시로만 표기 | 실제는 양일 21·22·23시 6행. 21·23시 4행+SWF 8+랜더스 3만 세면 15행. |
| [NIGHT_LOG.md:58](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/NIGHT_LOG.md:58) | 감사 당시 아침 계획 C1에 structural_floor, C2에 0.5 평균이 남았음 | **02:15 병행 갱신본에서 해결됨.** 최신 관찰본은 현재 main·events_hedged를 쓰며 구조 하한 폐기를 명시. 이전 버전과 diff를 보존. |
| [FINAL_REPORT.md:71](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/FINAL_REPORT.md:71) | 과거 공연 9일 전부 예측≤실제 1/4이라고 단정 | 제공된 과거 OOF 비교는 고유 7일이며 2025-03-20·21은 OOF가 없다고 ROUND5가 명시. 9일 모두의 정량 예측 검증으로 쓰기 어려움. `concert_oof_ratios_independent.csv:1`. |
| [FINAL_REPORT.md:102](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/snapshot/team/FINAL_REPORT.md:102) | 위키 교체 후 예측이 사실상 같다는 설명의 범위 누락 | 3건 +3명 전용 야구 트리 실험만 0행. 충돌 포함 4건은 630행, 최대 log .1419061688, 최대 인원 572.4153 차이. 원시 다수 모델은 고정. [SOURCES_FINAL.md:89](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night6/SOURCES_FINAL.md:89)·96행과 함께 설명해야 함. |
| [event_hedges.py:12](/Users/jeong-uiseok/sincon-2026/sincon-baseline/event_hedges.py:12) | 수식이 current^(1-W)×FULL^W로 적힘 | 실제는 `(1+current)^(1-W)×(1+FULL)^W−1`. 실행 60행은 log1p를 쓰며 산술 재현은 통과. |
| [event_hedges.py:37](/Users/jeong-uiseok/sincon-2026/sincon-baseline/event_hedges.py:37) | BASE를 정확한 중앙값처럼 표기 | 토22=21.5, 일21=24.5, 일23=4.5 등이 정수로 반올림돼 있음. 주후보 PLAVE22는 21.5/15를 정확히 사용. 별도 후보 BASE는 반올림 상수라고 적는 편이 정확. |
| [event_hedges.py:15](/Users/jeong-uiseok/sincon-2026/sincon-baseline/event_hedges.py:15) | 박효신과 PLAVE의 공연 길이가 비슷하다고 설명 | ROUND5 조사표에서 박효신 공식 러닝타임은 미확인. 시작 시각 및 실제 비중 참고와 러닝타임 확인을 구분해야 함. |

FINAL_REPORT의 현재 PLAVE·SWF·랜더스 반올림 예측과 주후보 층별 행 수는 실제 파일과 맞았다. `ROUND7`의 주후보 재현 해시·정밀도도 맞았다. 옛 보고서가 모든 부분에서 틀린 것은 아니다.

### 수치 검산 전체 목록

| file | line | claim | document_value | actual | status |
| --- | --- | --- | --- | --- | --- |
| sincon-baseline/FINAL_REPORT.md | 34 | timecapsule changed rows | 3.000000000 | 3.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 35 | plave_existing changed rows | 4.000000000 | 4.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 37 | friday changed rows | 2016.000000000 | 2016.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 38 | plave22 changed rows | 2.000000000 | 2.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 39 | lunar3122 changed rows | 36.000000000 | 36.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 14 | hedge rows | 17.000000000 | 17.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 66 | 0912 hedge hour 21 | 849.000000000 | 849.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 66 | 0912 hedge hour 22 | 5271.000000000 | 5271.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 66 | 0912 hedge hour 23 | 311.000000000 | 311.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 68 | 1017 hedge hour 20 | 1317.000000000 | 1317.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 68 | 1017 hedge hour 21 | 2190.000000000 | 2190.000000000 | 문제 없음 |
| sincon-baseline/FINAL_REPORT.md | 68 | 1017 hedge hour 22 | 496.000000000 | 496.000000000 | 문제 없음 |
| night5/ROUND5_RESULT.md | 5 | PLAVE 0912 hour22 | 4026.501352000 | 4026.501351809 | 문제 없음 |
| night5/ROUND5_RESULT.md | 5 | PLAVE 0913 hour22 | 3391.881330000 | 3391.881330111 | 문제 없음 |
| night3/ROUND3_RESULT.md | 13 | friday RMSLE 2025-06-30 | 0.252585316 | 0.252585316 | 문제 없음 |
| night3/ROUND3_RESULT.md | 14 | friday RMSLE 2025-07-31 | 0.174534458 | 0.174534458 | 문제 없음 |
| night3/ROUND3_RESULT.md | 17 | friday RMSLE 2025-10-31 | 0.159530321 | 0.159530321 | 문제 없음 |
| night3/ROUND3_RESULT.md | 19 | friday RMSLE 2026-02-28 | 0.149323254 | 0.149323254 | 문제 없음 |
| night/ROUND2_RESULT.md | 61 | ROUND2 event-only changed rows | 7.000000000 | 7.000000000 | 문제 없음 |
| night/ROUND2_RESULT.md | 69 | ROUND2 floor J013371 | 246.000000000 | 246.000000000 | 문제 없음 |
| night/ROUND2_RESULT.md | 70 | ROUND2 floor J013372 | 385.250000000 | 385.250000000 | 문제 없음 |
| night/ROUND2_RESULT.md | 71 | ROUND2 floor J013373 | 82.750000000 | 82.750000000 | 문제 없음 |
| night7/ROUND7_RESULT.md | 81 | lunar final sum 2026-09-24 | 4559.235807000 | 4559.235806843 | 문제 없음 |
| night7/ROUND7_RESULT.md | 82 | lunar final sum 2026-09-25 | 10065.960385000 | 10065.960384788 | 문제 없음 |
| night7/ROUND7_RESULT.md | 180 | timecapsule max log delta | 1.462482000 | 1.462482413 | 문제 없음 |
| night7/ROUND7_RESULT.md | 182 | station025 max log delta | 0.051717000 | 0.051716820 | 문제 없음 |
| night7/ROUND7_RESULT.md | 184 | plave22 max log delta | 0.478957000 | 0.478957051 | 문제 없음 |
| night7/ROUND7_RESULT.md | 185 | lunar3122 max log delta | 0.939176000 | 0.939176275 | 문제 없음 |
| night7/ROUND7_RESULT.md | 118 | J093669 hedged count in ROUND7 table | 414.152954632 | 849.214438731 | 문제 있음 |
| night7/ROUND7_RESULT.md | 120 | J093671 hedged count in ROUND7 table | 571.355120501 | 311.283254599 | 문제 있음 |
| night7/ROUND7_RESULT.md | 121 | J094947 hedged count in ROUND7 table | 298.448736068 | 651.477399205 | 문제 있음 |
| night7/ROUND7_RESULT.md | 123 | J094949 hedged count in ROUND7 table | 441.172366730 | 240.234711144 | 문제 있음 |
| night7/ROUND7_RESULT.md | 132 | J138398 hedged count in ROUND7 table | 1602.818389458 | 1317.330595243 | 문제 있음 |
| night7/ROUND7_RESULT.md | 133 | J138399 hedged count in ROUND7 table | 2026.883730197 | 2190.255053970 | 문제 있음 |
| night7/ROUND7_RESULT.md | 134 | J138400 hedged count in ROUND7 table | 323.491803178 | 496.018179630 | 문제 있음 |
| sincon-baseline/NIGHT_LOG.md | 39 | first lunar ratio | 5.500000000 | 5.239845261 | 문제 있음 |

## 6. 별도 후보 17행

### 산술 재현

공식 test에서 역3127·날짜·시간으로 위치를 정하고 독립적으로 다음 식을 계산했다.

```text
PLAVE·SWF: FULL = BASE[요일,시간] + 0.30 × 관객 대용치 × 시간 비중
랜더스: FULL = 2199 / 4102 / 860
별도 예측 = exp((1-W)log1p(주후보) + W log1p(FULL)) − 1
```

변경 위치 17개가 정확히 같고, count 및 log1p 최대 차이는 모두 **0**이다. `hedges_17_recomputed.csv:1`에 FULL·W·주후보·재계산·실제 후보를 한 행씩 보존했다. 공식 식은 [event_hedges.py:36](/Users/jeong-uiseok/sincon-2026/sincon-baseline/event_hedges.py:36)~60행이다.

### 입력 사실과 추정의 분리

| 입력 | 확보한 근거 | 판정 |
| --- | --- | --- |
| PLAVE 양일·장소·19시 | [공식 공지](https://weverse.io/plave/notice/36575?hl=ko), `night/ROUND2_RESULT.md:21`, `night7/research_sources.tsv` | 일정 확인 기록 존재. |
| 예매 23,120 / 19,494 | 사용자·팀원 제공, `night5/ROUND5_RESULT.md:11`, FINAL_REPORT:78 | 원 예매처·집계 정의·조회판·이용 조건 확인 불가. 주후보 2행과 별도 6행 모두 영향. |
| 0.30 | 공식 과거 승차와 기존 경기 관중의 36경기 대조를 독립 재계산. Q25=.2764522317, 중앙=.3132627855, Q75=.3375917981. `kbo_36_ratios_independent.csv:1` | 규모 가정으로 가능한 범위이나 정확한 중앙값이 .30인 것은 아님. 야구 하루와 공연 귀가의 수단 비율이 동일하다는 검증도 아님. |
| PLAVE 10/85/5, W=.7 | 박효신 세 날 초과 승차 비중 평균 약14/84/2. 현재 비중과는 다름 | 10/85/5로 바꾼 크기·W의 독립 검증 없음. |
| SWF 일정·480분 | [티켓링크 공지](https://www.ticketlink.co.kr/help/notice/65006), `night/ROUND2_RESULT.md:20`, `night5/ROUND5_RESULT.md:134` | 일정과 러닝타임 기록 존재. 일별 실관객 미확인. |
| SWF 하루12000·시간10/20/45/25·W=.5 | 주최 전망 이틀4만명에서 보수적으로 가정했다고 설명 | 60% 축소·퇴장 배분·W는 추정. 검증된 사실과 분리해서 표시해야 함. |
| 랜더스 전년약22000·올해매진23000 | [구단 전년 발표](https://www.ssglanders.com/media/news/detail?idx=19824), [올해 발표](https://www.ssglanders.com/media/news/detail?idx=19944), `night7/research_sources.tsv:8`·10 | 원출처 링크·조회일 기록 존재. 비상업 재사용 허락은 별도 미확인. |
| 랜더스 종료 -20분·FULL | `night6/SOURCES_FINAL.md`의 CC 대조, `landers_same_series_diagnostic.csv:5` 이후. 2199.4394 / 4101.9394 / 859.8030을 정수 반올림 | 같은 시리즈 한 기증일의 전이임을 재계산. W=.5와 시간 보간의 별도 독립 수령 검증 없음. |
| 팀원 STCIS 버스 | 최종 생성 코드와 현재 입력 trace에는 없음 | 직접 수치 입력 미사용. 다만 22시 집중 참고 사용 기록은 숨기지 말 것. |

외부 사실은 기존 보고서·보존 출처표의 확인 기록을 감사한 것이며, 이번에 웹 원문을 새로 열어 재취득한 것은 아니다. 조회일·비상업 이용 조건은 원표의 범위만 인정했다. 실제 출처 미확인을 “비공개 자료라 문제 없음”으로 바꾸어 결론내리지 않았다.

권고: 현재 별도 후보는 **가정이 명시된 미검증 대안**으로 남기고, 현재 해시에 대한 17행 검토표를 붙인다. 두 후보가 서로 받쳐준다는 설명만으로 W나 시간 비중을 정당화할 수 없다. 특히 17행 중 2개 PLAVE 22시는 이미 검증된 주후보 값을 다시 바꾸는 행이다.

## 7. 남은 위험과 권고

| 우선순위 | 위험 | 관찰·추측 구분 | 권고 |
| --- | --- | --- | --- |
| 높음 | 규칙3절의 이용 허락·조회 이력 불완전 | 관찰. 실제 경로는 KBO·주거·행사 입력을 유지하고 CC 대체 결과는 부분 실험. [SOURCES_FINAL.md:5](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/night6/SOURCES_FINAL.md:5)·15~18·96행. | 허용된 원자료·필드별 출처·조회일·허락을 확정하고, 바꾼 입력의 영향을 받는 모든 모델·캐시를 재생성. 단순 URL 교체를 완료로 표시하지 않음. |
| 높음 | OOF의 채택 판단에 미래 정답 사용 | 실제 반사실 검사로 입증. 규칙4절의 시험기간 실측 사용과는 다름. | 채택을 기준일 이전에서 고정한 OOF로 재검증하고 station025도 재적합. 검증 개선폭의 독립성 표현 수정. |
| 높음 | PLAVE 예매 수량의 원출처·정의 미확인 | 관찰. FINAL_REPORT 자체도 원출처 확인을 요청하고 있음. | 원 예매처, 집계시각, 예매건/좌석/실관객 정의, 조회일과 이용 조건을 보존. |
| 중간 | 최종 별도 후보 7행과 독립 감사 버전 불일치 | 실행 assertion 실패와 정확한 7행 차이로 입증. | 현재 해시를 기준으로 검토표를 새로 작성. 산술 재현과 타당성 검증을 별도 표시. |
| 중간 | 규칙7절의 전체 재학습·Kaggle/Colab 실기 | 확인 불가. 이번 assemble은 완전 재현됐지만 원시 전체 재학습·클라우드는 아님. STATUS도 미완료로 기록. | 백그라운드 최종 로그와 버전별 오차·시간·메모리를 보존하고 허용된 클라우드에서 실제 실행 확인. 감사자가 업로드하지 않음. |
| 중간 | 17행의 W·관객 대용치·시간 비중 미검증 | 관찰. 효과가 좋거나 나쁘다는 방향은 추측이며 이번에는 평가기간 정답이 없음. | 명시적 가정과 표본 의존성을 보존. 독립 검증 없이 검증 통과 후보라고 부르지 않음. |
| 낮음~중간 | 적은 독립 행사 수와 반복 origin | 관찰. 명절은 2회차, Friday는 2날, station fit은 고유76,680키를 3회 포함. | 반복 origin을 독립 표본으로 세지 않고 효과의 확실성을 제한. |
| 낮음~중간 | 비철도 생활이동 공급자 내부의 실측 간접 이용 | 확인 불가. 소비 mode에서 철도는 없고 팀 코드의 직접 결합은 미발견. | 이미 작성된 운영진 질의 범위를 유지. 이 감사가 공급자 내부까지 확인했다고 표시하지 않음. |
| 낮음 | 순수 log 식·반올림 표기 및 문서 버전 관리 | 관찰. NIGHT_LOG의 옛 제출 계획은 병행 갱신에서 해결됨. 후보 숫자 자체의 형식 오류는 아님. | 현재 최종 후보 해시·시간대·정확한 log1p 수식을 문서에 고정. |

이번 감사는 위 위험을 이유로 임의의 보정값을 정하거나 새 제출 후보를 만들지 않았다. 발견 사항을 반영할지는 Claude가 검토하되, Public 점수 변화를 이용한 값 조정 없이 처리해야 한다.

## 재현 파일과 출력

실행 안내는 [README.md](/Users/jeong-uiseok/.codex/.chatgpt-projects/g-p-6aac7228bb908191b5f1eb617f4ff9bd/final_audit/README.md)에 있다. 주요 스크립트는 `audit_core.py`, `guarded_run.py`, `audit_assemble.py`, `temporal_gates.py`, `inventory.py`, `scan_archives.py`, `deep_checks.py`, `additional_checks.py`, `reproduce_expected_failure.py`, `build_report.py`다.

검사 실패로 남긴 `old_hedge_audit_stderr.log`는 발견 F2의 **예상된 실패 증거**다. 나머지 최종 계산 로그는 예외 없이 완료했다. 생성물은 전부 `final_audit/`에 있으며 원본 후보·`sources/`·`final_package/`·`final_delivery/`를 수정하지 않았다.
