# 모델·중간 산출물 작성표

산출물 파일은 각 단계 패키지 안에 그대로 있다. 이 표는 무엇이 보관돼 있고, 무엇으로 다시 만들며, 다시 만들었을 때 보관본과 얼마나 같은지를 적는다. "해당 없음"은 쓰지 않은 항목이다.

**경로 읽는 법**: 각 절의 "위치"와 "다시 만드는 방법"에 적은 경로는 그 절 제목에 있는 패키지 폴더 기준이다. `provenance/nested_oof_scripts/`, `provenance/rail_intermediate/`, `code/` 로 시작하는 경로만 제출 폴더 최상위 기준이다.

## 1. 1단계 (`code/final_package/payload/`)

| 산출물 | 위치 | 내용 | 다시 만드는 방법 | 재생성 확인 |
|---|---|---|---|---|
| 팀 기본 모델 예측 | `team/ensemble_parts.csv`, `team/valid_predictions_ABC.csv.gz` | LightGBM(시드 3)·MLP(시드 30)의 시험 기간·검증 구간 예측 | 1단계 노트북 `RUN_MODE="full"`, 단계 `native` | 전체 재학습에서 MLP가 보관본과 다름(최대 log 0.097, RMS 0.005) |
| 로컬·조건별 스택 출력, 과거 예측 | `work/sincon_local_validation.csv.gz`, `sincon_local_repro.zip`, `sincon_source_reweight_portable.zip`, `sincon_rolling_conditional_cache.zip`, `sincon_summer_replay_validation.csv.gz`, `sincon_target_season_validation.zip` | 생활이동·그래프·시간대·버스·혼합·경기·축제·주거 모델의 출력 | `full`, 단계 `stacks`, `rolling` | 로컬 CPU 전체 재학습 1회(`records/dev_logs/codex/full_verification/FULL_RUN_RESULT.md`). 2025년 벡터 입력의 일부 선행 예측은 `sincon_rolling_conditional_cache.zip` 보관본을 다시 씀 |
| 시간별 XGBoost 예측 | `work/sincon_xgb_forecasts.zip`, `sincon_xgb_extra_validation.zip`, `team/experiments/valid_predictions_zoo.csv.gz` | 시험 기간과 과거 기준일 예측 | `full`, 단계 `hourly_xgb` | 위와 같음 |
| 벡터 XGBoost | `work/sincon_vector_shape_final_raw.csv.gz`, `sincon_vector_boost_validation.csv.gz` | 18시간 벡터 모델의 시간대 차이 | `full`, 단계 `vector` | 위와 같음 |
| TabICL 원시 예측, clean OOF | `work/sincon_clean_refined_cache.zip` | TabICL 최종·과거 예측, 순서 정리한 과거 예측 | `full`, 단계 `tabicl`, `clean_oof` | 위와 같음 |
| 행사 응답 | `work/sincon_munhak_cancellation_responses.zip`, `sincon_songdo_beach_location_responses.zip` | 공연 취소·장소 변경에 대한 모델 응답 | `full`, 단계 `event_responses` | 위와 같음 |
| **사용한 초기 모델** | `models/tabicl-regressor-v2-20260212.ckpt` (109MB) | TabICL 공개 사전학습 회귀 체크포인트. SHA-256 `0db9cb538f114e79026bf08f45f41ad8dd7ad2de2aaca9a5ca8cd3bd9748ae7a` | Hugging Face `jingang/TabICL` 에서 내려받음 (BSD-3-Clause) | 해시 고정 |

- 파일별 SHA-256: `code/final_package/payload_manifest.json`, `FILE_LIST.tsv`.
- 전체 재학습 결과와 보관본의 차이: 평균 절대 log 0.0012, RMS 0.0027, 최대 0.153, 99.85%의 행이 0.01 이내. 검증 점수는 A 0.149912 / 0.149904, B 0.164563 / 0.164576, C 0.161220 / 0.161175 (재학습 / 보관본).

## 2. 2단계 (`code/final_delivery_v2/`)

| 산출물 | 위치 | 내용 | 다시 만드는 방법 |
|---|---|---|---|
| 층 계산용 캐시 | `cache/` | 과거 예측 요약, 행사·공연 일정, 보호 행 | `prepare_assets.py` (원 작업 폴더 기준), 내용은 `PACKAGE_CONTENTS.md`, `provenance.json` |
| 기준 출력 | `reference/`, `verified_outputs/` | 비교용 | 노트북 실행 |

학습하는 모델은 없다(해당 없음).

## 3. 3단계 (`code/final_stack_delivery/`)

| 산출물 | 위치 | 내용 | 다시 만드는 방법 | 재생성 확인 |
|---|---|---|---|---|
| 순방향 과거 예측 | `cache/downstream_oof_nested_main.csv.gz`, `cache/hourbias_history_oof.csv.gz` | 9개 기준일의 주후보 과거 예측과 실측 log | `provenance/nested_oof_scripts/night11/reproduce_nested.py`, `night13_measurements/amp_final_layers.py` (1단계의 기준일별 보관 예측이 입력) | 제출 준비 중에는 다시 실행하지 않음 |
| 월요일 후보 | `inputs/submission_monday_main.csv` | 단계 2의 구성 입력 | `code/monday_delivery/SINCON_monday.ipynb` | **이번 실행에서 다시 만들어 대조: 최대 log 차이 0** |
| 코리아컵·걷기 후보 | `inputs/submission_night_v4_main_cup_walk.csv` | 단계 2의 구성 입력 | `code/cup_walk_overlay/model/build_v4_cup_walk.py` | **이번 실행에서 다시 만들어 대조: 최대 log 차이 8.9e-16** |
| 단계 7 모델 예측 6개 | `predictions/xgb_test.npy`, `lgb_test.npy`, `base_test_s0~s3.npy` | XGBoost, LightGBM, MLP 4시드의 시험 기간 log 예측 | `training_scripts/` (`prep.py` → `prep_test.py` → `xgb_test.py` → `run3.py`) | 다시 학습해 대조하지 않음. MLP는 Apple MPS에서 학습한 보관본이라 다른 기기에서 수치가 달라진다 |

## 4. 4단계 (`code/rail_delivery_v5/`), 4b단계 (`code/rail_delivery_v4/`)

두 패키지의 타 노선 자료(`cache/rail_all_allowed.csv.gz`, `cache/ban_list.json`), XGBoost 예측 2개(`predictions/`), 층 모듈(`factor_layer.py`, `hol_layer.py`)은 SHA-256이 서로 같다(2026-11-13 대조). 아래 표의 경로는 두 패키지에 공통이다.

| 산출물 | 위치 | 내용 | 다시 만드는 방법 | 재생성 확인 |
|---|---|---|---|---|
| 타 노선 일별 승차 | `cache/rail_all_allowed.csv.gz` | 허용한 561개 역, 2025-01-01~2026-10-31 | `provenance/fetch_all.py` (내려받는 즉시 7호선·환승역 제외, 원본 삭제) | 다시 내려받아 대조하지 않음 |
| 공휴일류 수준 층의 두 XGBoost 예측 | `predictions/xgbnb_test.npy`, `predictions/xgb_test.npy` | 인접 노선 날짜 피처 7개를 넣은 것과 넣지 않은 것 | `provenance/prep.py` → `prep_test.py` → `nb9.py`(피처) → `xgb_test.py`, `nb_test.py`. 피처 원자료는 `provenance/rail_intermediate/rail_allowed.csv.gz` | 다시 학습해 대조하지 않음. 중간 파일(`data.pkl`, `test.pkl`, `nb_features.pkl`)은 보관하지 않음 |
| 주성분·Ridge 계수 | (보관하지 않음) | 노트북이 실행할 때마다 계산 | 노트북 실행 | 실행마다 같은 값(결정적 계산) |

## 5. 해당 없음

- 임베딩 파일, 별도 저장한 최종 가중치 파일(신경망·트리 모델의 가중치는 저장하지 않고 예측만 보관했다).
- 대상 역의 2026년 7월 이후 승하차를 담은 파일.
