# SINCON 2026 제출 자료 — 팀 핫식스

작성: 2026-11-13. 「SINCON 2026 제출 자료 안내」의 순서에 맞춰 정리했다.

## 0. 먼저 알릴 것

1. **두 최종 예측 모두 다른 노선의 2026년 7~10월 승차 실측을 쓴다.** 규칙 4절의 문구에 해당하는 자료이고, 사용 근거는 운영진의 구두 설명(팀장이 2026-11-13에 두 차례 받아 전달)이다. 글로 남은 답변은 없다. 인천 1·2호선, 7호선, 그 환승역 자료는 쓰지 않았다. 이 자료를 쓰지 않은 마지막 단계의 출력은 3단계의 `submission_xgb7_w10_on_curvature.csv`(Public 0.144715)이고, 재현 과정에서 중간 산출물로 만들어진다.
2. **두 최종 예측 모두 예측 기간의 지하철이 아닌 실측**(생활이동, 버스 이용량, 날씨, 경기 결과·관중)을 1단계 모델 입력으로 쓴다.
3. **2026-11-12에 Public 점수에서 계산한 값 두 개를 쓴 적이 있고**, 같은 날 제거해 모든 후보를 다시 만들었다. 최종 예측에는 들어 있지 않다.
4. **제출 파일을 바이트까지 재현하는 경로는 보관한 모델 예측에서 조립하는 경로다.** 처음부터 다시 학습하면 신경망 때문에 값이 조금 달라진다(3절 "재현 변동").

범위·시점·사용 단계는 `records/DISCLOSURE.md` 에 적었다.

## 1. 최종 예측 파일

| | 파일 (`predictions/`) | SHA-256 | Public | 만드는 단계 |
|---|---|---|---:|---|
| 최종 예측 1 | `submission_rail_factors_k30_hour_on_xgb7.csv` | `aa455744556514d5…` | 0.143043 | 1 → 2 → 3 → 4 |
| 최종 예측 2 | `submission_rail_factors_k12_on_xgb7.csv` | `b3767450472ba9c6…` | 0.143545 | 1 → 2 → 3 → 4b |

- 리더보드에 올린 원본 파일 그대로다. 전체 해시는 `predictions/SHA256SUMS.txt`.
- Public 점수는 팀장이 Kaggle에서 확인한 값이다.

## 2. 폴더 구성

| 경로 | 내용 |
|---|---|
| `README.md` | 이 문서 |
| `predictions/` | 최종 예측 원본 2개 |
| `code/run_all.py` | 1단계부터 최종 예측 2개까지 차례로 실행하는 스크립트 |
| `code/final_package/` | **1단계.** 기본 모델 학습·결합·하위 보정. 노트북 `SINCON_final.ipynb`, 의존성 `requirements.txt` |
| `code/final_delivery_v2/` | **2단계.** 보정 6개. 노트북 `SINCON_final_step2_layers.ipynb` |
| `code/monday_delivery/`, `code/cup_walk_overlay/` | 3단계가 읽는 두 구성 입력을 만드는 코드 |
| `code/final_stack_delivery/` | **3단계.** 보정 7개 단계. 노트북 `SINCON_final_stack.ipynb`, 모델 학습 코드 `training_scripts/` |
| `code/rail_delivery_v5/` | **4단계 (최종 예측 1).** 다른 노선 자료를 쓰는 세 층, 주성분 30개. 노트북 `SINCON_rail_factors_k30.ipynb`, 수집·학습·검증 코드 `provenance/` |
| `code/rail_delivery_v4/` | **4b단계 (최종 예측 2).** 같은 방법의 두 층(변화 옮기기, 공휴일류 수준), 주성분 12개. 노트북 `SINCON_rail_factors_k12.ipynb` |
| `code/colab_k30_hour/` | 3·4단계를 Colab에서 한 번에 돌리는 노트북(선택) |
| `data/DATA_SOURCES.md` | 데이터 출처 작성표 (제공·외부·파생·캐시) |
| `provenance/PROVENANCE.md` | 제공 데이터에서 최종 예측까지의 생성 경로, 과거 예측을 만든 스크립트 |
| `models/ARTIFACTS.md` | 모델·중간 산출물 작성표 (보관 위치, 재생성 방법, 재생성 확인 여부) |
| `records/METHOD.md` | 방법 설명서 (검증 분할, 변수, 모델, 계수 결정) |
| `records/DISCLOSURE.md` | 평가 기간 자료의 열람·사용과 규칙 관련 경과 |
| `records/executed_runs/` | 이 폴더의 코드를 2026-11-13에 처음부터 끝까지 실행한 결과: 실행 결과가 든 노트북 6개, 로그, 요약, `pip freeze` |
| `records/dev_logs/` | 기존 개발 기록: 작업 일지, 사전 기록, 검증 결과, 감사, 실험 스크립트 |

실제 자료와 산출물 파일은 각 단계 패키지 안에 있다. 패키지마다 파일 해시 목록이 있어서 옮기지 않았다. 위치는 `data/DATA_SOURCES.md` 와 `models/ARTIFACTS.md` 에 적었다.

## 3. 실행 방법

### 환경 준비

| 항목 | 내용 |
|---|---|
| OS·기기 | macOS 26.6 (arm64), Apple M5 Max, 메모리 64GB. Linux에서의 실행은 확인하지 못했다 |
| 언어 | Python 3.12.15 (1단계 노트북은 3.11과 3.12만 받는다) |
| 의존성 | `code/final_package/requirements.txt` (고정 버전: numpy 2.5.4, pandas 3.1.1, scipy 1.17.1, scikit-learn 1.6.1, lightgbm 4.6.0, torch 2.9.1, xgboost 3.4.1, tabicl 2.2.0, einops 0.8.2, huggingface-hub 0.36.0, psutil 7.2.2, tqdm 4.70.1). 실행에 쓴 환경 전체는 `records/executed_runs/pip_freeze_python312.txt` |
| 설치 | `python3.12 -m venv .venv && . .venv/bin/activate && pip install -r code/final_package/requirements.txt nbclient nbformat nbconvert ipykernel` |
| 커널 등록 | `python -m ipykernel install --sys-prefix --name sincon312` 을 실행하고, 아래 명령 앞에 `JUPYTER_PATH="$VIRTUAL_ENV/share/jupyter"` 를 붙인다. 등록하지 않으면 기본 이름 `python3` 이 시스템의 다른 Python 커널로 연결될 수 있다(개발 중 실제로 겪었다) |
| CPU·GPU | 조립 경로는 CPU만 쓴다. 재학습은 CPU로 되고, CUDA가 있으면 1단계 신경망이 쓴다(실행해 보지는 못했다) |

### 학습 및 선택

| 항목 | 내용 |
|---|---|
| 실행 명령 (1단계 전체 재학습) | `cd code/final_package && SINCON_RUN_MODE=full SINCON_DEVICE=cpu jupyter nbconvert --to notebook --execute SINCON_final.ipynb --ExecutePreprocessor.timeout=86400 --ExecutePreprocessor.kernel_name=sincon312 --output SINCON_final.executed.ipynb` |
| 실행 명령 (3단계의 모델 6개) | `code/final_stack_delivery/README.md` 의 "6개 모델 예측을 다시 만드는 방법": `prep.py` → `prep_test.py` → `xgb_test.py` → `run3.py` |
| 실행 명령 (4단계의 XGBoost 2개) | `code/rail_delivery_v5/provenance/`: `prep.py` → `prep_test.py` → `nb9.py` → `xgb_test.py`, `nb_test.py` |
| 허용 초기 모델 | TabICL 2.2.0 회귀 체크포인트 `tabicl-regressor-v2-20260212.ckpt` (공개 사전학습 모델, BSD-3-Clause, 패키지에 포함). 그 밖의 모델은 `train.csv` 로 처음부터 학습한다 |
| 검증 분할 | 시간 순서 분할, 기준일 9개(2025-06-30 ~ 2026-04-30). `records/METHOD.md` 2절 |
| 설정·시드 | `records/METHOD.md` 3절, 정본은 `code/final_package/docs/SINCON_REPRODUCE_CLEAN.md` "시드와 환경" |
| 생성 모델 | 생성형 모델은 쓰지 않았다(해당 없음) |
| 예상 시간 | 1단계 전체 재학습: 로컬 CPU에서 약 5.5시간(신경망 30시드 3.9시간, rolling 51분, 나머지 42분. 다른 작업과 CPU를 나눠 쓴 측정). 3·4단계 모델: 재지 않았다 |

### 최종 추론

| 항목 | 내용 |
|---|---|
| 실행 명령 | `JUPYTER_PATH="$VIRTUAL_ENV/share/jupyter" python code/run_all.py --out <쓰기 가능한 폴더> --kernel sincon312` |
| 하는 일 | 1 → 2 → 2b → 2c → 3 → 4 → 4b 순서로 노트북과 스크립트를 실행하고, 두 최종 예측을 `predictions/` 의 제출 파일과 비교한다. 수치 차이가 1e-9를 넘으면 실패로 끝난다 |
| 모델·입력 경로 | 보관한 모델 예측(`models/ARTIFACTS.md`)과 패키지 안의 자료. 경로는 스크립트가 지정한다 |
| 후처리 설정 | 각 노트북의 설정 셀과 층 모듈의 상수. 값은 `records/METHOD.md` 4~6절 |
| 출력 | `<out>/rail/submission_rail_factors_k30_hour_on_xgb7.csv`, `<out>/rail_k12/submission_rail_factors_k12_on_xgb7.csv`, `<out>/run_summary.json`, `<out>/executed_notebooks/` (중간 산출물은 `<out>/stack/` 등) |
| 걸리는 시간 | 약 47초 (1단계 30초, 나머지 17초. `records/executed_runs/run_summary.json`) |

- 노트북을 하나씩 실행해도 된다. 2·3·4·4b단계 노트북 첫 설정 셀의 `BASELINE_CSV` 에 앞 단계 출력의 경로를 적는다. 2단계와 월요일 패키지는 `data/` 에 제공 CSV 세 개가 있어야 한다(`run_all.py` 는 1단계 패키지의 사본을 복사한다).
- 1단계 노트북 첫 셀은 `pip install` 을 실행한다. 인터넷이 없으면 `SINCON_PIP_NO_INDEX=1` 을 주고 미리 설치해 둔다.

### 재현 변동

| 항목 | 내용 |
|---|---|
| 조립 경로 | 난수를 쓰지 않는 결정적 계산이다. 2026-11-13에 이 폴더의 코드를 새 Python 3.12.15 환경에서 1단계부터 이어 실행한 결과, 두 최종 예측 모두 제출 파일과 **최대 log1p 차이 8.9e-16** 이었다. 바이트는 달랐다 |
| 바이트가 달라지는 곳 | 1단계 출력은 제출 때의 파일과 바이트까지 같았다. 2단계를 다시 실행한 출력이 끝자리에서 달라(8.9e-16) 그 뒤 CSV의 바이트가 달라진다. 3·4·4b단계를 패키지에 든 주후보에서 시작하면 두 최종 예측이 바이트까지 같다(`code/final_stack_delivery/VERIFICATION.md`, `code/rail_delivery_v5/VERIFICATION.md`, `code/rail_delivery_v4/VERIFICATION.md`) |
| 버전에 따른 차이 | 3·4단계를 패키지에 든 주후보에서 시작했을 때: Python 3.12.15·3.11.17(pandas 3.1.1)은 바이트 일치, pandas 2.2.2·numpy 2.0.2와 Python 3.14.6(pandas 3.0.6)은 수치 일치(최대 1.8e-15)이고 바이트는 다름 |
| 1단계 전체 재학습 | 비결정적이다. 같은 시드라도 신경망은 기기·라이브러리에 따라 달라진다. 로컬 CPU 재학습 1회의 결과는 제출 기준 파일과 평균 절대 log 차이 0.0012, RMS 0.0027, 최대 0.153이었고 99.85%의 행이 0.01 이내였다. 검증 점수는 세 구간 모두 0.00005 이내로 같았다 |
| 재학습 결과를 이어 붙일 때 | 2단계는 입력이 기준 파일과 1e-9 이내로 같을 때만 진행한다. 재학습한 1단계 출력은 이 검사에서 멈춘다. 재학습 결과로 끝까지 가려면 그 검사를 풀어야 하고, 그렇게 만든 최종 예측의 점수는 재 보지 않았다 |
| 3·4단계의 보관 모델 | XGBoost·LightGBM은 시드 0 고정. MLP 4시드는 Apple MPS에서 학습한 보관본이라 다른 기기에서 값이 달라진다. 다시 학습해 보관본과 대조하지는 않았다 |
| 반복 실행 결과 | `records/executed_runs/`, 각 패키지의 `VERIFICATION.md`·`verification/`, `code/colab_k30_hour/verification/` |

## 4. 제출 자료 목록과 위치

| 안내서 항목 | 위치 |
|---|---|
| 최종 예측 파일 | `predictions/` |
| 전체 실행 코드와 실행 순서 | `code/` (순서는 이 문서 3절과 `code/run_all.py`), 실행 결과가 든 노트북은 `records/executed_runs/executed_notebooks/` |
| 데이터 출처 및 생성 기록 | `data/DATA_SOURCES.md`, `provenance/PROVENANCE.md`, `code/final_package/EXTERNAL_DATA.md` |
| 실행 환경 및 방법 | 이 문서 3절, `code/final_package/requirements.txt`, `records/executed_runs/pip_freeze_python312.txt` |
| 설명서 | `records/METHOD.md` |
| 모델 및 중간 산출물 | `models/ARTIFACTS.md` (파일은 각 패키지 안) |
| 기존 개발 기록 | `records/dev_logs/` |

## 5. 제출 전 자체 점검

- [x] 최종 예측 파일과 실제 사용한 코드, 모델, 설정의 관계를 명시했다 (1절, 3절, `provenance/PROVENANCE.md`).
- [x] 데이터와 모델 작성표에 사용 항목을 기록하고 미사용 항목은 해당 없음으로 표시했다 (`data/DATA_SOURCES.md`, `models/ARTIFACTS.md`).
- [x] 제공 자료부터 최종 예측까지의 경로, 명령, 의존성, 시드를 설명했다 (3절). **단, 바이트 재현은 보관한 모델 예측에 기대고, 처음부터 다시 학습한 결과는 수치가 다르다**(3절 "재현 변동"). 순방향 과거 예측과 3·4단계 보관 모델은 이번에 다시 만들어 대조하지 못했다(`models/ARTIFACTS.md`).
- [x] 공개 데이터에서 평가 관련 자료를 열람·확보·사용한 사실을 기재했다 (`records/DISCLOSURE.md`).

## 6. 그 밖에 알아 둘 점

- 패키지 문서와 검증 기록에는 개발 기기의 절대 경로가 남아 있다. `records/executed_runs/` 의 실행 결과에서는 실행 폴더 경로를 `<실행 폴더>`, 가상환경 경로를 `<가상환경>` 으로 바꿨다(그 밖의 내용은 그대로다).
- 패키지 안의 문서 일부는 작성 시점의 상태를 적고 있다(예: "Public 미측정"). 최신 상태는 이 문서와 `records/METHOD.md` 다.
- 비밀번호, API 키, 토큰은 들어 있지 않다.
