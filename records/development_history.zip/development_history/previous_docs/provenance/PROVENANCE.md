# 생성 기록 — 제공 데이터에서 최종 예측까지

```
train.csv, test.csv, metaData.csv (제공)  +  외부 자료 (data/DATA_SOURCES.md)
        │
        ▼  [1] code/final_package/SINCON_final.ipynb
        │      full: 모델 학습 → 모델별 예측   /  assemble: 보관한 모델별 예측을 읽음
        │      → 결합(스택) → 하위 보정 → 행사 보정
        ▼
   submission_clean_refined.csv
        │
        ├──▶ [2b] code/monday_delivery/SINCON_monday.ipynb ─▶ submission_monday_main.csv ─┐
        ▼  [2] code/final_delivery_v2/SINCON_final_step2_layers.ipynb (보정 6개)           │
   submission_night_v4_main.csv (주후보)                                                    │
        │                                                                                   │
        ├──▶ [2c] code/cup_walk_overlay/model/build_v4_cup_walk.py                         │
        │         ─▶ submission_night_v4_main_cup_walk.csv ─────────────────────────────────┤
        ▼  [3] code/final_stack_delivery/SINCON_final_stack.ipynb (7개 단계)  ◀─────────────┘
        │      + 순방향 과거 예측(cache/), 모델 예측 6개(predictions/)
        ▼
   submission_xgb7_w10_on_curvature.csv
        │
        ├──▶ [4b] code/rail_delivery_v4/SINCON_rail_factors_k12.ipynb (주성분 12개, 두 층)
        │         ─▶ submission_rail_factors_k12_on_xgb7.csv              ← 최종 예측 2
        │
        ▼  [4] code/rail_delivery_v5/SINCON_rail_factors_k30.ipynb
        │      + 타 노선 일별 승차(cache/rail_all_allowed.csv.gz), XGBoost 예측 2개(predictions/)
        ▼
   submission_rail_factors_k30_on_xgb7.csv
   submission_rail_factors_k30_hour_on_xgb7.csv                 ← 최종 예측 1
```

- [3]은 [2b], [2c]의 출력을 패키지 안의 보관본(`inputs/`)으로 읽는다. `code/run_all.py` 는 두 출력을 다시 만들어 보관본과 대조한다.
- 각 화살표의 입력 파일 해시는 패키지의 `payload_manifest.json`(1), `delivery_manifest.json`·`provenance.json`(2), `SOURCE_MANIFEST.json`·`MANIFEST.json`(3), `MANIFEST.json`(4)에 있다.

## 이 폴더에 있는 것

| 경로 | 내용 |
|---|---|
| `nested_oof_scripts/night11/` | 순방향(중첩) 과거 예측을 만든 스크립트와 결과 문서 (`reproduce_nested.py`, `ROUND11_RESULT.md`) |
| `nested_oof_scripts/night13_measurements/` | 최종 6개 층까지 적용한 과거 예측을 뽑은 스크립트 (`amp_final_layers.py`, `extract_final_layers.py`, `common.py`) |
| `rail_intermediate/rail_allowed.csv.gz` | 경인선·수인선 허용 25개 역의 일별 승차. 4단계 공휴일류 수준 층의 XGBoost 피처 원자료 |
| `rail_intermediate/rail_hourly_allowed.csv.gz` | OA-12252 월별·시간대별 합계(25개 역). 탈락한 실험에만 썼고 최종 예측에는 쓰지 않음 |

`nested_oof_scripts/` 의 스크립트는 원래 작업 폴더의 경로를 가정한다. 이 제출 폴더 안에서 그대로 실행되도록 손보지 않았다. 생성 방법을 보여 주는 기록으로 넣었다.

## 패키지 안의 생성 코드

| 무엇 | 어디 |
|---|---|
| 1단계 모델 학습·결합·보정 | `code/final_package/pipeline.py`, `full_train.py`, `full_stage.py`, `payload/team/*.py`, `payload/work/*.py` |
| 2단계 층 | `code/final_delivery_v2/final_layers.py`, `event_hedges.py`, `delivery_runtime.py` |
| 3단계 층 | `code/final_stack_delivery/stack_*.py`, `hourbias_layer.py` |
| 3단계 모델 학습 | `code/final_stack_delivery/training_scripts/` |
| 4단계 층 | `code/rail_delivery_v5/factor_layer.py`, `hol_layer.py`, `hour_layer.py` |
| 4b단계 층 | `code/rail_delivery_v4/factor_layer.py`, `hol_layer.py` (4단계와 같은 모듈, 노트북의 주성분 수와 가중만 다름) |
| 4단계 자료 수집·모델 학습·검증 | `code/rail_delivery_v5/provenance/` |
| 검증·탈락 실험 | `records/dev_logs/experiment_scripts/` |
