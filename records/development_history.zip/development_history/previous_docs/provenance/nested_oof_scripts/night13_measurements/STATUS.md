# 18번 작업 진행 상태

2026-11-13T08:51:47.644836+09:00

사전등록 원문을 decisions_round13.tsv 첫 줄에 시각과 함께 보존. 판정 대기.

## 2026-11-13T08:53:02.540758+09:00

1단계 assemble 01_early 실행

## 2026-11-13T08:53:09.814805+09:00

1단계 assemble 02_events_before_model 실행

## 2026-11-13T08:53:12.007554+09:00

1단계 assemble 03_model_layers 실행

## 2026-11-13T08:53:24.400851+09:00

1단계 assemble 04_events_after_model 실행

## 2026-11-13T08:53:27.117757+09:00

최종 모델층 분해 완료: {"rows": 157194, "reference_sha256": "519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199", "output_sha256": "519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199", "max_abs_log1p_difference": 0.0, "layer_sum_max_error": 0.0, "closure_to_clean_max_error": 0.0, "stage1_model_roundtrip_error": 0.0, "protected_model_amplification_changes": 0, "run": "night13/stage1/runs/sincon_assemble_20261112T235302_311684Z"}

## 2026-11-13T08:55:10.924899+09:00

old 과거 9개 기준일 모델층·최종층 계산 및 기존 round11 경로 재현 완료

## 2026-11-13T08:55:44.328568+09:00

nested 과거 9개 기준일 모델층·최종층 계산 및 기존 round11 경로 재현 완료

## 2026-11-13T08:55:44.330514+09:00

과거 검증 잠정 판정 기준 충족. 최종 CSV·보호 행 검산을 계속한다. [{"path":"nested","stage":"final6","testable":8,"improved":8,"worst_delta":-0.0000072604,"best_delta":-0.0003084524,"passed":true},{"path":"nested","stage":"model","testable":9,"improved":9,"worst_delta":-0.0000362045,"best_delta":-0.0002839861,"passed":true},{"path":"old","stage":"final6","testable":8,"improved":8,"worst_delta":-0.0000072599,"best_delta":-0.0003089127,"passed":true},{"path":"old","stage":"model","testable":9,"improved":9,"worst_delta":-0.0000362044,"best_delta":-0.0002844186,"passed":true}]

## 2026-11-13T08:55:52.482501+09:00

1~4 완료. 최종 판정 기준 충족; 후보 CSV night13/submission_amp15_main.csv. {"verdict": "기준 충족", "passed": true, "created_kst": "2026-11-13T08:55:52.020678+09:00", "rows": 157194, "candidate_sha256": "06f589ba349fbf17c0cfc1b77edcdbeed3d2d883d318c7d2fe7f067fed1ae49c", "main_sha256": "4c85257294be267c47396587f3a71a2d1e238dc93f957a634cfe662f8e379965", "main_reproduction_max_log_error": 8.881784197001252e-16, "changed_rows_exact": 157192, "changed_rows_gt_1e_12": 157192, "mean_log_difference": 4.8173316819279446e-06, "mean_abs_log_difference": 0.001625531290576758, "max_abs_log_difference": 0.07005042123378935, "rms_log_difference": 0.003574897219854859, "station_refit_max_log_correction_difference": 0.003033865071031202, "station_refit_mean_abs_log_correction_difference": 8.546098791637232e-05, "protected_model_amplification_changes": 0, "package_required": true, "validation_summary": [{"path": "nested", "stage": "final6", "testable": 8, "improved": 8, "worst_delta": -7.260423289162654e-06, "best_delta": -0.00030845242157975794, "passed": true}, {"path": "nested", "stage": "model", "testable": 9, "improved": 9, "worst_delta": -3.620448809721344e-05, "best_delta": -0.00028398613440763776, "passed": true}, {"path": "old", "stage": "final6", "testable": 8, "improved": 8, "worst_delta": -7.259879592630414e-06, "best_delta": -0.0003089126668876785, "passed": true}, {"path": "old", "stage": "model", "testable": 9, "improved": 9, "worst_delta": -3.620444853094651e-05, "best_delta": -0.0002844185675028865, "passed": true}], "final_layer_order": ["timecapsule", "plave_existing", "station025", "friday", "plave22", "lunar3122"], "after_model_historical_identity": true}

## 2026-11-13T08:56:04.432323+09:00

독립 검산 완료: {"success": true, "created_kst": "2026-11-13T08:56:04.430588+09:00", "candidate_sha256": "06f589ba349fbf17c0cfc1b77edcdbeed3d2d883d318c7d2fe7f067fed1ae49c", "candidate_rows": 157194, "official_order": true, "finite_nonnegative": true, "final_layer_closure_max_error": 0.0, "final_fixed_formula_max_error": 0.0, "plave22_exactly_retained": true, "source_files_unchanged": 3283, "paths": [{"path": "old", "rows": 1283112, "origins": 9, "official_labels_exact": true, "formula_exact": true, "protected_addition_nonzero_rows": 0, "max_score_recheck_error": 5.551115123125783e-17, "max_station_refit_recheck_error": 0.0}, {"path": "nested", "rows": 1283112, "origins": 9, "official_labels_exact": true, "formula_exact": true, "protected_addition_nonzero_rows": 0, "max_score_recheck_error": 5.551115123125783e-17, "max_station_refit_recheck_error": 0.0}], "protected_groups": [{"group": "PLAVE", "rows": 36, "amplified_model_rows": 0, "final_changed_rows": 34, "max_abs_final_log_difference": 0.0030338650710310944}, {"group": "bupyeong_lunar", "rows": 36, "amplified_model_rows": 0, "final_changed_rows": 36, "max_abs_final_log_difference": 0.006543634910414653}, {"group": "model_protected", "rows": 27198, "amplified_model_rows": 0, "final_changed_rows": 27196, "max_abs_final_log_difference": 0.006543634910414653}, {"group": "timecapsule", "rows": 3, "amplified_model_rows": 3, "final_changed_rows": 3, "max_abs_final_log_difference": 4.3340929586577204e-05}], "station_future_poison_checks": 36, "verdict": "기준 충족", "historical_final_layer_method": "round11 chronological analogues", "environment": {"python": "3.12.15 (main, Oct  3 2026, 00:54:33) [Clang 22.1.3 ]", "numpy": "2.5.4", "pandas": "3.1.1"}}

## 2026-11-13T09:00:04.474193+09:00

재현 패키지 입력·노트북 생성 완료. 전체 코드 셀6개, 새 Python3.11/3.12 환경 검증 예정.

## 2026-11-13T09:00:36.952281+09:00

재현 패키지 입력·노트북 생성 완료. 전체 코드 셀6개, 새 Python3.11/3.12 환경 검증 예정.

## 2026-11-13T09:01:28.629462+09:00

오프라인 새 가상환경 py311 생성·설치 완료

## 2026-11-13T09:01:32.343112+09:00

오프라인 새 가상환경 py312 생성·설치 완료

## 2026-11-13T09:02:02.720528+09:00

py311 reference 모든 노트북 셀 실행 통과. max log1p=8.881784197001252e-16

## 2026-11-13T09:02:05.852195+09:00

py311 numeric_equivalence 모든 노트북 셀 실행 통과. max log1p=8.881784197001252e-16

## 2026-11-13T09:02:14.353369+09:00

py312 reference 모든 노트북 셀 실행 통과. max log1p=8.881784197001252e-16

## 2026-11-13T09:02:16.627017+09:00

py312 numeric_equivalence 모든 노트북 셀 실행 통과. max log1p=8.881784197001252e-16

## 2026-11-13T09:02:56.974457+09:00

패키지 입력·탐색 경계 검사 15개 통과

## 2026-11-13T09:02:57.938121+09:00

패키지 입력·탐색 경계 검사 15개 통과

## 2026-11-13T09:05:16.819812+09:00

측정값으로 결과보고서·README 작성 완료. ZIP 빈폴더 검사를 진행한다.

## 2026-11-13T09:06:13.929004+09:00

실제 배포ZIP py311 reference 빈폴더·읽기전용 재현 통과

## 2026-11-13T09:06:17.059441+09:00

실제 배포ZIP py311 numeric_equivalence 빈폴더·읽기전용 재현 통과

## 2026-11-13T09:06:19.329653+09:00

실제 배포ZIP py312 reference 빈폴더·읽기전용 재현 통과

## 2026-11-13T09:06:21.599150+09:00

실제 배포ZIP py312 numeric_equivalence 빈폴더·읽기전용 재현 통과

## 2026-11-13T09:06:21.621642+09:00

완료. 판정 기준 충족. 기존·중첩 최종8/8 개선. 후보CSV와 재현ZIP·노트북·문서·빈폴더 실행 검증 완료. Kaggle·Colab·Linux 실기와 업로드는 하지 않았다. ZIP SHA=ea4677501b7b4e99a53c87844d128c0428a1fd059b05e85ad735d8fb3b4c1735
