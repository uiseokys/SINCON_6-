"""Repack read-only cached wheel trees and install into two new virtualenvs."""
from common import *
import subprocess
from zipfile import ZipFile,ZIP_DEFLATED
import re
import argparse

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=OUT/'offline_envs')
    args=parser.parse_args();destination=args.output.resolve()
    if not destination.is_relative_to(OUT):raise ValueError('Output must be under night13')
    destination.mkdir(parents=True,exist_ok=False)
    wheels=destination/'wheels';wheels.mkdir(exist_ok=False)
    cache=Path('/Users/jeong-uiseok/.cache/uv/archive-v0')
    wanted={('numpy','2.2.6'),('numpy','2.5.4'),('pandas','2.2.3'),('pandas','3.1.1'),
            ('python_dateutil','4.0.0'),('pytz','2026.6'),('tzdata','2026.6')}
    records=[]
    for base in sorted(cache.iterdir()):
        if not base.is_dir():continue
        for info in sorted(base.glob('*.dist-info')):
            name,version=info.name[:-10].rsplit('-',1)
            if (name,version) not in wanted:continue
            text=(info/'WHEEL').read_text()
            tags=re.findall(r'^Tag: (.+)$',text,re.M)
            if name in ['numpy','pandas']:
                if not any(('cp311' in tag and version in ['2.2.6','2.2.3']) or ('cp312' in tag and version in ['2.5.4','3.1.1']) for tag in tags):continue
            tag=next((tag for tag in tags if tag.startswith('py3-')),tags[0])
            target=wheels/f'{name}-{version}-{tag}.whl'
            if target.exists():continue
            with ZipFile(target,'x',ZIP_DEFLATED,compresslevel=6) as archive:
                for p in sorted(base.rglob('*')):
                    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
                        archive.write(p,str(p.relative_to(base)))
            records.append(dict(wheel=target.name,sha256=sha(target),bytes=target.stat().st_size,
                source=str(base),source_kind='existing read-only uv wheel cache, repacked without code edits'))
    dump(destination/'wheel_provenance.json',records)
    for label,python,packages in [
        ('py311',Path('/opt/homebrew/bin/python3.11'),['numpy==2.2.6','pandas==2.2.3']),
        ('py312',Path(sys.base_prefix)/'bin/python3.12',['numpy==2.5.4','pandas==3.1.1'])]:
        env=destination/label
        subprocess.run([str(python),'-B','-m','venv',str(env)],check=True)
        command=[str(env/'bin/python'),'-B','-m','pip','install','--no-index','--find-links',str(wheels),
            '--disable-pip-version-check','--no-cache-dir',*packages]
        with (destination/(label+'_install.log')).open('x') as f:
            subprocess.run(command,env={**os.environ,'PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1'},stdout=f,stderr=subprocess.STDOUT,check=True)
        with (destination/(label+'_packages.json')).open('x') as f:
            subprocess.run([str(env/'bin/python'),'-B','-m','pip','list','--format=json','--disable-pip-version-check'],stdout=f,check=True)
        status('오프라인 새 가상환경 '+label+' 생성·설치 완료')

if __name__=='__main__':main()
