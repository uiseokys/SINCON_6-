"""Exercise supplied-input tolerance, strict hashes and bounded search contracts."""
from common import *
import argparse
import ast

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--package',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    package=args.package.resolve();rt=module('amp_boundary_runtime',package/'delivery_runtime.py')
    os.environ['SINCON_AMP_OUTPUT_DIR']=str(out/'results')
    grid=read(package/'data/test.csv',parse_dates=['date'])
    clean=read(package/'reference/submission_clean_refined.csv')
    checks=[]
    def rejected(name,call):
        try:call()
        except (ValueError,FileNotFoundError,KeyError):checks.append(dict(name=name,passed=True));return
        raise AssertionError('Expected rejection: '+name)
    rt.validate(clean,grid);checks.append(dict(name='official_submission_accepted',passed=True))
    rejected('wrong_order_rejected',lambda:rt.validate(clean.iloc[::-1].reset_index(drop=True),grid))
    rejected('missing_row_rejected',lambda:rt.validate(clean.iloc[:-1],grid))
    duplicate=clean.copy();duplicate.loc[1,'example_id']=duplicate.loc[0,'example_id']
    rejected('duplicate_id_rejected',lambda:rt.validate(duplicate,grid))
    for value,name in [(-1.,'negative'),(np.nan,'nan'),(np.inf,'inf')]:
        invalid=clean.copy();invalid.loc[0,'boardings']=value
        rejected(name+'_rejected',lambda:rt.validate(invalid,grid))
    reference=rt.prepare(package,output_override=str(out/'results'))
    baseline=rt.amplify_and_events(reference)
    near=clean.copy();near.loc[500,'boardings']=np.expm1(np.log1p(near.loc[500,'boardings'])+5e-10)
    nearpath=out/'within_tolerance.csv';csv(near,nearpath)
    ctx=rt.prepare(package,str(nearpath),str(out/'results'))
    assert ctx['baseline_verification']['acceptance']=='numeric_equivalence'
    changed=rt.amplify_and_events(ctx)
    actual=float(np.log1p(changed.loc[500,'boardings'])-np.log1p(baseline.loc[500,'boardings']))
    assert abs(actual-5e-10)<1e-14
    checks.append(dict(name='within_1e_9_accepted_and_supplied_value_used',passed=True,actual_log_change=actual))
    far=clean.copy();far.loc[500,'boardings']=np.expm1(np.log1p(far.loc[500,'boardings'])+2e-9)
    farpath=out/'outside_tolerance.csv';csv(far,farpath)
    rejected('over_1e_9_rejected',lambda:rt.prepare(package,str(farpath),str(out/'results')))
    fake=out/'fake_package';fake.mkdir()
    dump(fake/'amp_delivery_manifest.json',dict(package_kind='other_package',files={}))
    rejected('other_package_kind_rejected',lambda:rt.verify_inputs(fake))
    dump(fake/'amp_delivery_manifest.json',dict(package_kind=rt.KIND,files={'../escape':'x'}))
    rejected('manifest_traversal_rejected',lambda:rt.verify_inputs(fake))
    (fake/'frozen.txt').write_text('altered')
    dump(fake/'amp_delivery_manifest.json',dict(package_kind=rt.KIND,files={'frozen.txt':'0'*64}))
    rejected('frozen_hash_mismatch_rejected',lambda:rt.verify_inputs(fake))
    search=out/'content';search.mkdir()
    for name in ['a/b/c','a/b/c/d','drive/p','link_target']:
        p=search/name;p.mkdir(parents=True,exist_ok=True);(p/'amp_delivery_manifest.json').write_text('{}')
    link=search/'linked';link.symlink_to(search/'link_target',target_is_directory=True)
    # Execute the notebook's actual discovery helper, not a separately invented equivalent.
    nb=json.loads((package/'SINCON_amp15.ipynb').read_text())
    cell=next(c for c in nb['cells'] if 'prepare' in c.get('metadata',{}).get('tags',[]))
    tree=ast.parse(''.join(cell['source']))
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='bounded')
    ns=dict(os=os,Path=Path)
    exec(compile(ast.Module(body=[node],type_ignores=[]),'notebook_discovery','exec'),ns)
    found={str(p.relative_to(search)) for p in ns['bounded'](search,3,('drive',))}
    assert 'a/b/c' in found and 'a/b/c/d' not in found and 'drive/p' not in found and 'linked' not in found
    checks.append(dict(name='notebook_content_depth3_drive_and_symlink_excluded',passed=True,found=sorted(found)))
    deeper={str(p.relative_to(search)) for p in ns['bounded'](search,4,('drive',))}
    assert 'a/b/c/d' in deeper
    checks.append(dict(name='notebook_kaggle_depth4',passed=True))
    direct={str(p.parent.relative_to(search)) for p in rt.bounded(search,'amp_delivery_manifest.json',3,('drive',))}
    assert direct==found
    checks.append(dict(name='official_data_search_same_depth_contract',passed=True))
    dump(out/'boundary_checks.json',dict(success=True,checks=checks,total=len(checks),
        python=sys.version,numpy=np.__version__,pandas=pd.__version__))
    status('패키지 입력·탐색 경계 검사 '+str(len(checks))+'개 통과')

if __name__=='__main__':main()
