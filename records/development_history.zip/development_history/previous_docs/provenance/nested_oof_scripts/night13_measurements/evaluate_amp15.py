"""Evaluate exactly the preregistered two-layer 1.5 multiplier and emit one CSV."""
from common import *
import argparse
import ast
import shutil
from types import SimpleNamespace

KEY=['date','station_id','hour']
OK=['label','origin',*KEY]
END=pd.Timestamp('2026-06-30')
NAMES=['station_profiles','tabicl_fixed','dongchun_retail','lunar_eve_and_day',
       'geomdan_morning','tabicl_lead_weight','vector_xgboost']

def rms(y,p):return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))

def amplify(d):
    addition=.5*(d.station_profiles.to_numpy()+d.vector_xgboost.to_numpy())*d.amp_eligible.to_numpy()
    value=d.baseline.to_numpy()+addition
    assert np.isfinite(value).all() and (value>=0).all()
    assert np.array_equal(value[~d.amp_eligible],d.baseline.to_numpy()[~d.amp_eligible])
    return value

def downstream_function(final):
    """Use the reviewed round-11 chronological evaluation without importing its fence."""
    source=ROOT/'night11/reproduce_nested.py'
    tree=ast.parse(source.read_text())
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='validate_downstream')
    ns=dict(final=final,ROOT=ROOT,csv=csv,np=np,pd=pd,END=END,KEY=KEY,OK=OK,
        friday=module('round13_friday',ROOT/'sincon_clean_friday_calendar.py'),
        lunar=module('round13_lunar',ROOT/'night7/audit_lunar.py'),m=SimpleNamespace(rmsle=rms))
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
    return ns['validate_downstream']

def make_final_module(destination):
    """Keep all six algorithms; authorize only a caller-locked amplified baseline."""
    text=(ROOT/'night7/final_layers.py').read_text()
    old="[(baseline,CLEAN_SHA),(data_dir/'train.csv',TRAIN_SHA),(data_dir/'test.csv',TEST_SHA)]"
    assert text.count(old)==1
    text=text.replace(old,"[(data_dir/'train.csv',TRAIN_SHA),(data_dir/'test.csv',TEST_SHA)]")
    old="'clean_sha256':CLEAN_SHA"
    assert text.count(old)==1
    text=text.replace(old,"'clean_sha256':sha(baseline),'clean_reference_sha256':CLEAN_SHA")
    destination.write_text(text)
    return module('round13_final_amp',destination)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=OUT/'measurements')
    parser.add_argument('--extraction',type=Path,default=OUT/'stage1')
    parser.add_argument('--candidate',type=Path,default=OUT/'submission_amp15_main.csv')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    for p in [out,args.candidate.resolve(),args.extraction.resolve()]:
        if not p.is_relative_to(OUT):raise ValueError('Paths must be under night13')
    run=ROOT/json.loads((args.extraction/'extraction_verification.json').read_text())['run']
    final=module('round13_final',ROOT/'night7/final_layers.py')
    train=read(DATA/'train.csv',parse_dates=['date'])
    grid=read(DATA/'test.csv',parse_dates=['date'])
    assert len(train)==688176 and train.date.max()==END and not train.duplicated(KEY).any()
    assert len(grid)==157194 and grid.example_id.is_unique and not grid.duplicated(KEY).any()
    truth=np.log1p(train.set_index(KEY).boardings)
    validate=downstream_function(final)
    scores=[];fits={};checks=[];protection=[]
    for path in ['old','nested']:
        d=read(ROOT/f'night12/measurements_final/layer_oof_{path}.csv.gz',parse_dates=['date','origin'])
        assert len(d)==1283112 and d.origin.nunique()==9 and not d.duplicated(OK).any()
        assert d.date.gt(d.origin).all() and d.date.max()<=END
        y=truth.reindex(pd.MultiIndex.from_frame(d[KEY])).to_numpy()
        assert np.max(abs(y-d.y_log))<1e-12
        closure=d.initial.to_numpy()+d[NAMES].sum(axis=1).to_numpy()
        assert abs(closure-d.baseline).max()<1e-12
        amp=amplify(d)
        for variant,values in [('main',d.baseline.to_numpy()),('amp15',amp)]:
            label=path+'_'+variant
            rows=d[OK+['y_log']].assign(baseline=values)
            csv(rows,out/f'model_oof_{label}.csv.gz')
            b,h=validate(rows,train,out,label)
            fits[label]=(b,h)
        base=read(out/f'downstream_oof_{path}_main.csv.gz',parse_dates=['date','origin'])
        cand=read(out/f'downstream_oof_{path}_amp15.csv.gz',parse_dates=['date','origin'])
        assert base[OK].equals(cand[OK]) and base[OK].equals(d[OK])
        archived=read(ROOT/f'night11/measurements/downstream_oof_{path}.csv.gz',parse_dates=['date','origin'])
        ai=pd.MultiIndex.from_frame(base[OK])
        old=archived.set_index(OK).lunar3122.reindex(ai).to_numpy()
        cache_diff=float(abs(base.lunar3122.to_numpy()-old).max())
        assert cache_diff<1e-12
        checks.append(dict(path=path,rows=len(d),origins=9,official_label_max_error=float(abs(y-d.y_log).max()),
                           layer_sum_max_error=float(abs(closure-d.baseline).max()),
                           round11_downstream_max_error=cache_diff,
                           protected_amplification_changes=int(np.count_nonzero((amp-d.baseline.to_numpy())[~d.amp_eligible]))))
        for origin,p in d.groupby('origin',sort=True):
            ix=p.index
            hist=d.loc[d.origin.lt(origin)&d.date.le(origin)&d.date.gt(origin-pd.Timedelta(days=60))]
            for stage,col in [('model','baseline'),('final6','lunar3122')]:
                a=rms(p.y_log,base.loc[ix,col]);c=rms(p.y_log,cand.loc[ix,col])
                scores.append(dict(path=path,origin=str(origin.date()),label=p.label.iloc[0],stage=stage,
                    rows=len(p),prior_rows=len(hist),testable=bool(len(hist)) if stage=='final6' else True,
                    main_rmsle=a,amp15_rmsle=c,delta=c-a,improved=bool(c<a)))
        old_b=fits[path+'_main'][0];new_b=fits[path+'_amp15'][0]
        f=pd.DataFrame(dict(station_id=old_b.index,main_centered_error=old_b.values,
            amp15_centered_error=new_b.reindex(old_b.index).values))
        f['main_log_correction']=-.25*f.main_centered_error
        f['amp15_log_correction']=-.25*f.amp15_centered_error
        f['difference']=f.amp15_log_correction-f.main_log_correction
        csv(f,out/f'station_final_{path}.csv')
        assert len(f)==71 and f.notna().all().all()
        status(path+' 과거 9개 기준일 모델층·최종층 계산 및 기존 round11 경로 재현 완료')
    score=pd.DataFrame(scores);csv(score,out/'validation_scores.csv')
    summaries=[]
    for (path,stage),g in score.groupby(['path','stage']):
        q=g.loc[g.testable]
        summaries.append(dict(path=path,stage=stage,testable=len(q),improved=int(q.improved.sum()),
             worst_delta=float(q.delta.max()),best_delta=float(q.delta.min()),
             passed=bool(len(q)>0 and q.improved.all())))
    summary=pd.DataFrame(summaries);csv(summary,out/'validation_summary.csv')
    passed=bool(summary.loc[summary.stage.eq('final6'),'passed'].all())
    verdict='기준 충족' if passed else '기준 미달'
    dump(out/'historical_verification.json',checks)
    status('과거 검증 잠정 판정 '+verdict+'. 최종 CSV·보호 행 검산을 계속한다. '+summary.to_json(orient='records',force_ascii=False))

    traced=read(args.extraction/'final_model_layer_changes.csv.gz',parse_dates=['date'])
    assert grid[['example_id',*KEY]].equals(traced[['example_id',*KEY]])
    model=read(run/'model.csv')
    amp_model=model.assign(boardings=np.expm1(amplify(traced)))
    mask=~traced.amp_eligible
    amp_model.loc[mask,'boardings']=model.loc[mask,'boardings']
    csv(amp_model,out/'model_amp15.csv')
    import sincon_clean_event_replay as events
    old_argv=sys.argv[:]
    try:
        sys.argv=[str(WORK/'sincon_clean_event_replay.py'),str(DATA.parent),str(out/'model_amp15.csv'),
            str(run/'cache/sincon_clean_event_oof.csv.gz'),str(out/'clean_amp15.csv'),
            str(out/'after_model_amp15.json'),'--stage','after_model','--early-protected',
            str(run/'protected.csv'),'--protected',str(out/'event_keys_amp15.csv')]
        events.main()
    finally:sys.argv=old_argv
    # The original after_model rules address fixed Jul-Oct 2026 dates only.
    # Their historical input is exactly the same pre-model clean event OOF.
    after=json.loads((out/'after_model_amp15.json').read_text())
    historical_target_overlap=0
    for row in after['changes']:
        if pd.Timestamp(row['date'])<=END:historical_target_overlap+=1
    assert historical_target_overlap==0
    dump(out/'after_model_historical_scope.json',dict(
        fixed_target_dates_after_official_cutoff=True,historical_target_overlap=historical_target_overlap,
        historical_after_model='identity: fixed final-target keys are absent from all historical grids',
        chronological_final_layers='round11 validate_downstream; timecapsule historical patch, completed concert donors, station refit, Friday and lunar historical transfers; PLAVE22 final-only override has no historical analogue',
        limitation='Historical scores do not validate the final-only event overrides or the PLAVE22 forecast rule.'))
    cache=out/'amp_cache';cache.mkdir()
    for p in sorted((ROOT/'night7/cache').iterdir()):
        if p.is_file() and p.name not in ['manifest.json','final_stage_oof.csv.gz']:
            shutil.copyfile(p,cache/p.name)
    shutil.copyfile(out/'model_oof_old_amp15.csv.gz',cache/'final_stage_oof.csv.gz')
    dump(cache/'manifest.json',dict(files={p.name:sha(p) for p in sorted(cache.iterdir()) if p.is_file()},
        labels_through='2026-06-30',preregistered_multiplier=1.5,source='round13 old amplified OOF'))
    amp_final=make_final_module(out/'amp_final_layers.py')
    candidate,layers,report=amp_final.build_submission(DATA,cache,out/'clean_amp15.csv')
    main,layers_main,report_main=final.build_submission(DATA,ROOT/'night7/cache',ROOT/'final_package/reference/submission_clean_refined.csv')
    ref_path=ROOT/'final_delivery_v2/reference/submission_night_v4_main.csv'
    ref=read(ref_path)
    assert ref.example_id.equals(main.example_id)
    main_error=float(abs(np.log1p(main.boardings)-np.log1p(ref.boardings)).max())
    assert main_error<1e-12
    assert list(candidate)==['example_id','boardings'] and len(candidate)==157194
    assert candidate.example_id.equals(grid.example_id) and candidate.example_id.is_unique
    assert np.isfinite(candidate.boardings).all() and candidate.boardings.ge(0).all()
    csv(candidate,args.candidate)
    saved=read(args.candidate)
    assert np.array_equal(saved.boardings,candidate.boardings)
    csv(layers,out/'final_layer_deltas_amp15.csv.gz')
    csv(layers_main,out/'final_layer_deltas_main.csv.gz')
    dump(out/'final_layers_amp15.json',report)
    log=np.log1p(candidate.boardings)-np.log1p(main.boardings)
    diff=grid[['example_id',*KEY]].assign(log_difference=log,count_difference=candidate.boardings-main.boardings)
    csv(diff,out/'candidate_differences.csv.gz')
    for key in ['station_id','hour','month']:
        group=diff.assign(month=diff.date.dt.month).groupby(key).agg(rows=('log_difference','size'),
            changed=('log_difference',lambda x:int(np.count_nonzero(abs(x)>1e-12))),
            mean_log_difference=('log_difference','mean'),mean_abs_log_difference=('log_difference',lambda x:float(abs(x).mean())),
            max_abs_log_difference=('log_difference',lambda x:float(abs(x).max())),
            rms_log_difference=('log_difference',lambda x:float(np.sqrt(np.mean(x*x)))))
        csv(group.sort_values('mean_abs_log_difference',ascending=False).reset_index(),out/f'differences_by_{key}.csv')
    event_masks=dict(PLAVE=grid.station_id.eq(3127)&grid.date.isin(pd.to_datetime(['2026-09-12','2026-09-13'])),
        timecapsule=grid.station_id.eq(3139)&grid.date.eq('2026-07-11')&grid.hour.isin([21,22,23]),
        bupyeong_lunar=grid.station_id.eq(3122)&grid.date.isin(pd.to_datetime(['2026-09-24','2026-09-25'])),
        model_protected=~traced.amp_eligible)
    for name,selected in event_masks.items():
        p=grid.loc[selected,['example_id',*KEY]].copy()
        p['group']=name;p['amp_eligible']=traced.loc[selected,'amp_eligible']
        p['model_addition']=amplify(traced)[selected]-traced.loc[selected,'baseline']
        p['main']=main.loc[selected,'boardings'];p['amp15']=candidate.loc[selected,'boardings']
        p['final_log_difference']=log[selected]
        protection.append(p)
    csv(pd.concat(protection,ignore_index=True),out/'protected_rows_diagnostic.csv.gz')
    b_actual=pd.Series({int(k):v for k,v in report['layers']['station025']['evidence']['centered_errors'].items()})
    assert abs(b_actual-fits['old_amp15'][0].reindex(b_actual.index)).max()<1e-12
    station=read(out/'station_final_old.csv')
    result=dict(verdict=verdict,passed=passed,created_kst=now(),rows=len(candidate),
        candidate_sha256=sha(args.candidate),main_sha256=sha(ref_path),main_reproduction_max_log_error=main_error,
        changed_rows_exact=int(candidate.boardings.ne(main.boardings).sum()),
        changed_rows_gt_1e_12=int(log.abs().gt(1e-12).sum()),mean_log_difference=float(log.mean()),
        mean_abs_log_difference=float(log.abs().mean()),max_abs_log_difference=float(log.abs().max()),
        rms_log_difference=float(np.sqrt(np.mean(log*log))),
        station_refit_max_log_correction_difference=float(station.difference.abs().max()),
        station_refit_mean_abs_log_correction_difference=float(station.difference.abs().mean()),
        protected_model_amplification_changes=int(np.count_nonzero((amplify(traced)-traced.baseline.to_numpy())[~traced.amp_eligible])),
        package_required=passed,validation_summary=summaries,
        final_layer_order=list(final.LAYER_NAMES),after_model_historical_identity=True)
    dump(out/'result.json',result)
    record_reads(out/'read_manifest.json')
    status('1~4 완료. 최종 판정 '+verdict+'; 후보 CSV '+str(args.candidate.relative_to(ROOT))+'. '+json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
