"""Verify every ZIP member and execute the actual archive from an empty folder."""
from common import *
import shutil
import subprocess
import io
import csv as csvlib
from zipfile import ZipFile
from validate_delivery import readonly

def main():
    package=ROOT/'amp_delivery'
    distribution=json.loads((package/'DISTRIBUTION.json').read_text())
    archive=package/distribution['archive']
    assert sha(archive)==distribution['sha256'] and archive.stat().st_size==distribution['bytes']
    out=OUT/'archive_validation';out.mkdir(exist_ok=False)
    dest=out/'빈 한글 폴더';dest.mkdir();assert not list(dest.iterdir())
    with ZipFile(archive) as z:
        assert z.testzip() is None
        members=z.namelist();assert len(members)==len(set(members))==distribution['archive_members']
        assert all(name.startswith('amp_delivery/') and '..' not in Path(name).parts for name in members)
        assert all(Path(name).name not in ['train.csv','test.csv','metaData.csv'] and not name.endswith('.whl') for name in members)
        listing=z.read('amp_delivery/FILE_LIST.tsv')
        assert hashlib.sha256(listing).hexdigest()==distribution['file_list_sha256']
        records=list(csvlib.DictReader(io.StringIO(listing.decode()),delimiter='\t'))
        assert len(records)==distribution['files_listed']
        assert set(members)=={'amp_delivery/'+r['path'] for r in records}|{'amp_delivery/FILE_LIST.tsv'}
        for r in records:
            content=z.read('amp_delivery/'+r['path'])
            assert len(content)==int(r['bytes']) and hashlib.sha256(content).hexdigest()==r['sha256']
            assert sha(package/r['path'])==r['sha256']
        z.extractall(dest)
    unpacked=dest/'amp_delivery'
    for name in ['train.csv','test.csv','metaData.csv']:shutil.copyfile(DATA/name,unpacked/'data'/name)
    frame=read(unpacked/'reference/submission_clean_refined.csv')
    frame.to_csv(unpacked/'input/submission_numeric_equiv.csv',index=False,float_format='%.18e',mode='x')
    readonly(unpacked)
    results=[]
    for label in ['py311','py312']:
        python=OUT/'offline_envs_verified'/label/'bin/python'
        for case in ['reference','numeric_equivalence']:
            output=out/(label+'_'+case)
            command=[str(python),'-B',str(unpacked/'execute_notebook.py'),str(unpacked),'--output',str(output)]
            if case=='numeric_equivalence':command+=['--explicit-root','--baseline','input/submission_numeric_equiv.csv']
            with (out/(label+'_'+case+'.log')).open('x') as f:
                subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
            r=json.loads((output/'execution.json').read_text())
            assert r['success'] and r['all_code_cells_executed'] and r['package_readonly_permissions'] and r['inputs_unchanged']
            assert r['result']['max_abs_log1p_difference']<=1e-10
            results.append(dict(environment=label,case=case,**r))
            status('실제 배포ZIP '+label+' '+case+' 빈폴더·읽기전용 재현 통과')
    assert sha(archive)==distribution['sha256']
    report=dict(all_passed=True,tested_archive_sha256=sha(archive),created_kst=now(),
        archive_members_verified=len(records)+1,empty_directory_before_extract=True,
        official_csv_supplied_separately=True,package_readonly=True,
        runs=[dict(environment=r['environment'],case=r['case'],python=r['result']['environment']['python'],
            numpy=r['result']['environment']['numpy'],pandas=r['result']['environment']['pandas'],
            code_cells=r['code_cells_executed'],max_abs_log1p_difference=r['result']['max_abs_log1p_difference'],
            network_and_socket_blocked=r['network_and_socket_blocked'],original_project_reads_blocked=r['original_project_reads_blocked'],
            inputs_unchanged=r['inputs_unchanged']) for r in results])
    distribution['final_archive_execution']=report
    dump(package/'DISTRIBUTION.json',distribution)
    dump(out/'matrix.json',dict(success=True,archive=distribution,runs=results))
    with (OUT/'ROUND13_RESULT.md').open('a') as f:
        f.write('\n## 실제 배포ZIP 최종 검사\n\n'+now()+' 완료. ZIP '+str(distribution['bytes'])+'바이트, SHA-256 `'+distribution['sha256']+'`. '+
            str(distribution['archive_members'])+'개 ZIP 항목의 바이트·SHA를 FILE_LIST.tsv와 전부 검산했다. '+
            '빈 한글·공백 폴더에 풀고 공식CSV만 별도로 넣어 패키지를 읽기전용으로 만든 뒤 Python3.11·3.12 각각 기준입력·수치동등입력 총4회, 매회6/6셀을 실행했다. '+
            '최대 log1p 차이는 모두8.881784197001252e-16이다. 원본 프로젝트 읽기와 소켓을 차단했고 입력 해시는 유지됐다. '+
            '이 최종검사 후 ZIP을 변경하지 않았다. 근거는 archive_validation/matrix.json과 amp_delivery/DISTRIBUTION.json이다.\n')
    # Correct the independently runnable recheck command without rebuilding the ZIP.
    p=OUT/'ROUND13_RESULT.md';text=p.read_text()
    text=text.replace('--candidate night13/recheck_submission_amp15_main.csv --output night13/recheck_verification',
        '--candidate night13/recheck_submission_amp15_main.csv --extraction night13/recheck_stage1 --output night13/recheck_verification')
    p.write_text(text)
    status('완료. 판정 기준 충족. 기존·중첩 최종8/8 개선. 후보CSV와 재현ZIP·노트북·문서·빈폴더 실행 검증 완료. Kaggle·Colab·Linux 실기와 업로드는 하지 않았다. ZIP SHA='+distribution['sha256'])

if __name__=='__main__':main()
