"""Write measured results and concise delivery instructions from saved evidence."""
from common import *
import shutil

def table(frame):
    cols=list(frame.columns)
    def value(v):
        if isinstance(v,float):return f'{v:.12g}'
        return str(v)
    return '| '+' | '.join(cols)+' |\n| '+' | '.join('---' for _ in cols)+' |\n'+''.join(
        '| '+' | '.join(value(v) for v in row)+' |\n' for row in frame.itertuples(index=False,name=None))

def score_table(scores,stage):
    d=scores.loc[scores.stage.eq(stage)]
    a=d.loc[d.path.eq('old')].set_index('origin')
    b=d.loc[d.path.eq('nested')].set_index('origin')
    out=pd.DataFrame({'origin':a.index,
        '기존 주후보':a.main_rmsle.values,'기존 1.5배':a.amp15_rmsle.values,'기존 Δ':a.delta.values,
        '중첩 주후보':b.reindex(a.index).main_rmsle.values,'중첩 1.5배':b.reindex(a.index).amp15_rmsle.values,
        '중첩 Δ':b.reindex(a.index).delta.values})
    return table(out)

def main():
    ms=OUT/'measurements';pkg=ROOT/'amp_delivery'
    result=json.loads((ms/'result.json').read_text());assert result['passed']
    verify=json.loads((OUT/'verification/verification.json').read_text());assert verify['success']
    scores=read(ms/'validation_scores.csv');summary=read(ms/'validation_summary.csv')
    matrix=json.loads((OUT/'delivery_validation/matrix.json').read_text());assert matrix['success']
    regen=json.loads((OUT/'regenerated_inputs/regeneration_verification.json').read_text());assert regen['success']
    checks={p:json.loads((OUT/f'boundary_checks_{p}/boundary_checks.json').read_text()) for p in ['py311','py312']}
    assert all(c['success'] for c in checks.values())
    envrows=[]
    for r in matrix['runs']:
        env=r['result']['environment']
        envrows.append(dict(Python=env['python'],NumPy=env['numpy'],pandas=env['pandas'],input=r['case'],
            cells=f'{r["code_cells_executed"]}/6',max_log1p=r['result']['max_abs_log1p_difference'],
            readonly=r['package_readonly_permissions'],unchanged=r['inputs_unchanged']))
    envtable=table(pd.DataFrame(envrows))
    slim=[dict(environment=r['environment'],case=r['case'],code_cells_executed=r['code_cells_executed'],
        all_code_cells_executed=r['all_code_cells_executed'],package_readonly_permissions=r['package_readonly_permissions'],
        inputs_unchanged=r['inputs_unchanged'],network_and_socket_blocked=r['network_and_socket_blocked'],
        original_project_reads_blocked=r['original_project_reads_blocked'],result=r['result']) for r in matrix['runs']]
    dump(pkg/'evidence/notebook_validation.json',dict(success=True,runs=slim,
        execution_backend='standard-library sequential compile/exec; not a Jupyter kernel'))
    shutil.copyfile(OUT/'regenerated_inputs/regeneration_verification.json',pkg/'evidence/regeneration_verification.json')
    shutil.copyfile(OUT/'verification/event_rule_preservation.json',pkg/'evidence/event_rule_preservation.json')
    for p in ['py311','py312']:
        shutil.copyfile(OUT/f'boundary_checks_{p}/boundary_checks.json',pkg/f'evidence/boundary_checks_{p}.json')
    for name in ['sports_field_comparison.csv','sports_unresolved_and_differences.csv']:
        shutil.copyfile(ROOT/'final_delivery_v2/evidence'/name,pkg/'evidence'/name)
    metrics=pd.DataFrame([dict(metric=k,value=result[k]) for k in ['changed_rows_exact','mean_log_difference',
        'mean_abs_log_difference','max_abs_log_difference','rms_log_difference',
        'station_refit_max_log_correction_difference','station_refit_mean_abs_log_correction_difference']])
    tops=''
    for key,title in [('station_id','역별 상위5'),('hour','시간대 상위5'),('month','월별 전체')]:
        t=read(ms/f'differences_by_{key}.csv')
        if key!='month':t=t.head(5)
        tops+='\n### '+title+'\n\n'+table(t)
    policy=json.loads((OUT/'verification/event_rule_preservation.json').read_text())
    protection=read(OUT/'verification/protected_summary.csv')
    scope='''과거 점수는 11번 `validate_downstream`과 같은 시간순 대체 평가다. timecapsule 과거 패치, 종료된 공연 기증값, 기준일 이전 OOF 최근60일 역별 적합, 과거 금요일 및 명절 전이를 차례로 재계산했다. 주후보 경로는 11번 downstream OOF와 차이0으로 재현했다.

`after_model`의 실제 목표 키는 모두 2026년7월 이후라 과거 격자에서는 항등이다. 최종 전용 행사 override와 PLAVE22에는 이 과거 9개 기준일에 직접 적용할 대상이 없다. 따라서 최종6개층 점수는 11번이 시험할 수 있었던 과거 대응 층을 모두 지난 값이며, 최종 전용 행사 정확도를 검증한 값은 아니다. 최종2026-06-30 예측에서는 after_model과 실제6개층을 모두 실행했다.
'''
    limits='''이 규칙은 12번의 같은 과거 자료를 본 뒤 찾았다. 사전등록은 이번 두 층·1.5배와 통과 기준을 고정했지만 규칙 발견의 사후성을 없애지 않는다. 원시 예측을 동결한 검증이며 모델 전체를 재학습한 독립 홀드아웃이 아니다. 기준일별 평가기간도 겹친다. 특히 마지막 기준일의 개선은 작다.

Kaggle·Colab·Linux 실기, 표준 Jupyter kernel 실행, 전체 모델 재학습은 이번 작업에서 하지 않았다. Python3.11과3.12 검증은 macOS ARM64의 새 가상환경에서 표준 라이브러리 순차 셀 실행기로 수행했다. 외부 자료 이용 조건과 공급자 데이터 이력의 기존 미확인 사항도 해결하지 않았다. `SOURCES.md`, `LICENSE_NOTICES.md`와 Public 유래 보정 제외 이력을 보존했다. 2026년7월 이후 실측을 찾거나 사용하지 않았고 새 웹 조회·다운로드·Kaggle 업로드를 하지 않았다.
'''
    readme=f'''# SINCON 2026 핫식스 · 사전등록 1.5배 후보

1단계 assemble 출력에 `0.5 × (station_profiles 변화 + vector_xgboost 변화)`를 고정 마스크에서 더합니다. 모델층 뒤 행사 보정과 승인된 최종6개층을 같은 순서·계수로 다시 계산합니다. 역별60일·0.25배 층은 증폭 OOF로 다시 맞춥니다. 출력은 `submission_amp15_main.csv`입니다. 다른 배율이나 층 조합 설정은 없습니다.

판정은 **{result['verdict']}**입니다. 기존·중첩 모두 시험 가능한8개 기준일 전부 개선했습니다. 채택 판단은 Claude가 합니다. 이 패키지는 업로드하지 않았습니다.

## Kaggle 실행

1. 별도 1단계 `final_package/SINCON_final.ipynb`를 assemble로 실행합니다.
2. 이 ZIP을 읽기 전용 입력으로 연결하고 공식 train.csv·test.csv·metaData.csv를 연결합니다.
3. 1단계 CSV를 패키지 input/에 준비하거나 노트북 BASELINE_CSV에 경로를 지정합니다.
4. `SINCON_amp15.ipynb`의 ROOT를 패키지 폴더로 지정하고 모든 셀을 실행합니다.
5. `/kaggle/working`의 후보와 verification.json을 확인합니다.

## Colab 실행

1. 별도 1단계 assemble을 실행하고 이 ZIP을 `/content`에 풉니다.
2. 공식 CSV를 패키지 data/에, 1단계 CSV를 input/에 놓습니다.
3. `SINCON_amp15.ipynb`를 열고 ROOT를 패키지 폴더로 지정합니다.
4. NumPy와 pandas가 있는 환경에서 모든 셀을 실행합니다.
5. `/content`의 후보와 verification.json을 확인합니다.

## 로컬 실행

1. Python3.11 또는3.12 환경에 requirements.txt의 의존성을 준비합니다.
2. 별도 1단계 assemble을 실행하고 이 ZIP을 풉니다.
3. 공식 CSV는 data/, 1단계 CSV는 input/에 놓습니다.
4. `python -B amp_delivery/execute_notebook.py amp_delivery --output 새_쓰기폴더`로 실행합니다.
5. 새_쓰기폴더/results/의 후보와 verification.json을 확인합니다.

위 Kaggle·Colab 절차는 사용 안내이며 이번 작업의 실기 성공 기록이 아닙니다. 공식 원본CSV, 가상환경, wheel 및 별도1단계 패키지는 ZIP에 포함하지 않습니다. 노트북에는 설치·웹·다운로드·업로드 셀이 없습니다.

## 입력과 탐색

기본1단계 입력은 input/submission_clean_refined.csv, 없으면 동봉 reference/submission_clean_refined.csv입니다. SHA가 같거나 형식·공식순서·유한·비음수를 만족하고 기준과 최대 log1p 차이1e-9 이내이면 허용합니다. 수치 동등 입력도 실제 제공된 CSV로 계산하며 입력 SHA와 차이를 기록합니다. 최종 재현 비교 한계는1e-10입니다. 임의로1e-9에 가깝게 변조한 입력까지 최종1e-10 일치를 보장하는 뜻은 아닙니다.

ROOT는 고유한 amp_delivery_manifest.json과 package_kind=sincon_amp15_preregistered_v1이 있는 폴더입니다. 자동 탐색은 현재폴더·amp_delivery, `/content` 깊이3·drive 제외, `/kaggle/input` 깊이4 이내이며 symlink 폴더를 따라가지 않습니다. 여러 후보가 있으면 ROOT를 지정합니다. 공식CSV 탐색에도 같은 깊이 제한을 적용합니다. 출력은 읽기전용 입력과 분리하며 `SINCON_AMP_OUTPUT_DIR`로 지정할 수 있습니다.

## 최종 두 층 변화의 재생성

동봉 final_model_inputs.csv.gz와 after_model_recipe.json을 별도1단계 패키지에서 다시 만드는 명령입니다. 이미 설치된1단계 의존성을 쓰며 모델을 재학습하지 않습니다.

```bash
python -B amp_delivery/generate_model_inputs.py --stage1-root final_package --output 새_재생성폴더
```

스크립트는 원본1단계를 읽기만 하고 실행사본에서 apply 전후 변화를 기록합니다. 생성 파일 두 개의 SHA를 manifest와 엄격히 비교합니다. 이번에는 Python3.12.15·NumPy2.5.4·pandas3.1.1에서 두 해시의 정확한 일치를 확인했습니다. 다른 수치 라이브러리 버전의 재생성 바이트 일치는 측정하지 않았습니다. 수치 동등한1단계 CSV를 허용하는 절차와 동봉 입력의 해시 검사는 구분합니다.

## 검증표

Δ는 1.5배−주후보이며 음수가 개선입니다. 최초2025-06-30은 이전 OOF가 없어 최종 판정에서 제외했습니다. 모델 직후는 기존·중첩 모두9/9 개선입니다.

{table(summary)}

### 최종 단계의 기준일별 RMSLE

{score_table(scores,'final6')}

{scope}

## 보호 행과 최종값

고정 amp_eligible의 여집합27,198행에는 직접 증폭을 더하지 않았습니다. 역별 층을 다시 적합하므로 이 행들의 최종값까지 모두 같다는 뜻은 아닙니다. PLAVE22 두 행은 최종 override로 주후보와 정확히 같습니다. 나머지 PLAVE와 부평삼거리 최종값은 역별 적합과 새 대조일 예측에 따라 바뀝니다.

타임캡슐3행은 기존 amp_eligible에 포함됩니다. 마스크를 바꾸지 않고 기존0.75배 하한을 재적용했습니다. 역별 층 직전 값은 주후보와 최대 log 차이{policy['timecapsule_floor_preserved_before_station_max_error']:.12g}이며, 최종값에는 역별 재적합의 차이가 남습니다. 행사·명절 보정의 규칙과 계수를 보존했습니다.

## 직접 실행한 재현 검사

{envtable}

매회6개 코드 셀을 순차 compile/exec로 모두 실행했습니다. Jupyter kernel 실행은 아닙니다. 패키지는 파일444·폴더555로 만들고 원본 프로젝트 데이터 읽기, 패키지 쓰기와 네트워크·소켓을 차단했습니다. 입력해시는 유지됐습니다. 수치동등 입력은 같은 값을 다른 CSV 표기로 저장한 입력입니다. 별도로1e-9 이내 허용·초과 거부·실제 제공값 사용·엄격해시·탐색깊이·drive와symlink 제외 등 환경별15개 경계 검사를 통과했습니다.

배포 ZIP을 빈폴더에 푼 최종 실행 기록과 ZIP 크기·SHA는 ZIP 바깥 DISTRIBUTION.json에 연결합니다. 파일별크기·해시는 FILE_LIST.tsv에 있습니다. 상세 실행 근거는 evidence/에 있습니다.

## 약점과 한계

{limits}
'''
    (pkg/'README.md').write_text(readme)
    report=f'''# 18번 작업 결과 · 고정1.5배 후보

작성 {now()}. Claude 검토용.

**판정: {result['verdict']}.** 기존·중첩 두 방식 모두 최종 단계의 시험 가능한8개 기준일 전부에서 RMSLE가 개선됐다. 첫 기준일은 이전 OOF가 없어 판정에서 제외했다. 모델 직후는 두 방식 모두9/9 개선이다. 계수나 조합을 추가로 탐색하지 않았다. 채택 판단은 Claude가 한다.

## 사전등록과 실행 범위

08:50 KST의 원문을 먼저 읽고 decisions_round13.tsv 첫 줄에 읽은 시각과 함께 그대로 JSON 문자열로 보존했다. SHA-256은 `310d2deaf5972d5ced84eb1a35f777d19f12f7cb18882b63a05ca73ee8e50462`다. 사전등록에 적힌 Public 사실은 복사 보존 외에 계산·규칙·선택에 쓰지 않았다. 현재 지시에 따라 업로드하지 않았다.

`night13/` 실행사본에서1단계 assemble 전체를 돌렸다. clean 출력 SHA는 원본 `519c88bd46e991677316175a2d24f802db6248ebb7d3971ecbe75477532f2199`와 같다. initial + 일곱 모델층 변화 + after_model 변화가 원 clean에 최대 log 차이0으로 닫혔다. 두 층 변화는 actual apply 전후 차이로 기록했고 보호 행의 추가 증폭은0이다. stage1/extraction_verification.json과 final_model_layer_changes.csv.gz가 근거다.

공식 train688,176행과2026-06-30까지 정답만 썼다. 기존·중첩 각1,283,112행의 층 분해 캐시를 공식 정답에 다시 연결했다. 원시 모델은 동결했다. Python audit hook으로 두 새폴더 밖 쓰기와 네트워크를 막았고 수치 라이브러리 환경변수는1스레드다. 확인한 원본{verify['source_files_unchanged']:,}개 파일의 해시는 유지됐다.

## 사전 기준 판정

{table(summary)}

### 모델층 결합 직후

{score_table(scores,'model')}

### 최종6개층의 과거 대응 단계

{score_table(scores,'final6')}

{scope}

최악 Δ는 기존{result['validation_summary'][2]['worst_delta']:.12g}, 중첩{result['validation_summary'][0]['worst_delta']:.12g}다. 둘 다2026-04-30이다. 이 값이 음수여서 기준을 충족했다. 독립 검산의 점수 차이는 최대5.551115123125783e-17, 역별 적합 재계산 차이는0이다. 미래 정답과 예측을 각각+1000 및−777로 변조한36개 역별 적합 검사는 모두 같았다. 모델 전체의 미래변조 검사를 이번에 다시 수행했다고 주장하지 않는다.

## 후보CSV와 주후보 차이

후보 `submission_amp15_main.csv`는157,194행, 공식 example_id 순서·유일성·유한·비음수를 확인했다. SHA-256은 `{result['candidate_sha256']}`다. 주후보 재현 최대 log 차이는{result['main_reproduction_max_log_error']:.12g}다. 아래 변경 행은 절대 log 차이1e-12 초과 기준과 정확한 count 비교에서 모두157,192행이다.

{table(metrics)}

최근60일의 증폭 OOF로 적합을 다시 수행해 기존 캐시 적합과 최대 log 보정 차이가{result['station_refit_max_log_correction_difference']:.12g}였다. 기존 캐시 적합값을 재사용하지 않았다. 71역별 두 적합은 measurements/station_final_old.csv와 station_final_nested.csv에 있다. 최종 제출에는 기존 OOF의 증폭 경로를 사용하고 중첩은 검증·진단으로만 남겼다.

{tops}

### 행사·명절 보정 보존

{table(protection)}

보호는 모델 추가 증폭의 마스크다. 최종 층의 재적합 이후 보호행 전체가 주후보와 같다고 해석하지 않는다. PLAVE36행 중22시2행은 정확히 같고 나머지34행은 역별 적합 변화로 달라졌다. 부평삼거리36행은 새 평소 일요일 예측으로 다시 계산했다. 타임캡슐3행은 사전 고정 마스크에 포함돼 모델 신호가 바뀌지만0.75배 하한 재적용 뒤 역별층 직전 값은 주후보와 정확히 같았다. 최종 타임캡슐 차이는 역별 재적합에서 생겼다. 층 순서와 계수는 그대로다.

## 재현패키지 검사

{envtable}

`amp_delivery/SINCON_amp15.ipynb`의6개 코드 셀을 모두 실행했다. 새 Python3.11.17과3.12.15 환경을 기존 오프라인 wheel 캐시에서 설치했다. 패키지는 읽기전용으로 두고 별도 쓰기폴더를 사용했다. 원본 프로젝트 읽기와 네트워크도 차단했다. 환경별15개 입력·탐색 경계 검사도 통과했다. 1단계에서 다시 생성한 동봉 입력 두 파일은 manifest와 SHA가 일치했다.

최초 오프라인 설치는 pytz·tzdata의 다중 wheel tag 중 Python2 태그를 선택해 실패했다. Python3 호환 태그를 선택하도록 재포장 도구를 고치고 새폴더·새가상환경에서 재실행했다. 최초 로그와 실패 wheel은 남겨뒀다. 모델 산식·후보·계수는 바꾸지 않았다.

ZIP의 최종 빈폴더 실행 결과는 amp_delivery/DISTRIBUTION.json과 night13/archive_validation/에 기록한다. 이 보고서의 배포검사 추가 기록은 실제 완료 후 아래에 붙인다.

## 못 한 것과 한계

{limits}

## 재현 명령

프로젝트 루트에서 새 출력폴더와 새후보 파일명을 지정한다. 기존 결과가 있으면 덮어쓰지 않고 중단한다.

```bash
final_package/.build/venv/bin/python -B night13/extract_final_layers.py --output night13/recheck_stage1
final_package/.build/venv/bin/python -B night13/evaluate_amp15.py --extraction night13/recheck_stage1 --output night13/recheck_measurements --candidate night13/recheck_submission_amp15_main.csv
final_package/.build/venv/bin/python -B night13/verify_amp15.py --measurements night13/recheck_measurements --candidate night13/recheck_submission_amp15_main.csv --extraction night13/recheck_stage1 --output night13/recheck_verification
```

전달 노트북은 공식CSV와1단계출력을 배치한 후 `python -B amp_delivery/execute_notebook.py amp_delivery --output night13/recheck_notebook`로 재실행한다. 패키지 입력의1단계 재생성은 README의 generate_model_inputs.py 명령을 사용한다. 점수 원본은 measurements/validation_scores.csv, summary와 독립검산은 verification/verification.json이다.
'''
    (OUT/'ROUND13_RESULT.md').write_text(report)
    with (OUT/'decisions_round13.tsv').open('a') as f:
        for label,value in [('FROZEN_RULE',dict(multiplier=1.5,layers=['station_profiles','vector_xgboost'],mask='unchanged night12 amp_eligible')),
            ('FINAL_EVALUATION',dict(verdict=result['verdict'],old_improved=8,nested_improved=8,testable=8,first_origin_excluded=True)),
            ('AFTER_MODEL_SCOPE',dict(historical='identity: fixed final targets absent',final='actual rerun')),
            ('EVENT_MASK',dict(timecapsule_eligible_rows=3,mask_unchanged=True,existing_floor_reapplied=True)),
            ('FINAL_STATION_FIT',dict(source='old amplified OOF',days=60,weight=.25,nested='diagnostic only'))]:
            f.write(now()+'\t'+label+'\t'+json.dumps(value,ensure_ascii=False)+'\n')
    # Freeze all new evidence as well as the existing numeric/code inputs.
    manifest=json.loads((pkg/'amp_delivery_manifest.json').read_text())
    for p in sorted((pkg/'evidence').rglob('*')):
        if p.is_file():manifest['files'][str(p.relative_to(pkg))]=sha(p)
    dump(pkg/'amp_delivery_manifest.json',manifest)
    status('측정값으로 결과보고서·README 작성 완료. ZIP 빈폴더 검사를 진행한다.')

if __name__=='__main__':main()
