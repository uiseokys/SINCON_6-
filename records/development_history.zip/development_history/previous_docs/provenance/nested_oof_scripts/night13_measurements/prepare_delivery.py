"""Build the fixed candidate's portable assets and notebook, only after pass."""
from common import *
import shutil

PKG=ROOT/'amp_delivery'

def main():
    ms=OUT/'measurements'
    assert json.loads((ms/'result.json').read_text())['passed']
    for d in ['inputs','cache','reference','data','input','evidence']:(PKG/d).mkdir(exist_ok=True)
    sources={
        'final_layers.py':ms/'amp_final_layers.py',
        'reference/submission_clean_refined.csv':ROOT/'final_package/reference/submission_clean_refined.csv',
        'reference/submission_amp15_main.csv':OUT/'submission_amp15_main.csv',
        'reference/submission_night_v4_main.csv':ROOT/'final_delivery_v2/reference/submission_night_v4_main.csv',
        'official_inputs.json':ROOT/'final_delivery_v2/official_inputs.json',
        'evidence/validation_scores.csv':ms/'validation_scores.csv',
        'evidence/validation_summary.csv':ms/'validation_summary.csv',
        'evidence/station_final_old.csv':ms/'station_final_old.csv',
        'evidence/station_final_nested.csv':ms/'station_final_nested.csv',
        'evidence/historical_verification.json':ms/'historical_verification.json',
        'evidence/independent_verification.json':OUT/'verification/verification.json',
        'evidence/after_model_historical_scope.json':ms/'after_model_historical_scope.json',
        'evidence/preregistration.md':OUT/'AMP_CANDIDATE_PREREGISTRATION.md',
        'SOURCES.md':ROOT/'final_delivery_v2/SOURCES.md',
        'LICENSE_NOTICES.md':ROOT/'final_delivery_v2/LICENSE_NOTICES.md',
        'evidence/CC_ATTRIBUTION.csv':ROOT/'final_delivery_v2/evidence/CC_ATTRIBUTION.csv',
        'evidence/RULES_NOTICE_PUBLIC_SCORE.txt':ROOT/'final_delivery_v2/evidence/reports/RULES_NOTICE_PUBLIC_SCORE.txt',
        'evidence/SINCON_PUBLIC_SCORE_AUDIT.txt':ROOT/'final_delivery_v2/evidence/reports/SINCON_PUBLIC_SCORE_AUDIT.txt',
    }
    sources.update({'cache/'+p.name:p for p in (ms/'amp_cache').iterdir() if p.is_file()})
    for name,source in sources.items():shutil.copyfile(source,PKG/name)
    generator=module('amp_generator',PKG/'generate_model_inputs.py')
    run=ROOT/json.loads((OUT/'stage1/extraction_verification.json').read_text())['run']
    input_names=['final_model_inputs.csv.gz','after_model_recipe.json']
    if all((PKG/'inputs'/name).exists() for name in input_names):
        hashes={name:sha(PKG/'inputs'/name) for name in input_names}
    else:
        hashes=generator.create_inputs(run,WORK,DATA.parent,PKG/'inputs')
    dump(PKG/'provenance.json',dict(
        source_stage1_model_sha256=sha(WORK/'sincon_clean_model_layers.py'),
        source_pipeline_sha256=sha(ROOT/'final_package/pipeline.py'),
        source_final_layers_sha256=sha(ROOT/'night7/final_layers.py'),
        source_preregistration_sha256=sha(OUT/'AMP_CANDIDATE_PREREGISTRATION.md'),
        final_model_input_sha256=hashes,canonical_generation_environment=dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__),
        changes_to_final_builder='same six algorithms; amplified input and amplified OOF authorized by outer manifest checks; report records actual input hash',
        historical_oof_source='night12/measurements_final/layer_oof_old.csv.gz; baseline + .5*(station_profiles+vector_xgboost)*amp_eligible'))
    (PKG/'requirements.txt').write_text('numpy>=2.2,<3\npandas>=2.2,<4\n')
    (PKG/'data/PLACE_OFFICIAL_CSV_HERE.md').write_text('공식 train.csv, test.csv, metaData.csv를 여기에 직접 넣으세요. 원본은 ZIP에 동봉하지 않습니다.\n')
    (PKG/'input/PLACE_STAGE1_OUTPUT_HERE.md').write_text('1단계 assemble 출력 submission_clean_refined.csv를 여기에 넣으세요. 없으면 동봉 기준을 사용합니다.\n')
    cells=[]
    def md(text):cells.append(dict(cell_type='markdown',metadata={},source=text.splitlines(keepends=True)))
    def code(text,tag):cells.append(dict(cell_type='code',metadata={'tags':[tag]},execution_count=None,outputs=[],source=text.splitlines(keepends=True)))
    md('''# SINCON 2026 핫식스 · 고정 1.5배 후보

1단계 assemble의 `submission_clean_refined.csv`와 동봉 입력에서 사전등록한 후보 하나를 만듭니다.
`station_profiles`와 `vector_xgboost`의 실제 적용 변화에만 0.5배를 더합니다. 적용 행은 동결한 `night12 amp_eligible` 그대로입니다.
모델층 뒤 행사 보정을 재계산하고 timecapsule → plave_existing → station025 → friday → plave22 → lunar3122 순서를 유지합니다.
station025는 증폭한 과거 예측으로 최근60일·0.25배를 다시 적합합니다. 배율·층 조합·보호 마스크를 바꾸는 설정은 없습니다.

이 규칙은 같은 과거 자료를 본 뒤 찾았습니다. 8/8 개선은 독립 홀드아웃 성능 보장이 아닙니다. 정답은 공식 train의 2026-06-30까지뿐입니다.
웹·설치·다운로드·Kaggle 업로드 셀은 없습니다. NumPy와 pandas가 필요합니다. 클라우드 실행 순서는 README를 따르세요.
''')
    code('''ROOT = ""  # amp_delivery_manifest.json이 있는 패키지 폴더. 빈 값이면 제한 탐색.
BASELINE_CSV = ""  # 선택. 1단계 출력 경로, 기본 input/ 우선, 없으면 동봉 기준.
''','settings')
    code('''import os
import sys
sys.dont_write_bytecode = True
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[key] = "1"
from pathlib import Path
import importlib.util
import json

def bounded(root, depth, skip=()):
    root = Path(root)
    found = []
    if not root.is_dir():
        return found
    for directory, children, files in os.walk(root, followlinks=False):
        p = Path(directory)
        level = len(p.relative_to(root).parts)
        children[:] = sorted(n for n in children if n not in skip and level < depth and not (p / n).is_symlink())
        if "amp_delivery_manifest.json" in files:
            found.append(p)
    return found

if ROOT:
    package = Path(ROOT).expanduser().resolve()
else:
    candidates = [p for p in (Path.cwd(), Path.cwd() / "amp_delivery") if (p / "amp_delivery_manifest.json").is_file()]
    candidates += bounded("/content", 3, ("drive",)) + bounded("/kaggle/input", 4)
    candidates = list(dict.fromkeys(p.resolve() for p in candidates))
    candidates = [p for p in candidates if json.loads((p / "amp_delivery_manifest.json").read_text()).get("package_kind") == "sincon_amp15_preregistered_v1"]
    if len(candidates) != 1:
        raise ValueError("ROOT에 패키지 폴더를 지정하세요. 후보 수: " + str(len(candidates)))
    package = candidates[0]
spec = importlib.util.spec_from_file_location("sincon_amp15_runtime", package / "delivery_runtime.py")
rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
context = rt.prepare(package, BASELINE_CSV)
print(json.dumps(context["baseline_verification"], ensure_ascii=False, indent=2))
print(json.dumps(context["environment"], ensure_ascii=False, indent=2))
''','prepare')
    md('''## 1. 두 층 증폭과 행사 보정

동봉 최종 변화 파일은 1단계 패키지에서 `generate_model_inputs.py`로 다시 만들 수 있습니다. 스크립트는 원 모델의 apply 호출 전후를 기록할 뿐 모델 산식·채택 gate를 바꾸지 않습니다. 생성 파일 두 개의 SHA-256을 manifest와 비교합니다.
행사 보정은 고정한 기증 초과분·상한을 유지하고, 과학행사 바닥값은 새 예측 대조일 중앙값에서 다시 계산합니다.
''')
    code('''amplified_clean = rt.amplify_and_events(context)
print(json.dumps(context["model_amplification"], ensure_ascii=False, indent=2))
''','model_and_events')
    md('''## 2. 최종 6개 층

1. 타임캡슐 0.75배 초과분 하한
2. PLAVE 21·22시 합계 기증 전이 0.35배, log 상한0.50
3. 역별 최근60일·0.25배, 증폭 OOF로 재적합
4. 금요일0.20배, 시간별 중심화·log 절대상한0.05
5. PLAVE22 기존 지정 예매·과거 비율 대체
6. 부평삼거리 전날·당일, 새 평소 일요일 예측에서 전이
''')
    code('''candidate, layer_deltas, layer_report = rt.build_final(context)
table = []
for name in context["final"].LAYER_NAMES:
    table.append(dict(layer=name, changed_rows=layer_report["layers"][name]["changed_rows"], max_abs_log_delta=float(layer_deltas[name].abs().max())))
import pandas as pd
print(pd.DataFrame(table).to_string(index=False))
''','final_six')
    md('''## 보관 검증표

다음은 이 후보를 만들 때 측정한 과거 검증입니다. 노트북의 재현 계산에서 과거 모델을 새로 학습한 표가 아닙니다. 기존·중첩 모두 시험 가능한8개 기준일 전부 개선해야 통과합니다. 첫 기준일은 이전 OOF가 없어 최종 판정에서 제외했습니다.
최종 전용 행사 override와 PLAVE22는 과거 9개 기준일에 직접 적용 가능한 대상이 없으므로 11번의 과거 대체 평가 범위에 포함되지 않습니다.
''')
    code('''print(rt.read(package / "evidence/validation_summary.csv").to_string(index=False))
print(rt.read(package / "evidence/validation_scores.csv").to_string(index=False))
''','historical_evidence')
    md('''## 3. 저장과 검증

공식 example_id 순서, 157,194행, 유한·비음수를 검사하고 동봉 후보와 최대 log1p 차이1e-10 이내인지 확인합니다.
출력은 Kaggle `/kaggle/working`, Colab `/content`, 로컬은 현재 폴더의 `amp15_outputs`입니다. 읽기 전용 폴더에서는 실행 전 `SINCON_AMP_OUTPUT_DIR`을 쓰기 가능한 폴더로 지정할 수 있습니다.
''')
    code('''result = rt.finish(context, candidate, layer_deltas, layer_report)
print("후보 CSV:", context["output"] / "submission_amp15_main.csv")
''','finish')
    dump(PKG/'SINCON_amp15.ipynb',dict(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.11'}},nbformat=4,nbformat_minor=5))
    paths=[p for d in ['inputs','cache','reference','evidence'] for p in (PKG/d).rglob('*') if p.is_file()]
    paths.extend(PKG/name for name in ['delivery_runtime.py','final_layers.py','generate_model_inputs.py','execute_notebook.py','SINCON_amp15.ipynb','official_inputs.json','provenance.json'])
    dump(PKG/'amp_delivery_manifest.json',dict(package_kind='sincon_amp15_preregistered_v1',format=1,
        clean_sha256=sha(PKG/'reference/submission_clean_refined.csv'),
        candidate_sha256=sha(PKG/'reference/submission_amp15_main.csv'),
        files={str(p.relative_to(PKG)):sha(p) for p in sorted(paths)},official_csv_included=False))
    status('재현 패키지 입력·노트북 생성 완료. 전체 코드 셀6개, 새 Python3.11/3.12 환경 검증 예정.')

if __name__=='__main__':main()
