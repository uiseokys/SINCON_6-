"""Independently recheck labels, fixed formula, scores, fits and delivered values."""
from common import *
import argparse

KEY=['date','station_id','hour'];OK=['label','origin',*KEY]
END=pd.Timestamp('2026-06-30')

def centered(rows,origin):
    mask=(rows.origin<origin)&(rows.date<=origin)&(rows.date>origin-pd.Timedelta(days=60))
    h=rows.loc[mask]
    stat=(h.adjusted-h.y_log).groupby(h.station_id).agg(['mean','size'])
    raw=stat.loc[stat['size']>=360,'mean']
    return raw-raw.mean(),h

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--measurements',type=Path,default=OUT/'measurements')
    parser.add_argument('--output',type=Path,default=OUT/'verification')
    parser.add_argument('--candidate',type=Path,default=OUT/'submission_amp15_main.csv')
    parser.add_argument('--extraction',type=Path,default=OUT/'stage1')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    ms=args.measurements
    train=read(DATA/'train.csv',parse_dates=['date'])
    grid=read(DATA/'test.csv',parse_dates=['date'])
    truth=np.log1p(train.set_index(KEY).boardings)
    scores=read(ms/'validation_scores.csv')
    checks=[];temporal=[]
    for path in ['old','nested']:
        d=read(ROOT/f'night12/measurements_final/layer_oof_{path}.csv.gz',parse_dates=['date','origin'])
        y=truth.reindex(pd.MultiIndex.from_frame(d[KEY])).to_numpy()
        assert np.array_equal(y,d.y_log.to_numpy())
        signal=.5*(d.station_profiles.to_numpy()+d.vector_xgboost.to_numpy())
        signal[~d.amp_eligible.to_numpy()]=0.
        main=read(ms/f'downstream_oof_{path}_main.csv.gz',parse_dates=['date','origin'])
        amp=read(ms/f'downstream_oof_{path}_amp15.csv.gz',parse_dates=['date','origin'])
        assert d[OK].equals(main[OK]) and d[OK].equals(amp[OK])
        assert np.array_equal(d.baseline.to_numpy(),main.baseline.to_numpy())
        assert np.array_equal(d.baseline.to_numpy()+signal,amp.baseline.to_numpy())
        max_error=0.;fit_error=0.
        for origin,p in d.groupby('origin',sort=True):
            ix=p.index
            for stage,col in [('model','baseline'),('final6','lunar3122')]:
                a=float(np.linalg.norm(main.loc[ix,col].to_numpy()-y[ix])/np.sqrt(len(ix)))
                c=float(np.linalg.norm(amp.loc[ix,col].to_numpy()-y[ix])/np.sqrt(len(ix)))
                logged=scores.loc[scores.path.eq(path)&scores.origin.eq(str(origin.date()))&scores.stage.eq(stage)].iloc[0]
                max_error=max(max_error,abs(a-logged.main_rmsle),abs(c-logged.amp15_rmsle),abs(c-a-logged.delta))
                assert bool(logged.improved)==bool(c<a)
            for variant,rows in [('main',main),('amp15',amp)]:
                b,h=centered(rows,origin)
                expected=np.maximum(rows.loc[ix,'adjusted'].to_numpy()-.25*p.station_id.map(b).fillna(0.).to_numpy(),0.)
                fit_error=max(fit_error,float(abs(expected-rows.loc[ix,'station025']).max()))
                poisoned=rows.copy()
                # Unavailable labels and forecasts cannot enter the station refit.
                future=poisoned.date.gt(origin)|poisoned.origin.ge(origin)
                poisoned.loc[future,'y_log']+=1000.
                poisoned.loc[future,'adjusted']-=777.
                other,ph=centered(poisoned,origin)
                assert b.equals(other) and h[OK].equals(ph[OK])
                temporal.append(dict(path=path,variant=variant,origin=str(origin.date()),prior_rows=len(h),
                    future_label_and_prediction_poison_unchanged=True,
                    latest_date=str(h.date.max().date()) if len(h) else None,
                    latest_origin=str(h.origin.max().date()) if len(h) else None))
        assert max_error<1e-12 and fit_error<1e-12
        b,h=centered(amp,END)
        finalfit=read(ms/f'station_final_{path}.csv').set_index('station_id')
        assert abs(finalfit.amp15_log_correction+.25*b.reindex(finalfit.index)).max()<1e-12
        checks.append(dict(path=path,rows=len(d),origins=d.origin.nunique(),
            official_labels_exact=True,formula_exact=True,protected_addition_nonzero_rows=int(np.count_nonzero(signal[~d.amp_eligible])),
            max_score_recheck_error=max_error,max_station_refit_recheck_error=fit_error))
    cand=read(args.candidate);main=read(ROOT/'final_delivery_v2/reference/submission_night_v4_main.csv')
    assert len(cand)==157194 and list(cand)==['example_id','boardings']
    assert cand.example_id.equals(grid.example_id) and cand.example_id.is_unique
    assert np.isfinite(cand.boardings).all() and cand.boardings.ge(0).all()
    clean=read(ms/'clean_amp15.csv')
    layers=read(ms/'final_layer_deltas_amp15.csv.gz')
    names=['timecapsule','plave_existing','station025','friday','plave22','lunar3122']
    closed=np.log1p(clean.boardings).to_numpy()+layers[names].sum(axis=1).to_numpy()
    closure=float(abs(closed-np.log1p(cand.boardings)).max())
    assert closure<1e-12
    trace=read(args.extraction/'final_model_layer_changes.csv.gz',parse_dates=['date'])
    amp_model=read(ms/'model_amp15.csv')
    expected=trace.baseline+.5*(trace.station_profiles+trace.vector_xgboost)*trace.amp_eligible
    formula_error=float(abs(np.log1p(amp_model.boardings)-expected).max())
    assert formula_error<1e-12
    assert np.array_equal(np.log1p(amp_model.loc[~trace.amp_eligible,'boardings']),trace.loc[~trace.amp_eligible,'baseline'])
    protected=read(ms/'protected_rows_diagnostic.csv.gz',parse_dates=['date'])
    groups=[]
    for name,p in protected.groupby('group'):
        groups.append(dict(group=name,rows=len(p),amplified_model_rows=int(np.count_nonzero(abs(p.model_addition)>1e-12)),
            final_changed_rows=int(np.count_nonzero(abs(p.final_log_difference)>1e-12)),
            max_abs_final_log_difference=float(abs(p.final_log_difference).max())))
    plave22=grid.station_id.eq(3127)&grid.hour.eq(22)&grid.date.isin(pd.to_datetime(['2026-09-12','2026-09-13']))
    assert np.array_equal(cand.loc[plave22,'boardings'],main.loc[plave22,'boardings'])
    layerreport=json.loads((ms/'final_layers_amp15.json').read_text())
    assert layerreport['enabled']==names
    assert layerreport['layers']['station025']['evidence']['window_days']==60
    assert layerreport['layers']['station025']['evidence']['weight']==.25
    friday=layers.friday.to_numpy(); assert abs(friday).max()<=.05+1e-12
    for date,p in layers.loc[abs(friday)>1e-12].groupby('date'):
        assert p.groupby('hour').friday.sum().abs().max()<1e-12
    artifacts={}
    for manifest_path in [OUT/'stage1/read_manifest.json',ms/'read_manifest.json']:
        for name,before in json.loads(manifest_path.read_text()).items():
            after=sha(ROOT/name);assert before==after
            artifacts[name]=dict(sha256=before,unchanged=True)
    dump(out/'source_integrity.json',artifacts)
    dump(out/'station_future_poison.json',temporal)
    csv(pd.DataFrame(groups),out/'protected_summary.csv')
    result=json.loads((ms/'result.json').read_text())
    final=scores.loc[scores.stage.eq('final6')&scores.testable]
    assert result['passed']==bool(final.improved.all()) and len(final)==16
    report=dict(success=True,created_kst=now(),candidate_sha256=sha(args.candidate),
        candidate_rows=len(cand),official_order=True,finite_nonnegative=True,
        final_layer_closure_max_error=closure,final_fixed_formula_max_error=formula_error,
        plave22_exactly_retained=True,source_files_unchanged=len(artifacts),
        paths=checks,protected_groups=groups,station_future_poison_checks=len(temporal),
        verdict=result['verdict'],historical_final_layer_method='round11 chronological analogues',
        environment=dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__))
    dump(out/'verification.json',report)
    status('독립 검산 완료: '+json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
