"""Run all notebook cells in new 3.11/3.12 envs against a read-only relocated package."""
from common import *
import argparse
import shutil
import subprocess

def readonly(folder):
    for p in folder.rglob('*'):
        if p.is_file():p.chmod(0o444)
    for p in sorted([x for x in folder.rglob('*') if x.is_dir()],key=lambda x:len(x.parts),reverse=True):p.chmod(0o555)
    folder.chmod(0o555)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=OUT/'delivery_validation')
    args=parser.parse_args();output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    package=output/'readonly_package/amp_delivery'
    shutil.copytree(ROOT/'amp_delivery',package)
    for name in ['train.csv','test.csv','metaData.csv']:shutil.copyfile(DATA/name,package/'data'/name)
    frame=read(package/'reference/submission_clean_refined.csv')
    frame.to_csv(package/'input/submission_numeric_equiv.csv',index=False,float_format='%.18e',mode='x')
    assert sha(package/'input/submission_numeric_equiv.csv')!=sha(package/'reference/submission_clean_refined.csv')
    assert np.array_equal(read(package/'input/submission_numeric_equiv.csv').boardings,frame.boardings)
    readonly(package)
    records=[]
    for label in ['py311','py312']:
        python=OUT/'offline_envs_verified'/label/'bin/python'
        for case in ['reference','numeric_equivalence']:
            target=output/(label+'_'+case)
            command=[str(python),'-B',str(package/'execute_notebook.py'),str(package),'--output',str(target)]
            if case=='numeric_equivalence':command+=['--explicit-root','--baseline','input/submission_numeric_equiv.csv']
            with (output/(label+'_'+case+'.log')).open('x') as f:
                subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
            report=json.loads((target/'execution.json').read_text())
            assert report['success'] and report['all_code_cells_executed'] and report['package_readonly_permissions']
            assert report['result']['max_abs_log1p_difference']<=1e-10
            assert report['result']['baseline_verification']['acceptance']==('sha256_exact' if case=='reference' else 'numeric_equivalence')
            records.append(dict(environment=label,case=case,**report))
            status(label+' '+case+' 모든 노트북 셀 실행 통과. max log1p='+str(report['result']['max_abs_log1p_difference']))
    dump(output/'matrix.json',dict(success=True,runs=records))

if __name__=='__main__':main()
