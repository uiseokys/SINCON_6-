"""Measured summaries, version differences, and final artifact checks."""
from reproduce_nested import *

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HOME_OUT/'checks')
    args=parser.parse_args();out=args.output.resolve()
    assert out.is_relative_to(HOME_OUT)
    out.mkdir(exist_ok=False)
    event=HOME_OUT/'event_measurements'
    ratios=final.read_csv(event/'kbo_36_ratios.csv',parse_dates=['date'])
    games=final.read_csv(ROOT/'sincon_kbo_game_data.csv',parse_dates=['date'])
    games=games.loc[games.date.between('2026-03-28',END)&games.attendance.gt(0)]
    timed=ratios.merge(games[['date','start_kst','end_kst']],on='date',validate='one_to_one')
    timed['evening_start']=timed.start_kst.str[:2].astype(int).ge(17)
    csv(timed,out/'kbo_36_timing.csv')
    subset=timed.loc[timed.soldout&timed.evening_start]
    q=subset.excess_ratio_20_22.quantile([.25,.5,.75])
    dump(out/'soldout_evening_diagnostic.json',dict(games=len(subset),definition='pre-cutoff soldout games starting at or after 17:00',
        dates=subset.date.dt.strftime('%Y-%m-%d').tolist(),ratio20_22_quantiles={str(k):float(v) for k,v in q.items()},
        excess_scaled_to_23000={str(k):float(v*23000) for k,v in q.items()},
        total_with_target_ordinary234={str(k):float(v*23000+234) for k,v in q.items()},
        limitation='Diagnostic only; no weight or candidate selected from this subset'))
    review=final.read_csv(HOME_OUT/'hedges_17_current_review.csv')
    old=final.read_csv(ROOT/'night7/event_validation_v2/hedges_17_judgments.csv')
    x=review.merge(old[['example_id','hedged','full','share','weight']],on='example_id',suffixes=('','_round7'),validate='one_to_one')
    changed=x.loc[abs(x.current_hedged-x.hedged)>1e-9]
    assert len(changed)==7
    csv(changed[['example_id','event','date','hour','hedged','current_hedged','FULL','share','W','judgment']],out/'seven_changed_rows.csv')
    # Numerical reason for the tiny final station sensitivity.
    old_oof=final.read_csv(HOME_OUT/'measurements/model_oof_old.csv.gz',parse_dates=['date','origin'])
    new_oof=final.read_csv(HOME_OUT/'measurements/model_oof_nested.csv.gz',parse_dates=['date','origin']).set_index(OK)
    old_oof['difference']=new_oof.baseline.reindex(pd.MultiIndex.from_frame(old_oof[OK])).to_numpy()-old_oof.baseline.to_numpy()
    fit=old_oof.loc[old_oof.date.between('2026-05-02',END)]
    by=fit.groupby('station_id').difference.agg(['mean','min','max']).reset_index()
    csv(by,out/'fit_window_model_log_differences_by_station.csv')
    csv(fit.groupby(['label','origin','station_id']).difference.agg(['mean','min','max']).reset_index(),
        out/'fit_window_model_log_differences_by_vintage.csv')
    truth=final.read_csv(TEAM/'data/train.csv',parse_dates=['date'])
    reference=final.read_csv(ROOT/'night7/cache/final_stage_oof.csv.gz',parse_dates=['date','origin'])
    initial=[]
    for name,p in m.groups_for_scores(reference).items():
        initial.append(dict(label=name,rows=len(p),initial_rmsle=m.rmsle(p.y_log,p.initial)))
    csv(pd.DataFrame(initial),out/'model_initial_scores.csv')
    # The old downstream path must reproduce the already reviewed ROUND3 path too.
    d=final.read_csv(HOME_OUT/'measurements/downstream_oof_old.csv.gz',parse_dates=['date','origin'])
    archived=final.read_csv(ROOT/'night3/validation/oof_layers.csv.gz',parse_dates=['date','origin']).set_index(OK)
    ix=pd.MultiIndex.from_frame(d[OK])
    diffs={target:float(abs(d[source].to_numpy()-archived[target].reindex(ix).to_numpy()).max())
           for source,target in [('station025','round2'),('friday','friday')]}
    assert max(diffs.values())<1e-12
    test=final.read_csv(TEAM/'data/test.csv')
    main=final.read_csv(TEAM/'submission_night_v4_main.csv')
    hedge=final.read_csv(TEAM/'submission_night_v4_events_hedged.csv')
    alt=final.read_csv(HOME_OUT/'submission_events_hedged15.csv')
    second=final.read_csv(HOME_OUT/'event_reproduction/submission_events_hedged15.csv')
    assert len(alt)==157194 and alt.example_id.equals(test.example_id) and alt.example_id.is_unique
    assert np.isfinite(alt.boardings).all() and alt.boardings.ge(0).all()
    assert np.array_equal(alt.boardings,second.boardings)
    changed=abs(alt.boardings-main.boardings)>1e-9
    restored=~np.isclose(alt.boardings,hedge.boardings,atol=1e-9,rtol=0)
    assert changed.sum()==15 and restored.sum()==2
    assert set(alt.loc[restored,'example_id'])=={'J093670','J094948'}
    assert np.array_equal(alt.loc[restored,'boardings'],main.loc[restored,'boardings'])
    assert np.array_equal(alt.loc[~restored,'boardings'],hedge.loc[~restored,'boardings'])
    # All compared raw and primary inputs remained byte-identical.
    nested_inputs=json.loads((HOME_OUT/'measurements/inputs.json').read_text())
    event_inputs=json.loads((event/'inputs.json').read_text())
    all_inputs={**nested_inputs,**event_inputs}
    integrity={p:sha(p)==value for p,value in all_inputs.items()}
    assert all(integrity.values())
    dump(out/'verification.json',dict(original_downstream_max_log_differences=diffs,candidate_rows=len(alt),
        candidate_changed_rows=int(changed.sum()),restored_plave22_rows=int(restored.sum()),
        exact_id_order=True,unique_ids=True,finite=True,nonnegative=True,
        candidate_sha256=sha(HOME_OUT/'submission_events_hedged15.csv'),
        candidate_reproduction_sha256=sha(HOME_OUT/'event_reproduction/submission_events_hedged15.csv'),
        reproducible_bytes=sha(HOME_OUT/'submission_events_hedged15.csv')==sha(HOME_OUT/'event_reproduction/submission_events_hedged15.csv'),
        all_primary_inputs_unchanged=all(integrity.values()),input_integrity=integrity,
        no_nested_station_candidate=True,post_cutoff_subway_observations_used=False))
    from threadpoolctl import threadpool_info
    dump(out/'threadpools.json',threadpool_info())
    dump(out/'environment.json',dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,
        thread_env={name:os.environ[name] for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')}))
    status('최종 파일 검산 완료. 15행 후보 157194행·ID 순서·유일성·유한·비음수 통과, 재실행 바이트 해시 일치. 원본 입력 해시 유지. 기존 ROUND3 downstream도 차이 0 재현.')

if __name__=='__main__':main()
