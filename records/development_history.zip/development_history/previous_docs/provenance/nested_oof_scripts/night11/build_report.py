"""Generate the review document from measured artifacts, without manual numeric transcription."""
from reproduce_nested import *

def table(d, columns=None, digits=9):
    d=d if columns is None else d[columns]
    def cell(v):
        if isinstance(v,(float,np.floating)):
            return '' if pd.isna(v) else f'{v:.{digits}f}'
        return str(v).replace('|',' / ').replace('\n',' ')
    return '| '+' | '.join(d.columns)+' |\n| '+' | '.join(['---']*len(d.columns))+' |\n'+'\n'.join(
        '| '+' | '.join(cell(v) for v in row)+' |' for row in d.itertuples(index=False,name=None))

def readjson(p):return json.loads(Path(p).read_text())

def paired(folder,prefix,keys):
    a=final.read_csv(folder/(prefix+'_old.csv'))
    b=final.read_csv(folder/(prefix+'_nested.csv'))
    return a.merge(b,on=keys,suffixes=('_old','_nested'),validate='one_to_one')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HOME_OUT/'ROUND11_RESULT.md')
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    measured=HOME_OUT/'measurements';events=HOME_OUT/'event_measurements'
    scores=final.read_csv(measured/'model_scores.csv').pivot(index='label',columns='path',values='rmsle').reset_index()
    initial=final.read_csv(HOME_OUT/'checks/model_initial_scores.csv')
    scores=scores.merge(initial[['label','initial_rmsle']],on='label',validate='one_to_one')
    scores['nested_minus_old']=scores.nested-scores.old
    order=['A','B','C','summer','2025-07-31','2025-08-31','2025-09-30','2026-03-31','2026-04-30',
           'disjoint_A_C','disjoint_warm','summer_established_68']
    scores=scores.set_index('label').loc[order].reset_index()
    station=paired(measured,'station_validation',['origin','label'])
    friday_full=paired(measured,'friday_validation',['origin','label'])
    friday_exposed=paired(measured,'friday_exposed',['origin','date'])
    lunar_full=paired(measured,'lunar_validation',['origin','label'])
    lunar_exposed=paired(measured,'lunar_exposed',['origin','date','rel'])
    sensitivity=readjson(measured/'station_sensitivity.json')
    fit=final.read_csv(measured/'station_final_71.csv')
    gates=final.read_csv(measured/'adoption_gates.csv')
    gate_table=gates.loc[gates.path.eq('nested')].pivot(index='origin',columns='layer',values='choice').reset_index()
    weights=readjson(measured/'original_tabicl.json')
    gate_table['TabICL_weight_if_adopted']=gate_table.tabicl.map({'baseline':'0','fixed':'0.10','guarded':'0.30'})
    review=final.read_csv(HOME_OUT/'hedges_17_current_review.csv')
    event_summary=readjson(events/'summary.json')
    scale=final.read_csv(events/'kbo_scale_comparison.csv')
    ratios=final.read_csv(events/'kbo_36_ratios.csv')
    evening=readjson(HOME_OUT/'checks/soldout_evening_diagnostic.json')
    prev=final.read_csv(events/'landers_2025_oof_by_origin.csv')
    totals=prev.groupby(['path','origin']).agg(predicted=('after_station_friday','sum'),actual=('actual','sum')).reset_index()
    totals['ratio']=totals.predicted/totals.actual
    wide=prev.loc[prev.path.eq('old')].pivot(index='origin',columns='hour',values='after_station_friday').reset_index()
    wide.columns=['origin','pred20','pred21','pred22']
    wide=wide.merge(totals.loc[totals.path.eq('old'),['origin','predicted','actual','ratio']],on='origin')
    verify=readjson(HOME_OUT/'checks/verification.json')
    poison=readjson(HOME_OUT/'temporal_verification/full_chain_future_poison.json')
    assert len(poison)==9 and all(x['max_abs_model_oof_difference']==0 for x in poison)
    env=readjson(HOME_OUT/'checks/environment.json')
    rows=['# 11번 작업 결과', '',
    '작성 시각 '+datetime.now(timezone(timedelta(hours=9))).isoformat()+'. Claude 검토용. 04:30 KST 마감 전에 완료했다.', '',
    '## 결론', '',
    '- **(a) 주후보의 역별 층은 그대로 둬도 된다.** 중첩 OOF로 재적합해도 최대 log 보정 차이는 '+f"{sensitivity['max_abs_log_correction_difference']:.12g}"+
      ', 최종 count 차이는 최대 '+f"{sensitivity['max_abs_final_count_difference']:.9f}"+'명이다. 기존·중첩 모두 8개 유효 기준일 중 7개 개선했고 B는 악화했다.',
    '- **(b) 기존 개선폭의 독립성 표현은 고쳐야 한다.** 기존 OOF는 최종 채택 구성을 과거에 소급한 사후 재계산이다. 아래 중첩 수치를 순방향 정책의 검증값으로 적고, 기존 수치는 최종 구성의 조건부 재계산으로만 남긴다. 새로운 독립 홀드아웃을 확보한 것은 아니다.',
    '- **(c) `submission_nested_station.csv`는 만들지 않았다.** 71역 보정의 상관은 '+f"{sensitivity['correlation']:.12f}"+
      ', 평균 절대 log 보정 차이는 '+f"{sensitivity['mean_abs_log_correction_difference']:.12g}"+'다. 진단은 메모리에서 동일한 최종 순서로 실행했고, CSV에는 예측값 대신 행별 차이만 저장했다.',
    '- 현재 17행은 지지 2행, 근거 부족 13행, 과함 2행이다. 지지 2행은 랜더스 21·22시의 상향 방향·규모에 한정한다. W가 검증됐다는 판정은 아니다. PLAVE 22시 두 행을 주후보로 되돌린 `submission_events_hedged15.csv`는 17행 버전보다 방어하기 쉬운 비교 후보로 만들었다. 주후보 교체를 승인하는 문서는 아니다.', '',
    '## 범위와 시간 경계', '',
    '모든 새 산출물은 `night11/`에만 썼다. 기존 프로젝트·팀 파일은 수정·삭제하지 않았다. Python audit hook으로 night11 밖 쓰기와 소켓 연결을 차단했다. Public 점수로 값이나 판정을 정하지 않았고, 새 웹 조회·다운로드와 Kaggle 업로드를 하지 않았다. 다른 작업과 신경망 재학습 프로세스도 건드리지 않았다.', '',
    '정답은 공식 train의 688,176행, 2025-01-01~2026-06-30뿐이다. 2026년 7월 이후 지하철 실측을 찾거나 사용하지 않았다. 기존 파일의 미래 행사 일정·관객 대용치와 예측값은 지하철 실측과 구분했다. 원시 모델은 재학습하지 않았다.', '',
    '기준일 T는 그날까지의 관측을 마친 예측 cutoff로 해석한다. 채택 점수·잔차 적합에는 `date <= T` 및 `origin < T`인 정답만 쓴다. 이전 예측의 전체 평가기간이 끝날 때까지 기다리지는 않고, T까지 관측된 부분만 비교한다. 비교군의 다른 행이나 미래 origin의 예측은 채택 점수에 넣지 않는다.', '',
    'TabICL의 A+C·여름68역·warm, 동춘의 A+C·warm이라는 필수 비교군과 원래의 엄격한 개선 부등식을 유지했다. 벡터는 원래 코드처럼 그 시점에 존재하는 pooled 비교군 모두의 개선을 요구한다. 필수 비교군이 없으면 미채택한다. 초기 TabICL 내부 fallback 0.20은 채택을 보장하지 않으며, 초기 예측에는 적용하지 않았다. 고정 0.10·최대 0.30, 역별 60일·0.25배, 기타 계수를 새로 탐색하지 않았다.', '',
    '## F1 중첩 OOF', '',
    '기존 OOF 1,283,112행은 보관된 9개 origin 원시 예측으로 재조립했으며, night7 캐시와 최대 log 차이가 0이었다. 기존 ROUND3의 station025·friday 경로도 차이 0으로 재현했다. 최종 주후보 재현 차이는 log 8.88e-16이었다. 파일은 `measurements/old_oof_reproduction.json`, `checks/verification.json`, `measurements/final_main_reproduction.json`이다.', '',
    '각 cutoff 이후의 공식 관측 log와 OOF 정답에 1000을 더하고 미래 origin을 제거해 실제 중첩 모델층을 다시 실행했다. 역 프로필·TabICL 적합과 채택·동춘 적합과 채택·명절·아침·벡터 채택을 거친 해당 cutoff 예측은 9개 모두 차이 0이었다. 원시 모델의 재학습 반사실 검사는 아니다. `temporal_verification/full_chain_future_poison.json` 참조.', '',
    '### 기준일별 채택', '', table(gate_table,digits=2), '',
    '2026-06-30 최종 적합에서는 모든 검증 정답이 이미 관측됐으므로 기존 최종 채택 판단을 쓰는 것이 정당하다. 기존 최종 TabICL은 guarded, 적합 가중치 '+str(weights['weight'])+'이며 동춘과 벡터도 채택 상태다. 이번 대안 비교는 이 최종 구성과 나머지 5개 최종 층을 유지한 채 station025의 입력만 바꿨다.', '',
    '최종 진단 순서는 `timecapsule → plave_existing → station025 → friday → plave22 → lunar3122`다. 나머지 5개 층은 원 함수를 그대로 실행했다.', '',
    '### 1단계 모델층 결합 후 RMSLE', '',
    '`initial_rmsle`는 모델층 적용 전 보관 OOF다. old·nested는 모델층 결합 후 값이다. `nested_minus_old`는 중첩 때문에 달라진 오차이며 층의 개선폭과는 다르다. 여름 전체에는 신설역 3개가 들어 있으므로 여름68역도 함께 적었다.', '',
    table(scores,['label','initial_rmsle','old','nested','nested_minus_old']), '',
    '### 역별 60일·0.25배 층', '',
    '동일한 타임캡슐·기존 PLAVE 행사층을 먼저 반영한 잔차로 적합했다. Δ는 candidate−reference이며 음수가 개선이다. earliest summer는 이전 OOF가 없어 보정하지 않는다.', '',
    table(station,['origin','label','reference_old','candidate_old','delta_old','reference_nested','candidate_nested','delta_nested']), '',
    '기존·중첩 모두 유효 8개 origin에서 개선 7개·악화 1개다. 중복되는 평가기간이 있으므로 8개의 독립 시행이라고 쓰지 않는다. B의 악화를 유지한 채 고정 규칙을 평가했으며 값은 재조정하지 않았다.', '',
    '### 금요일 공휴일 층', '',
    '전체 origin 평가기간의 Δ는 다음과 같다. 발동 5개 origin은 고유 공휴일 2025-08-15·2026-05-01 두 날을 반복 평가한 것이다.', '',
    table(friday_full,['origin','label','changed_rows_old','delta_old','delta_nested']), '',
    '실제 변경된 1,008행 부분집합의 Δ도 모두 개선이다.', '',
    table(friday_exposed,['origin','date','delta_old','delta_nested']), '',
    '### 부평삼거리 전날·당일 층', '',
    '기증일과 주변 평소 일요일 실측을 cutoff로 자르는 ROUND7 수정 규칙이다. station025·friday 뒤에 적용했다. 발동 6개 origin 모두 전체 점수가 개선했다.', '',
    table(lunar_full,['origin','label','changed_rows_old','delta_old','delta_nested']), '',
    '각 명절 날짜의 18시간 Δ도 다음과 같다. 고유 명절은 2025 추석·2026 설 두 회차다. 216 OOF행은 고유 72개 station-date-hour의 반복이며, 독립 여섯 명절 검증이 아니다.', '',
    table(lunar_exposed,['origin','date','rel','delta_old','delta_nested']), '',
    '이 downstream 검증은 기존 ROUND3·ROUND7과 같은 순서다. 별도로 채택된 PLAVE22 최종 override를 OOF 전체에 새로 적용한 점수는 아니다.', '',
    '## 최종 역별 적합의 민감도', '',
    '최종 적합 구간은 2026-05-02~06-30이다. 230,040개 예측 잔차, 고유 실측 키 76,680개를 사용하며, A·3월말·4월말 origin 세 예측을 그대로 포함한다. 최신 origin은 2026-04-30이다. 중복을 제거하는 새 규칙은 도입하지 않았다.', '',
    '| 항목 | 측정값 |\n| --- | --- |\n'+
    f"| 71역 centered error b 최대 절대 차이 | {4*sensitivity['max_abs_log_correction_difference']:.12g} |\n"+
    f"| 최종 log 보정 −0.25b 최대 절대 차이 | {sensitivity['max_abs_log_correction_difference']:.12g} |\n"+
    f"| 최종 log 보정 평균 절대 차이 | {sensitivity['mean_abs_log_correction_difference']:.12g} |\n"+
    f"| 71역 보정 Pearson 상관 | {sensitivity['correlation']:.12f} |\n"+
    f"| 동일 순서 최종 예측 최대 count 차이 | {sensitivity['max_abs_final_count_difference']:.9f} |\n"+
    f"| 최종 예측 총합 차이 | {sensitivity['count_sum_difference']:.9f} |\n"+
    f"| log 차이 1e-12 초과 최종 행 수 | {sensitivity['changed_rows']} |", '',
    '71역의 기존 b·새 b·기존 log 보정·새 log 보정·차이는 `measurements/station_final_71.csv`다. 최대 차이 역은 동춘3131이다.', '',
    table(fit.loc[fit.station_id.eq(3131)],['station_id','old_centered_error','nested_centered_error','old_log_correction','nested_log_correction','difference'],12), '',
    '적합 구간에서 old−nested의 역별 평균 차이를 직접 계산하면 동춘 이외 역은 수치 오차 수준이다. 나머지 역의 최종 보정이 조금 달라지는 이유는 역 평균을 빼는 중심화다. TabICL은 역·월·요일 log 평균을, 벡터는 일별 시간 합을 보존하므로 이런 작은 차이는 구조와도 맞는다. 이것은 측정된 평균과 구현 구조에 근거한 설명이다. `checks/fit_window_model_log_differences_by_station.csv` 참조.', '',
    '### 최종 적합에 어떤 OOF가 맞는가', '',
    '독립 검증에는 중첩 OOF가 맞다. 과거 시점의 채택 결정을 재현한다는 주장에 기존 OOF를 쓰면 안 된다. 중첩 결과로 검증 표를 고치고 기존 사후 수치는 별도로 표시해야 한다.', '',
    '최종 잔차 보정의 학습에는 최종 구성과 같은 구성의 cross-fit OOF를 쓰는 선택도 타당하다. June30 시점에 채택한 모델의 잔차를 보정하려는 목적이기 때문이다. 중첩 OOF는 초기의 미채택·약한 모델까지 섞은 과거 운영 정책의 잔차라서 최종 구성의 잔차와 다른 대상을 추정한다. 다만 최종 구성 선택에도 같은 정답이 쓰였으므로 기존 OOF의 보정 성능을 독립 검증이라고 부를 수는 없다.', '',
    '두 경우의 수치를 실제로 비교했고 차이가 작다. 따라서 최종 적합에는 기존 구성을 유지하고, 성능 설명은 중첩 표로 교정하는 판단을 권한다. 이번 결과만으로 엄격한 새 홀드아웃에서의 이득이나 시험기간 이득을 보장하지 않는다.', '',
    '### 문서에 넣을 교정 문구', '',
    '> 보관 원시 예측에서 기준일마다 그 시점까지의 정답만으로 층 채택을 다시 정한 순방향 OOF를 만들었다. 최근 60일·0.25배 역별 층은 유효 8개 기준일 중 7개 개선했고 B는 악화했다. 금요일 층은 발동 5개 기준일에서, 부평삼거리 층은 발동 6개 기준일에서 개선했다. 기준일별 평가기간이 겹치며 금요일은 두 날짜, 명절은 두 회차다. 기존 OOF는 최종 채택 구성을 소급한 조건부 재계산으로 구분한다. 최종 역별 보정은 두 적합법의 최대 log 차이가 0.000067407이어서 기존값을 유지했다.', '',
    '## F2 현재 17행', '',
    '검토한 현재 파일의 고정 해시는 아래와 같다.', '',
    '- 주후보 SHA-256 `'+sha(TEAM/'submission_night_v4_main.csv')+'`',
    '- 현재 17행 SHA-256 `'+sha(TEAM/'submission_night_v4_events_hedged.csv')+'`',
    '- 현재 코드 SHA-256 `'+sha(TEAM/'event_hedges.py')+'`', '',
    '현재 코드에서 계수와 FULL을 읽어 모든 변경행을 다시 계산했다. 최대 산술 오차는 0이다. ROUND7 표와 달라진 7행은 `checks/seven_changed_rows.csv`에 있다. 아래 Landers share는 FULL 합계 중의 비율이다. 코드 입력은 비율이 아니라 2199·4102·860이라는 시간별 count다.', '',
    table(review,['example_id','event','date','hour','current_main','current_hedged','FULL','share','W','judgment'],6), '',
    '행별 지지 근거·한계·산술 오차는 `hedges_17_current_review.csv`에 있다. 지지의 범위는 방향과 과거 규모이며 수치 전체가 시간 순서 검증을 통과했다는 뜻이 아니다.', '',
    '### PLAVE 22시는 주후보로 되돌리는 편이 낫다', '',
    '기존 주후보는 네 공연 계열의 22시 비율에서 계산한 '+f"{event_summary['accepted_plave22_rate']:.15g}"+' × 예매 + 평소다. 현재 17행은 FULL에서 0.30×0.85=0.255를 쓰고 W=0.7로 다시 올린다. 주후보 4026.501352·3391.881330을 5271.451973·4441.795568로 올릴 추가 검증은 없다.', '',
    '박효신 3일의 평균 초과 승차 비중은 21·22·23시 각각 '+', '.join(f'{100*v:.4f}%' for v in event_summary['park_mean_shares'].values())+
    '였다. 현재 10%·85%·5%가 옛 3%·85%·12%보다 이 모양에 가깝다는 근거는 있다. 그러나 같은 가수나 같은 종료 시각의 독립 수령 검증은 아니다. PLAVE 21·23시 네 행은 근거 부족, 22시 두 행은 이미 검증한 계수에 비해 과함으로 판정했다. PLAVE 예매 23120·19494의 원출처·정의는 이번에도 확인하지 못했다.', '',
    'Sustainable 8행은 관객 12000, 시간 비중 10·20·45·25%, W=0.5를 지지할 동종 과거 검증이 없어 근거 부족이다. 새 숫자로 교체하지 않았다.', '',
    '### 랜더스 전년 OOF는 실제를 크게 낮게 예측했다', '',
    '2025-10-24의 20·21·22시 실제는 391·5279·1140명, 합계 6810명이다. 기존 pipeline의 station025·friday 뒤 OOF는 아래와 같다. 중첩 경로도 거의 같으며 24개 행의 정확한 값과 비율은 `event_measurements/landers_2025_oof_by_origin.csv`에 있다.', '',
    table(wide,digits=6), '',
    '21시 OOF는 실제의 약 0.96~1.16%, 22시는 약 1.37~1.64%였다. 한 번의 행사 날짜를 네 origin으로 반복 예측한 결과다. 네 독립 같은 시리즈 행사 검증은 아니다. 과거 이 날짜를 크게 놓쳤다는 사실과 2026-10-17의 특정 시간별 값이 정확하다는 주장은 구분한다.', '',
    '올해 주후보의 20~22시 합계는 '+f"{event_summary['landers_main20_22']:.6f}"+'명, 현재 절충은 '+f"{event_summary['landers_hedged20_22']:.6f}"+
    '명, 현재 FULL은 '+f"{event_summary['landers_current_FULL20_22']:.0f}"+'명이다. FULL은 ROUND7 같은 시리즈 진단 2199.439394·4101.939394·859.803030을 반올림한 기존값이다. 전년 약22000 관객을 올해23000석으로 옮기고 종료 시차 -20분을 가정한다. 새로 튜닝하지 않았다.', '',
    '20시 증가는 21시 피크를 앞당기는 보간에 크게 의존해 근거 부족으로 남긴다. 21·22시 상향 방향과 총량에는 같은 시리즈 관측 지지가 있다. 다만 경기 종료가 지하철 귀가 시작과 같다는 증거와 W=0.5의 독립 검증은 없다.', '',
    '### 36경기와 매진 11경기의 총량 점검', '',
    '기존 36경기는 2026-03-28~06-30의 관중이 있는 36경기 전체다. 이 중 23000명 매진은 11경기다. 따라서 "매진 36경기"라고 적으면 틀린다. 평소는 이전120일·같은 요일·경기와 알려진 공연 제외의 시간별 중앙값이다. 하루 초과 승차는 실제 하루 합계−평소 하루 합계다.', '',
    table(scale.loc[scale.span.isin(['day','20_22'])],['group','games','span','quantile','excess_ratio','excess_scaled_to_23000','total_with_target_ordinary_20_22'],6), '',
    'day 비율은 하루 초과분이므로 그 총량을 20~22시에 전부 귀가한다고 볼 수 없다. 표의 20_22는 같은 세 시간의 초과분이다. target ordinary234는 기존 토요일 평소 150+63+21이며, 새로운 적합값이 아니다.', '',
    '매진11경기 중 6경기는 14시 시작이고 기록된 종료는 16:54~18:22다. 이 경기들의 낮은 20~22시 초과 승차는 빠른 종료와 맞는다. 매진 전체의 20~22시 중앙값을 저녁 행사에 그대로 옮기면 안 된다. 17시 이후 시작한 매진5경기의 세 시간 초과 비율 Q25·Q50·Q75는 '+
    ', '.join(f'{v:.6f}' for v in evening['ratio20_22_quantiles'].values())+'이고, 23000명에 기존 평소234를 더한 점검 범위는 '+
    ', '.join(f'{v:.0f}' for v in evening['total_with_target_ordinary234'].values())+'명이다. 시간대 분류는 진단일 뿐 계수 선택에 쓰지 않았다. `checks/kbo_36_timing.csv` 참조.', '',
    '주후보2244명은 전년 같은 시리즈 실제6810명과 저녁 매진경기 총량 점검보다 낮다. 이는 잔여 과소 위험을 지지하지만, 어느 시간에 얼마나 올릴지나 0.5가 최적이라는 증거는 아니다. 기존0.72 log 혼합의 큰 축소는 ROUND7에서 확인됐으며 이번에도 새 가중치를 고르지 않았다.', '',
    '## 전달 파일과 검증', '',
    '- `ROUND11_RESULT.md`, `STATUS.md`, 재현 스크립트5개와 측정·검산 폴더.',
    '- `hedges_17_current_review.csv` 17행. 현재값·절충값·FULL·비중·W·근거·판정.',
    '- `submission_events_hedged15.csv`만 후보로 전달한다. 157194행, 공식 example_id 순서·유일성·유한·비음수 확인. 주후보와 정확히15행만 다르고, 현재17행과는 PLAVE22 두 행만 다르다.',
    '- 후보 SHA-256 `'+verify['candidate_sha256']+'`. 별도 새 폴더 재실행 결과와 바이트 해시가 일치했다.',
    '- `measurements/station_final_71.csv` 71역의 두 적합값. `measurements/nested_station_row_differences.csv.gz`는 후보 예측값 없이 차이만 담은 진단이다.', '',
    '실행 환경은 Python '+env['python'].split()[0]+', NumPy '+env['numpy']+', pandas '+env['pandas']+'다. 계산은 단일 프로세스에서 라이브러리별1스레드로 제한했고, 로드된 OpenMP도1스레드임을 확인했다. `checks/threadpools.json`과 `checks/environment.json` 참조.', '',
    '02:27 KST 통합 재현 검산까지 완료했다. 새 폴더 `reproduction_verified/`에서 실행한 핵심 측정표·채택표·71역 비교표·17행 검토표·15행 후보는 원 실행과 바이트가 일치한다. 9개 기준일 반사실 검사도 다시 차이0이었다. `final_verification.json`이 최종 검산 결과다.', '',
    '## 못 한 것과 남은 한계', '',
    '- 새 독립 홀드아웃 확보와 원시 모델 전체 재학습은 하지 않았다. 원시 예측의 전 생애 이력과 그 밖의 선택 편향까지 해소한 검증은 아니다.',
    '- 기존 층·계수·비교군 자체의 개발 과정에서 생긴 사후 선택, 행사 선택의 사후성, 겹치는 origin은 남는다. 이번 F1 수정은 세 채택 판단의 시간 경계를 고쳤다.',
    '- PLAVE 예매 수량 원출처와 규칙3절 이용 허락 증빙은 해결하지 못했다. 새 웹 조회 금지 조건을 지켰다. 감사7절의 전체 재학습·클라우드 실기와 공급자 내부 데이터 이력도 이번 범위 밖이다.',
    '- 시험기간 정답이 없으므로 15행 후보의 실제 성능은 평가하지 못했다. 검증하지 않은 수치를 성능 개선이라고 쓰지 않았다.', '',
    '## 재현 명령', '',
    '프로젝트 루트에서 기존 산출물을 보존하는 새 하위 폴더명을 사용한다. 모델을 학습하거나 네트워크를 쓰지 않는다. 중첩 OOF·반사실 검사·17행 검토·15행 후보의 통합 재실행은 `reproduce_all.sh`다. 보충 진단과 문서 생성은 보관된 측정 파일에서 아래 명령으로 재실행한다.', '',
    '```bash\nbash night11/reproduce_all.sh night11/recheck_01\nfinal_package/.build/venv/bin/python -B night11/supplement_checks.py --output night11/recheck_supplement\nfinal_package/.build/venv/bin/python -B night11/build_report.py --output night11/ROUND11_RESULT_reproduced.md\n```', '',
    '주요 원 실행은 다음과 같다. 기본 출력이 이미 있으므로 그대로 재실행하면 덮어쓰기 대신 중단한다.', '',
    '```bash\nfinal_package/.build/venv/bin/python -B night11/reproduce_nested.py --output night11/recheck_02/measurements\nfinal_package/.build/venv/bin/python -B night11/verify_temporal.py --measurements night11/recheck_02/measurements --output night11/recheck_02/temporal\nfinal_package/.build/venv/bin/python -B night11/review_events.py --measurements night11/recheck_02/measurements --output night11/recheck_02/events --review night11/recheck_02/review.csv --candidate night11/recheck_02/submission_events_hedged15.csv\n```', '',
    '초기 nested 실행에는 import 경로 오류, 초기 행사 실행에는 모든 파일 저장 뒤 마지막 상태 출력의 json import 누락이 있었다. 코드 수정 뒤 새 폴더에서 정상 종료를 확인했다. 초기 로그는 숨기거나 덮어쓰지 않고 보존했다. 최종 재현 실행과 검산에는 예외가 없다.', '']
    args.output.write_text('\n'.join(rows))
    # Intermediate items were available before the requested 03:30 checkpoint.
    status('03:30 중간 보고 요청 항목은 조기 완료했다. 실제 측정 완료 02:18 KST. A/B/C 기존→중첩 RMSLE: '+
           '; '.join(f'{r.label} {r.old:.9f}→{r.nested:.9f}' for r in scores.loc[scores.label.isin(['A','B','C'])].itertuples())+
           '. station025는 두 경로 모두7개 개선·1개 악화. 최대 최종 count 차이0.118272303명. 17행 검토·15행 후보·9개 origin 반사실 검사도 완료. 최종 결과 문서 작성 완료.')

if __name__=='__main__':main()
