"""Poison unavailable labels and rerun the actual nested layer chain at each cutoff."""
from reproduce_nested import *

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HOME_OUT/'temporal_verification')
    parser.add_argument('--measurements',type=Path,default=HOME_OUT/'measurements')
    args=parser.parse_args();out=args.output.resolve()
    assert out.is_relative_to(HOME_OUT)
    out.mkdir(exist_ok=False)
    train=final.read_csv(TEAM/'data/train.csv',parse_dates=['date'])
    history=train[KEY].assign(observed=np.log1p(train.boardings))
    raw=m.read_oof(CACHE/'sincon_clean_event_oof.csv.gz',history,'baseline')
    explicit=final.read_csv(RUN/'protected.csv',parse_dates=['date'])
    days=pd.MultiIndex.from_frame(explicit[m.DAY].drop_duplicates())
    holidays,known=m.protected_days(WORK);protected=(holidays,known.union(days))
    games,_=m.home_dates(WORK)
    alts=m.read_daily(CACHE/'sincon_clean_tabicl_oof.csv',['label','origin',*m.DAY])
    vector=m.vector_archive(WORK)
    extra=final.read_csv(ROOT/'night/cache/vector_all_extra_origins.csv.gz',parse_dates=['date'])
    vector.update({label:q.set_index(KEY).raw_delta for label,q in extra.groupby('label')})
    expected=final.read_csv(args.measurements/'model_oof_nested.csv.gz',parse_dates=['date','origin']).set_index(OK).baseline
    checks=[]
    for origin in sorted(raw.origin.unique()):
        origin=pd.Timestamp(origin)
        # Only target origins up to this cutoff are recomputed. This also removes future forecast vintages.
        rows=raw.loc[raw.origin.le(origin)].copy()
        rows.loc[rows.date.gt(origin),'y_log']+=1000.
        hist=history.copy();hist.loc[hist.date.gt(origin),'observed']+=1000.
        def station_pred(q,cutoff):
            d,_=m.station_adjustments(hist.loc[hist.date.le(cutoff)],q[KEY].assign(combined=q.baseline),cutoff,protected,games)
            return (q.baseline+d['joint']).clip(lower=0.)
        station,_=m.oof_layer(rows,station_pred)
        _,_,trials=m.tabicl_oof(station,alts,protected)
        nested,gates=build_oof(station,trials,hist,protected,vector,True)
        q=nested.loc[nested.origin.eq(origin)]
        diff=q.baseline.to_numpy()-expected.reindex(pd.MultiIndex.from_frame(q[OK])).to_numpy()
        assert abs(diff).max()<1e-12
        checks.append(dict(origin=str(origin.date()),rows=len(q),future_label_log_add=1000,
            max_abs_model_oof_difference=float(abs(diff).max()),changed_gt_1e_12=int((abs(diff)>1e-12).sum()),
            future_origins_removed=True,poisoned_columns=['official observed','OOF y_log'],
            scope='Frozen raw predictions; station profile, TabICL weight/adoption, retail fit/adoption, lunar, morning, vector adoption rerun'))
        print(checks[-1],flush=True)
    dump(out/'full_chain_future_poison.json',checks)
    status('중첩 모델층 전체 경로 반사실 검사 완료. 9개 기준일마다 이후 정답 log에 +1000, 미래 origin 제거 후 해당 기준일 예측 변화 0.')

if __name__=='__main__':main()
