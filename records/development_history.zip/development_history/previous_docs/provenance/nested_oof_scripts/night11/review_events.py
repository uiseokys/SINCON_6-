"""Review the current 17-row formula; never choose new numeric parameters."""
from reproduce_nested import (HOME_OUT,ROOT,TEAM,KEY,END,final,module,sha,csv,dump,status)
import argparse
import json
from zipfile import ZipFile
import numpy as np
import pandas as pd

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=__import__('pathlib').Path,default=HOME_OUT/'event_measurements')
    p.add_argument('--measurements',type=__import__('pathlib').Path,default=HOME_OUT/'measurements')
    p.add_argument('--candidate',type=__import__('pathlib').Path,default=HOME_OUT/'submission_events_hedged15.csv')
    p.add_argument('--review',type=__import__('pathlib').Path,default=HOME_OUT/'hedges_17_current_review.csv')
    a=p.parse_args();a.output.mkdir(exist_ok=False,parents=True)
    assert all(x.resolve().is_relative_to(HOME_OUT) for x in [a.output,a.candidate,a.review])
    if a.candidate.exists():raise FileExistsError(a.candidate)
    sources=[TEAM/'event_hedges.py',TEAM/'submission_night_v4_main.csv',TEAM/'submission_night_v4_events_hedged.csv',
             TEAM/'data/train.csv',TEAM/'data/test.csv',ROOT/'night5/historical_event_audit.csv',
             ROOT/'sincon_kbo_game_data.csv',ROOT/'sincon_local_repro.zip',
             ROOT/'night7/event_validation_v2/landers_same_series_diagnostic.csv']
    before={str(x):sha(x) for x in sources};dump(a.output/'inputs.json',before)
    events=module('night11_current_hedges',TEAM/'event_hedges.py')
    train=final.read_csv(TEAM/'data/train.csv',parse_dates=['date'])
    test=final.read_csv(TEAM/'data/test.csv',parse_dates=['date'])
    main=final.read_csv(TEAM/'submission_night_v4_main.csv')
    hedge=final.read_csv(TEAM/'submission_night_v4_events_hedged.csv')
    assert train.date.max()==END and len(train)==688176 and not train.duplicated(KEY).any()
    assert main.example_id.equals(test.example_id) and hedge.example_id.equals(test.example_id)
    diff=abs(main.boardings-hedge.boardings)>1e-9
    assert diff.sum()==17
    audit=final.read_csv(ROOT/'night5/historical_event_audit.csv',parse_dates=['date'])
    for row in audit.itertuples():
        actual=train.loc[train.station_id.eq(3127)&train.date.eq(row.date)].set_index('hour').boardings
        for h in [21,22,23]:assert actual[h]==getattr(row,'actual_'+str(h))
    park=audit.loc[audit.event.eq('park_hyo_shin')]
    csv(park,a.output/'park_three_dates.csv')
    rate_audit=final.read_csv(ROOT/'night7/cache/historical_concerts.csv')
    rates=rate_audit.loc[rate_audit.ratio_22.notna()].groupby('event').ratio_22.median().to_numpy()
    q25,q50=np.quantile(rates,[.25,.5]);rate=float(np.sqrt(q25*q50))
    # Exact current parameters from the current code, including the seven revised rows.
    rows=[];indices=[];plave22=[]
    for event,date,attendance,shares,w in events.EVENTS:
        day=pd.Timestamp(date);total=sum(shares.values())
        for hour,share in shares.items():
            index=np.flatnonzero(test.station_id.eq(events.STATION)&test.date.eq(day)&test.hour.eq(hour))
            assert len(index)==1;i=int(index[0]);indices.append(i)
            full=share if attendance is None else events.BASE[day.day_of_week][hour]+events.RATIO*attendance*share
            computed=float(np.expm1((1-w)*np.log1p(main.boardings[i])+w*np.log1p(full)))
            assert abs(computed-hedge.boardings[i])<1e-9
            if event=='PLAVE' and hour==22:
                expected=(21.5 if day.day_of_week==5 else 15.)+rate*attendance
                assert abs(main.boardings[i]-expected)<1e-9
                verdict='과함';support='22시 추가 상향을 지지하는 독립 검증 없음'
                evidence=f'주후보는 기존 네 계열 보정 {rate:.15g} × 예매 + 평소. FULL 초과분 계수는 0.255로 더 큼.'
                limits='박효신 3일의 22시 집중은 시간 모양의 참고이며 PLAVE의 0.255 및 W=0.7을 검증하지 않음. 예매 원출처·정의 미확인.'
                plave22.append(i)
            elif event=='PLAVE':
                verdict='근거 부족';support='박효신 3일의 모양과 부분적으로 부합'
                evidence=f'박효신 초과 승차 {hour}시 평균 비중 {park["share_"+str(hour)].mean():.12g}. 현재 비중 {share:g}.'
                limits='같은 가수·같은 종료 시각의 독립 과거 수령 검증 없음. 0.30, W=0.7, 해당 비중의 조합 미검증. 예매 원출처 미확인.'
            elif attendance is not None:
                verdict='근거 부족';support='동종 과거 행사로 관객·퇴장 비중을 확인하지 못함'
                evidence='1.2만 관객은 이틀 4만 전망을 일별 분할한 뒤 60%로 둔 가정. 10/20/45/25% 시간 비중도 가정.'
                limits='공연 일정·장소는 관객 수와 퇴장 시간을 보증하지 않음. W=0.5의 독립 검증 없음.'
            elif hour==20:
                verdict='근거 부족';support='같은 시리즈의 과거 총량 근거는 있음. 20시 집중의 직접 근거는 부족'
                evidence='전년 20시 실제 391명. -20분 이동을 가정한 기존 진단 FULL 약 2199명을 현재 코드가 사용.'
                limits='종료 시차가 귀가 시차와 같은지 미확인. 20시 증가폭은 21시 피크의 시간 보간에 크게 의존. W=0.5 미검증.'
            else:
                verdict='지지';support='추가 귀가 승차의 방향과 규모에 같은 시리즈 과거 관측 근거가 있음'
                evidence=f'전년 {hour}시 실제 '+str({21:5279,22:1140}[hour])+'명. 기존 같은 시리즈 관객 비례·시간 이동 진단을 반올림한 FULL.'
                limits='지지는 상향 방향·규모에 한정. 한 회차·약 22000 관객·-20분 가정, W=0.5를 독립 검증한 판정은 아님.'
            rows.append(dict(example_id=test.example_id[i],event=event,date=date,station_id=events.STATION,hour=hour,
                current_main=float(main.boardings[i]),current_hedged=float(hedge.boardings[i]),FULL=float(full),
                share=float(share) if attendance is not None else float(share/total),
                share_definition='초과 승차 배분' if attendance is not None else 'FULL 합계 중 비중, 코드 입력은 시간별 count',
                W=w,attendance=attendance,ratio=events.RATIO if attendance is not None else None,
                ordinary=events.BASE[day.day_of_week][hour] if attendance is not None else None,
                arithmetic_abs_error=abs(computed-hedge.boardings[i]),past_support=support,judgment=verdict,
                evidence=evidence,limitation=limits,
                main_to_hedged_count_delta=float(hedge.boardings[i]-main.boardings[i])))
    assert set(indices)==set(np.flatnonzero(diff)) and len(plave22)==2
    table=pd.DataFrame(rows)
    csv(table,a.output/'hedges_17_current_review.csv')
    # Deliver the review at the requested top-level path as well.
    if a.review.exists():raise FileExistsError(a.review)
    csv(table,a.review)
    # 15-row alternative changes no coefficient; simply restores the accepted PLAVE 22h rows.
    alt=hedge.copy();alt.loc[plave22,'boardings']=main.loc[plave22,'boardings']
    changed=abs(alt.boardings-main.boardings)>1e-9
    assert changed.sum()==15 and np.isfinite(alt.boardings).all() and alt.boardings.ge(0).all()
    assert (alt.loc[plave22,'boardings']==main.loc[plave22,'boardings']).all()
    csv(alt,a.candidate)
    actual=final.read_csv(a.candidate)
    assert len(actual)==157194 and actual.example_id.is_unique and actual.example_id.equals(test.example_id)
    assert np.array_equal(actual.boardings,alt.boardings)
    dump(a.output/'candidate15_verification.json',dict(rows=len(actual),id_order_equal=True,unique=True,
        finite=bool(np.isfinite(actual.boardings).all()),nonnegative=bool(actual.boardings.ge(0).all()),
        changed_from_main=int(changed.sum()),restored_ids=test.loc[plave22,'example_id'].tolist(),
        sha256=sha(a.candidate),main_sha256=sha(TEAM/'submission_night_v4_main.csv'),
        hedged17_sha256=sha(TEAM/'submission_night_v4_events_hedged.csv')))
    # Training-period KBO ratios, whole day and comparable departure hours.
    games=final.read_csv(ROOT/'sincon_kbo_game_data.csv',parse_dates=['date'])
    games=games.loc[games.date.le(END)]
    with ZipFile(ROOT/'sincon_local_repro.zip') as z:
        special=pd.read_csv(z.open('external_inputs/external/events_daily.csv'),parse_dates=['date'])
    blocked=set(games.date)|set(special.loc[special.station_id.eq(3127)&special.date.le(END),'date'])|set(audit.date)
    ordinary=train.loc[train.station_id.eq(3127)&~train.date.isin(blocked)]
    ratios=[]
    for game in games.loc[games.date.ge('2026-03-28')&games.attendance.gt(0)].itertuples():
        controls=ordinary.loc[ordinary.date.between(game.date-pd.Timedelta(days=120),game.date-pd.Timedelta(days=1))&
                              ordinary.date.dt.day_of_week.eq(game.date.day_of_week)]
        normal=controls.groupby('hour').boardings.median()
        observed=train.loc[train.station_id.eq(3127)&train.date.eq(game.date)].set_index('hour').boardings
        assert len(normal)==18 and len(observed)==18
        row=dict(date=str(game.date.date()),attendance=game.attendance,soldout=game.attendance==23000,
                 controls=controls.date.nunique())
        for span,hours in [('day',list(range(6,24))),('20_22',[20,21,22]),('17_23',list(range(17,24)))]:
            row.update({f'actual_{span}':float(observed.loc[hours].sum()),f'ordinary_{span}':float(normal.loc[hours].sum()),
                        f'excess_ratio_{span}':float((observed.loc[hours].sum()-normal.loc[hours].sum())/game.attendance)})
        ratios.append(row)
    ratios=pd.DataFrame(ratios);assert len(ratios)==36
    csv(ratios,a.output/'kbo_36_ratios.csv')
    comparisons=[]
    for group,q in [('all36',ratios),('soldout11',ratios.loc[ratios.soldout])]:
        for span in ['day','20_22','17_23']:
            quant=q['excess_ratio_'+span].quantile([.25,.5,.75])
            for level,ratio in quant.items():
                comparisons.append(dict(group=group,games=len(q),span=span,quantile=level,excess_ratio=ratio,
                    excess_scaled_to_23000=ratio*23000,
                    total_with_target_ordinary_20_22=ratio*23000+234 if span=='20_22' else None))
    csv(pd.DataFrame(comparisons),a.output/'kbo_scale_comparison.csv')
    # Exact held-out predictions for the previous same-series date, every available origin.
    old=final.read_csv(a.measurements/'downstream_oof_old.csv.gz',parse_dates=['date','origin'])
    nested=final.read_csv(a.measurements/'downstream_oof_nested.csv.gz',parse_dates=['date','origin'])
    landers=[]
    for path,d in [('old',old),('nested',nested)]:
        subset=d.loc[d.station_id.eq(3127)&d.date.eq('2025-10-24')&d.hour.isin([20,21,22])]
        for x in subset.itertuples():
            y=float(np.expm1(x.y_log));base=float(np.expm1(x.baseline));pipe=float(np.expm1(x.friday))
            landers.append(dict(path=path,origin=str(x.origin.date()),label=x.label,date='2025-10-24',hour=x.hour,
                actual=y,model_oof=base,after_station_friday=pipe,predicted_minus_actual=pipe-y,
                predicted_over_actual=pipe/y,underprediction_fraction=1-pipe/y))
    csv(pd.DataFrame(landers),a.output/'landers_2025_oof_by_origin.csv')
    final_m=test.loc[test.station_id.eq(3127)&test.date.eq('2026-10-17')&test.hour.isin([20,21,22])].copy()
    final_m['main']=main.loc[final_m.index,'boardings'];final_m['hedged17']=hedge.loc[final_m.index,'boardings']
    csv(final_m,a.output/'landers_2026_predictions.csv')
    summary=dict(judgments=table.judgment.value_counts().to_dict(),arithmetic_max_abs_error=float(table.arithmetic_abs_error.max()),
        accepted_plave22_rate=rate,plave22_main=main.loc[plave22,'boardings'].tolist(),
        plave22_hedged=hedge.loc[plave22,'boardings'].tolist(),park_mean_shares=park[['share_21','share_22','share_23']].mean().to_dict(),
        kbo_games=len(ratios),soldout_games=int(ratios.soldout.sum()),
        landers_main20_22=float(final_m.main.sum()),landers_hedged20_22=float(final_m.hedged17.sum()),
        landers_current_FULL20_22=float(table.loc[table.event.eq('랜더스페셜 매치'),'FULL'].sum()),
        landers_last_year_actual20_22=float(train.loc[train.station_id.eq(3127)&train.date.eq('2025-10-24')&train.hour.isin([20,21,22]),'boardings'].sum()),
        candidate15='PLAVE22의 중복 상향 제거로 17행보다 방어 가능. 남은 15행의 독립 검증 완료를 뜻하지 않음.')
    dump(a.output/'summary.json',summary)
    after={x:sha(x) for x in before};assert before==after
    dump(a.output/'source_integrity_end.json',dict(all_unchanged=True,sha256=after))
    status('현재 17행 산술 재현·검토 완료. '+json.dumps(summary,ensure_ascii=False))
    print(table[['example_id','event','hour','current_main','current_hedged','FULL','share','W','judgment']].to_string(index=False))

if __name__=='__main__':main()
