#!/usr/bin/env python
"""SINCON 2026 핫식스: 제공 데이터에서 최종 예측 2개까지 차례로 다시 만든다.

사용:  python run_all.py --out <쓰기 가능한 폴더> [--kernel python3] [--mode assemble|full] [--device cpu|auto]

차례 (자세한 설명은 ../README.md):
  1  final_package/SINCON_final.ipynb                 -> submission_clean_refined.csv
  2  final_delivery_v2/SINCON_final_step2_layers.ipynb -> submission_night_v4_main.csv
  2b monday_delivery/SINCON_monday.ipynb              -> submission_monday_main.csv        (3번의 보관 입력과 대조)
  2c cup_walk_overlay/model/build_v4_cup_walk.py      -> submission_night_v4_main_cup_walk.csv (3번의 보관 입력과 대조)
  3  final_stack_delivery/SINCON_final_stack.ipynb    -> submission_xgb7_w10_on_curvature.csv
  4  rail_delivery_v5/SINCON_rail_factors_k30.ipynb   -> submission_rail_factors_k30_hour_on_xgb7.csv (최종 예측 1)
  4b rail_delivery_v4/SINCON_rail_factors_k12.ipynb   -> submission_rail_factors_k12_on_xgb7.csv      (최종 예측 2)

노트북은 실제 Jupyter 커널로 실행하고, 실행 결과가 들어간 사본을 <out>/executed_notebooks 에 남긴다.
1번과 2번은 패키지 안의 outputs/ 폴더에도 결과를 쓴다(패키지의 원래 동작).
"""
import argparse, glob, hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path

CODE = Path(__file__).resolve().parent
PRED = CODE.parent / "predictions"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()

def newest(patterns, since):
    hits = [p for pat in patterns for p in glob.glob(str(pat)) if os.path.getmtime(p) >= since - 1]
    assert hits, f"출력을 찾지 못했다: {patterns}"
    return Path(max(hits, key=os.path.getmtime))

def compare(a, b):
    import numpy as np, pandas as pd
    x, y = pd.read_csv(a), pd.read_csv(b)
    assert list(x.columns) == list(y.columns) and len(x) == len(y) and (x.iloc[:, 0] == y.iloc[:, 0]).all(), f"ID가 다르다: {a} / {b}"
    return float(np.abs(np.log1p(x.iloc[:, -1].to_numpy(float)) - np.log1p(y.iloc[:, -1].to_numpy(float))).max())

def execute(name, notebook, cwd, out, kernel, inject=None, env=None, timeout=86400):
    import nbformat
    from nbclient import NotebookClient
    nb = nbformat.read(notebook, as_version=4)
    if inject:
        first = next(c for c in nb.cells if c.cell_type == "code")
        first.source += "\n# --- run_all.py 가 지정한 값 ---\n" + "\n".join(f"{k} = {str(v)!r}" for k, v in inject.items()) + "\n"
    saved = dict(os.environ); os.environ.update({k: str(v) for k, v in (env or {}).items()})
    target = out / "executed_notebooks" / f"{name}__{Path(notebook).name}"; target.parent.mkdir(parents=True, exist_ok=True)
    started = time.time(); print(f"[{name}] {notebook} 실행 시작", flush=True)
    try:
        NotebookClient(nb, timeout=timeout, kernel_name=kernel, resources={"metadata": {"path": str(cwd)}}).execute()
    finally:
        nbformat.write(nb, target); os.environ.clear(); os.environ.update(saved)
    print(f"[{name}] 끝, {time.time() - started:.0f}초, 실행 결과 사본 {target}", flush=True)
    return started, round(time.time() - started, 1)

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, required=True); ap.add_argument("--kernel", default="python3")
    ap.add_argument("--mode", default="assemble", choices=["assemble", "full"], help="1번의 실행 모드. full 은 공식 train 부터 다시 학습한다.")
    ap.add_argument("--device", default="cpu"); ap.add_argument("--threads", default="4")
    a = ap.parse_args(); out = a.out.resolve(); out.mkdir(parents=True, exist_ok=True); (out / "logs").mkdir(exist_ok=True)
    assert CODE not in out.parents and out != CODE, "--out 은 code/ 폴더 밖에 둔다."
    S, T = {}, {}

    # 1. 1단계: 기본 모델 조립(또는 재학습)
    t, T["1"] = execute("1_final_package", CODE / "final_package/SINCON_final.ipynb", CODE / "final_package", out, a.kernel,
                        env={"SINCON_LOCAL_ROOT": CODE / "final_package", "SINCON_RUN_MODE": a.mode, "SINCON_DEVICE": a.device, "SINCON_THREADS": a.threads})
    S["clean_refined"] = newest([CODE / f"final_package/outputs/sincon_{a.mode}_*/submission_clean_refined.csv"], t)

    # 2단계·월요일 패키지에는 공식 CSV가 들어 있지 않다. 1단계 패키지에 든 같은 파일(대회 제공 원본)을 data/ 에 복사한다.
    import shutil
    for package in ("final_delivery_v2", "monday_delivery"):
        (CODE / package / "data").mkdir(exist_ok=True)
        for name in ("train.csv", "test.csv", "metaData.csv"):
            if not (CODE / package / "data" / name).is_file():
                shutil.copyfile(CODE / "final_package/payload/team/data" / name, CODE / package / "data" / name)

    # 2. 2단계: 검증한 보정 6개 -> 주후보
    t, T["2"] = execute("2_final_delivery_v2", CODE / "final_delivery_v2/SINCON_final_step2_layers.ipynb", CODE / "final_delivery_v2", out, a.kernel,
                        inject={"ROOT": CODE / "final_delivery_v2", "BASELINE_CSV": S["clean_refined"]})
    S["night_v4_main"] = newest([d / "sincon_step2_*/submission_night_v4_main.csv" for d in (CODE / "final_delivery_v2/outputs", Path("/content"), Path("/kaggle/working"))], t)

    # 2b. 월요일 대체공휴일 후보 (3번의 보관 입력을 다시 만든다)
    t, T["2b"] = execute("2b_monday_delivery", CODE / "monday_delivery/SINCON_monday.ipynb", CODE / "monday_delivery", out, a.kernel,
                         inject={"ROOT": CODE / "monday_delivery", "BASELINE_CSV": S["clean_refined"], "OUTPUT_DIR": out / "monday"})
    S["monday_main"] = newest([out / "monday/sincon_monday_*/submission_monday_main.csv"], t)

    # 2c. 코리아컵·걷기대회 11행 (3번의 보관 입력을 다시 만든다)
    cw = out / "cup_walk"; cw.mkdir(exist_ok=True); S["cup_walk"] = cw / "submission_night_v4_main_cup_walk.csv"; t0 = time.time()
    cmd = [sys.executable, "-B", "model/build_v4_cup_walk.py", "--official", CODE / "final_stack_delivery/data", "--base", S["night_v4_main"],
           "--reference", CODE / "final_stack_delivery/reference/submission_night_v4_main.csv", "--calendar", "inputs/calendar_features.csv",
           "--protected", "inputs/protected_event_keys.csv", "--output", S["cup_walk"]]
    done = subprocess.run([str(c) for c in cmd], cwd=CODE / "cup_walk_overlay", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out / "logs/2c_cup_walk.log").write_text("$ " + " ".join(str(c) for c in cmd) + "\n" + done.stdout, encoding="utf-8"); print(done.stdout[-1500:])
    assert done.returncode == 0, "2c 실패"; T["2c"] = round(time.time() - t0, 1)
    links = {"monday_main vs 3번 보관 입력": compare(S["monday_main"], CODE / "final_stack_delivery/inputs/submission_monday_main.csv"),
             "cup_walk vs 3번 보관 입력": compare(S["cup_walk"], CODE / "final_stack_delivery/inputs/submission_night_v4_main_cup_walk.csv")}
    print("보관 입력 대조(최대 log1p 차이):", links, flush=True)

    # 3. 보정 7개 단계
    t, T["3"] = execute("3_final_stack_delivery", CODE / "final_stack_delivery/SINCON_final_stack.ipynb", CODE / "final_stack_delivery", out, a.kernel,
                        env={"SINCON_STACK_ROOT": CODE / "final_stack_delivery", "SINCON_STACK_OUTPUT": out / "stack", "SINCON_STACK_BASELINE": S["night_v4_main"]})
    S["xgb7"] = out / "stack/submission_xgb7_w10_on_curvature.csv"

    # 4. 타 노선 층 -> 최종 예측 1
    t, T["4"] = execute("4_rail_delivery_v5", CODE / "rail_delivery_v5/SINCON_rail_factors_k30.ipynb", CODE / "rail_delivery_v5", out, a.kernel,
                        inject={"ROOT": CODE / "rail_delivery_v5", "BASELINE_CSV": S["xgb7"], "OUTPUT_DIR": out / "rail"})
    S["k30_hour"] = out / "rail/submission_rail_factors_k30_hour_on_xgb7.csv"

    # 4b. 타 노선 층(주성분 12개) -> 최종 예측 2
    t, T["4b"] = execute("4b_rail_delivery_v4", CODE / "rail_delivery_v4/SINCON_rail_factors_k12.ipynb", CODE / "rail_delivery_v4", out, a.kernel,
                         inject={"ROOT": CODE / "rail_delivery_v4", "BASELINE_CSV": S["xgb7"], "OUTPUT_DIR": out / "rail_k12"})
    S["k12"] = out / "rail_k12/submission_rail_factors_k12_on_xgb7.csv"

    import numpy, pandas
    finals = {}
    for key, name in (("k30_hour", "submission_rail_factors_k30_hour_on_xgb7.csv"), ("k12", "submission_rail_factors_k12_on_xgb7.csv")):
        ref = PRED / name
        finals[name] = {"output": str(S[key]), "sha256": sha256(S[key]), "submitted_sha256": sha256(ref), "byte_identical": sha256(S[key]) == sha256(ref), "max_abs_log1p_diff_vs_submitted": compare(S[key], ref)}
        print(name, "| 제출 파일과 최대 log1p 차이", finals[name]["max_abs_log1p_diff_vs_submitted"], "| 바이트 일치", finals[name]["byte_identical"], flush=True)
    summary = {"mode": a.mode, "device": a.device, "python": platform.python_version(), "platform": platform.platform(), "numpy": numpy.__version__, "pandas": pandas.__version__,
               "seconds": T, "outputs": {k: str(v) for k, v in S.items()}, "archived_input_checks_max_abs_log1p_diff": links, "final_predictions": finals}
    (out / "run_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert all(v["max_abs_log1p_diff_vs_submitted"] <= 1e-9 for v in finals.values()), "최종 예측이 제출 파일과 수치로 다르다(run_summary.json 참고)."
    print("끝. 요약:", out / "run_summary.json")

if __name__ == "__main__":
    main()
