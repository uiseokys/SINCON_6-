# 데이터 출처 작성표

실제 자료 파일은 각 단계 패키지 안에 그대로 있다(패키지의 해시 목록과 맞물려 있어 옮기지 않았다). 이 표는 무엇이 어디에 있고 어디서 왔는지를 적는다. 생성 경로는 `../provenance/PROVENANCE.md`.

## 1. 대회 제공 데이터 (변형 없음)

| 파일 | 위치 | 비고 |
|---|---|---|
| `train.csv`, `test.csv`, `metaData.csv` | `code/final_package/payload/team/data/` | 제공 원본. 해시는 `code/final_delivery_v2/official_inputs.json` |
| `train.csv`, `test.csv` (같은 파일의 사본) | `code/final_stack_delivery/data/`, `code/rail_delivery_v5/data/`, `code/final_stack_delivery/training_scripts/team_features/data/` | 각 패키지가 단독으로 실행되도록 넣은 사본 |

`sample_submission.csv` 는 쓰지 않았다.

## 2. 외부 데이터

1~3단계가 쓰는 외부 자료의 정본 표는 `code/final_package/EXTERNAL_DATA.md` (이름·보관 위치·출처 링크·조회일·이용 조건·7월 이후 정보 포함 여부)와 `code/final_package/docs/SINCON_EXTERNAL_SOURCES.md` (행사별 URL)다. 아래는 그 요약이다.

| 자료 | 출처 | 조회일 | 이용 조건 | 예측 기간(7~10월) 값 | 쓰는 단계 |
|---|---|---|---|---|---|
| 공휴일·선거일·연휴 | 공휴일에 관한 법률, 천문연 월력요항 | 2026-11-11 | 공개 날짜 | 예정 날짜 | 1~4 |
| NEIS 학사일정 | data.go.kr 15137088, open.neis.go.kr | 2026-11-11 | 제한 없음 | 포함 | 1 |
| 대학 방학 | 인천대 공문, 고등교육법 시행령 | 2026-11-11 | 날짜 사실. 첨부문서 조건 미확인 | 포함 | 1 |
| Open-Meteo 시간별 날씨 | open-meteo.com | 2026-11-11 | CC BY 4.0 | **실제 날씨** | 1 |
| 서울시·KT 생활이동 OA-22655 (비지하철 수단) | data.seoul.go.kr | 최초 기록 없음, 재확인 2026-11-12 | 공공누리 1유형 | **실제 이동량** | 1 |
| 인천 버스 정류장별 월간 승하차·좌표 | data.go.kr 15048264, 15067528 | 최초 기록 없음, 재확인 2026-11-12 | 제한 없음 | **실제 버스 이용량** | 1 |
| 인천교통공사 역 주소·출입구 좌표 | data.go.kr 15043811, 15166820 | 최초 기록 없음, 재확인 2026-11-12 | 제한 없음 | 정적 정보 | 1 |
| K-apt 단지 승인·입주월·세대수·좌표 | k-apt.go.kr, data.go.kr 15073271 | 최초 기록 없음 | 일부 미확인 | 입주월 | 1 |
| 문체부 지역축제 계획·표준데이터 | mcst.go.kr, data.go.kr 15013104 | 최초 기록 없음 | 유형 미확인 | 일정 | 1 |
| KBO 문학 경기·결과·관중·종료 시각 | koreabaseball.com | 2026-11-11 | **허용 미확인**(약관이 자동 수집 제한). CC BY-NC-SA 위키와 대조 | **실제 경기 정보** | 1 |
| K리그 부천 경기·킥오프·관중 | kleague.com | 최초 기록 없음 | 미확인. 위키와 대조 | **실제 경기 정보** | 1 |
| 팀 수기 공연·행사, 취소·장소 공지 | 주최 측 페이지(행사별 URL은 부록) | 2026-11-11~12 | 일정 사실. 개별 조건 미확인 | 일정·취소 사실 | 1~3 |
| 동춘 대형마트 정기 휴무 | 연수구 운영표 | 2026-11-12 | 미확인 | 정기 규칙 | 1 |
| PLAVE 공연 예매 수량 | 팀원 제공(KOPIS라고 전달받음) | 기록 없음 | 미확인 | 2행에 사용 | 2 |
| 코리아컵·걷기대회 일정 | `code/cup_walk_overlay/graph_clean/bucheon_cup_facts.csv`, `bottleneck/incheon_walk.csv` 에 행별 출처·조건·조회일 | 파일에 기록 | 파일에 기록 | 일정 | 3 |
| TabICL 2.2.0, 체크포인트 `20260212` | PyPI, Hugging Face `jingang/TabICL` | 2026-11-12 확인 | BSD-3-Clause | 사전학습 모델 | 1 |
| **타 노선 일별 승차 OA-12914** | data.seoul.go.kr/dataList/OA-12914 | **2026-11-13** | 공공누리 1유형 (서울특별시·코레일·공항철도) | **실제 지하철 승차(타 노선)** | **4, 4b (최종 예측 1·2)** |

- 타 노선 자료의 범위·제외 목록·규칙 관련 사실은 `records/DISCLOSURE.md` 2절. 데이터셋 페이지 사본은 `code/rail_delivery_v5/provenance/OA-12914_dataset_page_20261113.html`.
- 이용 조건 점검 결과: `records/dev_logs/codex/night6/SOURCES_FINAL.md`, `records/dev_logs/codex/night_sources/SOURCES_AUDIT.md`.

## 3. 내려받았지만 최종 예측에 쓰지 않은 것

| 자료 | 상태 |
|---|---|
| OA-12252 지하철 호선별 역별 시간대별 승하차(월 합계), 경인선·수인선 25개 역 | 과거 검증 탈락. `provenance/rail_intermediate/rail_hourly_allowed.csv.gz` |
| 기상청 AWS 강수·기온, 일출·일몰, 국가교통DB 버스 정류장 자료(팀원 제공) | 검증에서 채택하지 않았거나 이용 조건 미확인으로 계산에 쓰지 않음 (`FINAL_REPORT.md` 7절) |
| 부산 등 다른 지역 도시철도 | 시험 기간 값이 공개돼 있지 않아 진행하지 않음 |

## 4. 파생 데이터·캐시

| 파일 | 위치 | 내용 | 만든 방법 |
|---|---|---|---|
| 기준일별 과거 예측(검증 예측) | `code/final_package/payload/` 의 ZIP들 | 1단계 모델의 기준일별 예측 | `docs/SINCON_REPRODUCE_CLEAN.md` 3~7번 |
| `downstream_oof_nested_main.csv.gz` | `code/final_stack_delivery/cache/` | 주후보의 순방향(중첩) 과거 예측과 실측 log | `provenance/nested_oof_scripts/` |
| `hourbias_history_oof.csv.gz` | `code/final_stack_delivery/cache/` | 위 파일에서 날짜만 잘라 낸 것 | 같은 스크립트 |
| `calendar_flags.csv`, `calendar_features.csv` | 각 패키지 `cache/` | 공휴일류 표시 | `make_calendar.py` |
| `events_frozen_v3.csv`, `protected_event_keys.csv`, `team_event_station_days.csv`, `festival_station_days.csv`, `historical_concerts.csv` | 각 패키지 `cache/` | 행사 역·날짜와 보호 행 | 행사 목록에서 정리(출처 열 포함) |
| `rail_all_allowed.csv.gz`, `ban_list.json` | `code/rail_delivery_v5/cache/` | 허용한 타 노선 561개 역의 일별 승차, 제외 이름 목록 | `code/rail_delivery_v5/provenance/fetch_all.py` |
| `rail_allowed.csv.gz` | `provenance/rail_intermediate/` | 경인선·수인선 허용 25개 역의 일별 승차(공휴일류 수준 층의 피처 원자료) | `code/rail_delivery_v5/provenance/fetch.py` |
| 모델별 시험 기간 예측 | `models/ARTIFACTS.md` 참고 | | |
